Use with:

Pichu Bros. Mini (Japan).min (No Intro)
a587b6f5aa51fc8506ae818127e5d1b3
