Use with:

Pokemon Sodateyasan Mini (Japan).min (No-Intro)
0eb5e7e191ce056f3ee2c6572bc61906
D55FC4C8
