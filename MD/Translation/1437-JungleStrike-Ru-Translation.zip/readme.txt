Use with:

Jungle Strike (USA, Europe).md (No Intro)
3164c16bab8088a7991857750edaecb6