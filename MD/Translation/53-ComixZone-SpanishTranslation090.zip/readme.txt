Use with:

Comix Zone (USA).md (No Intro)
7078e8018ded17f3ce4c70cc8bf74afc