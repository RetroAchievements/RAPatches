Use with:

Crusader of Centy (USA).md (No Intro)
4ead1c30202dbc10ad3e327f69770570