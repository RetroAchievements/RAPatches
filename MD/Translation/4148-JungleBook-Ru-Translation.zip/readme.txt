Use with:

Jungle Book, The (USA).md (No Intro)
2e1c1f784c9463152cd1a772f87677af