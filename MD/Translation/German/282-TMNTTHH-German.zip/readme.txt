Use with:

Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA).md (No Intro)
30ede62c8efe3e046e5409758b091eb6