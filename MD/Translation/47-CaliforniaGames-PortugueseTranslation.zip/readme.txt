Use with:

California Games (USA,Europe).md (No Intro)
6cb2871511f53a30996963f30839de75