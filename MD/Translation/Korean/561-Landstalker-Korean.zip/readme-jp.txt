Use with:

(No Intro)
Landstalker - Koutei no Zaihou (Japan).md
d9a7922681a126653dc16a0d907d7f32
60D4CEDB