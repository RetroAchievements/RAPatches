Use with:

Light Crusader (USA).md (No Intro)
2869e0d4ad512a1fbd9b79d6937d9446