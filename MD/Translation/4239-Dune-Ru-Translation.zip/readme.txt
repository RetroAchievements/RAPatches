Use with:

Dune - The Battle for Arrakis (USA).md (No Intro)
d4df66f77d52718798ec07d350d3a3cd