Use with:
Castle of Illusion Starring Mickey Mouse (USA, Europe).md (No Intro)
24863151abd5baf28c9386d49ffe3c09
BA4E9FD0