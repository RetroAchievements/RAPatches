Use with:

Tougiou King Colossus (Japan).md (No Intro)
7e6b1144fe4f929dff15fd6dca89fc37