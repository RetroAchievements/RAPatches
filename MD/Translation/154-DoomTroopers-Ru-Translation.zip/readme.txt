Use with:

Doom Troopers (USA).md (No Intro)
5641bc53143ece5de5d9dbd4e2083dc7