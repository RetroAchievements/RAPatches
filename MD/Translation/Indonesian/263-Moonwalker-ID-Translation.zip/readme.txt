Use with:

Michael Jackson's Moonwalker (World) (Rev A).md (No Intro)
73b63cac3f15bfe4a7bad170654878a9