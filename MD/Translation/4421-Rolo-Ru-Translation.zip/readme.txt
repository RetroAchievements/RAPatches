Use with:

Rolo to the Rescue (USA, Europe).md (No Intro)
46f0c65ea34800bd53c14712ad57eeff