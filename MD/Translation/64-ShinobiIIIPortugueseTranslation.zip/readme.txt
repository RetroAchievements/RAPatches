Use with:

Shinobi III - Return of the Ninja Master (USA).md (No Intro)
691eeff9c5741724a8751ec0fa9cfbf0