Use with:

Splatterhouse 3 (USA).md (No Intro)
8c2a9b15ba24b611c895efd49c175ebe