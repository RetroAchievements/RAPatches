The "Old" folder contains a patch for the older No Intro ROM,
which shares its hash with "Shining Force (U)[!].bin"

Use with:

(No Intro)
Shining Force (USA).md
5111aa25931e6789ce4972bc6bafaa04

(Older No Intro)
Shining Force (USA).md
4b4acbe75ff7aaeb534ab78ed95910d1