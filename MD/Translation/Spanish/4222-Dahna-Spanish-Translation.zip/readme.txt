Use with:

Dahna - Megami Tanjou (Japan).md (No Intro)
731b77ec3acab4aaf3b76cd3c8d82a41