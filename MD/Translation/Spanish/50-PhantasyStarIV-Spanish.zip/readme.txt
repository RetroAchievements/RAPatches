Use with:

(No Intro)
Phantasy Star IV (USA).md
MD5: 84cbd0ff47f3c8e9d21d2c2fc39185fa
CRC: FE236442