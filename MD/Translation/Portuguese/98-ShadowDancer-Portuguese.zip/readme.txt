Use with:

Shadow Dancer - The Secret of Shinobi (World).md (No Intro)
1f2a9f322e770be0a3cc2aabdf8bc575