Use either with:

Altered Beast (USA, Europe).md (No Intro)
2ed5293e46abe1e74edeb96da0e7a618