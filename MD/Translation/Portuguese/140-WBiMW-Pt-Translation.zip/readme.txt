Use with:

(No Intro)
Wonder Boy in Monster World (USA, Europe).md
945335637611a0951595fae0994f4303

(Older No Intro)
Wonder Boy in Monster World (USA, Europe).md
edba0bdb192d47712edbe0097f885f40