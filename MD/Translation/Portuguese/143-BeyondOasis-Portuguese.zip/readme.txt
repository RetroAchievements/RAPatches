Use with:

Beyond Oasis (USA).md (No Intro)
5a79de198ed6b1ece2518574fe78d962