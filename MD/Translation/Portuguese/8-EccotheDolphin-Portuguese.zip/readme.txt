Use with:

Ecco the Dolphin (USA, Europe, Korea).md (No Intro)
18b49fe6ad55975b6021b40b193035f5