Use with:

(No Intro)
Super Monaco GP (World) (En,Ja).md
ded2b235f625424f353c13c4d3a2cf89
B1823595

Super Monaco GP (World) (En,Ja) (Rev A).md
7c343c0b33f8af9f4719ead8cee7b201
BE91B28A