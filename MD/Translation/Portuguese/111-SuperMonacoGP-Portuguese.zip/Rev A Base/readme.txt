Use with:

(No Intro)
File:               Super Monaco GP (World) (En,Ja) (Rev A).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              BE91B28A
MD5:                7C343C0B33F8AF9F4719EAD8CEE7B201
SHA1:               1E49A449367F0EC7BA0331B7B0D074F796E48D58
SHA256:             64CB62CF32CB0E17ADACA5FFFA1E240B2F8D10CDDFBC3E42FF3F5D74A5C434E6