Use with:

Flintstones, The (USA) (Taito).md (No Intro)
60ea3535c8a939d26ded83bde0f4809d