Use with:

Phantasy Star II - Amia's Adventure (Japan) (SegaNet).md
76cb3b2ec8b827ec9288d28bc8d0cd3b

Phantasy Star II - Anne's Adventure (Japan) (SegaNet).md
10195dfcde401acafd406f2640e384de

Phantasy Star II - Huey's Adventure (Japan) (SegaNet).md
4efb0bc21c9df35ff39eb1862f972c47

Phantasy Star II - Kinds's Adventure (Japan) (SegaNet).md
dbe39f02548beaae0aa652dc4874c09e

Phantasy Star II - Nei's Adventure (Japan) (SegaNet).md
d60bc80b482dfc1b31cb6c383f3fd88c

Phantasy Star II - Rudger's Adventure (Japan) (SegaNet).md
8ce3458a47e1dcb75982403e8b3cbf3f

Phantasy Star II - Shilka's Adventure (Japan) (SegaNet).md
5abe74899da838cc9dc7cabfb4d8f816

Phantasy Star II - Yushis's Adventure (Japan) (SegaNet).md
83f22a27147bdfd85d405daf111fde92