Use with:

Road Rash II (USA, Europe).md (No Intro)
c04a309f607aaf59f55eb8dad6affa73