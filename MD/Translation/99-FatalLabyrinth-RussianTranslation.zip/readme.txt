Use with:

Fatal Labyrinth (USA, Europe).md (No Intro)
f4550e6ca0b6c8a9de2376f85bdc6a8a