Use with:

Battle Golfer Yui (Japan).md (No Intro)
8cfd0e5a169193cf9c66e6d237a45d77