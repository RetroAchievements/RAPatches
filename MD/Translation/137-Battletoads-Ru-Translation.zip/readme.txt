Use with:

Battletoads (World).md (No Intro)
f1e299d6eb40e3ecec6460d96e1e4dc9