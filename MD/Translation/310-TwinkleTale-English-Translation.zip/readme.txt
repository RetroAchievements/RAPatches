Use with:

Twinkle Tale (Japan).md (No Intro)
809887a9535753ee7a13c8a2d365f0eb