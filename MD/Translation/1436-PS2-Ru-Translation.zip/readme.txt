Use with:

Phantasy Star II (USA, Europe) (Rev A).md (No Intro)
0fa38b12cf0ab0163d865600ac731a9a