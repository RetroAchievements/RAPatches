Use with:

Super Street Fighter II (USA).md (No Intro)
75950e3aa9357a21715ffe2fa51a454c