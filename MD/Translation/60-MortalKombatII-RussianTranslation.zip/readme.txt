Use with:

Mortal Kombat II (World).md (No Intro)
c8e887ca9cdde7bde85f324f66d34b2d