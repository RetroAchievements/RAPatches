Use with:

Lost Vikings, The (USA) (November, 1993).md (No Intro)
a8dcb5476855a83702e2f49ebd4e2d57