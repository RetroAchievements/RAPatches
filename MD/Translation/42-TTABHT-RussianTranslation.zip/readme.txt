Use with:

Tiny Toon Adventures - Buster's Hidden Treasure (USA).md (No Intro)
4831cb1b067887a086467ec51653af48