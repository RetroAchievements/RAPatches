Use with:

(No Intro)
File:               Undead Line (Japan).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              FB3CA1E6
MD5:                F7E2E19770FF41441F79D014BC963122