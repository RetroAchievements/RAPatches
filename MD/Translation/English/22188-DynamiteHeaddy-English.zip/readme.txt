Use with:

(No Intro)
File:               Dynamite Headdy (Japan).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D03CDB53
MD5:                CDB36911439289D3453060F58682057C