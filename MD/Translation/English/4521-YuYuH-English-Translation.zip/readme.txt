Use with:

Yu Yu Hakusho - Makyou Toitsusen (Japan).md (No Intro)
8130283788f82677ec583b7f627dbf0c