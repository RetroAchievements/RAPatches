Use with:

(No Intro)
File:               Phantasy Star II - Amia's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              A3A724AA
MD5:                76CB3B2EC8B827EC9288D28BC8D0CD3B
SHA1:               08C6BEAB6F02AD533FB814A8A877849DA67FC1A4
SHA256:             747E3662E3BACC03755EA1DEFDE2734066B4A9DB5E13F9645F0CE5B4255AFDDD

File:               Phantasy Star II - Anne's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              FAFA5B6F
MD5:                10195DFCDE401ACAFD406F2640E384DE
SHA1:               CF93D2D5EAFC72B9DE7AAA6D35B81A813862D9B7
SHA256:             6DF2F38DFD0C3CF59060B34A8B9537DF6167C33596166568D653CAA483485101

File:               Phantasy Star II - Huey's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              1A076F83
MD5:                4EFB0BC21C9DF35FF39EB1862F972C47
SHA1:               ABC5A7AC58AEFC055ED8CA5FD0F7C802AB3E1AD5
SHA256:             98C47D54F7DDF6C70A997303D16EE0D340CC3DE1E83A8604D082AD1CBDE03997

File:               Phantasy Star II - Kinds's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              C334F308
MD5:                DBE39F02548BEAAE0AA652DC4874C09E
SHA1:               F2BD41741ADD13E8551250CF6AFEB746E8CEA316
SHA256:             256EA23BE5581D01C24B1856E9C2ED011FA304AC1F42B83F706B0FA2B9FE8C0F

File:               Phantasy Star II - Nei's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              3D9AD465
MD5:                D60BC80B482DFC1B31CB6C383F3FD88C
SHA1:               BC1B2955D1EAD44D744DACDC072481DFF42E4D81
SHA256:             18A64FEFFF83B77E8EAFC13715D0CBCB5FEC80250590158A74FB71100A46AFDA

File:               Phantasy Star II - Rudger's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              6B5916D2
MD5:                8CE3458A47E1DCB75982403E8B3CBF3F
SHA1:               DDA0783CD5C6340C8DDE665BE22366108FADF50B
SHA256:             0A8D3F4BC05240CBB0A96ED597CF413F3B58BFE5B293E2AF72BF8498AB06EFD7

File:               Phantasy Star II - Shilka's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              1F83BEB2
MD5:                5ABE74899DA838CC9DC7CABFB4D8F816
SHA1:               114F37A287B51664E52BA483F07911A660F9E7DF
SHA256:             52D797560F1588BD3B96E58E958AEC8DD7BD1802EB0A97DB784C062698B0F3CC

File:               Phantasy Star II - Yushis's Adventure (Japan) (Sega Game Toshokan).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              D40C76D6
MD5:                83F22A27147BDFD85D405DAF111FDE92
SHA1:               85679E11000387B6EF002C53BB03593F1C3F1C11
SHA256:             DC515FF777FA750CCD23BE7AFF79076172FB3D6110CE8B5CCD5F2268540812A2

