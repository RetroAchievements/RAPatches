Use with:

Bishoujo Senshi Sailor Moon (Japan).md (No Intro)
b5365025a46a2781c63e254345268bf1