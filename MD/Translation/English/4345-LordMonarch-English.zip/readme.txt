Use with:

(No Intro)
File:               Lord Monarch - Tokoton Sentou Densetsu (Japan).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              238BF5DB
MD5:                5E06D2DE451ECC57A9A91577BB0DC59C