Use with:

Advanced Busterhawk Gleylancer (Japan).md (No Intro)
8bd4a97783cda077c342173df0a9b51e