Use with:

(No Intro)
File:               Hexagonos (Brazil) (Mega Drive 4).md
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              2F6F3168
MD5:                26B5B360C94D2976441EB419D64BD18C
SHA1:               21698EDB85433DD8851949A511273535BA9F7525
SHA256:             AA0D157E5C45633B3F7D191A0C45EE45439C82A0638CDB79E0D3835BCD9AB259