Use with:

(No Intro)
File:               Langrisser II (Japan) (Rev B).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              4967C9F9
MD5:                A5DE915F62156FEB8680F9CF34017DBD