Use with:

Panorama Cotton (Japan).md (No Intro)
422a285546a9755df77da2840fb2c817