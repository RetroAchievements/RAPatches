Use with:

(No Intro)
File:               Rent a Hero (Japan).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              2E515F82
MD5:                BAA47B5E85264AC958072ED0F0037525