Use with:

(No Intro)
File:               Magical Taruruuto-kun (Japan).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              F11060A5
MD5:                F676DFDD836199352F105465905C25DE
SHA1:               208F1D83BB410F9CC5E5308942B83C0E84F64294
SHA256:             DFEFF1B64E372B91FD795C73CD5574F23401D5AA34395DF2CE034E225011CD2F