Use with:

(No Intro)
File:               Fushigi no Umi no Nadia (Japan).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              4762062A
MD5:                72A68C9A735CE36A83A74E5B3C33554C
SHA1:               BBCD26D5D1F1422051467AACAA835E1F38383F64
SHA256:             8281500EFDB93CE6168E37921F774327BDA0EA55E8682A5F7C123D72D59E6F9A