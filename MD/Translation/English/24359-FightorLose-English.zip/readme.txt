Use with:

(No Intro)
File:               Cavalos & Peoes (Brazil) (Mega Drive 4).md
BitSize:            617 Kbit
Size (Bytes):       79010
CRC32:              96CA83FA
MD5:                538467A3AE4C905D9FCD3C53C763DABB
SHA1:               79D84F6AEF26F9661E3B90F83042B257C6FEA050
SHA256:             1890B94015AC736300BDC69F454F27A67CC5308D3E26E71E291548F5761F65CC