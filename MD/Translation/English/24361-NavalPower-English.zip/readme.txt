Use with:

(No Intro)
File:               Batalha Naval (Brazil) (Mega Drive 4).md
BitSize:            646 Kbit
Size (Bytes):       82792
CRC32:              C6AD942D
MD5:                822E029A4E0D93A32BF1D3BA06F3C6E2
SHA1:               59582C98F9ECD87FDC42742294E134580B8698C8
SHA256:             5FBF17385DD67FCB6070EA0662654D13F672366B46F4D278359CF7C6897F0E70