Use with:

Battle Mania Daiginjou (Japan, Korea).md (No Intro)
1ffe5b490cddeb691e3add6947024f83