Use with:

Batman - The Video Game (USA).md (No Intro)
5ae78355da64cf17755175e9cfe48405