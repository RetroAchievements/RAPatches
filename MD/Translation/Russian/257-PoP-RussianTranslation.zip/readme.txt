Use with:

Prince of Persia (USA).md (No Intro)
a942e336b5d2e9f962b289fc08b890c6