Use with:

Phantasy Star IV (USA).md (No Intro)
84cbd0ff47f3c8e9d21d2c2fc39185fa