Use with:

Sunset Riders (USA).md (No Intro)
19cdf861c543f9c9cd9c8b6b70adeb1c