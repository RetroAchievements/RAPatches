Use with:

File:               Shining Force (USA).md (No-Intro)
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              E82ACDFC
MD5:                5111AA25931E6789CE4972BC6BAFAA04