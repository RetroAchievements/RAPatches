Use with:

For (Ru) (NewGame):
Teenage Mutant Hero Turtles - The Hyperstone Heist (Europe).md (No Intro)
d55083fb5a014db1c8692e1545309fc7

For (Ru):
Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA).md (No Intro)
30ede62c8efe3e046e5409758b091eb6