Use with:

(No Intro)
Super Hang-On (Europe) (En,Ja) (Rev A).md
MD5: 9b5d500a7ce1de56fba9c554bbf9a0b2
CRC: 3877D107