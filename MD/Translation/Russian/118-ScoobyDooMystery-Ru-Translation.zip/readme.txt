Use with:

(No Intro)
Scooby-Doo Mystery (USA).md
F27EA503631E67C05860926099D97F7A