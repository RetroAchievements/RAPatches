Use with:

Sonic the Hedgehog 3 (USA).md (No Intro)
d724ea4dd417fe330c9dcfd955c596b2