Use with:

Streets of Rage 2 (USA).md (No Intro)
cb75d5a6919b61efe917bea5762c1cb7