Use with:

Desert Strike - Return to the Gulf (USA, Europe).md (No Intro)
6f37f036c8de2bf78d11079cd2424370