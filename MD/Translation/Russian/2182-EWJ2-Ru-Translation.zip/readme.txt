Use with:

Earthworm Jim 2 (USA).md (No Intro)
2ed39b147fa5fa67d6d0707f54a5a078