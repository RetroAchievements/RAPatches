Use with:

Story of Thor, The (Europe).md (No Intro)
475519d9cbdeb91db301780bff83d81e