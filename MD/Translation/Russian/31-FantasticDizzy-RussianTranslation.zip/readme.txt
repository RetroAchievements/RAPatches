Use with:

Fantastic Dizzy (USA, Europe) (En,Fr,De,Es,It).md (No Intro)
2b3655b2935c727ee6400721fb5b4451