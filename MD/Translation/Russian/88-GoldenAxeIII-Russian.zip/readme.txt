Use with:

Golden Axe III (Japan) (En).md (No Intro)
7d9f963c9c2e22b542516edd03ada6f6