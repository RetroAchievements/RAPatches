Use with:

(No Intro)
File:               Bomber (Brazil) (En) (Unl).md
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              6389A658
MD5:                FD36DC99F8915416005880427FDAE2D9