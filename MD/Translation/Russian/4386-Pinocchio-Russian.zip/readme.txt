Use with:

Pinocchio (USA).md (No Intro)
bace0d15220dcfc8b8a3efb6668e45ba