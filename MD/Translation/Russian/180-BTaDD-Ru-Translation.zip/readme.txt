Use with:

Battletoads-Double Dragon (USA).md (No Intro)
78f3ea32bcb4f627e4f9bc9711e017b8