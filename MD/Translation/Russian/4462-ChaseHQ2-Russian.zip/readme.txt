Use with:

(No Intro)
Chase H.Q. II (USA).md
93cacc2d10b6176afa16e4d08ab6ee1c
F39E4BF2