Use with:

Flashback - The Quest for Identity (USA) (En,Fr).md (No Intro)
385e4e66174a76fd4a05639f24b54562