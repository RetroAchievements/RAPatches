Use with:

Streets of Rage (World)(Rev A).md (No Intro)
59a3b22a1899461dceba50d1ade88d3a