Use with:

RoboCop versus The Terminator (USA).md (No Intro)
cfc3568cc985f7b73dd5afa69c9f28a4