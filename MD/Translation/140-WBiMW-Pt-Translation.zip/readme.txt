Use with:

Wonder Boy in Monster World (USA, Europe).md (No Intro)
edba0bdb192d47712edbe0097f885f40