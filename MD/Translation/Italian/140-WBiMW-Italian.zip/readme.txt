Use with:

(No Intro)
File:               Wonder Boy in Monster World (USA, Europe).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              0D901482
MD5:                945335637611A0951595FAE0994F4303
SHA1:               772C3C71973762EAC46E6C180A036C1F3BBD937A
SHA256:             8D905C863B73A1522F6EA734D630BEAE1B824B9EECB63F899534C02EFBDE20FD