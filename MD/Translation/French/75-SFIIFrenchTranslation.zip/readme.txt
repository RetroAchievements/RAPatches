Use with:

Shining Force II (USA).md (No Intro)
6473b1505334ef5620d13191c18251fe