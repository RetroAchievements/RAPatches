Use with:

Dr. Robotnik's Mean Bean Machine (USA).md (No Intro)
4d6bdac51d2f5969a91496142ea53232