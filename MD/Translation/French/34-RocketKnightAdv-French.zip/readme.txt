Use with:

Rocket Knight Adventures (USA).md (No Intro)
ce0fde21d2c418b24c3d904e57df466e