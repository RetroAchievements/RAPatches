Use with:

Thunder Force III (Japan, USA).md (No Intro)
64766dae889d039eb391bc5bf2973f5d