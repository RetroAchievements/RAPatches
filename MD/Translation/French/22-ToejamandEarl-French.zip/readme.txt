Use with:

ToeJam & Earl (USA, Europe, Korea).md (No Intro)
0a6af20d9c5b3ec4e23c683f083b92cd