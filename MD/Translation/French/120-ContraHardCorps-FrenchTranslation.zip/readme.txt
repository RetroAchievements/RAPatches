Use with:

Contra - Hard Corps (USA, Korea).md (No Intro)
2bd30479556da5c310d8f2a1fe66e8fa