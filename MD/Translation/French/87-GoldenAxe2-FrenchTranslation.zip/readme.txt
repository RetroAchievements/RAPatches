Use with:

(No Intro)
File:               Golden Axe II (World).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              725E0A18
MD5:                2CD3573172961FA52F622F14CCFF4E1A