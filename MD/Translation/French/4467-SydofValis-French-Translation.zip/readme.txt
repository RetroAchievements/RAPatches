Use with:

Syd of Valis (USA).md (No Intro)
a81d327574d49aab69c2a6fe4cdc893a