Use with:

Alien Soldier (USA) (Virtual Console).md (No Intro)
54d06fe70c75bf6828a503bb8ce806b0