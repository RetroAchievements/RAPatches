Use with:

World of Illusion Starring Mickey Mouse and Donald Duck (USA, Korea).md (No Intro)
c2c5a4b990ce72f98b7b7f236e66c022