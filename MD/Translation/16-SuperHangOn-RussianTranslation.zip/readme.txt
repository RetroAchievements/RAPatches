Use with:

Super Hang-On (World) (En,Ja) (Rev A).md (No Intro)
9b5d500a7ce1de56fba9c554bbf9a0b2