Use with:

Golden Axe II (World).md (No Intro)
2cd3573172961fa52f622f14ccff4e1a