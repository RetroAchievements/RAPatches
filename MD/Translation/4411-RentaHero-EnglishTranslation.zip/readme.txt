Use with:

Rent a Hero (Japan).md (No Intro)
baa47b5e85264ac958072ed0f0037525