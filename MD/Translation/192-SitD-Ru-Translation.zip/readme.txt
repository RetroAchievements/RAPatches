Use with:

Shining in the Darkness (USA, Europe).md (No Intro)
522b689a1b2f0ea8578fa9d888554b82