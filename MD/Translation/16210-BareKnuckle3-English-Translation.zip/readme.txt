Use with:

Bare Knuckle III (Japan).md (No Intro)
f1cb9e887bf4bc512d9535c89e420df7