Use with:

Super Monaco GP (Japan, Europe) (En,Ja).md (No Intro)
ded2b235f625424f353c13c4d3a2cf89