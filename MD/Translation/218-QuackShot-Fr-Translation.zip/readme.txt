Use with:

QuackShot Starring Donald Duck ~ QuackShot - I Love Donald Duck - Guruzia Ou no Hihou (World).md (No Intro)
a184d044b122b73026b8f4f8fb6bc528