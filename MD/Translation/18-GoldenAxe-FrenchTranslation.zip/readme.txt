Use with:

Golden Axe (World).md (No Intro)
04d2c7da9aac3fbeadf6bb8ccd27b560