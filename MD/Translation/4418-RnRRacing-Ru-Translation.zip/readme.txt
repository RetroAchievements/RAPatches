Use with:

Rock n' Roll Racing (USA).md (No Intro)
530c58317b5626fa15b77adab0aacc9d