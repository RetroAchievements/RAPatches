Use with:

Blades of Vengeance (USA, Europe).md (No Intro)
0ef8cf31e77cf8fab03bd7540a4751c0