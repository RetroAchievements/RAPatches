Use either with:

Animaniacs (USA).md (No Intro)
ce0a42a75a9e374cf5092f34bf6927b7