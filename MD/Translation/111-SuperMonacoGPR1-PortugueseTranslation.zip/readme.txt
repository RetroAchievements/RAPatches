Use with:

Super Monaco GP (Japan, Europe) (En,Ja) (Rev A).md (No Intro)
7c343c0b33f8af9f4719ead8cee7b201