Use with:

(No-Intro)
File:               Sonic Jam 6 (Taiwan) (En) (Pirate)
Size (Bytes):       2097152 (2 MB)
MD5 checksum:       601dbecadde306ab238443193c76c918

RA Hash:            601dbecadde306ab238443193c76c918