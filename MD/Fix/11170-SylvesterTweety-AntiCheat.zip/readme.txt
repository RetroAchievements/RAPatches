Use with:

(No Intro)
File:               Sylvester & Tweety in Cagey Capers (USA, Europe).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              89FC54CE
MD5:                BBF74E8F5EDA63631CE7617370D1F747