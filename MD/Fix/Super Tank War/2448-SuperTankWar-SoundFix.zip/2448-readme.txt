Use with:

(No Intro)
File:               Super Tank War (Taiwan) (En) (Unl).md
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              5E519EA1
MD5:                11382E11A4ED5834E80E30D1D95CA006
SHA1:               7E00475F99035FB20F624A7FE0D6BB77C7E834B1