Use with:

(No Intro)
File:               Dungeons & Dragons - Warriors of the Eternal Sun (USA, Europe).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              AF4A9CD7
MD5:                4F5F970A5FE5936C897BAE017D88921E