Use with: 

(No Intro)
Light Crusader (USA).md
md5: 2869e0d4ad512a1fbd9b79d6937d9446
CRC: BEB715DC