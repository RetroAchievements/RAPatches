Use with:

(No Intro)
File:               Pokemon Stadium (Taiwan) (En) (Unl).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              FE187C5D
MD5:                984511C98143E3ED4C4301D8CB508CD8
SHA1:               F65AF5D86ABA33BD3F4F91A0CD7428778BCCEEDF
SHA256:             2184B2AE034A68271E5F9C38B885A6D5ACC6A3DF7DE77E76ED79B9E1EF369D6A