Use with:

(No Intro)
File:               Super Mario World 64 (Taiwan) (En) (Unl).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              E7AC4161
MD5:                394783B469E8DD48F14A0063257B51A9
SHA1:               2CCF970FFFD173F1984E69617C330A8F297F3481
SHA256:             A6A53D5D4F9696791042087CE5FB1FB99CC13FF3282BBFB2898F786144838912