Use with:

Zero Wing (Japan).md (No Intro)
9647d8ec9183f3ec9f944d5ea49a99a9