Use with:

(No Intro)
File:               Dr. Robotnik's Mean Bean Machine (USA).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C7CA517F
MD5:                4D6BDAC51D2F5969A91496142EA53232
SHA1:               AA6B60103FA92BC95FCC824BF1675E411627C8D3
SHA256:             882E25427763260FA6D028C965B314FC5673560D82EC065CF154A1274E343FFE