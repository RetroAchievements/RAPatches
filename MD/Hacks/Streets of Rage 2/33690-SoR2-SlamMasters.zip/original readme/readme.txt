Streets of Rage 2 x Slam Masters
Mod author: Da Lao Hu (Dha Lau Hoo)

After Axel and his heroic team defeated Mr. X, the city was peaceful for a while.
However, Mr. X returned to the city once again. This time he possesses a new killing weapon, Robot-A, which was modeled based on the real Axel. After Robot-A defeated the real Axel, the city fell to the hands of Mr. X again.
However, new allies joined the battle to reinforce Axel: the mighty wrestlers from Saturday Night Slam Masters (Muscle Bomber)! They will put an end to Mr. X's crime empire with body slams!

This mod also uses the system of Da Lao Hu's previous mods, except for
*Takedowns are much more powerful than strikes. 
*Air juggle is not available, because this mod emphasizes grapple attacks.
*A glitch that caused the player character's jump movement laggy has been fixed.

Move list:

The Scorpion (The Astro)
Strikes:
Clothesline: Forward, Forward (running) + B
Flash Kick: Forward + A
Spiral Kick (Special): A
Block/Counter: Press and hold BC
Grapple attacks:
DDT: Grab enemy in the front and press Back + B (44 pts damage)
German Suplex: Grab enemy in the back and press B (48 pts damage)
Vault: Up + C
Grab jump: C
Tiger Bomb: Grab jump, and then press B (44 pts damage)

Gunloc (Lucky Colt)
Strikes:
Clothesline: Forward, Forward (running) + B
Knee Lift: Forward, Forward (running) + A
Sonic Fist: Forward + A
Skull Cracker (Special): A
Block/Counter: Press and hold BC
Grapple attacks:
Fisherman Suplex: Grab enemy in the front and press Back + B (44 pts damage)
Back Body Drop: Grab enemy in the back and press B (48 pts damage)
Vault: C

Titanic Tim (Titan the Great)
Strikes:
Big Boot: Forward, Forward (running) + B
Leaping Knee: Forward, Forward (running) + A
Tomahawk Dive: Forward + A
Tsunami (Special): A
Block/Counter: Press and hold BC
Grapple attacks:
Titan Slam: Grab enemy in the front and press B (48 pts damage)
Body Drop: Grab enemy in the front and press Back + B (52 pts damage)
Russian Leg Sweep: Grab enemy in the back and press B (48 pts damage)
Vault: C

The Great Oni (Mysterious Budo)
Strikes:
Clothesline: Forward, Forward (running) + B
Moon Slicer: Forward + A
Cyclone Kick (Special): A
Block/Counter: Press and hold BC
Grapple attacks:
Belly to Belly Suplex: Grab enemy in the front and press Back + B (44 pts damage)
German Suplex: Grab enemy in the back and press B (48 pts damage)
Neck Wrecker (Keppujin): Grab enemy in the back and press Up + B (16~56 pts damage)
Vault: C

The sprites were provided by Radman, and modified by the author to be used in this hack.

You must apply the IPS patch to this ROM:
No-Intro Name: Streets of Rage 2 (USA)
(No-Intro version 20130710-102701)
ROM/File SHA-1: 8B656EEC9692D88BBBB84787142AA732B44CE0BE

Merry Christmas, and have fun!