I. Overview:

This hack is for fans to play for usual characters from the SOR universe.
The hack is primarily inspired by these two works http://www.romhacking.net/hacks/4197/ and http://www.romhacking.net/hacks/4283/
This hack allows the player to play as the modified versions Max and SOR3 versions of Axel, Blaze, and Roo in SOR2.


II. Features:

* Axel and Blaze have SOR3 style appearances with some modifications.
* All playable characters can run (with weapon animations).
* All playable characters can change direction and turn around while running.
* All playable characters can jump further while running.
* The command to run (f, f) becomes more sensitive.
* The game has Juggling !!.
* Neutral Air Attack is now Air to Air. Works great for juggling an opponent in a corner or while playing in Co-op, but can miss when attacking a ground target.
* You can choose the same characters.
* SoR3 like �ombo style - you can deal combo, without hit enemy.
* Player characters have new animation recovery when they escape from being thrown (up + C).
* Charge attacks require holding B for only 2/3 second.
* Offensive Special no longer costs player�s own health.
* If the player presses A while running, the player�s character will perform Offensive Special (in the original game, nothing will happen).
* You can use the Defensive Special and Offensive Special when you capture the enemy.
* You can use the Defensive Special and Offensive Special when grabbing an enemy from behind.
* KO count of the players is displayed.
* Roo replaces Skate as a playable character.
* Mania difficulty is directly accessible.
* Stage selection is available.
* Added 6-Button gamepad Support. Back attack now is Y button

III. Characters:

Max:
* Max has the fewest changes, the new dynamics will boost it incredibly.
* Used Pile driver patch http://www.romhacking.net/hacks/4418/ (but replaced the sprite with a more suitable one)
* You can move a little while using Defensive Special.


Axel:
* Inspired by this hack http://www.romhacking.net/hacks/4197/, but sprites from SoR3 were used.
* Jump Down + B: Tatsumaki.
* New Grab Combo.
* New FFB. Spin to Win!
* FA now is "Shoryuken" You can destroyed Jet.

Blaze:
* Used color scheme from this hack http://www.romhacking.net/hacks/4283/
* New, custom B + C attack;
* B + C. The sprite is drawn by savok.
* B + C new special effect taken from this rom http://www.romhacking.net/hacks/4636/
* Jump Down + B: Terra Shield
* New FFB (There was no sense in the classics, because there is Jump Down + B).


ROO:
* The best representative of the Hunter family!
* Used some new sprites from SORRemake.
* New Throw Animation.
* New grab combo.
* Roo can now use the �headbat� immediately, when capturing, the neutral attack button.
* Jump DB: "Tatsumaki"




IV. Hint:

If you did a Forward Jump Attack with a run, and continue to hold forward, then upon landing the character will run further. You can use this to apply the new B + C Blaze attack. Example

V. v0.4.33 Changelog:

New Blitz Attack for Blaze;
Few minor fix;
Added Mana System 
The player can gain MP by hitting the enemies: Each hit will increase MP by 1. Throwing an enemy will increase MP by 2. Piledriver (Max only) will increase MP by 3. Offensive special attacks do not increase SP. The maximum value of MP is 100.
Player can perform offensive special attack by pressing forward and A only if he have 20 MP.
Tea and coffee help the player to recover MP. A cup increases player MP by 10. A pot increases player MP by 20

VI. Credit:

All new code is taken from different hacks Dha_Lau_Hoo , fixed by Docm@n88hz and compiled by savok.
Special thanks to Dha Lau Hoo for taking notes on his hacks and for guides with Air combo and Skate Throw.
Thanks to Docm@n88hz for helping to parse and fix the new code.
Thanks to FinalCrashSoR3 for found SORRemake sprites