Use with:

(No Intro)
File:               Sonic & Knuckles + Sonic The Hedgehog 3 (USA) (Lock-on Combination).md
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              63522553
MD5:                C5B1C655C19F462ADE0AC4E17A844D10
SHA1:               CFBF98C36C776677290A872547AC47C53D2761D6
SHA256:             FBA0677FDE9F76DF93F3E98D6310D8AF68B9847BDE16E253D73CD4DD8134ED23