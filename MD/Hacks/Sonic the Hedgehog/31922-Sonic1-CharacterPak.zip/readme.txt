Use with:

(No Intro)
File:               Sonic The Hedgehog (Japan, Europe, Korea) (En).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              AFE05EEE
MD5:                09DADB5071EB35050067A32462E39C5F
SHA1:               69E102855D4389C3FD1A8F3DC7D193F8EEE5FE5B
SHA256:             1B7F6635BD713F37F3C2F44F302B872C2E3C5F56E63637918DAD4637146900FD