Use with:

No Intro
Sonic The Hedgehog (USA, Europe).md
1bc674be034e43c96b86487ac69d9293
F9394E97