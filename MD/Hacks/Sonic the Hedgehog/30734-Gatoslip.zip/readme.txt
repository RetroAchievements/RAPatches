Use with:

(No-Intro)
File:               Sonic The Hedgehog (USA, Europe).md
Size (Bytes):       524288
CRC32:              f9394e97
MD5:                1bc674be034e43c96b86487ac69d9293
SHA1:               6ddb7de1e17e7f6cdb88927bd906352030daa194
SHA256:             46160baa06362c711c9f1a5017cb7371026444936c8af5e93a78996cf32ff2a6