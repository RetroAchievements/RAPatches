Use with:

(No Intro)
File:               Street Fighter II' - Special Champion Edition (USA).md
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              13FE08A1
MD5:                94C07E0D90ECB7A7745D5EEC376B1D61
SHA1:               A5AAD1D108046D9388E33247610DAFB4C6516E0B
SHA256:             D9224423C80754A4EE945F7348D7478D56A134654A9389E02CD82CAAB76DDDEF