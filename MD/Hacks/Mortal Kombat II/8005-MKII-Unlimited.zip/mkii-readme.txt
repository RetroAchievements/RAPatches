Use with:

(No Intro)
File:               Mortal Kombat II (World).md
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              A9E013D8
MD5:                C8E887CA9CDDE7BDE85F324F66D34B2D