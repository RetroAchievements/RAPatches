Use with:

(No Intro)
File:               Mortal Kombat (USA, Europe) (Rev A) (Beta).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              33F19AB6
MD5:                E0BB4D00EA95B75AAC52851FB4D8EE47
SHA1:               2C4A0618CC93EF7BE8329A82CA6D2D16F49B23E0
SHA256:             42E33FFBABBCFEFE60267D53215621E64DD9C3F0E336BC72CA43C0009BD53C05