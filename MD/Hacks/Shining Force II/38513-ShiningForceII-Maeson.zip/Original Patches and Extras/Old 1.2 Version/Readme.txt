This is the old version of Shining Force 2 Maeson.

It is included merely as a fun little thing to check,
as there's not much point in playing this version beyond 
comparing the many, many changes made on the newer one, 
but I rather keep it for preservation reasons, just 
like with my FF3 Hack.