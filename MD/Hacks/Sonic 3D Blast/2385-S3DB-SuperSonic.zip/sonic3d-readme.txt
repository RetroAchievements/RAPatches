Use with:

(No Intro)
File:               Sonic 3D Blast (USA, Europe, Korea) (En).md
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              44A2CA44
MD5:                50ACBEA2461D179B2BF11460A1CC6409