Use with:

(No Intro)
File:               Sonic The Hedgehog 2 (World).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              24AB4C3A
MD5:                8E2C29A1E65111FE2078359E685E7943