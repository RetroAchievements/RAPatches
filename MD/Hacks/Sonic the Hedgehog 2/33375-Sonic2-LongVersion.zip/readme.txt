Use with:

(No-Intro)
File:               Sonic The Hedgehog 2 (World) (Rev A).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7B905383
MD5:                9FEEB724052C39982D432A7851C98D3E
SHA1:               8BCA5DCEF1AF3E00098666FD892DC1C2A76333F9
SHA256:             193BC4064CE0DAF27EA9E908ED246D87EC576CC294833BADEBB590B6AD8E8F6B