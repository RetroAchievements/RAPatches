Use with:

No Intro
Streets of Rage 2 (USA).md
cb75d5a6919b61efe917bea5762c1cb7
E01FA526