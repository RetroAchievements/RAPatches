File:               Streets of Rage 2 (USA).md
Size (Bytes):       2097152
CRC32:              E01FA526
MD5:                cb75d5a6919b61efe917bea5762c1cb7