Use with:

(No Intro)
File:               Mega Man - The Sequel Wars - Episode Red (World) (v1.1) (Aftermarket) (Unl).bin
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              9C6433CE
MD5:                BFF0EB90C2006EDADE14063D4A2D13CF