Use with:

(No Intro)
File:               World of Illusion Starring Mickey Mouse and Donald Duck (USA, Korea) (En).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              921EBD1C
MD5:                C2C5A4B990CE72F98B7B7F236E66C022