Use with:

(No Intro)
File:               Streets of Rage 2 (USA).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              E01FA526
MD5:                CB75D5A6919B61EFE917BEA5762C1CB7
SHA1:               8B656EEC9692D88BBBB84787142AA732B44CE0BE
SHA256:             4A314EDBFEE92282850FE95C4C764921916EFD9D3C2277FDEC2581279B1369B1

-------------------------------------------------------------------

File:               Streets of Rage II (Japan, Europe) (En,Ja).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              42E3EFDC
MD5:                C53FAEA21CA58DE2282A8F1A210527BA
SHA1:               A0D3A216278AEF5564DCBED83DF0DD59222812C8
SHA256:             EDEB8A10AB697B4719E3284F7713D8E3A2E06D3AAFD077FCB4833FED871B59DC