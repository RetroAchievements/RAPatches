Use with:

(No Intro)
File:               Shadow of the Beast (USA, Europe).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              BD385C27
MD5:                BA07D4050B453D68CB2BD7E28FC8F74C