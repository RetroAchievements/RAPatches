Use with:

(No Intro)
File:               Sonic The Hedgehog (USA, Europe).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              F9394E97
MD5:                1BC674BE034E43C96B86487AC69D9293
SHA1:               6DDB7DE1E17E7F6CDB88927BD906352030DAA194
SHA256:             46160BAA06362C711C9F1A5017CB7371026444936C8AF5E93A78996CF32FF2A6

(No Intro + RAPatches)
File:               Sonic 1 - Knuckles the Echidna in Sonic The Hedgehog (v1.1) (Stealth).md
BitSize:            4 Mbit
Size (Bytes):       655232
CRC32:              57A6DDB3
MD5:                6AF2FFD9D06B0AA2125E3438C28C7C83
SHA1:               8BC0672F95B1DD0EB16AE0A56483BCCDB99C197C
SHA256:             D431FBA665990F8AE17858322DEED32368B8345D91A289FE0B578B1A016E63E4