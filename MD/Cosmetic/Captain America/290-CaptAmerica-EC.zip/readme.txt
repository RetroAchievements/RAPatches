Use with:

Captain America and the Avengers (USA).md (No Intro)
1dc96693afd74e7b0623a6e06fbdcf87