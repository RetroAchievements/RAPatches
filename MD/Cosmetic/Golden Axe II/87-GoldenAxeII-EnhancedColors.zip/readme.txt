Use with:

(No Intro)
Golden Axe II (World).md
MD5: 2cd3573172961fa52f622f14ccff4e1a
CRC: 725E0A18