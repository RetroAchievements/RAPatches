Use with:

(No Intro)
File:               Mega Man - The Wily Wars (USA) (Genesis Mini).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              0CD405DB
MD5:                8E860E4F7C7EE5FEBAD9134A56766112
SHA1:               26AD72719991E94DBE477C78E65D68F4A4FE51E6
SHA256:             C3E5E56C1252DE5A1FF3BB68B47366120F2C85D333A9CA0EB6DF3DAB1B03E583