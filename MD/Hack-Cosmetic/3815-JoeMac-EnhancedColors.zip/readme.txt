Use with:

(No Intro)
File:               Joe & Mac (USA).md
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              85BCC1C7
MD5:                9800244038A6235C6D437582AA75F52F