Use with:

Awesome Possum... ...Kicks Dr. Machino's Butt (USA).md (No Intro)
3ad4ffc5046a21b6a7d7f5589c39dd76
1F07577F