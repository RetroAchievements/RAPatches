Use with:

Mortal Kombat (World).md (No Intro)
a1dd8a3e4b8c98dee49d5e90d6b87903