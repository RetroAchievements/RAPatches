Use with:

Samurai Shodown (USA).md (No Intro)
d50b365a99d5efae6164ef084e808ff2