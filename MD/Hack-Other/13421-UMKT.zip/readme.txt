Use with:

No Intro
Ultimate Mortal Kombat 3 (USA).md
5a129779699f8b388e97c9c0d703d503
7290770D