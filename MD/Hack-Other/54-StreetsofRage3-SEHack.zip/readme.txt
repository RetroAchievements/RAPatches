Use with:

Streets of Rage 3 (USA).md (No Intro)
2d0b0c8f10edf76131708e874e8d1ee4