Use with:

(No Intro)
Rock n' Roll Racing (USA).md
530c58317b5626fa15b77adab0aacc9d
6ABAB577