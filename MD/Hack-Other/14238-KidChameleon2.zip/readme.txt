Use with:

Kid Chameleon (USA, Europe).md (No Intro)
756e603b6cf9b3ebbb1b0f79d9447e43
CE36E6CC