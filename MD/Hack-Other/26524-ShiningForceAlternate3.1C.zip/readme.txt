Use With:

[No-Intro]
Shining Force (USA).md
HASH: 5111aa25931e6789ce4972bc6bafaa04
CRC32: e82acdfc