Use with:

Shining Force (USA).md (No Intro)
4b4acbe75ff7aaeb534ab78ed95910d1
E0594ABE