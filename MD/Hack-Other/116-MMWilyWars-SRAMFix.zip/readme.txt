Use with:

Mega Man - The Wily Wars (Europe).md (No Intro)
bb891aec8a7dfe6164033f57af2025bd