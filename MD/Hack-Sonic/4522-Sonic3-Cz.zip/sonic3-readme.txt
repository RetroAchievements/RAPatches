Use with:

(No Intro)
File:               Sonic The Hedgehog 3 (USA).md
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              9BC192CE
MD5:                D724EA4DD417FE330C9DCFD955C596B2