Use with:

Sonic & Knuckles (World).md (No Intro)
4ea493ea4e9f6c9ebfccbdb15110367e
0658F691