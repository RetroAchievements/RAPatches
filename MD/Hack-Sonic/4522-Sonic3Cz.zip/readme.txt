Use with:

No Intro
Sonic & Knuckles + Sonic the Hedgehog 3 (USA).md
c5b1c655c19f462ade0ac4e17a844d10
63522553