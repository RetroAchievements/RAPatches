Use with:

No Intro
Sonic the Hedgehog 2 (World).md
8e2c29a1e65111fe2078359e685e7943
24ab4c3a