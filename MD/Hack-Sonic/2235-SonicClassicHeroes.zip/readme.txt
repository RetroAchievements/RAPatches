Use with:

Sonic The Hedgehog 2 (World).md (No Intro)
8e2c29a1e65111fe2078359e685e7943