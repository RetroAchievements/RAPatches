Use with:

Sonic 3D Blast ~ Sonic 3D Flickies' Island (USA, Europe, Korea).md (No Intro)
50acbea2461d179b2bf11460a1cc6409