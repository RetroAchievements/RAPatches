Use with:

Sonic the Hedgehog 2.md (No Intro)
8e2c29a1e65111fe2078359e685e7943
24AB4C3A