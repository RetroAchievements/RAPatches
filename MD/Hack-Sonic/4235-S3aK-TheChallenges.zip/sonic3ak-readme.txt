Use with:

(No Intro)
File:               Sonic & Knuckles + Sonic The Hedgehog 3 (USA).md
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              63522553
MD5:                C5B1C655C19F462ADE0AC4E17A844D10