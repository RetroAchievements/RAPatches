Use with:

(No Intro)
File:               Sonic The Hedgehog (USA, Europe).md
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              F9394E97
MD5:                1BC674BE034E43C96B86487AC69D9293