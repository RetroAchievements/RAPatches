Use with:

Sonic the Hedgehog (USA, Europe).md (No Intro)
1bc674be034e43c96b86487ac69d9293