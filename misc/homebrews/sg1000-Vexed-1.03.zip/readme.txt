Vexed is a puzzle game in which the goal is to move similar blocks together, causing them to disappear. To finish the level, remove all the blocks.

Move blocks by putting the select target on them and pressing the fire button then moving to the left or right. If an empty space is encountered when moved, the blocks will fall towards the bottom.

Scoring is based on a golf-like par concept. If the level is solved in the same number of moves as the target, a score of 0, or par, is given for that level. Note that the target may not be the most efficient one, is it is possible to beat "par" and have a negative score.

Click the right button to restart the level. The moves counter is reset to zero. The level can be restarted as often as needed. 

