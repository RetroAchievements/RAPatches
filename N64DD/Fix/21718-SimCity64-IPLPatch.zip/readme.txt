Use with:

(No Intro)
File:               [BIOS] Nintendo 64DD IPL (Japan) (v1.2).z64
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              7F933CE2
MD5:                8D3D9F294B6E174BC7B1D2FD1C727530
SHA1:               BF861922DCB78C316360E3E742F4F70FF63C9BC3
SHA256:             806400EC0DF94B0755DE6C5B8249D6B6A9866124C5DDBDAC198BDE22499BFB8B

----------------------

To play using RAP64 you must apply the following settings:

Options -> Settings -> Plugins -> Video -> Glide64 Public Release 4.0
https://github.com/gonetz/GLideN64/releases/tag/Public_Release_4_0

(This will crash using other video plugins)

I could not get graphics to load properly using Glide64 Public Release 3.0

Options -> Settings -> Plugins -> Audio -> Azimer's Audio v0.70 WIP 10
https://github.com/Azimer/AziAudio/releases/tag/WIP10

Other Audio Plugins caused issues in which an error would appear. Gameplay would 
continue but all sounds would break and ending a map would crash.

Options -> Advanced -> 64DD IPL ROM Path: -> Insert path to your PATCHED IPL BIOS
for the N64 DD

Once the above is done launch the "SimCity 64 (Japan).ndd" like you would be launch-
ing any other N64 game.