Use with:

(No Intro)
File:               Mario Artist - Talent Studio (Japan).ndd
BitSize:            495 Mbit
Size (Bytes):       64931840
CRC32:              649BBCB1
MD5:                88228E990B58A94E9B3460BEFF632304
SHA1:               24CA7508157466E5D289EE49C2C714806D1ECCE2
SHA256:             CB4D3F841E8405C4BCB760AAD6EF9496DEF6AA1CAC7B2F9E54FE7085B6BF8536