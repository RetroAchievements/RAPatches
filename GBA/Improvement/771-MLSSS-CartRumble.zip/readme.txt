Use with:

(No Intro)
Mario and Luigi - Superstar Saga (Europe) (En,Fr,De,Es,It).gba
3b50b9f9e13e271ead33ee5a234650a9
170CC574

Mario and Luigi - Superstar Saga (USA).gba
4b1a5897d89d9e74ec7f630eefdfd435
E718D850