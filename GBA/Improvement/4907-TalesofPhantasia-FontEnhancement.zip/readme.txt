Use with:

(No Intro)
File:               Tales of Phantasia (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              FA172A4A
MD5:                C3439DFD940ADEAB78B4F9D13599FD49
SHA1:               2CC3C21C99C48DC445F499E6CC8AA9B90B2C795B
SHA256:             1C9BFA8ADACD7340407BD04790D83B06B8ADC2C323BE7BB03C51A80197A74E2A