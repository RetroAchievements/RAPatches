Use with:

(No Intro)
File:               Castlevania - Harmony of Dissonance (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              88C1B562
MD5:                EA589465486D15E91BA94165C8024B55