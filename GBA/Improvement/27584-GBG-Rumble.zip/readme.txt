Use with:

(Lost Level Archive)
File:               Goodboy Galaxy (World) (En,Ja,Fr,De,Es,Pt-BR,Zh,Ar) (v1.3) (Aftermarket) (Rik Nicol, Jeremy Clarke).gba
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              159FF629
MD5:                BB9368A99E87251D9323A54841045914
SHA1:               DF5473DBB005816293238095076E8F8C75484F93
SHA256:             ABB7309EF1FF42618B348C28AC73615B534B18A2532D03B0718A4FF4772F6706