Use with:

Super Mario Advance 3 - Yoshi's Island + Mario Brothers (Japan).gba (No-Intro)
9f0877f89cb43331c36f7edbe8c9ba46
26321120
