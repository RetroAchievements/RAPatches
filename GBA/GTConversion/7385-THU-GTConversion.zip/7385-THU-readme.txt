Use with:

Tony Hawk's Underground (USA, Europe).gba (No-Intro)
cf489b93e646c5f102ef2c8cc8fa64cf
1F5149BC
