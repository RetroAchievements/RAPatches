Use with:

Harry Potter and the Goblet of Fire (USA, Europe) (En,Fr,De,Es,It,Nl,Da).gba (No-Intro)
33d83aec45345690ffe48ad9ed7a4ff8
052708D7
