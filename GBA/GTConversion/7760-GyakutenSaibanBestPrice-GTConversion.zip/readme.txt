Use with:

Gyakuten Saiban (Japan).gba (No-Intro)
a476526adc63d7e287d905eb7251d120
C88F0952
