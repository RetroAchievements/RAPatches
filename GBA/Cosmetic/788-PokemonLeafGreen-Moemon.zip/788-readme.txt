Use with:

(No Intro)
File:               Pokemon - LeafGreen Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              D69C96CC
MD5:                612CA9473451FA42B51D1711031ED5F6