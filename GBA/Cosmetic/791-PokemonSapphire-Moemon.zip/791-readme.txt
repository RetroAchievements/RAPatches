Use with:

(No Intro)
File:               Pokemon - Sapphire Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              554DEDC4
MD5:                F34E91399C719812E66E2C828A2E93D7