Use with:

(No Intro)
File:               Pokemon - Ruby Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              F0815EE7
MD5:                53D1A2027AB49DF34A689FAA1FB14726