Use with:

(No Intro)
File:               Donkey Kong Country (Europe) (En,Fr,De,Es,It).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              41D277FE
MD5:                C1FB9BADF816B6D7836F4990F8119815
SHA1:               8995F0BE99A9CFF66474A8975B8499BD69FB4C45
SHA256:             DB7B3C1F402FDA48D26975130854E1D6E8D367BD8A9EF7BCD9FCA866DA82B83F