Use with:

(No Intro)
File:               Super Mario Advance 3 - Yoshi's Island (Europe) (En,Fr,De,Es,It).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              639E9D3B
MD5:                5A0BD0EC784823F2C45FDAA5DD914BEA
SHA1:               BD52EB4B4EBE438E9B9ECAAC792BD389725CDE41
SHA256:             C80B956254D01759DDA43395B455E4C39ABDB8A5335405159EA33680F02E84EE

File:               Super Mario Advance 3 - Yoshi's Island (USA).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              40A48276
MD5:                BB09508C782F37934C9519C5F8A7350C
SHA1:               7352D2BD064D9EBAEC579E264228AA21C7345B80
SHA256:             A8BB331A6F0FF7AF4387DF9AC8566AE395863C2F79A5A597528A64C8BFF57941