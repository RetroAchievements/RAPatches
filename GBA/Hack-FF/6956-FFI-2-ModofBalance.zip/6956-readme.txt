Use with:

(No Intro)
File:               Final Fantasy I & II - Dawn of Souls (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              1B39CDAB
MD5:                5D29999685413C4D2BEC10D3160F6EE6