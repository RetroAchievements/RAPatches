Use with:

No Intro
Final Fantasy I & II - Dawn of Souls (USA).gba
5d29999685413c4d2bec10d3160f6ee6
1B39CDAB