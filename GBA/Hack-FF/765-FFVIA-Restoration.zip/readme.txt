Use with:

No Intro
Final Fantasy VI Advance (USA).gba
d1c3d1798a3f347fbab41f151c99dece
D708F5AB