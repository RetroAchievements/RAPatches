Use with:

No Intro
Pokemon - Emerald Version (USA, Europe).gba
RA Checksum: 605b89b67018abcea91e693a4dd25be3
CRC Checksum: 619D5C64