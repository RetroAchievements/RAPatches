Use with:

Sonic Battle (USA) (En,Ja,Fr,De,Es,It).gba (No-Intro)
100579ef01225c620560f88e65ca423a
9EC9D86F
