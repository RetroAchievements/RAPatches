Use with:

No Intro
Metroid Fusion (USA).gba
af5040fc0f579800151ee2a683e2e5b5
6C75479C