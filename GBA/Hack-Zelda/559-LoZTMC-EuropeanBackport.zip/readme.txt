Use with:

(No Intro)
File:               Legend of Zelda, The - The Minish Cap (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              E8637292
MD5:                2AF78EDBE244B5DE44471368AE2B6F0B