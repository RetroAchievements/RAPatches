Use with:

No Intro
X2 - Wolverine's Revenge (USA, Europe).gba
69662d33f665b2e00e4f95aa75b16a6a
41A92220