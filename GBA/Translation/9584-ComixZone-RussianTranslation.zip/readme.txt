Use with:

No Intro
Comix Zone (Europe) (En,Fr,De,Es,It).gba
f586b690746adce9fcaaef9d3d081117
9F30002F