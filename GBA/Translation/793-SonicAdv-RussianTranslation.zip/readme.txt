Use with:

No Intro
Sonic Advance (USA) (En,Ja).gba
49ecc8ef1988e7ae81fbda1b4cf71eed
63F70FD8