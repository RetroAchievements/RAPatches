Use with:

No Intro
Teenage Mutant Ninja Turtles 2 - Battle Nexus (USA).gba
da96ce67d0ddad72e032632c8fd9994a
802FC7C1