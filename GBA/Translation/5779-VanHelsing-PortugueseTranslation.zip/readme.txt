Use with:

No Intro
Van Helsing (USA).gba
1cf89b423893a12ee0bbc1c4e2868509
36159D63