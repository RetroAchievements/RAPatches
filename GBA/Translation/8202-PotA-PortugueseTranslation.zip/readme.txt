Use with:

No Intro
Planet of the Apes (USA) (En,Fr,De,Es,It,Nl).gba
23a5cf12dda1bd5ef4d3e03fa6112c19
A0F0269B