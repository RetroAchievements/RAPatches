Use with:

No Intro
Tales of the World - Narikiri Dungeon 2 (Japan).gba
1933352fdcc12b8bdb603ee7ed8f9027
231B9FCA