Use with:

For Portuguese and Russian:
No Intro
Shaman King - Master of Spirits (USA).gba
1c92edbad07a372ee382d16cf624dc4b
10E554AE

For Italian:
No Intro
Shaman King - Master of Spirits (Europe) (En,Fr,De).gba
959f4e677160366f356742016427595d
4864B878