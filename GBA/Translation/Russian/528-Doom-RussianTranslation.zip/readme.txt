Use with:
Doom (USA, Europe).gba (No-Intro)
a4078f38dbb47ab22a9c74b725f3e481
58C641B3