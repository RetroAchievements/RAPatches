Use with:

(No Intro)
File:               Legend of Spyro, The - A New Beginning (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              1B81CC00
MD5:                15FB7BB864E9876537890AF774B43DBF