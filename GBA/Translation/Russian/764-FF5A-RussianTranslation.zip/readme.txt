Use with:
Final Fantasy V Advance (USA).gba (No-Intro)
9ed82843cc54876362be56faccb15d75
7A24AB0C