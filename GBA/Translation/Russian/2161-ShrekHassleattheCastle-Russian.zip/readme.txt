Use with:

(No Intro)
File:               Shrek - Hassle at the Castle (USA) (En,Fr,De,Es,It,Nl).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              09E7472C
MD5:                F986D79271E685679F0B5ECB673E9DEA
SHA1:               AFEB14671FAD093FEC0B3AB0E95E01A01DE9F4D8
SHA256:             E716BCE02239BFC87B3A2B84294DC6B92D877AFA0140A3E5A2425B0657BD0C88