Use with:
Naruto - Ninja Council (USA).gba (No-Intro)
dffc7306234751e18b163fbf3e925f1b
C402878C