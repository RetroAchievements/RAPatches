Use with:
Lost Vikings, The (USA).gba (No-Intro)
36c04fe38ba46cff285b060907db94f6
8CB58997