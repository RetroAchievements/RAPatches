Use with:

(No Intro)
File:               Broken Sword - The Shadow of the Templars (USA) (En,Fr,De,Es,It).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              3278CE51
MD5:                5BF98EB8CC6247B4EDF7B9B5B08DBAB9
SHA1:               314ECED054604866153883EE20E0966E1443E0D9
SHA256:             BD66DFEE0A05C252957333B9B040BC8F730B3E986FD5F18CC12F0981AEF08D30