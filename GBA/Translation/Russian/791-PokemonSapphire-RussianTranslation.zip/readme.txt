Use with:

No Intro
Pokemon - Sapphire Version (USA).gba
f34e91399c719812e66e2c828a2e93d7
554DEDC4