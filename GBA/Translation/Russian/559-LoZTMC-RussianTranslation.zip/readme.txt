Use with:
Legend of Zelda, The - The Minish Cap (USA).gba (No-Intro)
a104896da0047abe8bee2a6e3f4c7290
ABCEBBB1