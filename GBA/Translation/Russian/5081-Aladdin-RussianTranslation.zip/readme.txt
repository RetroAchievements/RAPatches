Use with:
Aladdin (USA) (En,Fr,De,Es).gba (No-Intro)
4bda2a3e0249dfd09330dabc3aa20978
40B383F6