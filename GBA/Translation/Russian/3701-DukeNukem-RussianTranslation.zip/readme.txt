Use with:
Duke Nukem Advance (USA).gba (No-Intro)
dfca43fb18b5ee86b3ecab2631862d6f
06570282