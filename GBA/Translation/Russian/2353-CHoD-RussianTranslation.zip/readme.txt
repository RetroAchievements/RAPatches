Use with:
Castlevania - Harmony of Dissonance (USA).gba (No-Intro)
ea589465486d15e91ba94165c8024b55
88C1B562