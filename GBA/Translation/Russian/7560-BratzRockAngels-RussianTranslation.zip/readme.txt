Use with:

No-Intro
Bratz - Rock Angelz (USA, Europe).gba
874AA5C4C6217FEBEC6405A22D7BC9EF
AA245D0C