Use with:
Naruto - Ninja Council 2 (USA).gba (No-Intro)
60eca5e9057972a76361158cc7ab31b8
94699FCA