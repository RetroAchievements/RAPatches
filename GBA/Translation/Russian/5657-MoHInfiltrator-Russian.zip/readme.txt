Use with:

(No Intro)
File:               Medal of Honor - Infiltrator (USA, Europe) (En,Fr,De).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              F23150A4
MD5:                78DB66A92F5F4405266E154DE49EEA8D
SHA1:               47761911475E9548C81FED78E3D3336DDAE89A58
SHA256:             CB2AFD12E286890FCFFEE82A0B394E1101FA2983E2B6C0CF7AB05B46622024EB