Use with:

No-Intro (https://datomatic.no-intro.org/index.php?page=show_record&s=23&n=0564)
Densetsu no Stafy (Japan).gba
MD5: 06ed08799b2f163076fe9fc0cfe65a4c
CRC32: fae94c8b