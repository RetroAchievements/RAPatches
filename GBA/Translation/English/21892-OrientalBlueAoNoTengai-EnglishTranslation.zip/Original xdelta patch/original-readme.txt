Oriental Blue: Ao no Tengai
English Localization (v1.0)
The Romhacking Aerie
aerie.wingdreams.net
Released: September 16th, 2013

----------------------------------------------------------------------------------------

This fan translation is provided for free by The Romhacking Aerie.
 - Please do not attempt to sell this patch in any way, shape, or form.
 - Please do not post pre-patched roms using this patch.
 - Please do not attempt to modify this patch in any way.
 - Please do not use this patch as the basis for a derivative translation.

----------------------------------------------------------------------------------------
Message from Kingcom

Hacking this game was not easy. There are tons of menus, and each menu has up to two
dozen duplicates that all had to be hacked individually. On top of that it had a
graphics format that came straight out of hell that doubled as an animation and map
format and basically combined everything the game could do with graphics into one huge
huge mess. Not to mention all the information it tries to display with very limited
screen space...
But despite all that, I think it was worth it in the end. A lot of work went into
this translation, and I hope many people can enjoy this first localized entry of the
Tengai series.
Thanks to Tom for translating the game, to our beta testers who did a really great job,
to Deets for his typical high quality graphics editing, and to Gemini for his wonderful
fonts.

----------------------------------------------------------------------------------------
             ---Notes from Tom, the translator of Oriental Blue: Ao no Tengai---

1. (First things first... Tengai Makyou does NOT equal Far East of Eden.)

As a fan of the Tengai series, it irked me that people were calling ALL of the Tengai
series games "Far East of Eden" games. (Not all of them are.) It's not hard to see how
the confusion came about. English speakers, seeing "Far East of Eden" on the package
of many of the games (above the much larger kanji), were led to believe that it was
the actual title of the game series.

Far East of Eden is actually the name of the (albeit make-believe) English book about
the history of the (yes, make-believe) country known as Jipang by (the also made-up)
historian known as P.H. Chada. The developers "worked with" P.H. Chada to make
"Tengai Makyou," the game --adaptation-- of the English book (Far East of Eden).
Of course, P.H. Chada and the book  don't really exist, but it's an important
distinction to make, especially when it comes to the titles in the Tengai series.

When you see "Far East of Eden" on the package of a Tengai Makyou game, it really
means that THAT particular Tengai Makyou game is -inspired by- Far East of Eden.
A game with Far East of Eden will be about Jipang. Far East of Eden is also there
to "give props" to P.H. Chada for writing his book about the history of Jipang.
(This is made especially clear in the credits of Tengai Makyou Ziria on the PC
Engine, but most people haven't played it yet.) If Far East of Eden does not appear
on the cover of a game, it means that the game does not revolve around Jipang and
thus has nothing to do with Far East of Eden.

Tengai Makyou: Daiyon no Mokushiroku The Apocalypse IV and Oriental Blue Ao no Tengai
do not feature "Far East of Eden" on the cover because they are not about the history
of Jipang, and P.H. Chada's "historical book" isn't being referenced. Thus, some
Tengai series games aren't Far East of Eden... When referencing the games, I do hope
that people will make the proper distinction between the three terms: Tengai series,
Tengai Makyou, and Far East of Eden.

2. (The Process of Translating Oriental Blue: Ao no Tengai)

When I first played Oriental Blue, I thought it was garbage. The graphics were weak.
The Tengai series charm seemed absent, and the game seemed overly non-linear. It
didn't make a good first impression... But the more I played it, the more I saw
things about the game that I liked. For example, in most RPGs when you gain a new
spell or skill, you can pretty much stop using your old skill and focus entirely on
the new one, unless you just don't have enough MP to cast the more powerful spell.
However, in this game, spells are material-based (along with MP), and all skills
have pros and cons (and do ratio-based damage), so nothing becomes obsolete. A skill
that you get at the beginning of the game may prove to be just as useful by the end
of the game. It had a great balance in terms of its battle system.

The game was open-ended, but not to the point of being a completely nonsensical mess.
Each town has its own unique feeling and culture. One of the most interesting things
in the game was the "ancient text" that appears throughout the story. Several
characters are capable of translating it. Depending on who you have in your party,
you may hear different translations of the same text. (The person who's translating
something makes their own stylistic interpretations, omissions, or oversights as
they translate.) I thought it was really interesting to read so many interpretations
of the same text. For instance, when Kashin Koshi translates text for you, he tends
to paraphrase it and summarize it, leaving out bits that don't interest him (that
may or not be important)... But when Professor Ren translates the same bit, she
tries hard to make sure she gets the translation word for word, but sometimes loses
out on the subtleties behind it. It was the first time I've actually had to translate
scenes that show the process of translation. I thought it was a very nice touch. Most
people won't notice this very small detail, because you're not going to see multiple
translations in one playthrough.

My favorite parts to translate were the poems that appear sporadically throughout
the game. I tried really hard to capture the original meaning while still maintaining
a good, rhythmic flow. I also enjoyed deciphering the ancient alphabet. My least
favorite part was translating the quirky Turks, because of their odd speech pattern.
I still have this fear that there's a line somewhere in the game in which a Turk
accidentally doesn't speak in the proper Turk manner... Let me know if you find
such an instance!

The script itself was pretty big, broken up into countless files. I decided to work
on the biggest files first, getting those out of the way so I could breeze through
the smaller files later on. The script was over one and a half megs of text. I
eventually finished it, but the project was put aside for a long time for various
reasons. During that time, I worked on fixing typos and such, but the script was
so massive, every time I played the game, I'd find more.

The game seemed to be complete, but it wasn't. It was fully playable in the sense
that you could beat the game, but there were many snags in the system, little
imperfections and glitches that made it not worthy of releasing... But after
switching to a new system called SVN to streamline the editing process, progress
came swiftly. The beta testers found plenty of typos that would have been quite
embarassing had they made it into the game. They have my utmost gratitude.
Especially Oddeye, who was especially thorough, reporting hundreds of typos,
errors and the like. My hat is off to you.

3. (My hope for the future of the Tengai series.)

Since Hudson is out of the gaming business, I suppose fan translations are the
only way to spread the Tengai series to English speaking gamers. I still have
hope that one day, the Tengai series will make a big comeback. When it does,
perhaps these fan translations of Tengai series games will prove to the
publishers in English speaking countries that there is actually a market for
these games.

In the meantime, I hope to continue to provide fan translations for other
Tengai series games in the future.

----------------------------------------------------------------------------------------
Patching Instructions

To make use of this patch, you will need the included obpatch.xdelta file and an
unpatched rom of Oriental Blue. We are providing only the patch and will not provide
links or other means by which to acquire an illegal copy of the game. Please only use
this patch  in conjunction with a backup made from your legally purchased copy of
Oriental Blue.

The patch is in an xdelta format, so it's fairly simple to use.

If you are familiar with xdelta patching, feel free to use the command line. Otherwise,
you may want to use one of these interfaces:
 PC:  KaioShin's xdelta UI (http://www.romhacking.net/utils/598/)
 Mac: Sappharad's MultiPatch (http://www.romhacking.net/utilities/746/)

Note: As of the release date, VBA-M seems to be the only emulator that plays this game
without any graphical issues. Other emulators may sometimes display garbled lines
above a text box.

----------------------------------------------------------------------------------------
Localization Staff

 Programming         Kingcom
 Translation         Tom
 Graphic Editing     Deets
 Beta Testing        Carnivol
                     DAISfromSB
                     Kaioshin
                     Lord Oddeye
                     VgameT
                     Xanathis
 Special Thanks      Gemini