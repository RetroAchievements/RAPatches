Use with:

(No Intro)
File:               Oriental Blue - Ao no Tengai (Japan).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              05E80ECC
MD5:                4BB1D95611B7CFDADA71F2B6A4BF961C