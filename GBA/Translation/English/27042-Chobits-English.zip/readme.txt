Use with:

(No Intro)
File:               Chobits for Game Boy Advance - Atashi Dake no Hito (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              DDC4B118
MD5:                FA6A6FD3E3898A58977F468DB9A1F6F9
SHA1:               0B32C3ABB700F36864BC468EF6188513B0F4B0A1
SHA256:             443CD8ECE2124A9997283D8AFB63CBDD95D17914424AF65319F4B86E6914591F