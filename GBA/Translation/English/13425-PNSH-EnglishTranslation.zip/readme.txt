Use with:

No Intro
Play Novel - Silent Hill (Japan).gba
df9bd674970714489629e97a8bcd32f7
318A1E9B