Use with:

(No Intro)
Magi Nation (Japan).gba
MD5 - 27ebadff2f3b46ae0bf7a198b5f29952
CRC32 - 6A94531B
