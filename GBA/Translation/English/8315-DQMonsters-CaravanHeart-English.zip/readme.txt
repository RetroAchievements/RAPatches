Use with:

(No Intro)
File:               Dragon Quest Monsters - Caravan Heart (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              3C24ABCC
MD5:                FC6A66C32B91FA0E526AE7782F29E86A
SHA1:               430A7062844888E68BD5587ED53A769BA548ADB3
SHA256:             FB388539B95FDAF6009BAD879E9BBB25955DAF8D4D438486A9213D407B2B48CE