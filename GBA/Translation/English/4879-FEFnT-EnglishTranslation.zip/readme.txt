Use with:
Fire Emblem - Fuuin no Tsurugi (Japan).gba (No-Intro)
8643fe7632d4895dcaaca230475e70fb
D38763E1