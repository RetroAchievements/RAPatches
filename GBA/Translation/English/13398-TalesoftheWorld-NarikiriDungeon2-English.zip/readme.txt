Use with:

(No Intro)
File:               Tales of the World - Narikiri Dungeon 2 (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              231B9FCA
MD5:                1933352FDCC12B8BDB603EE7ED8F9027
SHA1:               2FEB4CFF9485C68758C1FAC847C6EB907E747A01
SHA256:             A92C0F6DBB5C013B47B7178E23D81663E3952A10DF7B1F68967EBF7BB3B98EB7