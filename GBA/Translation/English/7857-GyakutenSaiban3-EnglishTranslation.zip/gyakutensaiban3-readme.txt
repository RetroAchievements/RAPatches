Use with:

(No Intro)
File:               Gyakuten Saiban 3 (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              51B6CF22
MD5:                3BB63215DC9DC1ED394C9A4E2CD632DD