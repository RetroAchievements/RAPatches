Use with:
F-Zero - Climax (Japan).gba (No-Intro)
RA hash: 8d27b349bca44d938b67f9a28712f6c9
CRC32: DBDC71E3
