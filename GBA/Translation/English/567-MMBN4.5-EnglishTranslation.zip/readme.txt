Use with:

(No Intro)
File:               Rockman EXE 4.5 - Real Operation (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              A646601B
MD5:                0F82BB24585C9EC64E99394C9D316315
SHA1:               F89EF4CA8EC1823EB75FA184F2D0F9E66CC78A59
SHA256:             588A77DA006FB0DCA0C8ADDBCC316D7BD4B1C3A42DB24750BCFE17B170AC5EF8