Use with:

(No Intro)
File:               Mother 1+2 (Japan).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              0A44569C
MD5:                F41E36204356974C94FABF7D144DD32A