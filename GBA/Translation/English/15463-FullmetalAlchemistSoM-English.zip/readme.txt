Use with:

(No Intro)
File:               Hagane no Renkinjutsushi - Omoide no Sonata (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              C6144316
MD5:                EF9C063AB316CA610DD5A6C5C35FCA7F
SHA1:               585B84B1A9A169FDB3ED30F9AD07D512A6A636DE
SHA256:             F7EBA3B4BBD6E0E3BCFD745AA156C4CBAE6E75E14597D827F4BE171B6859DC84