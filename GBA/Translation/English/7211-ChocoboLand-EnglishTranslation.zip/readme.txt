Use with:

No-Intro
File: Chocobo Land - A Game of Dice (Japan).gba
MD5: 6341167e3c3212c632e7956cf0e69119
CRC-32: d4f8152e