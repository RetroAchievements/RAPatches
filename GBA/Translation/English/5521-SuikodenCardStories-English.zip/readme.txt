Use with:

(No Intro)
File:               Gensou Suikoden - Card Stories (Japan).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              5E67AAB4
MD5:                0A3523DB5FE9A0329D766D9D1FF5E654
SHA1:               C01772CD0416DDCA38DCD1EF63E53A4EBDA90BBC
SHA256:             5E525D21CE9205C3A8F906FECB36722FA6F6BB8C8217DD2B94E9043EC9413F86