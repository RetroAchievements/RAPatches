Use with:
Love Hina Advance - Shukufuku no Kane wa Naru Kana (Japan).gba (No-Intro)
53bfc207dd7320ad7db94e299adca245
B8E67449