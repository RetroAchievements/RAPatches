Use with:

(No Intro)
Shin chan - Aventuras en Cineland (Spain).gba
0dbc85a954aba764a3bbae2e078d26f0
769A7666