Use with:

(No Intro)
File:               Rockman EXE 6 - Dennoujuu Gregar (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              6285918A
MD5:                053CF73404DCC39BE7CBD77C8E833150
SHA1:               48472EFA4657DB47CD3B6D146D9FE9FE730C4439
SHA256:             FA6808A5C63C2CC09430EC7AD74C6E02F4F35928448E6FF5F8DBDEC0795160CF