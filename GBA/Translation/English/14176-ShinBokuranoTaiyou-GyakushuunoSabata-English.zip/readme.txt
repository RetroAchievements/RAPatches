Use with:

(No Intro)
System:             Nintendo - Nintendo Entertainment System
Path:               GBA-To Patch
Archive:            
File:               Shin Bokura no Taiyou - Gyakushuu no Sabata (Japan).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              AF453162
MD5:                FBAD88C14DCEDEFE6C70B06ADCD0A0DB
SHA1:               2651C5E6875AC60ABFF734510D152166D211C87C
SHA256:             0B170FC99DEF2CA5BDEBBFD642327E135304ADBA1E3E0BFD5D66CDD298ADB90F