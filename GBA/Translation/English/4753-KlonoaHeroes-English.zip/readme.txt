Use with:

(No Intro)
File:               Klonoa Heroes - Densetsu no Star Medal (Japan).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              E7EADDCC
MD5:                46D2A77E4FD8429E6B7BF79C0679770E
SHA1:               323465C8A36517A1E8B0DDE2D500BBCD4C396D4E
SHA256:             CB3FF23FC56440EFA97321A2CB93A87AACF05AE4214527972AF3CE0F29834E63