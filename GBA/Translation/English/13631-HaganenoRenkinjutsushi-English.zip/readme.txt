Use with:

(No Intro)
File:               Hagane no Renkinjutsushi - Meisou no Rondo (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              A8CDA373
MD5:                11A1C991749EDEDFCE2CEF42E1019CC7
SHA1:               863E778FA08B3181440948241470EA37552D7820
SHA256:             49DF5E9E128302733FB1465104153923A4A5C0EF36EFD8B77A0006BBC0A629D8