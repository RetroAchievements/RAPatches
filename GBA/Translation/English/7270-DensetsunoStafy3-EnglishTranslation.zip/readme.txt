Use with:

(No-Intro)
Densetsu no Stafy 3 (Japan) (Rev 1).gba
ee4fbcec249a68b796be491f56ffe03d
2D6E4C3B