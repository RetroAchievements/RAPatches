Use with:

(No Intro)
File:               Morning Adventure, The (Spain) (Promo).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              B734EB4E
MD5:                5F745975CA8B358D15D3AEEDD432DE56
SHA1:               2E1E22DB04DBEDFE1E98416CB9861E64E986122B
SHA256:             EFFE21E844DBDC8FE614B60744B6291AC1E6DA0B809479A090A8624C6A63AA85