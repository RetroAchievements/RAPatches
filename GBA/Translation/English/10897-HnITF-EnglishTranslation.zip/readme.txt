Use with:
Hajime no Ippo - The Fighting! (Japan).gba (No-Intro)
07c67caee98287f303193d837ebdb702
782DC7EB