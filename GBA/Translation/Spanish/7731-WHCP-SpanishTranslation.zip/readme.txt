Use with:
Wade Hixton's Counter Punch (USA, Europe).gba (No-Intro)
MD5   : 05b82f996a7ebc44c62697b02833a68f
CRC32 : 47b49060