Use with:

(No Intro)
Mega Man Battle Network (USA).gba
9ff40cf640575211202b7bda5487abbb
1D347971