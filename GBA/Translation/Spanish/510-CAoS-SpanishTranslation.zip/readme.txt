Use with:
Castlevania - Aria of Sorrow (USA).gba (No-Intro)
e7470df4d241f73060d14437011b90ce
35536183