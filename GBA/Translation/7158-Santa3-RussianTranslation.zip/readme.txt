Use with:

No Intro
Santa Clause 3, The - The Escape Clause (USA).gba
b3a719f647a84f5496c0ad97d5de6370
206933F5