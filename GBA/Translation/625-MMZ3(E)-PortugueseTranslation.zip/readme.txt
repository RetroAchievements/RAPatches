Use with:
Mega Man Zero 3 (Europe).gba (No-Intro)
9ce73ff9aa1473f250d103c1bdbbd738
B099577F