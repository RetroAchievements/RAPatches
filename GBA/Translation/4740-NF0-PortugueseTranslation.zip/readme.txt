Use with:
Ninja Five-0 (USA).gba (No-Intro)
04244f72a9b8f17ee33e0b5bff2b8b1f
EB3954C6