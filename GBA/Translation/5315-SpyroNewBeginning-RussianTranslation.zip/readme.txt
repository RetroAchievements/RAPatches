Use with:

No Intro
Legend of Spyro, The - A New Beginning (USA).gba
15fb7bb864e9876537890af774b43dbf
1B81CC00