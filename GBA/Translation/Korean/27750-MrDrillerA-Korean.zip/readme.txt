Use with:

(No Intro)
File:               Mr. Driller A - Fushigi na Pacteria (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              529F06A4
MD5:                D7F4CB6AEA9409ACF23E2EAE5A697C5E
SHA1:               CCFB5F3051B4D3BDEC38F0085F2A585ECF249F20
SHA256:             145A2C13AA206BC64B0CD1A1D5F22D7C8F77A8FCA47424255661B1C08B293CCD