Use with:
Mega Man Battle Network (Europe).gba (No-Intro)
62e32a9ccf6c31850041555cb8151440
1A7FB4FA