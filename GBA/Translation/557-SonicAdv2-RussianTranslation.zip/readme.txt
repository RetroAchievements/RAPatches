Use with:

No Intro
Sonic Advance 2 (USA) (En,Ja,Fr,De,Es,It).gba
3fb865c5f142a8fc1f82105bfc6b8935
7EFEE7F7