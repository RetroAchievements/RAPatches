Use with:

No Intro
Rockman EXE 4.5 - Real Operation (Japan).gba
0f82bb24585c9ec64e99394c9d316315
A646601B