Use with:

No Intro
X-Men - The Official Game (USA).gba
2584c4d9c73888ffc9096a02fafea08c
C87F460A