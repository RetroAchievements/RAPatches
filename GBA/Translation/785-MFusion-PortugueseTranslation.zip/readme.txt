Use with:
Metroid Fusion (USA).gba (No-Intro)
af5040fc0f579800151ee2a683e2e5b5
6C75479C