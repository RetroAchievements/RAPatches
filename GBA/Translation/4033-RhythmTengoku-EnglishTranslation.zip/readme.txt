Use with:

No Intro
Rhythm Tengoku (Japan).gba
f81f60fdb2fd774c72a170a1805db52e
349D7025