Use with:

No Intro
Army Men Advance (USA, Europe) (En,Fr,De,Es,It).gba
30ff69a44658fcf2cc381736403e74ef
9A4A509F