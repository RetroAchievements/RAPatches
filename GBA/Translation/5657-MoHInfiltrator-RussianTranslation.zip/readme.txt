Use with:

No Intro
Medal of Honor - Infiltrator (USA, Europe) (En,Fr,De).gba
78db66a92f5f4405266e154de49eea8d
F23150A4