Use with:

No Intro
Sonic Advance 3 (USA) (En,Ja,Fr,De,Es,It).gba
e0533faf6aa36e3111669574f1c5df92
49DDA5E6