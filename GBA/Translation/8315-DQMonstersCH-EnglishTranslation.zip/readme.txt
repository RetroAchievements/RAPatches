Use with:

No Intro
Dragon Quest Monsters - Caravan Heart (Japan).gba
fc6a66c32b91fa0e526ae7782f29e86a
3C24ABCC