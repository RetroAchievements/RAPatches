Use with:
Mega Man Zero 4 (USA).gba (No-Intro)
0d1e88bdb09ff68adf9877a121325f9c
7EE24793