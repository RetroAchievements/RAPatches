Use with:

(No Intro)
File:               Mario & Luigi - Superstar Saga (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              170CC574
MD5:                3B50B9F9E13E271EAD33EE5A234650A9