Use with:
Pokemon Mystery Dungeon - Red Rescue Team (USA, Australia).gba (No-Intro)
2100cf6f17e12cd34f1513647dfa506b
DD0AC86C