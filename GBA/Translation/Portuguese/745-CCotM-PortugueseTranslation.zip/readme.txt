Use with:
Castlevania - Circle of the Moon (USA).gba (No-Intro)
50a1089600603a94e15ecf287f8d5a1f
1CC059A4