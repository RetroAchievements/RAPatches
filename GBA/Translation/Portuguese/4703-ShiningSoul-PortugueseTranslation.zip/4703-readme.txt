

Use with:

Shining Soul (USA).gba (No-Intro)
d9b338efe2c15f9493ca0b28714a679b
E95BBA0C
