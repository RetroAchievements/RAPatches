Use with:

(No Intro)
File:               Teenage Mutant Ninja Turtles 2 - Battle Nexus (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              802FC7C1
MD5:                DA96CE67D0DDAD72E032632C8FD9994A
SHA1:               F42D0131E908942BF84D2323739CE015EE930142
SHA256:             FB728FD8E940F35112F9B41B42288455D0ACDC69BC4E88C0EA56667A53ABD670