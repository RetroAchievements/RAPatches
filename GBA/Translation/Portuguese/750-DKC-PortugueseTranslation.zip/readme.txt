Use with:
Donkey Kong Country (USA).gba (No-Intro)
b3806462180cda73d1f8f48d72236394
12F7A968