Use with:
Bomberman Tournament (USA, Europe).gba (No-Intro)
79aef9bbe1378adfbd688cd66e11a7be
240282E6