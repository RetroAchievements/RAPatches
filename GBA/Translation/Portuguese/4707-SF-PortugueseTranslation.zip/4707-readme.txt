

Use with:

Shining Force - Resurrection of the Dark Dragon (USA).gba (No-Intro)
6a1b056d8a006e069466c08c69de56c0
563AA3A0
