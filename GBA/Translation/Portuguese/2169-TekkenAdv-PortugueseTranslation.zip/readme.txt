Use with:

No Intro
Tekken Advance (Japan).gba
a5968bc058ea60a1e389bcd9306d9c7d
C2EEAE53