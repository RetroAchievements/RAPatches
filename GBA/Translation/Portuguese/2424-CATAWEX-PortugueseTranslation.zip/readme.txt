Use with:
Contra Advance - The Alien Wars EX (USA).gba (No-Intro)
78672ead9f35f00e467f8c7d308acdfc
59781C54