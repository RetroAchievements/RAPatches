Use with:

No Intro
Scooby-Doo 2 - Monsters Unleashed (Europe) (En,Fr,De,Es,It).gba
49c6c446c5f7bc6b61e158994f8896b0
7BDAB2CF