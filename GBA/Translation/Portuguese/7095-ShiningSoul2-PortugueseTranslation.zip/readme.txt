

Use with:

Shining Soul II (Europe) (En,Fr,De,Es,It).gba (No-Intro)
49aa688745111aaa51076a345f8f18c3
55E503C1
