Use with:

(No Intro)
File:               Castlevania - Harmony of Dissonance (Europe).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              521B3091
MD5:                E619F9DCD7EF3D4C6851834018B139BD