Use with:
Metal Slug Advance (USA).gba (No-Intro)
6838eb5df807a0f3299ad76066d59d26
09980880