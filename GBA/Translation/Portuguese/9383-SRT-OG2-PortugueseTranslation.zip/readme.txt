Use with:

Super Robot Taisen - Original Generation 2 (USA).gba (No-Intro)
f3d168d87d3e2ae25dbec012471cd9b5
2AEE0380
