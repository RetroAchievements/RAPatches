Use with:

(No Intro)
File:               X2 - Wolverine's Revenge (USA, Europe).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              41A92220
MD5:                69662D33F665B2E00E4F95AA75B16A6A
SHA1:               DC2E861013A9B6A65B9BCD122F070C8F55D1471B
SHA256:             26EAC12F29B1BEC1CD0F206C3A050DC50B8BE91A210B19F210A2176DF5308F40