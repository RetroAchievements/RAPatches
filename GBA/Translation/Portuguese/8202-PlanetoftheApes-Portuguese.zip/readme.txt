Use with:

(No Intro)
File:               Planet of the Apes (USA) (En,Fr,De,Es,It,Nl).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              A0F0269B
MD5:                23A5CF12DDA1BD5EF4D3E03FA6112C19
SHA1:               574A047AB79431E05E716DB2688A3A012A6BC85D
SHA256:             276AA09DCEF2DB458FCD8E01C52D1B51EF71621DA62D7FCF9A9CCAE2C1E39D99