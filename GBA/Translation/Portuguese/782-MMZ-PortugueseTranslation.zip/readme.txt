Use with:
Mega Man Zero (USA, Europe).gba (No-Intro)
b24a17d080a01a404cbf018ba42b9803
9707D2A1