Use with:

(No Intro)
Wario Land 4 (USA, Europe).gba
5fe47355a33e3fabec2a1607af88a404
D6141609