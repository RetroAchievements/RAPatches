Use with:
Mega Man Zero 2 (USA).gba (No-Intro)
182363b0698322e1864ced6e9eed7ead
CE1E37BB