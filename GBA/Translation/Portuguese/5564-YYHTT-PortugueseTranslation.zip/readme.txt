Use with:

No Intro
Yu Yu Hakusho - Ghostfiles - Tournament Tactics (USA, Europe).gba
acefebbe5fdf25ae83a386a6d1c09bca
AEF6B7CC