Use with:
Legend of Zelda, The - A Link to the Past & Four Swords (USA).gba (No-Intro)
3287ca66e5cc285a9fe3a922051e84c6
8E91CD13