Use with:

No Intro
Shaman King - Master of Spirits 2 (USA).gba
5af6a63f85fa386c7889695308dc32a4
201E3412