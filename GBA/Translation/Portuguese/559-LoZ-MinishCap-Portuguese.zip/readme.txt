Use with:

(No Intro)
File:               Legend of Zelda, The - The Minish Cap (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              ABCEBBB1
MD5:                A104896DA0047ABE8BEE2A6E3F4C7290
SHA1:               B4BD50E4131B027C334547B4524E2DBBD4227130
SHA256:             BEDC74DF62755F705398273DE8ED3BC59BE610CF55760D0B9AA277F1F5035E73