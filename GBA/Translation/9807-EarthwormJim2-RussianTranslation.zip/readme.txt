Use with:

No Intro
Earthworm Jim 2 (USA).gba
41c45028c30a5f0241f5b479a954c745
7496555C