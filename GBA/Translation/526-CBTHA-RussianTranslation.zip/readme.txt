Use with:
Crash Bandicoot - The Huge Adventure (USA).gba (No-Intro)
32d74527bfe723470c2c5406c325fb59
034D2D4B