Use with:
Mother 3 (Japan).gba (No-Intro)
af8b0b175f7ec8914cb87b3161ba1aaa
42AC9CB9