Use with:
Crash Bandicoot Fusion (Europe) (En,Fr,De,Es,It).gba (No-Intro)
15e37fb594c2dfe85b8b7ba3b7e565bd
F24C8E77