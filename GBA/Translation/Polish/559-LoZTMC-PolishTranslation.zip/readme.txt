Use with:
Legend of Zelda, The - The Minish Cap (Europe) (En,Fr,De,Es,It).gba (No-Intro)
2af78edbe244b5de44471368ae2b6f0b
E8637292