Use with:

(No Intro)
File:               Golden Sun (USA, Europe).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              E1FB68E8
MD5:                1CDD7F33C9A27061201E1D1CE029A700