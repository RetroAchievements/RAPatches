Use with:

No Intro
Super Robot Taisen - Original Generation 2 (Japan).gba
B817219C91FAEDD9FE53F7C226FF0364
A608800F
