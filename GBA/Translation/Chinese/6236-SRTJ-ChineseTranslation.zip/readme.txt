Use with:

No Intro
Super Robot Taisen J (Japan).gba
ef32f93816b6dbcf788f08faf1e71450
C956FD37
