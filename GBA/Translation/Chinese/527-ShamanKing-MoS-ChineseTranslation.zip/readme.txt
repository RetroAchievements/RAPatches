Use with:

(No Intro)
File:               Shaman King - Master of Spirits (Europe) (En,Fr,De).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              4864B878
MD5:                959F4E677160366F356742016427595D