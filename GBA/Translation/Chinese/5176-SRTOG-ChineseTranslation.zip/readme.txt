Use with:

No Intro
Super Robot Taisen - Original Generation (Japan).gba
BE2ED0AE2D2DA48BFE6F9E49EE2DAF7B
75127EC4
