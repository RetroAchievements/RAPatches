Use with:
Advance Wars (USA).gba (No-Intro)
27f322f5cd535297ab21bc4a41cbfc12
DBEF116C