Use with:

No Intro
Sims 2, The (USA, Europe) (En,Fr,De,Es,It,Nl).gba
51455002b0daa27de8eaa5d9ad1afd6f
8B1BC7DF