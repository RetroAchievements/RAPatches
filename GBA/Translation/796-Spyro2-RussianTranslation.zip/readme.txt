Use with:

No Intro
Spyro 2 - Season of Flame (Europe) (En,Fr,De,Es,It).gba
b7236bf34d66ead26ba5b6c1cb16c5f0
104B4CAA