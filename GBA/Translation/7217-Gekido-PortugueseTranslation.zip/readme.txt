Use with:

No Intro
Gekido Advance - Kintaro's Revenge (Europe) (En,Fr,De,Es,It).gba
cdde24e4b71ac0cb1cf32bab1374f64a
2FB5B819