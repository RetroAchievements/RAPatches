Use with:
F-Zero - Climax (Japan).gba (No-Intro)
8d27b349bca44d938b67f9a28712f6c9
DBDC71E3