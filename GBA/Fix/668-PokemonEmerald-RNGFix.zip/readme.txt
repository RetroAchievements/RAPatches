Use with:

(No Intro) 	
File:	Pokemon - Emerald Version (USA, Europe).gba
CRC32: 	1f1c08fb
MD5: 	605b89b67018abcea91e693a4dd25be3