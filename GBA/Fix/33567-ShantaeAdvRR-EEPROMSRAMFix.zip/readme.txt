Use with:

(No Intro)
File:               Shantae Advance - Risky Revolution (World) (Limited Run Games).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              31265C5D
MD5:                A82BD152BAF314B0D69A12A47C38E60F
SHA1:               13BA1AB9AF37FE874BB8A7C34C7597FA8554A241
SHA256:             2E463EB4C5EA16DEE3EE96296DADB94D943997A0E3711443778B0433B33D9BE2