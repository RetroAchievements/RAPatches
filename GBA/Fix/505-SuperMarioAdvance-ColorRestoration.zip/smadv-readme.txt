Use with:

(No Intro)
File:               Super Mario Advance (USA, Europe).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              1E4C6D6A
MD5:                FF6B0C48065389B888C7A78731D4B58D