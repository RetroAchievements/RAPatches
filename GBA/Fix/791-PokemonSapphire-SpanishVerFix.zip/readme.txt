Use with:

(No Intro)
File:               Pokemon - Edicion Zafiro (Spain).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              A04F5F0B
MD5:                CC87721BB3DFA680F15E875EDCF0B4DD
SHA1:               3A6489189E581C4B29914071B79207883B8C16D8
SHA256:             23F26D9858944B86BAB00019F3AEE3B50BA8C5D100DBA650177025078208AEA9