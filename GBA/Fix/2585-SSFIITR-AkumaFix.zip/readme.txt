Use with:

(No Intro)
File:               Super Street Fighter II Turbo - Revival (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              063045AA
MD5:                7A36A7486EF2C534111EE417B8ACF9B7