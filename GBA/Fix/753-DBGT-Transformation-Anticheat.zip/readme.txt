Use with:

(No Intro)
Dragon Ball GT - Transformation (USA).gba
RA Checksum: b60abac7fdbf012de5a3c9403ece89e8
md5: B60ABAC7FDBF012DE5A3C9403ECE89E8
CRC: AD964A91