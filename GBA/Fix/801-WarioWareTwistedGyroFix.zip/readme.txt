Use with:

[No Intro]
WarioWare - Twisted! (USA).gba
md5: 89579f4dfe1ed24a7cd16a6a61a72a17
CRC: CB4E844B

Mawaru - Made in Wario (Japan).gba
md5: d76d992d936c308b7d1bb70ac71a1c37
CRC: E69964F1