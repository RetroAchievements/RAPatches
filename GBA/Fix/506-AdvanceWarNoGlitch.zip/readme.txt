Use with:

(No Intro)
Advance Wars (USA) (Rev 1).gba
md5: 04775a93461d24cf1a7e3346d244e516
crc: 26FD0FC9