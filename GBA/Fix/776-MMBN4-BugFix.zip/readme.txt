Use with:

(No Intro)
File:               Mega Man Battle Network 4 - Blue Moon (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              758A46E9
MD5:                E9DFE02B283E29D67C224AB6F86C3B9C