Use with:

(No Intro)
File:               Final Fantasy VI Advance (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              D15DEBA5
MD5:                7F6BF3B4D84F113AA454136E5B53FD77