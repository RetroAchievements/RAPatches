Use with:

(No Intro)
Super Mario Advance 3 - Yoshi's Island (Europe) (En,Fr,De,Es,It).gba
RA Checksum: 5a0bd0ec784823f2c45fdaa5dd914bea
CRC32 Checksum: 639E9D3B