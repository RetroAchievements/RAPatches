Use with:

(No Intro)
File:               Mega Man Zero 3 (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              2784F3F2
MD5:                AA1D5EEFFCD5E4577DB9EE6D9B1100F9