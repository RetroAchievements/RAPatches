Use with:

(No Intro)
Pokemon - Emerald Version (USA, Europe).gba
MD5 - 605b89b67018abcea91e693a4dd25be3
CRC - 1F1C08FB