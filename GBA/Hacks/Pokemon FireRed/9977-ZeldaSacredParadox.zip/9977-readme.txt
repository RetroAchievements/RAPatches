Use with:

(No Intro)
File:               Pokemon - FireRed Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DD88761C
MD5:                E26EE0D44E809351C8CE2D73C7400CDD