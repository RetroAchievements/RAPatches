Use with:

(No-Intro)
File:               Pokemon - FireRed Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DD88761C
MD5:                E26EE0D44E809351C8CE2D73C7400CDD
SHA1:               41CB23D8DCCC8EBD7C649CD8FBB58EEACE6E2FDC
SHA256:             3D0C79F1627022E18765766F6CB5EA067F6B5BF7DCA115552189AD65A5C3A8AC