Use with:

(No-Intro)
File:               Pokemon - FireRed Version (USA, Europe).gba
Size (Bytes):       16777216
CRC32:              dd88761c
MD5:                e26ee0d44e809351c8ce2d73c7400cdd
SHA1:               41cb23d8dccc8ebd7c649cd8fbb58eeace6e2fdc