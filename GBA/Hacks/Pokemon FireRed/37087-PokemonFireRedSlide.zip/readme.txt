Use with:

(No Intro)
File:               Pokemon - FireRed Version (USA, Europe) (Rev 1).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              84EE4776
MD5:                51901A6E40661B3914AA333C802E24E8
SHA1:               DD5945DB9B930750CB39D00C84DA8571FEEBF417
SHA256:             729041B940AFE031302D630FDBE57C0C145F3F7B6D9B8ECA5E98678D0CA4D059