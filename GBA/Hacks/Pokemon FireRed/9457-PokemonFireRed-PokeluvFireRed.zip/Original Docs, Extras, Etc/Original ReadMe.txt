Pokéluv (25 August 2022) by Akiak

https://www.pokecommunity.com/showthread.php?t=398903

HOW TO PLAY:
1) Obtain a ROM (.gba file) of Pokemon Emerald or Pokemon FireRed (BPRE 1.0)
2) Download Lunar IPS if you're on Windows, MultiPatch if you're on Mac (both from romhacking.net)
3) Apply PokeluvEmerald.ips or PokeluvFireRed.ips to the ROM using one of these tools

If you don't want to (or can't) use the randomizer app, use one of the pre-randomized 'Presets' instead!

TO RANDOMIZE:
4) Double-click RunRandomizer (you might need to download Java or JDK)
5) A window will open. Click on File in the top left, then Open, and find and open your patched ROM
6) The recommended settings are already set, so there's no need to change anything unless you want to.
7) Click on File again in the top left, then Save

The terminal window in the back should show a list of numbers up to 386. If it shows a bunch of errors, repeat the steps, but slowly (with a freshly patched ROM).

You're done! Simply close the randomizer, and open the ROM with your preferred emulator :)

FEATURES:

- All 386 Pokemon, including pre-evolutions, have been 'rebalanced' (stats, movesets, abilities etc.) to be at least somewhat viable, but without being unrealistic.
- All level-up and trade evolutions have been replaced by an optional evolution via Rare Candy. Stone evolutions are unchanged.
- Many moves have been rebalanced (full list below)
- 9 new moves, including Poison Jab & Shadow Claw
- Legendary Pokemon have been considerably buffed, and are now uncatchable (think of them as boss fights)
- Based off of Emerald Final & Throwback, which include many QoL features
- A more balanced distribution of single & double battles
- A specially tailored version of Reasonable Randomizer, with competitive movesets for all 386 Pokemon. This is an essential part of the experience, and I don't recommend playing without it.
- Optional Gen 6-style EXP Share from the start (entire party receives 100% of the EXP)

- Scaled EXP system from Gen 5
- Gym leaders have better teams
- Better AI
- Recolored Player Sprites
- 7 new Move Tutors
- Physical/Special split (applied to certain moves)
- HMs don't need to be taught
- Catch rates have been buffed, to make Nuzlocking less painful
- Critical hits nerfed to 1.5x
- Sturdy & Rough Skin have been updated
- Steel no longer resists Ghost
- Poison survival on 1 HP
- Rare Candy substitutes can be bought in certain Pokemarts
- Cleanse Tag nerfs encounter rate by 1/3
- Lucky Eggs can be obtained early on that disable EXP gain (useful for level caps)
- The Master Ball is replaced by TM35, and an extra PP Max is available (hint: scanner) (Emerald)
- Eevee, Tyrogue & Wurmple evolve via Sun Stones (which can be found on wild Gloom & Vileplume) and Moon Stones
- Revamped Battle Tent/Battle Frontier sets (Emerald)

MODIFIED MOVES:

Acid* (45BP 50%spdef drop)
Air Cutter (60BP)
Ancientpower*
Arm Thrust (16BP)
Aurora Beam (20%atk drop)
Barrage (25BP)
Beat Up (12BP)
Bide (+1 priority)
Bite*
Blaze Kick*
Blizzard (110BP)
Bone Rush (85acc)
Bubble (25BP 20%speed drop)
Bubblebeam (20%speed drop)
Bullet Seed (16BP)
Clamp* (95acc)
Comet Punch (95acc)
Covet (45BP)
Confusion (20%conf)
Constrict (15BP 90%speed drop)
Crabhammer*
Crunch*
Cut (crit)
Dig (65BP)
Disable (95acc)
Dive* (65BP)
Dizzy Punch (35%conf)
Doubleslap (16BP 100acc)
Dragon Claw*
Drill Run (replaces Kinesis)
Earth Power* (80BP 20%spdef drop) (replaces Bind)
Eerie Pulse (25BP spatk drop) (replaces Mirror Move)
Egg Bomb (85acc)
Ember (45BP)
False Swipe (45BP)
Fire Blast (110BP)
Fire Spin (20BP 80acc)
Flame Wheel* (65BP 30%burn)
Flamethrower (90BP)
Flash (hits both foes)
Fly (75BP)
Fury Attack (90acc)
Fury Cutter (25BP)
Fury Swipes (85acc)
Future Sight (95BP 95acc)
Giga Drain (10PP)
Glare (95acc)
Grasswhistle (60acc)
Gunk Shot (110BP 30%toxic) (replaces Razor Wind)
Gust* (45BP)
Headache (replaces Extrasensory)
Head Smash (replaces Horn Drill)
Heat Wave (95BP)
Hi Jump Kick (90BP)
Horn Attack (10%flinch)
Hydro Pump (110BP)
Hyper Voice*
Ice Ball*
Ice Beam (90BP)
Icicle Spear* (16BP)
Iron Tail (95BP 80acc)
Jump Kick (75BP)
Knock Off* (25BP)
Leaf Blade*
Leech Life (40BP)
Lick (25BP 50%para)
Mega Drain (15PP)
Megahorn (80acc)
Metal Claw (20%atk buff)
Mimic (is now Mirror Move)
Mud Shot*
Mud Sport (+1 priority)
Mud-Slap (25BP)
Muddy Water (90BP)
Needle Arm*
Octazooka (65%acc drop)
Outrage*
Overheat (130BP)
Peck (40BP)
Petal Dance (80BP)
Pin Missile (90acc)
Poison Fang (70BP 40%toxic)
Poison Gas (60acc)
Poison Jab (20%poison crit) (replaces Poison Tail)
Poison Sting (20BP)
Powder Snow (45BP)
Present (100acc)
Psybeam (20%conf)
Psywave (85acc)
Pursuit*
Rapid Spin (25BP)
Razor Leaf (60BP)
Recover (15PP)
Rock Blast (85acc)
Rock Smash (35BP)
Rock Tomb (55BP 85acc)
Sand Tomb (20BP 80acc)
Secret Power (physical Hidden Power)
Shadow Claw (replaces Crush Claw)
Signal Beam*
Silver Wind*
Sing (95acc)
Smog* (80acc 45%poison)
Snore (45BP)
Spark*
Splash (?)
Steel Wing (20%def buff)
Strength (is now Secret Power)
Supersonic (60acc)
Surf (90BP)
Swift*
Tackle (45BP)
Thief (45BP)
Thunder (110BP)
Thunder Wave (95acc)
Thunderbolt (90BP)
Thundershock (45BP)
Toxic (90acc)
Tri Attack*
Triple Kick (15BP 95acc)
Twineedle (30BP 35%poison)
Twister (45BP)
Uproar* (55BP)
Vine Whip (40BP)
Water Gun (45BP)
Water Sport (+1 priority)
Waterfall* (75BP 95acc crit 10PP)
Whirlpool (20BP 80acc)
Will-O-Wisp (85acc)
X-Scissor (70BP crit) (replaces Doom Desire)

*Physical/Special split applied

MOVE TUTOR LOCATIONS:
Safari, Ship, Mall, Drill, Ice, Bunker, Mount

HM BEHAVIOR (FireRed):
Cut (Grass/Steel/Bug/Psychic)
Fly (Flying/Psychic)
Surf (Water/Ice)
Strength (Fighting/Rock/Psychic)
Flash (doesn't work sadly, need to use normally)
Rock Smash (only need badge)
Waterfall (Water/Flying)
You need both the HM and the badge for all HMs except Rock Smash

RARE CANDY SUBSTITUTES:
Berry Juice can be bought in certain Pokemarts.
For Nuzlockers, see Nuzlocke section of forum thread.

KNOWN BUGS:
Multi-hit moves don't break Sturdy
Entering a double battle with only 1 Pokemon can cause issues

CREDITS:
Pokemon Throwback v21101 by RichterSnipes (https://www.pokecommunity.com/showthread.php?t=285094)
Pokemon Emerald Final v7.38 by dearman4 (https://www.pokecommunity.com/showthread.php?t=410480)
Reasonable Randomizer by LAT10S (https://www.reddit.com/r/PokemonROMhacks/comments/159cta/pokemon_3rd_gen_reasonable_randomizer)
FireRed HM patch: https://www.pokecommunity.com/showthread.php?t=384906

THANKS:
karatekid552, Gamer2020, DoesntKnowHowToPlay, MrDollSteak, Jambo51, esperance, TL, haven1433, SevenChurches, ABZB, LocksmithArmy, Cha Cha Dinosaur, HackMew, Anthroyd, dylan, Lunos, FBI, Uncommon, mbcn10ww, AkameTheBulbasaur, Samu, you

CONTACT:
Akiak#4655 on Discord