import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.System;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;

import java.awt.EventQueue;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.ButtonGroup;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.UIManager;

import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;

public class randomizer implements ActionListener{
	
	//general variables
	int iStarter1 = 0; //0 - random, rest - pkmn id
	int iStarter2 = 0; //0 - random, rest - pkmn id
	int iStarter3 = 0; //0 - random, rest - pkmn id
	int iWildPkmn = 3; //0 - unchanged, 1 - global, 2 - local, 3 - random
	int iTrainerPkmn = 3; //0 - unchanged, 1 - global, 2 - local, 3 - random
	boolean bStarters;
	boolean b3stage;
	boolean bTrio;
	boolean bStrength;
	boolean bHabitat; 
	boolean bNoLegendWild;
	boolean bNoWobs;
	boolean bAllPkmn;
	boolean bTrainer;
	boolean bType;
	boolean bNoLegendTrain;
	boolean bMovesets;
	int iWildStrict;
	int iTrainStrict;
	int iROMGame; //0 - FR, 1 - LG, 2 - Ruby, 3 - Sapphire, 4 - Emerald
	int iROMLang; //0 - Japan, 1 - English, 2 - French
	boolean bDebug = false;
	
	//offset variables
	int iOffStart1;
	int iOffStart2;
	int iOffStart3;
	int iOffMapBegin;
	int iOffMapEnd;
	int iOffTrainerBegin;
	int iOffTrainerEnd;
	int iOffLearned;
	int iOffEgg;
	int iOffTM;
	int iOffEvo;
	int iOffObey1 = 0;
	int iOffObey2 = 0;
	int iOffNatDex;
	
	//misc variables
	File ROMFile;
	JFileChooser fileChooser;
	RandomAccessFile accessor;
	Random rng;
	Moves moves;
	Moveset moveset;
	boolean [] lAllPkmn;
	
	//frame variables
	private JFrame frmPokmonFireredleafgreenRandomizer;
	
	//menu variables
	JMenuItem mntmOpen;
	JMenuItem mntmSave;
	JMenuItem mntmClose;
	JMenuItem mntmExit;
	
	//combo box variables
	JComboBox cmbxPkmn_1;
	JComboBox cmbxPkmn_2;
	JComboBox cmbxPkmn_3;
	
	//radio button variables
	JRadioButton rdbtnW_Unchanged;
	JRadioButton rdbtnW_GlobalSubstitutions;
	JRadioButton rdbtnW_LocalSubstitutions;
	JRadioButton rdbtnW_CompletelyRandom;
	JRadioButton rdbtnT_Unchanged;
	JRadioButton rdbtnT_GlobalSubstitutions;
	JRadioButton rdbtnT_LocalSubstitutions;
	JRadioButton rdbtnT_CompletelyRandom;
	
	//checkbox variables
	JCheckBox chckbxUnevolvedStarters;
	JCheckBox chckbx3EvoStarters;
	JCheckBox chckbxTypeTrio;
	JCheckBox chckbxRetainPokemonStrength;
	JCheckBox chckbxRetainPokemonHabitat;
	JCheckBox chckbxNoWildLegendaries;
	JCheckBox chckbxNoWobs;
	JCheckBox chckbxAllPokemon;
	JCheckBox chckbxRetainTrainerStrength;
	JCheckBox chckbxRetainTypeSpecialties;
	JCheckBox chckbxNoTrainLegendaries;
	JCheckBox chckbxAdvancedMovesets;
	
	//slider variables
	JSlider sldrWildPkmnStrictness;
	JSlider sldrTrainPkmnStrictness;
	
	//label variables
	JLabel lblWildPkmnStrictness;
	JLabel lblTrainPkmnStrictness;
	
	//constants
	//ROM file header
	final String FR_ENG_HEADER = "POKEMON FIREBPRE01";
	final String FR_JAP_HEADER = "POKEMON FIREBPRJ01";
	final String FR_FRA_HEADER = "POKEMON FIREBPRF01";
	final String LG_ENG_HEADER = "POKEMON LEAFBPGE01";
	final String LG_JAP_HEADER = "POKEMON LEAFBPGJ01";
	final String LG_FRA_HEADER = "POKEMON LEAFBPGF01";
	final String RU_ENG_HEADER = "POKEMON RUBYAXVE01";
	final String RU_JAP_HEADER = "POKEMON RUBYAXVJ01";
	final String RU_FRA_HEADER = "POKEMON RUBYAXVF01";
	final String SA_ENG_HEADER = "POKEMON SAPPAXPE01";
	final String SA_JAP_HEADER = "POKEMON SAPPAXPJ01";
	final String SA_FRA_HEADER = "POKEMON SAPPAXPF01";
	final String EM_ENG_HEADER = "POKEMON EMERBPEE01";
	final String EM_JAP_HEADER = "POKEMON EMERBPEJ01";
	final String EM_FRA_HEADER = "POKEMON EMERBPEF01";
	
	//locations of starters in ROMs
	final int FR_ENG_BULB = 0x00169BB5; final int FR_JAP_BULB = 0x0017D1D0; final int FR_FRA_BULB = 0x00169BDC;
	final int FR_ENG_SQRT = 0x00169D82; final int FR_JAP_SQRT = 0x0017D39D; final int FR_FRA_SQRT = 0x00169DA9;
	final int FR_ENG_CHAR = 0x00169DB8; final int FR_JAP_CHAR = 0x0017D3D3; final int FR_FRA_CHAR = 0x00169DDF;
	final int LG_ENG_BULB = 0x00169B91; final int LG_JAP_BULB = 0x0017D1AC; final int LG_FRA_BULB = 0x00169BB8;
	final int LG_ENG_SQRT = 0x00169D5E; final int LG_JAP_SQRT = 0x0017D379; final int LG_FRA_SQRT = 0x00169D85;
	final int LG_ENG_CHAR = 0x00169D94; final int LG_JAP_CHAR = 0x0017D3AF; final int LG_FRA_CHAR = 0x00169DBB;
	final int RU_ENG_TREE = 0x003F76C4; final int RU_JAP_TREE = 0x003D25C8; final int RU_FRA_TREE = 0x003FF3F4;
	final int RU_ENG_TORC = 0x003F76C6; final int RU_JAP_TORC = 0x003D25CA; final int RU_FRA_TORC = 0x003FF3F6;
	final int RU_ENG_MUDK = 0x003F76C8; final int RU_JAP_MUDK = 0x003D25CC; final int RU_FRA_MUDK = 0x003FF3F8;
	final int SA_ENG_TREE = 0x003F771C; final int SA_JAP_TREE = 0x003D25AC; final int SA_FRA_TREE = 0x003FEF24;
	final int SA_ENG_TORC = 0x003F771E; final int SA_JAP_TORC = 0x003D25AE; final int SA_FRA_TORC = 0x003FEF26;
	final int SA_ENG_MUDK = 0x003F7720; final int SA_JAP_MUDK = 0x003D25B0; final int SA_FRA_MUDK = 0x003FEF28;
	final int EM_ENG_TREE = 0x005B1DF8; final int EM_JAP_TREE = 0x00590C08; final int EM_FRA_TREE = 0x005B63E4; 
	final int EM_ENG_TORC = 0x005B1DFA; final int EM_JAP_TORC = 0x00590C0A; final int EM_FRA_TORC = 0x005B63E6;
	final int EM_ENG_MUDK = 0x005B1DFC; final int EM_JAP_MUDK = 0x00590C0C; final int EM_FRA_MUDK = 0x005B63E8;
	
	//locations of map wild pkmn in ROMs
	final int FR_ENG_TANOBY_BEGIN = 0x003C739C; final int FR_JAP_TANOBY_BEGIN = 0x0038E218; final int FR_FRA_TANOBY_BEGIN = 0x003C1714;
	final int FR_ENG_ALTERING_END = 0x003C9CB3; final int FR_JAP_ALTERING_END = 0x00390B2F; final int FR_FRA_ALTERING_END = 0x003C402B;
	final int LG_ENG_TANOBY_BEGIN = 0x003C71D8; final int LG_JAP_TANOBY_BEGIN = 0x0038E088; final int LG_FRA_TANOBY_BEGIN = 0x003C1550;
	final int LG_ENG_ALTERING_END = 0x003C9AEF; final int LG_JAP_ALTERING_END = 0x0039099F; final int LG_FRA_ALTERING_END = 0x003C3E67;
	final int RU_ENG_PETAL_BEGIN = 0x0039B53C; final int RU_JAP_PETAL_BEGIN = 0x003773EC; final int RU_FRA_PETAL_BEGIN = 0x003A21BC;
	final int RU_ENG_UNWATER_END = 0x0039D434; final int RU_JAP_UNWATER_END = 0x003792E4; final int RU_FRA_UNWATER_END = 0x003A40B4;
	final int SA_ENG_PETAL_BEGIN = 0x0039B384; final int SA_JAP_PETAL_BEGIN = 0x003773E4; final int SA_FRA_PETAL_BEGIN = 0x003A2004;
	final int SA_ENG_UNWATER_END = 0x0039D27C; final int SA_JAP_UNWATER_END = 0x003792DC; final int SA_FRA_UNWATER_END = 0x003A3EFC;
	final int EM_ENG_101_BEGIN = 0x005507E0; final int EM_JAP_101_BEGIN = 0x0052B48C; final int EM_FRA_101_BEGIN = 0x005556CC;
	final int EM_ENG_ALTER_END = 0x00552CD4; final int EM_JAP_ALTER_END = 0x0052D980; final int EM_FRA_ALTER_END = 0x00557BC0;
	
	//locations of trainer data in ROMs
	final int FR_ENG_BEN = 0x0023F8B0;    final int FR_JAP_BEN = 0x001FEAF8;    final int FR_FRA_BEN = 0x00239CBC;
	final int FR_ENG_PAXTON = 0x00245EB8; final int FR_JAP_PAXTON = 0x00203C98; final int FR_FRA_PAXTON = 0x002402C4;
	final int LG_ENG_BEN = 0x0023F88C;    final int LG_JAP_BEN = 0x001FEAD4;    final int LG_FRA_BEN = 0x00239C98;
	final int LG_ENG_PAXTON = 0x00245E94; final int LG_JAP_PAXTON = 0x00203C74; final int LG_FRA_PAXTON = 0x002402A0;
	final int RU_ENG_ARCHIE = 0x001F0524; final int RU_JAP_ARCHIE = 0x001C4CB4; final int RU_FRA_ARCHIE = 0x001F892C;
	final int RU_ENG_EUGENE = 0x001F7144; final int RU_JAP_EUGENE = 0x001CA334; final int RU_FRA_EUGENE = 0x001FF54C;
	final int SA_ENG_ARCHIE = 0x001F04B4; final int SA_JAP_ARCHIE = 0x001C4C44; final int SA_FRA_ARCHIE = 0x001F88BC;
	final int SA_ENG_EUGENE = 0x001F70D4; final int SA_JAP_EUGENE = 0x001CA2C4; final int SA_FRA_EUGENE = 0x001FF4DC;
	final int EM_ENG_SAWYER = 0x00310058; final int EM_JAP_SAWYER = 0x002E385C; final int EM_FRA_SAWYER = 0x00317B88;
	final int EM_ENG_MAY = 0x00317858;    final int EM_JAP_MAY = 0x002E985C;    final int EM_FRA_MAY = 0x0031F388;
	
	//locations of move data in ROMs
	final int FR_ENG_LEARNED = 0x0025D7B8; final int FR_JAP_LEARNED = 0x0021A1C0; final int FR_FRA_LEARNED = 0x00257C08;
	final int LG_ENG_LEARNED = 0x0025D798; final int LG_JAP_LEARNED = 0x0021A1A0; final int LG_FRA_LEARNED = 0x00257BE8;
	final int RU_ENG_LEARNED = 0x00207BCC; final int RU_JAP_LEARNED = 0x001D9980; final int RU_FRA_LEARNED = 0x00210018;
	final int SA_ENG_LEARNED = 0x00207B5C; final int SA_JAP_LEARNED = 0x001D9910; final int SA_FRA_LEARNED = 0x0020FFA8;
	final int EM_ENG_LEARNED = 0x00329380; final int EM_JAP_LEARNED = 0x002F9D08; final int EM_FRA_LEARNED = 0x00330EF0;
	final int FR_ENG_EGG = 0x0025EF0C; final int FR_JAP_EGG = 0x0021B918; final int FR_FRA_EGG = 0x0025935C;
	final int LG_ENG_EGG = 0x0025EEEC; final int LG_JAP_EGG = 0x0021B8F8; final int LG_FRA_EGG = 0x0025933C;
	final int RU_ENG_EGG = 0x002091DC; final int RU_JAP_EGG = 0x001DAF78; final int RU_FRA_EGG = 0x00211628;
	final int SA_ENG_EGG = 0x0020916C; final int SA_JAP_EGG = 0x001DAF08; final int SA_FRA_EGG = 0x002115B8;
	final int EM_ENG_EGG = 0x0032ADD8; final int EM_JAP_EGG = 0x002FB764; final int EM_FRA_EGG = 0x00332948;
	final int FR_ENG_TM = 0x00252BD0; final int FR_JAP_TM = 0x0020F5D8; final int FR_FRA_TM = 0x0024D020;
	final int LG_ENG_TM = 0x00252BAC; final int LG_JAP_TM = 0x0020F5B4; final int LG_FRA_TM = 0x0024CFFC;
	final int RU_ENG_TM = 0x001FD0F8; final int RU_JAP_TM = 0x001CEEAC; final int RU_FRA_TM = 0x00205544;
	final int SA_ENG_TM = 0x001FD088; final int SA_JAP_TM = 0x001CEE3C; final int SA_FRA_TM = 0x002054D4;
	final int EM_ENG_TM = 0x0031E8A0; final int EM_JAP_TM = 0x002EF228; final int EM_FRA_TM = 0x00326410;
	
	//locations of evolution data in ROMs
	final int FR_ENG_EVO_BULB  = 0x0025977C; final int FR_JAP_EVO_BULB  = 0x00216184; final int FR_FRA_EVO_BULB  = 0x00253BCC;
	final int FR_ENG_EVO_CHIME = 0x0025D78C; final int FR_JAP_EVO_CHIME = 0x0021A194; final int FR_FRA_EVO_CHIME = 0x00257BDC;
	final int LG_ENG_EVO_BULB  = 0x0025975C; final int LG_JAP_EVO_BULB  = 0x00216164; final int LG_FRA_EVO_BULB  = 0x00253BAC;
	final int LG_ENG_EVO_CHIME = 0x0025D76C; final int LG_JAP_EVO_CHIME = 0x0021A174; final int LG_FRA_EVO_CHIME = 0x00257BBC;
	final int RU_ENG_EVO_BULB  = 0x00203B90; final int RU_JAP_EVO_BULB  = 0x001D5944; final int RU_FRA_EVO_BULB  = 0x0020BFDC;
	final int SA_ENG_EVO_BULB  = 0x00203B20; final int SA_JAP_EVO_BULB  = 0x001D58D4; final int SA_FRA_EVO_BULB  = 0x0020BF6C;
	final int EM_ENG_EVO_BULB  = 0x00325344; final int EM_JAP_EVO_BULB =  0x002F5CCC; final int EM_FRA_EVO_BULB =  0x0032CEB4;
	final int EM_ENG_EVO_CHIME = 0x00329354;
	
	//location of obedience check in ROMs
	final int FR_ENG_OBEY_1 = 0x0001D3F0; final int FR_JAP_OBEY_1 = 0x0001CC00; final int FR_FRA_OBEY_1 = 0x0001D360; 
	final int FR_ENG_OBEY_2 = 0x0001D402; final int FR_JAP_OBEY_2 = 0x0001CC12; final int FR_FRA_OBEY_2 = 0x0001D372;
	final int EM_ENG_OBEY_1 = 0x00045C74; final int EM_JAP_OBEY_1 = 0x000458B4; final int EM_FRA_OBEY_1 = 0x00045C74;
	final int EM_ENG_OBEY_2 = 0x00045C86; final int EM_JAP_OBEY_2 = 0x000458C6; final int EM_FRA_OBEY_2 = 0x00045C86;
	
	//location of nat dex evo block in ROMs
	final int FR_ENG_NATDEX = 0x000CE91A; final int FR_JAP_NATDEX = 0x000CFA36; final int FR_FRA_NATDEX = 0x000CEB7A;
	final int LG_ENG_NATDEX = 0x000CE8EE; final int LG_JAP_NATDEX = 0x000CFA0A; final int LG_FRA_NATDEX = 0x000CEB4E;

	//type constants
	final int T_NORMAL = 0;		final int T_FIRE = 9;
	final int T_FIGHTING = 1;	final int T_WATER = 10;
	final int T_FLYING = 2;		final int T_GRASS = 11;
	final int T_POISON = 3;		final int T_ELECTRIC = 12;
	final int T_GROUND = 4;		final int T_PSYCHIC = 13;
	final int T_ROCK = 5;		final int T_ICE = 14;
	final int T_BUG = 6;		final int T_DRAGON = 15;
	final int T_GHOST = 7;		final int T_DARK = 16;
	final int T_STEEL = 8;
	
	//easy chat constant
	final String [] L_CHAT = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};
	
	//general list data - sorted by national dex number
	final String [] L_POKEMON = {"Random", "Bulbasaur", "Ivysaur", "Venusaur", "Charmander", "Charmeleon", "Charizard", "Squirtle", "Wartortle", "Blastoise", 
            "Caterpie", "Metapod", "Butterfree", "Weedle", "Kakuna", "Beedrill", "Pidgey", "Pidgeotto", "Pidgeot", "Rattata", 
            "Raticate", "Spearow", "Fearow", "Ekans", "Arbok", "Pikachu ", "Raichu", "Sandshrew", "Sandslash", "Nidoran(F)", 
            "Nidorina", "Nidoqueen", "Nidoran(M)", "Nidorino", "Nidoking", "Clefairy", "Clefable", "Vulpix", "Ninetales", "Jigglypuff", 
            "Wigglytuff", "Zubat", "Golbat", "Oddish", "Gloom", "Vileplume", "Paras", "Parasect", "Venonat", "Venomoth", 
            "Diglett", "Dugtrio", "Meowth", "Persian", "Psyduck", "Golduck", "Mankey", "Primeape", "Growlithe", "Arcanine", 
            "Poliwag", "Poliwhirl", "Poliwrath", "Abra", "Kadabra", "Alakazam", "Machop", "Machoke", "Machamp", "Bellsprout", 
            "Weepinbell", "Victreebel", "Tentacool", "Tentacruel", "Geodude", "Graveler", "Golem", "Ponyta", "Rapidash", "Slowpoke", 
            "Slowbro", "Magnemite", "Magneton", "Farfetch'd", "Doduo", "Dodrio", "Seel", "Dewgong", "Grimer", "Muk", 
            "Shellder", "Cloyster", "Gastly", "Haunter", "Gengar", "Onix", "Drowzee", "Hypno", "Krabby", "Kingler", 
            "Voltorb", "Electrode", "Exeggcute", "Exeggutor", "Cubone", "Marowak", "Hitmonlee", "Hitmonchan", "Lickitung", "Koffing", 
            "Weezing", "Rhyhorn", "Rhydon", "Chansey", "Tangela", "Kangaskhan", "Horsea ", "Seadra", "Goldeen", "Seaking", 
            "Staryu", "Starmie", "Mrmime", "Scyther", "Jynx", "Electabuzz", "Magmar", "Pinsir", "Tauros", "Magikarp", 
            "Gyarados", "Lapras", "Ditto", "Eevee", "Vaporeon", "Jolteon", "Flareon", "Porygon", "Omanyte", "Omastar", 
            "Kabuto", "Kabutops", "Aerodactyl", "Snorlax", "Articuno", "Zapdos", "Moltres", "Dratini", "Dragonair ", "Dragonite", 
            "Mewtwo", "Mew", "Chikorita", "Bayleef", "Meganium", "Cyndaquil", "Quilava", "Typhlosion", "Totodile", "Croconaw", 
            "Feraligatr", "Sentret", "Furret", "Hoothoot", "Noctowl", "Ledyba", "Ledian", "Spinarak", "Ariados", "Crobat", 
            "Chinchou", "Lanturn", "Pichu", "Cleffa", "Igglybuff", "Togepi", "Togetic", "Natu", "Xatu", "Mareep", 
            "Flaaffy", "Ampharos", "Bellossom", "Marill", "Azumarill", "Sudowoodo", "Politoed", "Hoppip", "Skiploom", "Jumpluff", 
            "Aipom", "Sunkern", "Sunflora", "Yanma", "Wooper", "Quagsire", "Espeon", "Umbreon", "Murkrow", "Slowking", 
            "Misdreavus", "Unown", "Wobbuffet", "Girafarig", "Pineco", "Forretress", "Dunsparce", "Gligar", "Steelix", "Snubbull", 
            "Granbull", "Qwilfish", "Scizor", "Shuckle", "Heracross", "Sneasel", "Teddiursa", "Ursaring", "Slugma", "Magcargo", 
            "Swinub", "Piloswine", "Corsola", "Remoraid", "Octilerry", "Delibird", "Mantine", "Skarmory", "Houndour", "Houndoom", 
            "Kingdra", "Phanpy ", "Donphan", "Porygon2", "Stantler", "Smeargle", "Tyrogue", "Hitmontop", "Smoochum", "Elekid", 
            "Magby", "Miltank", "Blissey", "Raikou", "Entei", "Suicune", "Larvitar", "Pupitar", "Tyranitar", "Lugia", 
            "Ho-oh", "Celebi", "Treecko", "Grovyle", "Sceptile", "Torchic", "Combusken", "Blaziken", "Mudkip", "Marshtomp", 
            "Swampert", "Poochyena", "Mightyena", "Zigzagoon", "Linoone", "Wurmple", "Silcoon", "Beautifly", "Cascoon", "Dustox", 
            "Lotad", "Lombre", "Ludicolo", "Seedot", "Nuzleaf", "Shiftry", "Taillow", "Swellow", "Wingull", "Pelipper", 
            "Ralts", "Kirlia", "Gardevoir", "Surskit", "Masquerain", "Shroomish", "Breloom", "Slakoth", "Vigoroth", "Slaking", 
            "Nincada", "Ninjask", "Shedinja", "Whismur", "Loudred", "Exploud", "Makuhita", "Hariyama", "Azurill", "Nosepass", 
            "Skitty", "Delcatty", "Sableye", "Mawile", "Aron", "Lairon", "Aggron", "Meditite", "Medicham", "Electrike", 
            "Manectric", "Plusle", "Minun", "Volbeat", "Illumise", "Roselia", "Gulpin", "Swalot", "Carvanha", "Sharpedo", 
            "Wailmer", "Wailord", "Numel", "Camerupt", "Torkoal", "Spoink", "Grumpig", "Spinda", "Trapinch", "Vibrava", 
            "Flygon", "Cacnea", "Cacturne", "Swablu", "Altaria", "Zangoose", "Seviper", "Lunatone", "Solrock", "Barboach", 
            "Whiscash", "Corphish", "Crawdaunt", "Baltoy", "Claydol", "Lileep", "Cradily", "Anorith", "Armaldo", "Feebas", 
            "Milotic", "Castform", "Kecleon", "Shuppet", "Banette", "Duskull", "Dusclops", "Tropius", "Chimecho", "Absol", 
            "Wynaut", "Snorunt", "Glalie", "Spheal", "Sealeo", "Walrein", "Clamperl", "Huntail", "Gorebyss", "Relicanth", 
            "Luvdisc", "Bagon", "Shelgon", "Salamence", "Beldum", "Metang", "Metagross", "Regirock", "Regice", "Registeel", 
            "Latias", "Latios", "Kyogre", "Groudon", "Rayquaza", "Jirachi", "Deoxys"}; //1-indexed, chimecho moved to end

	final int [] L_BASE_STAT = {411, 450, 500, 411, 450, 500, 411, 450, 500, 399,  //0-indexed
            450, 483, 399, 450, 483, 400, 450, 500, 400, 450, 
            400, 475, 400, 452, 400, 452, 400, 452, 400, 450, 
            500, 400, 450, 500, 409, 489, 433, 500, 409, 489, 
            400, 465, 400, 450, 500, 409, 485, 409, 486, 400, 
            485, 400, 480, 400, 488, 400, 485, 412, 500, 400, 
            450, 500, 400, 450, 500, 400, 450, 500, 400, 450, 
            500, 402, 488, 400, 450, 500, 410, 495, 410, 490, 
            400, 492, 403, 419, 484, 400, 486, 410, 487, 410, 
            490, 400, 450, 500, 410, 405, 483, 401, 485, 401, 
            480, 401, 486, 405, 480, 457, 457, 415, 408, 485, 
            410, 470, 445, 435, 490, 400, 440, 400, 455, 408, 
            500, 460, 479, 474, 480, 480, 480, 480, 410, 495, 
            489, 399, 400, 491, 491, 491, 420, 418, 481, 418, 
            481, 490, 500, 580, 580, 580, 401, 450, 500, 680, 
            600, 411, 450, 500, 411, 450, 500, 411, 450, 500, 
            400, 451, 400, 451, 400, 450, 400, 450, 500, 403, 
            471, 400, 400, 400, 400, 455, 402, 470, 402, 449, 
            495, 480, 410, 459, 455, 490, 400, 448, 484, 410, 
            400, 450, 450, 400, 455, 500, 500, 425, 490, 430, 
            400, 489, 450, 400, 470, 419, 428, 500, 410, 460, 
            436, 490, 460, 480, 415, 405, 489, 401, 460, 400, 
            455, 440, 412, 480, 420, 469, 469, 404, 480, 500, 
            410, 475, 480, 452, 419, 400, 460, 400, 400, 400, 
            459, 500, 580, 620, 580, 401, 445, 500, 680, 680, 
            600, 420, 450, 500, 415, 450, 500, 423, 450, 500, 
            403, 459, 400, 456, 400, 413, 459, 413, 459, 410, 
            450, 500, 400, 450, 495, 401, 460, 401, 460, 400, 
            445, 498, 410, 455, 422, 470, 433, 450, 497, 400, 
            460, 475, 412, 450, 495, 429, 480, 401, 433, 405, 
            458, 450, 450, 418, 449, 500, 428, 475, 415, 470, 
            420, 420, 425, 425, 450, 410, 470, 418, 465, 428, 
            480, 415, 465, 466, 402, 470, 430, 402, 430, 490, 
            420, 470, 410, 490, 455, 455, 452, 452, 415, 465, 
            415, 475, 415, 468, 415, 468, 415, 468, 415, 500, 
            421, 461, 418, 465, 418, 465, 465, 445, 469, 430, 
            411, 500, 415, 449, 500, 425, 469, 469, 469, 412, 
            418, 449, 500, 418, 449, 500, 580, 580, 580, 600, 
            600, 670, 670, 680, 600, 600};
	
	final int [] L_HABITAT = {1, 1, 1, 6, 6, 6, 3, 3, 3, 2, 	// 1 = Grassland. 0-indexed
            2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 						//2 = Forest
            7, 7, 1, 1, 2, 2, 7, 7, 1, 1, 						//3 = Water's-edge
            1, 1, 1, 1, 6, 6, 1, 1, 1, 1, 						//4 = Sea
            5, 5, 1, 1, 1, 2, 2, 2, 2, 5, 						//5 = Cave
            5, 8, 8, 3, 3, 6, 6, 1, 1, 3, 						//6 = Mountain
            3, 3, 8, 8, 8, 6, 6, 6, 2, 2, 						//7 = Rough-terrain
            2, 4, 4, 6, 6, 6, 1, 1, 3, 3, 						//8 = Urban
            7, 7, 1, 1, 1, 4, 4, 8, 8, 4, 						//9 = Rare
            4, 5, 5, 5, 5, 1, 1, 3, 3, 8, 
            8, 2, 2, 6, 6, 8, 8, 1, 8, 8, 
            7, 7, 8, 1, 1, 4, 4, 3, 3, 4, 
            4, 8, 1, 8, 1, 6, 2, 1, 3, 3, 
            4, 8, 8, 8, 8, 8, 8, 4, 4, 4, 
            4, 6, 6, 6, 6, 6, 3, 3, 3, 5, 
            2, 1, 1, 1, 1, 1, 1, 3, 3, 3, 
            1, 1, 2, 2, 2, 2, 2, 2, 5, 4, 
            4, 2, 6, 1, 2, 2, 2, 2, 1, 1, 
            1, 1, 3, 3, 2, 3, 1, 1, 1, 2, 
            1, 1, 2, 3, 3, 8, 8, 2, 3, 5, 
            9, 5, 1, 2, 2, 5, 6, 5, 8, 8, 
            4, 1, 6, 2, 2, 6, 6, 6, 6, 5, 
            5, 4, 4, 4, 6, 4, 7, 7, 7, 4, 
            7, 7, 8, 2, 8, 8, 8, 8, 1, 6, 
            1, 8, 1, 1, 1, 6, 6, 6, 4, 1, 
            2, 2, 2, 2, 1, 1, 1, 3, 3, 3, 
            1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 
            3, 3, 2, 2, 2, 1, 1, 4, 4, 8, 
            8, 8, 3, 3, 2, 2, 2, 2, 2, 2, 
            2, 2, 5, 5, 5, 6, 6, 3, 5, 2, 
            2, 5, 5, 6, 6, 6, 6, 6, 1, 1, 
            1, 1, 2, 2, 1, 1, 1, 4, 4, 4, 
            4, 6, 6, 6, 6, 6, 6, 7, 7, 7, 
            7, 7, 2, 2, 1, 1, 5, 5, 3, 3, 
            3, 3, 7, 7, 4, 4, 3, 3, 3, 3, 
            1, 2, 8, 8, 2, 2, 2, 1, 6, 5, 
            5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 
            7, 7, 7, 7, 7, 7, 5, 5, 5, 3, 
            3, 4, 7, 1, 6, 8};
	
	final int [] L_TYPE_1 = {T_GRASS, T_GRASS, T_GRASS, T_FIRE, T_FIRE, T_FIRE, T_WATER, T_WATER, T_WATER, T_BUG, //0-indexed
			T_BUG, T_BUG, T_BUG, T_BUG, T_BUG, T_NORMAL, T_NORMAL, T_NORMAL, T_NORMAL , T_NORMAL , 
			T_NORMAL, T_NORMAL, T_POISON, T_POISON, T_ELECTRIC, T_ELECTRIC, T_GROUND, T_GROUND, T_POISON, T_POISON, 
			T_POISON, T_POISON, T_POISON, T_POISON, T_NORMAL, T_NORMAL, T_FIRE, T_FIRE, T_NORMAL, T_NORMAL, 
			T_POISON, T_POISON, T_GRASS, T_GRASS, T_GRASS, T_BUG, T_BUG, T_BUG, T_BUG, T_GROUND, 
			T_GROUND, T_NORMAL, T_NORMAL, T_WATER, T_WATER, T_FIGHTING, T_FIGHTING, T_FIRE, T_FIRE, T_WATER, 
			T_WATER, T_WATER, T_PSYCHIC, T_PSYCHIC, T_PSYCHIC, T_FIGHTING, T_FIGHTING, T_FIGHTING, T_GRASS, T_GRASS, 
			T_GRASS, T_WATER, T_WATER, T_ROCK, T_ROCK, T_ROCK, T_FIRE, T_FIRE, T_WATER, T_WATER, 
			T_ELECTRIC, T_ELECTRIC, T_NORMAL, T_NORMAL, T_NORMAL, T_WATER, T_WATER, T_POISON, T_POISON, T_WATER, 
			T_WATER, T_GHOST, T_GHOST, T_GHOST, T_ROCK, T_PSYCHIC, T_PSYCHIC, T_WATER, T_WATER, T_ELECTRIC, 
			T_ELECTRIC, T_GRASS, T_GRASS, T_GROUND, T_GROUND, T_FIGHTING, T_FIGHTING, T_NORMAL, T_POISON, T_POISON, 
			T_GROUND, T_GROUND, T_NORMAL, T_GRASS, T_NORMAL, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, 
			T_WATER, T_PSYCHIC, T_BUG, T_ICE, T_ELECTRIC, T_FIRE, T_BUG, T_NORMAL, T_WATER, T_WATER, 
			T_WATER, T_NORMAL, T_NORMAL, T_WATER, T_ELECTRIC, T_FIRE, T_NORMAL, T_ROCK, T_ROCK, T_ROCK, 
			T_ROCK, T_ROCK, T_NORMAL, T_ICE, T_ELECTRIC, T_FIRE, T_DRAGON, T_DRAGON, T_DRAGON, T_PSYCHIC, 
			T_PSYCHIC, T_GRASS, T_GRASS, T_GRASS, T_FIRE, T_FIRE, T_FIRE, T_WATER, T_WATER, T_WATER, 
			T_NORMAL, T_NORMAL, T_NORMAL, T_NORMAL, T_BUG, T_BUG, T_BUG, T_BUG, T_POISON, T_WATER, 
			T_WATER, T_ELECTRIC, T_NORMAL, T_NORMAL, T_NORMAL, T_NORMAL, T_PSYCHIC, T_PSYCHIC, T_ELECTRIC, T_ELECTRIC, 
			T_ELECTRIC, T_GRASS, T_WATER, T_WATER, T_ROCK, T_WATER, T_GRASS, T_GRASS, T_GRASS, T_NORMAL, 
			T_GRASS, T_GRASS, T_BUG, T_WATER, T_WATER, T_PSYCHIC, T_DARK, T_DARK, T_WATER, T_GHOST, 
			T_PSYCHIC, T_PSYCHIC, T_NORMAL, T_BUG, T_BUG, T_NORMAL, T_GROUND, T_STEEL, T_NORMAL, T_NORMAL, 
			T_WATER, T_BUG, T_BUG, T_BUG, T_DARK, T_NORMAL, T_NORMAL, T_FIRE, T_FIRE, T_ICE, 
			T_ICE, T_WATER, T_WATER, T_WATER, T_ICE, T_WATER, T_STEEL, T_DARK, T_DARK, T_WATER, 
			T_GROUND, T_GROUND, T_NORMAL, T_NORMAL, T_NORMAL, T_FIGHTING, T_FIGHTING, T_ICE, T_ELECTRIC, T_FIRE, 
			T_NORMAL, T_NORMAL, T_ELECTRIC, T_FIRE, T_WATER, T_ROCK, T_ROCK, T_ROCK, T_PSYCHIC, T_FIRE, 
			T_PSYCHIC, T_GRASS, T_GRASS, T_GRASS, T_FIRE, T_FIRE, T_FIRE, T_WATER, T_WATER, T_WATER, 
			T_DARK, T_DARK, T_NORMAL, T_NORMAL, T_BUG, T_BUG, T_BUG, T_BUG, T_BUG, T_WATER, 
			T_WATER, T_WATER, T_GRASS, T_GRASS, T_GRASS, T_NORMAL, T_NORMAL, T_WATER, T_WATER, T_PSYCHIC, 
			T_PSYCHIC, T_PSYCHIC, T_WATER, T_BUG, T_GRASS, T_GRASS, T_NORMAL, T_NORMAL, T_NORMAL, T_BUG, 
			T_BUG, T_BUG, T_NORMAL, T_NORMAL, T_NORMAL, T_FIGHTING, T_FIGHTING, T_NORMAL, T_ROCK, T_NORMAL, 
			T_NORMAL, T_DARK, T_STEEL, T_STEEL, T_STEEL, T_STEEL, T_PSYCHIC, T_PSYCHIC, T_ELECTRIC, T_ELECTRIC, 
			T_ELECTRIC, T_ELECTRIC, T_BUG, T_BUG, T_GRASS, T_POISON, T_POISON, T_WATER, T_WATER, T_WATER, 
			T_WATER, T_FIRE, T_FIRE, T_FIRE, T_PSYCHIC, T_PSYCHIC, T_NORMAL, T_GROUND, T_GROUND, T_GROUND, 
			T_GRASS, T_GRASS, T_NORMAL, T_DRAGON, T_NORMAL, T_POISON, T_ROCK, T_ROCK, T_WATER, T_WATER, 
			T_WATER, T_WATER, T_GROUND, T_GROUND, T_ROCK, T_ROCK, T_ROCK, T_ROCK, T_WATER, T_WATER, 
			T_NORMAL, T_NORMAL, T_GHOST, T_GHOST, T_GHOST, T_GHOST, T_GRASS, T_PSYCHIC, T_DARK, T_PSYCHIC, 
			T_ICE, T_ICE, T_ICE, T_ICE, T_ICE, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, 
			T_DRAGON, T_DRAGON, T_DRAGON, T_STEEL, T_STEEL, T_STEEL, T_ROCK, T_ICE, T_STEEL, T_DRAGON, 
			T_DRAGON, T_WATER, T_GROUND, T_DRAGON, T_STEEL, T_PSYCHIC};

	final int [] L_TYPE_2 = {T_POISON, T_POISON, T_POISON, T_FIRE, T_FIRE, T_FLYING, T_WATER, T_WATER, T_WATER, T_BUG, //0-indexed
			T_BUG, T_FLYING, T_POISON, T_POISON, T_POISON, T_FLYING, T_FLYING, T_FLYING, T_NORMAL , T_NORMAL , 
			T_FLYING, T_FLYING, T_POISON, T_POISON, T_ELECTRIC, T_ELECTRIC, T_GROUND, T_GROUND, T_POISON, T_POISON, 
			T_GROUND, T_POISON, T_POISON, T_GROUND, T_NORMAL, T_NORMAL, T_FIRE, T_FIRE, T_NORMAL, T_NORMAL, 
			T_FLYING, T_FLYING, T_POISON, T_POISON, T_POISON, T_GRASS, T_GRASS, T_POISON, T_POISON, T_GROUND, 
			T_GROUND, T_NORMAL, T_NORMAL, T_WATER, T_WATER, T_FIGHTING, T_FIGHTING, T_FIRE, T_FIRE, T_WATER, 
			T_WATER, T_FIGHTING, T_PSYCHIC, T_PSYCHIC, T_PSYCHIC, T_FIGHTING, T_FIGHTING, T_FIGHTING, T_POISON, T_POISON, 
			T_POISON, T_POISON, T_POISON, T_GROUND, T_GROUND, T_GROUND, T_FIRE, T_FIRE, T_PSYCHIC, T_PSYCHIC, 
			T_STEEL, T_STEEL, T_FLYING, T_FLYING, T_FLYING, T_WATER, T_ICE, T_POISON, T_POISON, T_WATER, 
			T_ICE, T_POISON, T_POISON, T_POISON, T_GROUND, T_PSYCHIC, T_PSYCHIC, T_WATER, T_WATER, T_ELECTRIC, 
			T_ELECTRIC, T_PSYCHIC, T_PSYCHIC, T_GROUND, T_GROUND, T_FIGHTING, T_FIGHTING, T_NORMAL, T_POISON, T_POISON, 
			T_ROCK, T_ROCK, T_NORMAL, T_GRASS, T_NORMAL, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, 
			T_PSYCHIC, T_PSYCHIC, T_FLYING, T_PSYCHIC, T_ELECTRIC, T_FIRE, T_BUG, T_NORMAL, T_WATER, T_FLYING, 
			T_ICE, T_NORMAL, T_NORMAL, T_WATER, T_ELECTRIC, T_FIRE, T_NORMAL, T_WATER, T_WATER, T_WATER, 
			T_WATER, T_FLYING, T_NORMAL, T_FLYING, T_FLYING, T_FLYING, T_DRAGON, T_DRAGON, T_FLYING, T_PSYCHIC, 
			T_PSYCHIC, T_GRASS, T_GRASS, T_GRASS, T_FIRE, T_FIRE, T_FIRE, T_WATER, T_WATER, T_WATER, 
			T_NORMAL, T_NORMAL, T_FLYING, T_FLYING, T_FLYING, T_FLYING, T_POISON, T_POISON, T_FLYING, T_ELECTRIC, 
			T_ELECTRIC, T_ELECTRIC, T_NORMAL, T_NORMAL, T_NORMAL, T_FLYING, T_FLYING, T_FLYING, T_ELECTRIC, T_ELECTRIC, 
			T_ELECTRIC, T_GRASS, T_WATER, T_WATER, T_ROCK, T_WATER, T_FLYING, T_FLYING, T_FLYING, T_NORMAL, 
			T_GRASS, T_GRASS, T_FLYING, T_GROUND, T_GROUND, T_PSYCHIC, T_DARK, T_FLYING, T_PSYCHIC, T_GHOST, 
			T_PSYCHIC, T_PSYCHIC, T_PSYCHIC, T_BUG, T_STEEL, T_NORMAL, T_FLYING, T_GROUND, T_NORMAL, T_NORMAL, 
			T_POISON, T_STEEL, T_ROCK, T_FIGHTING, T_ICE, T_NORMAL, T_NORMAL, T_FIRE, T_ROCK, T_GROUND, 
			T_GROUND, T_ROCK, T_WATER, T_WATER, T_FLYING, T_FLYING, T_FLYING, T_FIRE, T_FIRE, T_DRAGON, 
			T_GROUND, T_GROUND, T_NORMAL, T_NORMAL, T_NORMAL, T_FIGHTING, T_FIGHTING, T_PSYCHIC, T_ELECTRIC, T_FIRE, 
			T_NORMAL, T_NORMAL, T_ELECTRIC, T_FIRE, T_WATER, T_GROUND, T_GROUND, T_DARK, T_FLYING, T_FLYING, 
			T_GRASS, T_GRASS, T_GRASS, T_GRASS, T_FIRE, T_FIGHTING, T_FIGHTING, T_WATER, T_GROUND, T_GROUND, 
			T_DARK, T_DARK, T_NORMAL, T_NORMAL, T_BUG, T_BUG, T_FLYING, T_BUG, T_POISON, T_GRASS, 
			T_GRASS, T_GRASS, T_GRASS, T_DARK, T_DARK, T_FLYING, T_FLYING, T_FLYING, T_FLYING, T_PSYCHIC, 
			T_PSYCHIC, T_PSYCHIC, T_BUG, T_FLYING, T_GRASS, T_FIGHTING, T_NORMAL, T_NORMAL, T_NORMAL, T_GROUND, 
			T_FLYING, T_GHOST, T_NORMAL, T_NORMAL, T_NORMAL, T_FIGHTING, T_FIGHTING, T_NORMAL, T_ROCK, T_NORMAL, 
			T_NORMAL, T_GHOST, T_STEEL, T_ROCK, T_ROCK, T_ROCK, T_FIGHTING, T_FIGHTING, T_ELECTRIC, T_ELECTRIC, 
			T_ELECTRIC, T_ELECTRIC, T_BUG, T_BUG, T_POISON, T_POISON, T_POISON, T_DARK, T_DARK, T_WATER, 
			T_WATER, T_GROUND, T_GROUND, T_FIRE, T_PSYCHIC, T_PSYCHIC, T_NORMAL, T_GROUND, T_DRAGON, T_DRAGON, 
			T_GRASS, T_GRASS, T_FLYING, T_FLYING, T_NORMAL, T_POISON, T_PSYCHIC, T_PSYCHIC, T_GROUND, T_GROUND, 
			T_WATER, T_DARK, T_PSYCHIC, T_PSYCHIC, T_GRASS, T_GRASS, T_BUG, T_BUG, T_WATER, T_WATER, 
			T_NORMAL, T_NORMAL, T_GHOST, T_GHOST, T_GHOST, T_GHOST, T_FLYING, T_PSYCHIC, T_DARK, T_PSYCHIC, 
			T_ICE, T_ICE, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, T_WATER, 
			T_DRAGON, T_DRAGON, T_FLYING, T_PSYCHIC, T_PSYCHIC, T_PSYCHIC, T_ROCK, T_ICE, T_STEEL, T_PSYCHIC, 
			T_PSYCHIC, T_WATER, T_GROUND, T_FLYING, T_PSYCHIC, T_PSYCHIC};
	
	final int [][] L_TYPE_EFF = { //0 - NFE, 1 - effective, 2 - super-effective. left is attacking, top is defending
				//NOR FGT FLY POI GRO ROC BUG GHO STE FIR WAT GRA ELE PSY ICE DRA DAR
		/*NOR*/	 {1,  1,  1,  1,  1,  0,  1,  0,  0,  1,  1,  1,  1,  1,  1,  1,  1  }, 
		/*FGT*/	 {2,  1,  0,  0,  1,  2,  0,  0,  2,  1,  1,  1,  1,  0,  2,  1,  2  }, 
		/*FLY*/	 {1,  2,  1,  1,  1,  0,  2,  1,  0,  1,  1,  2,  0,  1,  1,  1,  1  }, 
		/*POI*/	 {1,  1,  1,  0,  0,  0,  1,  0,  0,  1,  1,  2,  1,  1,  1,  1,  1  }, 
		/*GRO*/	 {1,  1,  0,  2,  1,  2,  0,  1,  2,  2,  1,  0,  2,  1,  1,  1,  1  }, 
		/*ROC*/	 {1,  0,  2,  1,  0,  1,  2,  1,  0,  2,  1,  1,  1,  1,  2,  1,  1  }, 
		/*BUG*/	 {1,  0,  0,  0,  1,  1,  1,  0,  0,  0,  1,  2,  1,  2,  1,  1,  2  }, 
		/*GHO*/	 {0,  1,  1,  1,  1,  1,  1,  2,  0,  1,  1,  1,  1,  2,  1,  1,  0  }, 
		/*STE*/	 {1,  1,  1,  1,  1,  2,  1,  1,  0,  0,  0,  1,  0,  1,  2,  1,  1  }, 
		/*FIR*/	 {1,  1,  1,  1,  1,  0,  2,  1,  2,  0,  0,  2,  1,  1,  2,  0,  1  }, 
		/*WAT*/	 {1,  1,  1,  1,  2,  2,  1,  1,  1,  2,  0,  0,  1,  1,  1,  0,  1  }, 
		/*GRA*/	 {1,  1,  0,  0,  2,  2,  0,  1,  0,  0,  2,  0,  1,  1,  1,  0,  1  }, 
		/*ELE*/	 {1,  1,  2,  1,  0,  1,  1,  1,  1,  1,  2,  0,  0,  1,  1,  0,  1  }, 
		/*PSY*/	 {1,  2,  1,  2,  1,  1,  1,  1,  0,  1,  1,  1,  1,  0,  1,  1,  0  }, 
		/*ICE*/	 {1,  1,  2,  1,  2,  1,  1,  1,  0,  0,  0,  2,  1,  1,  0,  2,  1  }, 
		/*DRA*/	 {1,  1,  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1,  2,  1  }, 
		/*DAR*/	 {1,  0,  1,  1,  1,  1,  1,  2,  0,  1,  1,  1,  1,  2,  1,  1,  0  }
	};
	
	final int [] L_CONV = {277, 278, 279, 280, 281, 282, 283, 284, 285, 286, //starts at Treecko, ends at Deoxys
			          287, 288, 289, 290, 291, 292, 293, 294, 295, 296, 
			          297, 298, 299, 300, 304, 305, 309, 310, 392, 393, 
			          394, 311, 312, 306, 307, 364, 365, 366, 301, 302, 
			          303, 370, 371, 372, 335, 336, 350, 320, 315, 316, 
			          322, 355, 382, 383, 384, 356, 357, 337, 338, 353, 
			          354, 386, 387, 363, 367, 368, 330, 331, 313, 314, 
			          339, 340, 321, 351, 352, 308, 332, 333, 334, 344, 
			          345, 358, 359, 380, 379, 348, 349, 323, 324, 326, 
			          327, 318, 319, 388, 389, 390, 391, 328, 329, 385, 
			          317, 377, 378, 361, 362, 369, 411, 376, 360, 346, 
			          347, 341, 342, 343, 373, 374, 375, 381, 325, 395, 
			          396, 397, 398, 399, 400, 401, 402, 403, 407, 408, 
			          404, 405, 406, 409, 410};
	
	final boolean [] L_EVO = {true, false, false, true, false, false, true, false, false, true, //0-indexed. True if not evolved, false if evolved.
	          false, false, true, false, false, true, false, false, true, false, 
	          true, false, true, false, false, false, true, false, true, false, 
	          false, true, false, false, false, false, true, false, false, false, 
	          true, false, true, false, false, true, false, true, false, true, 
	          false, true, false, true, false, true, false, true, false, true, 
	          false, false, true, false, false, true, false, false, true, false, 
	          false, true, false, true, false, false, true, false, true, false, 
	          true, false, true, true, false, true, false, true, false, true, 
	          false, true, false, false, true, true, false, true, false, true, 
	          false, true, false, true, false, false, false, true, true, false, 
	          true, false, true, true, true, true, false, true, false, true, 
	          false, true, true, false, false, false, true, true, true, false, 
	          true, true, true, false, false, false, true, true, false, true, 
	          false, true, true, false, false, false, true, false, false, false, 
	          false, true, false, false, true, false, false, true, false, false, //mew (151), chikorita, bayleef...
	          true, false, true, false, true, false, true, false, false, true, 
	          false, true, true, true, true, false, true, false, true, false, 
	          false, false, false, false, true, false, true, false, false, true, 
	          true, false, true, true, false, false, false, true, false, true, 
	          true, false, true, true, false, true, true, false, true, false, 
	          true, false, true, true, true, true, false, true, false, true, 
	          false, true, true, false, true, true, true, true, false, false, 
	          true, false, true, true, true, true, false, true, true, true, 
	          true, false, false, false, false, true, false, false, false, false, 
	          false, true, false, false, true, false, false, true, false, false, //celebi (251), treecko, grovyle...
	          true, false, true, false, true, false, false, false, false, true, 
	          false, false, true, false, false, true, false, true, false, true, 
	          false, false, true, false, true, false, true, false, false, true, 
	          false, false, true, false, false, true, false, true, true, true, 
	          false, true, true, true, false, false, true, false, true, false, 
	          true, true, true, true, true, true, false, true, false, true, 
	          false, true, false, true, true, false, true, true, false, false, 
	          true, false, true, false, true, true, true, true, true, false, 
	          true, false, true, false, true, false, true, false, true, false, 
	          true, true, true, false, true, false, true, true, true, true, 
	          true, false, true, false, false, true, false, false, true, true, 
	          true, false, false, true, false, false, false, false, false, false, 
	          false, false, false, false, false, false};
	
	final boolean [] L_EVO3 = {true, false, false, true, false, false, true, false, false, true, //0-indexed. True if not evolved, false if evolved.
	          false, false, true, false, false, true, false, false, false, false, 
	          false, false, false, false, false, false, false, false, true, false, 
	          false, true, false, false, false, false, false, false, false, false, 
	          true, false, true, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, true, 
	          false, false, true, false, false, true, false, false, true, false, 
	          false, false, false, true, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, true, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, true, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, true, false, false, false, 
	          false, true, false, false, true, false, false, true, false, false, //mew (151), chikorita, bayleef...
	          false, false, false, false, false, false, false, false, false, false, 
	          false, true, true, true, false, false, false, false, true, false, 
	          false, false, false, false, false, false, true, false, false, false,
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, true, false, 
	          false, false, false, false, false, true, false, false, false, false, 
	          false, true, false, false, true, false, false, true, false, false, //celebi (251), treecko, grovyle...
	          false, false, false, false, true, false, false, false, false, true, 
	          false, false, true, false, false, false, false, false, false, true, 
	          false, false, false, false, false, false, true, false, false, false, 
	          false, false, true, false, false, false, false, true, false, false, 
	          false, false, false, true, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, true, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, false, false, false, false, false, false, false, false, 
	          false, false, true, false, false, false, false, false, false, false, 
	          true, false, false, true, false, false, false, false, false, false, 
	          false, false, false, false, false, false};
	
	final int [] L_LEGENDARIES = {144, 145, 146, 150, 151, 243, 244, 245, 249, 250, 251, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386}; //legendaries list, nat dex #
	
	public static void main(final String[] args) throws IOException {
		/*
		 * Notes:
		 *  - 2 ways to store pkmn ID number - A and B
		 *     - A - Identical to national dex. Format used within program. 1-indexed. Ranges from 1-386.
		 *     - B - Pokemon index number. Format used within ROM. 1-indexed. Ranges from 1-411.
		 *     - L_CONV converts between the two: pkmnA = L_CONV[pkmnB - 252], and pkmnB = indexOf(L_CONV, pkmnA) + 252.
		 */
		//Displaying GUI
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					randomizer window = new randomizer();
					window.frmPokmonFireredleafgreenRandomizer.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void actionPerformed(ActionEvent e){
		//menu option
		if (e.getSource() == mntmOpen) {
			//Open ROM file
			//utility.print("Opening File");
			fileChooser = new JFileChooser(); //customize file opener
			fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			ROMFilter instROMFilter = new ROMFilter();
			fileChooser.addChoosableFileFilter(instROMFilter);
			fileChooser.setFileFilter(instROMFilter);
			fileChooser.setAcceptAllFileFilterUsed(false);
			
			int returnVal = fileChooser.showOpenDialog(fileChooser);
			if (returnVal == JFileChooser.APPROVE_OPTION) 
			{
				ROMFile = fileChooser.getSelectedFile();
				//set file accessor
				accessor = null;
				try {
					accessor = new RandomAccessFile (ROMFile, "rw");
				} catch (FileNotFoundException e2) {
					e2.printStackTrace();
				}
				try {
					//Determine ROM version, language
					accessor.seek(0xA0);
					String sROMType = accessor.readLine();
					sROMType = sROMType.substring(0, 0xB1 - 0xA0 + 1);
					boolean bSuccess;
					
					//Set offsets
					bSuccess = setOffsets(sROMType);
					
					if (bSuccess)
					{
						//set starters in combo box
						accessor.seek(iOffStart1);
						//cmbxPkmn_1.setSelectedIndex(readPKMN(accessor));
						accessor.seek(iOffStart2);
						//cmbxPkmn_2.setSelectedIndex(readPKMN(accessor));
						accessor.seek(iOffStart3);
						//cmbxPkmn_3.setSelectedIndex(readPKMN(accessor));
						
						//generate move data lists
						moves = new Moves();
						moves.genLearned(accessor, iOffLearned, L_CONV);
						moves.genEgg(accessor, iOffEgg, iOffEvo, L_EVO, L_CONV);
						moves.genTM(accessor, iOffTM, L_CONV);
						moveset = new Moveset();
						
						//enable buttons after file open
						setAllEnabled(true);
						
						//print for debugging
						//String [] lGames = {"Fire Red", "Leaf Green", "Ruby", "Sapphire", "Emerald"};
						//String [] lLangs = {"Japanese", "English", "French"};
						//utility.print(lGames[iROMGame] + " - " + lLangs[iROMLang]);
					}
					else
					{
						//display warning
						JFrame frmWarning = new JFrame();
						JOptionPane.showMessageDialog(frmWarning , "The ROM given is not supported\n" +
								"The randomizer works with FireRed, LeafGreen, Ruby, Sapphire, and Emerald ROMs,\n" +
								"and with the English, Japanese, and French languages");
					}
				}
				catch (IOException e2){
					e2.printStackTrace();
				}
			}
			else
			{
				//display warning
				//JFrame frmWarning = new JFrame();
				//JOptionPane.showMessageDialog(frmWarning , "The ROM given is not supported");
				//utility.print("ERROR: FILE NOT APPROVED");
			}
		}
		else if (e.getSource() == mntmSave) 
			randomize();
		else if (e.getSource() == mntmClose) 
		{
			//utility.print("Closing file");
			try {
				accessor.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
			setAllEnabled(false);
		}
		else if (e.getSource() == mntmExit) 
			frmPokmonFireredleafgreenRandomizer.dispose();
		
		//starter options
		else if (e.getSource() == cmbxPkmn_1) //pkmn 1
			iStarter1 = cmbxPkmn_1.getSelectedIndex();
		else if (e.getSource() == cmbxPkmn_2) //pkmn 2
			iStarter2 = cmbxPkmn_2.getSelectedIndex();
		else if (e.getSource() == cmbxPkmn_3) //pkmn 3
			iStarter3 = cmbxPkmn_3.getSelectedIndex();
		
		//wild pkmn options
		else if (e.getSource() == rdbtnW_Unchanged)
			iWildPkmn = 0;
		else if (e.getSource() == rdbtnW_GlobalSubstitutions)
			iWildPkmn = 1;
		else if (e.getSource() == rdbtnW_LocalSubstitutions)
			iWildPkmn = 2;
		else if (e.getSource() == rdbtnW_CompletelyRandom)
			iWildPkmn = 3;
		
		//trainer pkmn options
		else if (e.getSource() == rdbtnT_Unchanged)
			iTrainerPkmn = 0;
		else if (e.getSource() == rdbtnT_GlobalSubstitutions)
			iTrainerPkmn = 1;
		else if (e.getSource() == rdbtnT_LocalSubstitutions)
			iTrainerPkmn = 2;
		else if (e.getSource() == rdbtnT_CompletelyRandom)
			iTrainerPkmn = 3;
		
		//options
		else if (e.getSource() == chckbxUnevolvedStarters)
			bStarters = !bStarters;
		else if (e.getSource() == chckbx3EvoStarters)
			b3stage = !b3stage;
		else if (e.getSource() == chckbxTypeTrio)
			bTrio = !bTrio;
		else if (e.getSource() == chckbxRetainPokemonStrength)
			bStrength = !bStrength;
		else if (e.getSource() == chckbxRetainPokemonHabitat)
			bHabitat = !bHabitat;
		else if (e.getSource() == chckbxNoWildLegendaries)
			bNoLegendWild = !bNoLegendWild;
		else if (e.getSource() == chckbxAllPokemon)
			bAllPkmn = !bAllPkmn;
		else if (e.getSource() == chckbxNoWobs)
			bNoWobs = !bNoWobs;
		else if (e.getSource() == chckbxRetainTrainerStrength)
			bTrainer = !bTrainer;
		else if (e.getSource() == chckbxRetainTypeSpecialties)
			bType = !bType;
		else if (e.getSource() == chckbxNoTrainLegendaries)
			bNoLegendTrain = !bNoLegendTrain;
		else if (e.getSource() == chckbxAdvancedMovesets)
			bMovesets = !bMovesets;
	}
	
	private void randomize()
	{
		//Alters ROM file according to options set
		try
		{
			//disable obedience check
			if (iROMGame == 0 || iROMGame == 1 || iROMGame == 4) //if FR/LG or Emerald
			{
				accessor.seek(iOffObey1); //sets 4 bytes to 0
				accessor.writeInt(0); 
				accessor.seek(iOffObey2);
				accessor.writeInt(0);
			}
			
			//fix evolution problem in FR/LG
			if (iROMGame == 0 || iROMGame == 1)
			{
				accessor.seek(iOffNatDex);
				accessor.writeByte(0x00);
				accessor.writeByte(0x00);
				accessor.writeByte(0x14);
				accessor.writeByte(0xE0);
			}
			
			//randomize starters
			int ret1 = iStarter1, ret2 = iStarter2, ret3 = iStarter3;
			boolean done1 = false;
			while (!done1)
			{
				if (iStarter1 == 0) //random
				{
					ret1 = replacePKMN(accessor, iOffStart1, false, false, false, bStarters, b3stage, false, false, false, 1, 0, 0, -1, -1);
					//utility.print("Starter 1: " + L_POKEMON[ret1]);
				}
				else //set
				{
					accessor.seek(iOffStart1);
					writePKMN(accessor, iStarter1);
				}
				
				if (iStarter2 == 0) //random
				{
					ret2 = replacePKMN(accessor, iOffStart2, false, false, false, bStarters, b3stage, false, false, false, 4, 0, 0, -1, -1);
					//utility.print("Starter 2: " + L_POKEMON[ret2]);
				}
				else //set
				{
					accessor.seek(iOffStart2);
					writePKMN(accessor, iStarter2);
				}
				
				if (iStarter3 == 0) //random
				{
					ret3 = replacePKMN(accessor, iOffStart3, false, false, false, bStarters, b3stage, false, false, false, 7, 0, 0, -1, -1);
					//utility.print("Starter 3: " + L_POKEMON[ret3]);
				}
				else //set
				{
					accessor.seek(iOffStart3);
					writePKMN(accessor, iStarter3);
				}
				
				if (iStarter1 != 0 && iStarter2 != 0 && iStarter3 != 0)  //if all starters set
				{
					done1 = true;
				}
				else if (!bTrio) //if trio option not selected
				{
					done1 = true;
				}
				else if ((iROMGame == 0 || iROMGame == 1) &&
						((L_TYPE_EFF[L_TYPE_1[ret1-1]][L_TYPE_1[ret2-1]] * L_TYPE_EFF[L_TYPE_1[ret1-1]][L_TYPE_2[ret2-1]] > 1) || //if starter 1 type adv on starter 2
						(L_TYPE_EFF[L_TYPE_2[ret1-1]][L_TYPE_1[ret2-1]] * L_TYPE_EFF[L_TYPE_2[ret1-1]][L_TYPE_2[ret2-1]] > 1)) &&
						((L_TYPE_EFF[L_TYPE_1[ret2-1]][L_TYPE_1[ret3-1]] * L_TYPE_EFF[L_TYPE_1[ret2-1]][L_TYPE_2[ret3-1]] > 1) || //if starter 2 type adv on starter 3
						(L_TYPE_EFF[L_TYPE_2[ret2-1]][L_TYPE_1[ret3-1]] * L_TYPE_EFF[L_TYPE_2[ret2-1]][L_TYPE_2[ret3-1]] > 1)) &&
						((L_TYPE_EFF[L_TYPE_1[ret3-1]][L_TYPE_1[ret1-1]] * L_TYPE_EFF[L_TYPE_1[ret3-1]][L_TYPE_2[ret1-1]] > 1) || //if starter 3 type adv on starter 1
						(L_TYPE_EFF[L_TYPE_2[ret3-1]][L_TYPE_1[ret1-1]] * L_TYPE_EFF[L_TYPE_2[ret3-1]][L_TYPE_2[ret1-1]] > 1)))
				{
					done1 = true;
				}
				else if ((iROMGame == 2 || iROMGame == 3 || iROMGame == 4) &&
						((L_TYPE_EFF[L_TYPE_1[ret1-1]][L_TYPE_1[ret3-1]] * L_TYPE_EFF[L_TYPE_1[ret1-1]][L_TYPE_2[ret3-1]] > 1) || //if starter 1 type adv on starter 3
						(L_TYPE_EFF[L_TYPE_2[ret1-1]][L_TYPE_1[ret3-1]] * L_TYPE_EFF[L_TYPE_2[ret1-1]][L_TYPE_2[ret3-1]] > 1)) &&
						((L_TYPE_EFF[L_TYPE_1[ret2-1]][L_TYPE_1[ret1-1]] * L_TYPE_EFF[L_TYPE_1[ret2-1]][L_TYPE_2[ret1-1]] > 1) || //if starter 2 type adv on starter 1
						(L_TYPE_EFF[L_TYPE_2[ret2-1]][L_TYPE_1[ret1-1]] * L_TYPE_EFF[L_TYPE_2[ret2-1]][L_TYPE_2[ret1-1]] > 1)) &&
						((L_TYPE_EFF[L_TYPE_1[ret3-1]][L_TYPE_1[ret2-1]] * L_TYPE_EFF[L_TYPE_1[ret3-1]][L_TYPE_2[ret2-1]] > 1) || //if starter 3 type adv on starter 2
						(L_TYPE_EFF[L_TYPE_2[ret3-1]][L_TYPE_1[ret2-1]] * L_TYPE_EFF[L_TYPE_2[ret3-1]][L_TYPE_2[ret2-1]] > 1)))
				{
					done1 = true;
				}

			}
			
			//randomize wild pokemon
			if (iWildPkmn != 0) //global/local/random
			{
				accessor.seek(iOffMapBegin);
				int [] l_mapping = new int[386+1]; //mapping for global/local subs
				Arrays.fill(l_mapping, 0);
				Arrays.fill(lAllPkmn, false);
				if (bNoWobs)
				{
					lAllPkmn[202-1] = true;
					lAllPkmn[360-1] = true;
				}
				if (bNoLegendWild)
				{
					for (int i = 0; i < L_LEGENDARIES.length; i++)
					{
						lAllPkmn[L_LEGENDARIES[i]-1] = true;
					}
				}
				boolean bNotAllPkmnChosen = true; 
				boolean done;
				int iPos, iPoke, ret, iMedBs, iUpBs = 0, iLoBs = 0, iSlotNo;
				while (accessor.getFilePointer() < iOffMapEnd) //for each region
				{
					if (iWildPkmn == 2) //if local subs
						Arrays.fill(l_mapping, 0); //clear local mapping
					accessor.skipBytes(4); //skip over 4 byte header
					done = false;
					iSlotNo = 0;
					//utility.print("---Region---");
					while (!done) //for each slot in region
					{
						accessor.skipBytes(2); //skip over min/max level
						iPos = (int) accessor.getFilePointer(); //save location
						iPoke = readPKMN(accessor); //get current pkmn, 1-indexed
						if (iPoke == 0) //at encounter ratio
						{
							done = true;
						}
						else if (l_mapping[iPoke] != 0 && iWildPkmn != 3)
						{
							accessor.seek(iPos);
							writePKMN(accessor, l_mapping[iPoke]);
							//utility.print(L_POKEMON[iPoke] + " > " + L_POKEMON[l_mapping[iPoke]]);
						}
						else
						{
							if (bStrength)
							{
								//iMedBs = (int) ((L_BASE_STAT[iPoke-1] - 340) * (L_BASE_STAT[iPoke-1] - 340) * (L_BASE_STAT[iPoke-1] - 340) * 0.00006 + 400);
								iLoBs = L_BASE_STAT[iPoke-1] - 10 - (100 - iWildStrict) + iSlotNo*2; //iSlotNo correlates with rarity (except when fishing, where slots taken by old, good then super rod)
								iUpBs = L_BASE_STAT[iPoke-1] + 10 + (100 - iWildStrict) * 3 / 2 + iSlotNo*2; //therefore, shift by maximum of ~25 base stats based on rarity
							}
							ret = replacePKMN(accessor, iPos, bHabitat, bStrength, false, false, false, 
									bAllPkmn && bNotAllPkmnChosen, bNoWobs, bNoLegendWild, iPoke, iLoBs, iUpBs, -1, -1);
							if (bNotAllPkmnChosen)
							{
								lAllPkmn[ret-1] = true;
								if (utility.indexOf(lAllPkmn, false) == -1)
								{
									bNotAllPkmnChosen = false; //once all pkmn chosen at least once, then set flag to false
									System.out.println("all pkmn");
								}
							}
							//utility.print(L_POKEMON[iPoke] + " > " + L_POKEMON[ret]);
							if (iWildPkmn != 3)
								l_mapping[iPoke] = ret;
						}
						iSlotNo++;
					}
				}
			}
			
			for (int i = 0; i < 386; i++)
				System.out.println((i + 1) + " : " + lAllPkmn[i]);
			
			//randomize trainer pokemon
			if (iTrainerPkmn != 0)
			{
				//general variables
				int iTrainerNum, iPkmnFormat, iTrainerClass, iGender, iTrainerSprite, iNumPkmn, iPointer, iCurPt, iTempPt, iRetPkmn = 0, iChar, iLen, 
						iAI, iPkmnLvl, iPkmnA, iLoBs = 0, iUpBs = 0, iType1 = 0, iType2 = 0, iRivalPoke = 0, iRivalA = 0, iRivalA0, iRivalA1, iRivalA2, iRivalID = 0, iPkmnB;
				String name,  nameID, IDChar;
				int [] l_mapping = new int [386+1]; //mapping for global/local subs
				Arrays.fill(l_mapping, 0);
				int [] lMoveset = new int [4];
				int [] lTypes = new int [2];
				int [] lResult = new int [2];
				int [][] lRivalEvo = new int [3][3]; //[pkmn][stage]
				int [][] lRivalLvl = new int [3][3]; //[pkmn][stage]
				
				if (iROMGame == 0 || iROMGame == 1) // FR/LG
					iTrainerNum = 0x059; // start at Ben
				else if (iROMGame == 2 || iROMGame == 3) // RU/SA
					iTrainerNum = 0x001; // start at Archie
				else //Emerald
					iTrainerNum = 0x001; // start at Sawyer
				
				if (iROMGame == 0 || iROMGame == 1) // FR/LG
				{
					iRivalA0 = ret1; iRivalA1 = ret3; iRivalA2 = ret2;
				}
				else // RU/SA/EM
				{
					iRivalA0 = ret1; iRivalA1 = ret2; iRivalA2 = ret3;
				}
				
				//predetermine evolutions for rival
				lRivalEvo[0][0] = iRivalA0; lRivalEvo[1][0] = iRivalA1; lRivalEvo[2][0] = iRivalA2;
				lRivalLvl[0][0] = 5; lRivalLvl[1][0] = 5; lRivalLvl[2][0] = 5;
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 2; j++)
					{
						lResult = evolve(accessor, lRivalEvo[i][j]);
						lRivalEvo[i][j+1] = lResult[0];
						lRivalLvl[i][j+1] = lResult[1];
					}
				}
				
				//variables for rematch trainers
				HashMap<String, int []> mTrainer = new HashMap<String, int []>(100);
				boolean bNewTrainer, bRival;
				int iPartySize = 0; //-1 if full party
				
				accessor.seek(iOffTrainerBegin);
				while (accessor.getFilePointer() <= iOffTrainerEnd) //for each trainer
				{
					if (iTrainerPkmn == 2)
						Arrays.fill(l_mapping, 0); //clear local mapping
					
					//read trainer variables
					iPkmnFormat = accessor.readUnsignedByte();
					iTrainerClass = accessor.readUnsignedByte(); 
					iGender = accessor.readUnsignedByte() & 0x80; //gender at bit 7
					iTrainerSprite = accessor.readUnsignedByte();
					//read name, easy chat -> string
					
					name = "";
					nameID = "";
					for (iLen = 0; iLen < 12; iLen++)
					{
						iChar = accessor.readUnsignedByte();
						if (iChar == 0x00)
							name += " ";
						else if (iChar == 0x2D)
							name += "&";
						else if (iChar == 0xAD)
							name += ".";
						else if (0xBB <= iChar && iChar <= 0xD4)
							name += L_CHAT[iChar - 0xBB];
						else if (iChar == 0xFF)
							break;
						else
							name += "?";
						IDChar = Integer.toHexString(iChar);
						if (IDChar.length() < 2)
							nameID += "0";
						 nameID += IDChar;
					}
					nameID = nameID.toUpperCase();
					accessor.skipBytes(12 - 1 - iLen);
					
					//instantiate vars, determine if rematch trainer
					int [] lParty = new int[6];
					bNewTrainer = !mTrainer.containsKey(nameID);
					if (bNewTrainer)
						Arrays.fill(lParty, 0); 
					else
						lParty = mTrainer.get(nameID);
					iPartySize = utility.indexOf(lParty, 0);
					bRival = false;
					
					//read rest of variables
					if (iROMLang == 0) //japanese ROM has different formating
						accessor.skipBytes(4 + 4); //skip 8 bytes less than usual
					else
						accessor.skipBytes(8 + 4 + 4); //skip 12 byte easy chat name, 8 byte item array, 4 byte double battle flag, 4 byte unknown
					iNumPkmn = accessor.readUnsignedByte();
					accessor.skipBytes(3); //skip 3 byte padding
					iPointer = accessor.readUnsignedByte() + (accessor.readUnsignedByte() << 8) + 
							(accessor.readUnsignedByte() << 16);
					accessor.skipBytes(1); //skip $08 symbol
					
					//if (name.indexOf("?") != -1)
					//	utility.print("---" + nameID + " (" + iTrainerClass + ")" + "---");
					//else
					//	utility.print("---" + name + " (" + iTrainerClass + ")" + "---");
					
					//jump to pkmn data
					iCurPt = (int) accessor.getFilePointer();
					accessor.seek(iPointer);
					
					//go through each pkmn
					for (int i = 0; i < iNumPkmn; i++)
					{
						//read pkmn variables
						iAI = accessor.readUnsignedByte();
						accessor.skipBytes(1); //skip padding
						iPkmnLvl = accessor.readUnsignedByte();
						accessor.skipBytes(1); //skip padding
						iTempPt = (int) accessor.getFilePointer();
						iPkmnB = accessor.readUnsignedByte() + (accessor.readUnsignedByte() << 8);
						iPkmnA = iPkmnB;
						if (iPkmnB > 276)
							iPkmnA = utility.indexOf(L_CONV, iPkmnB) + 252; //convert from B to A format
						
						//randomize/change pkmn
						if (i == iNumPkmn - 1 && 
							(((iROMGame == 0 || iROMGame == 1) && (iTrainerClass == 0x51 || iTrainerClass == 0x59 || iTrainerClass == 0x5A)) || //if FR/LG and Rival/Champion, last pkmn
							((iROMGame == 2 || iROMGame == 3) && (iTrainerSprite == 0x00 || iTrainerSprite == 0x01)) || //if Ruby/Sapphire and Brendan/May, last pkmn
							((iROMGame == 4) && (iTrainerSprite == 0x47 || iTrainerSprite == 0x48)))) //if Emerald and Brendan/May, last pkmn
						{
							bRival = true;
														
							//determine rival poke (0 - bulb/tree, 1 - char/torc or 2 - squirt/mudk)
							if (iROMGame == 0 || iROMGame == 1) //FR/LG
							{
								if (iTrainerNum < 0x150)
									iRivalPoke = (iTrainerNum % 3);
								else if (iTrainerNum < 0x1BA)
									iRivalPoke = (iTrainerNum - 1) % 3;
								else if (iTrainerNum < 0x2E6)
									iRivalPoke = (iTrainerNum + 1) % 3;
							}
							else if (iROMGame == 2 || iROMGame == 3 || iROMGame == 4) //SA/RU/EM
							{
								if (iTrainerNum < 0x20B) //Brendan 1-3
									iRivalPoke = 0;
								else if (iTrainerNum < 0x20E)
									iRivalPoke = 1;
								else if (iTrainerNum < 0x211)
									iRivalPoke = 2;
								else if (iTrainerNum < 0x214) //May 1-3
									iRivalPoke = 0;
								else if (iTrainerNum < 0x217)
									iRivalPoke = 1;
								else if (iTrainerNum < 0x21A)
									iRivalPoke = 2;
								else if (iTrainerNum == 0x250 && iROMGame == 4) //Opt battle in EM, brendan
									iRivalPoke = 1;
								else if (iTrainerNum == 0x251 && iROMGame == 4) //Opt battle in EM, brendan
									iRivalPoke = 0;
								else if (iTrainerNum == 0x257 && iROMGame == 4) //Opt battle in EM, brendan
									iRivalPoke = 2;
								else if (iTrainerNum == 0x258 && iROMGame == 4) //Opt battle in EM, may
									iRivalPoke = 0;
								else if (iTrainerNum < 0x29B) //Brendan/May 4
									iRivalPoke = (iTrainerNum - 1) % 3;
								else if (iTrainerNum == 0x300 && iROMGame == 4) //Opt battle in EM, may
									iRivalPoke = 1;
								else if (iTrainerNum == 0x301 && iROMGame == 4) //Opt battle in EM, may
									iRivalPoke = 2;
							}
							
							//determine appropriate evolution given level
							iRivalA = lRivalEvo[iRivalPoke][0];
							for (int k = 0; k < 3; k++)
							{
								if (iPkmnLvl >= lRivalLvl[iRivalPoke][k] && lRivalLvl[iRivalPoke][k] != 0)
								{
									iRivalA = lRivalEvo[iRivalPoke][k];
								}
							}
							
							accessor.seek(iTempPt);
							writePKMN(accessor, iRivalA); //converted to format B in func
							iRetPkmn = iRivalA;
							//utility.print("Rival > " + L_POKEMON[iRivalA] + " (" + iPkmnLvl + ")");
							
						}
						else if (!bNewTrainer && (iPartySize == -1 || iPartySize > i)) //if rematch trainer
						{
							//check for new evolutions, update party
							lResult = evolve(accessor, lParty[i]);
							if (iPkmnLvl > lResult[1])
								lParty[i] = lResult[0];
							
							accessor.seek(iTempPt);
							writePKMN(accessor, lParty[i]);
							iRetPkmn = lParty[i];
							//utility.print("Re: " + L_POKEMON[iPkmnA] + " > " + L_POKEMON[lParty[i]] + " (" + iPkmnLvl + ")");
						}
						else if (l_mapping[iPkmnA] != 0 && iTrainerPkmn != 3) //if mapping exists, use mapping
						{
							accessor.seek(iTempPt);
							writePKMN(accessor, l_mapping[iPkmnA]);
							iRetPkmn = l_mapping[iPkmnA];
							lParty[i] = iRetPkmn;
							//utility.print("Mapped: " + L_POKEMON[iPkmnA] + " > " + L_POKEMON[l_mapping[iPkmnA]] + " (" + iPkmnLvl + ")");
						}
						else
						{
							if (bTrainer)
							{
								iLoBs = L_BASE_STAT[iPkmnA-1] - 10 - (100 - iTrainStrict) + iAI/10; //base stat limits shifted depending on AI lvl
								iUpBs = L_BASE_STAT[iPkmnA-1] + 10 + (100 - iTrainStrict) * 3 / 2 + iAI/10;
							}
							if (bType)
							{
								lTypes = getTypeSpec(iTrainerClass, iTrainerSprite, iTrainerNum);
								iType1 = lTypes[0];
								iType2 = lTypes[1];
							}
							
							iRetPkmn = replacePKMN(accessor, iTempPt, false, bTrainer, bType, false, false, false, false, bNoLegendTrain, iPkmnA, iLoBs, iUpBs, iType1, iType2);
							if (iTrainerPkmn != 3)
								l_mapping[iPkmnA] = iRetPkmn;
							lParty[i] = iRetPkmn;
							//utility.print(L_POKEMON[iPkmnA] + " > " + L_POKEMON[iRetPkmn] + " (" + iPkmnLvl + ")");
							//print("   " + iTrainerClass + " & " + iTrainerSprite + " : " + iType1 + ", " +  iType2);
							//print("   " + iLoBs + " - " + iUpBs);
						}
						
						//deal with rest of data - hold items, movesets
						if (iPkmnFormat == 0 || iPkmnFormat == 2)
						{
							accessor.skipBytes(2); //skip hold item data
						}
						else if (iPkmnFormat == 1 || iPkmnFormat == 3)
						{
							if (iPkmnFormat == 3)
								accessor.skipBytes(2); //skip hold item data
							
							//randomize movesets
							if (bMovesets)	//if advanced movesets
							{
								if (rng.nextInt(100) < iPkmnLvl + iAI/4 && iPkmnLvl > 15)
									lMoveset = moveset.getAdvMoveset(iRetPkmn, iPkmnLvl, moves, !L_EVO[iRetPkmn-1]);
								else
									lMoveset = moveset.getRegMoveset(iRetPkmn, iPkmnLvl, moves, !L_EVO[iRetPkmn-1]);
							}
							else			//if regular movesets
							{
								lMoveset = moveset.getRegMoveset(iRetPkmn, iPkmnLvl, moves, !L_EVO[iRetPkmn-1]);
							}
							for (int j = 0; j < 4; j++)
							{
								//utility.print(" - " + lMoveset[j]);
								accessor.writeByte(lMoveset[j] & 0xFF);
								if(lMoveset[j] == 0xFF)
									accessor.writeByte(0x00);
								else
									accessor.writeByte(lMoveset[j] / 0xFF);
							}
							
							if (iPkmnFormat == 1)
								accessor.skipBytes(2); //skip hold item data
						}
					}
					if (!name.equals("GRUNT") && !nameID.equals("0C10504B") && !name.equals("SBIRE") && !bRival) //GRUNTs and Rival get new pkmn
						mTrainer.put(nameID, lParty); //updates trainer party
					
					accessor.seek(iCurPt);
					iTrainerNum++;
				}
			}
		}
		
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	private void setAllEnabled(boolean b)
	{
		mntmSave.setEnabled(b);
		mntmClose.setEnabled(b);
		cmbxPkmn_1.setEnabled(b);
		cmbxPkmn_2.setEnabled(b);
		cmbxPkmn_3.setEnabled(b);
		rdbtnW_Unchanged.setEnabled(b);
		rdbtnW_GlobalSubstitutions.setEnabled(b);
		rdbtnW_LocalSubstitutions.setEnabled(b);
		rdbtnW_CompletelyRandom.setEnabled(b);
		rdbtnT_Unchanged.setEnabled(b);
		rdbtnT_GlobalSubstitutions.setEnabled(b);
		rdbtnT_LocalSubstitutions.setEnabled(b);
		rdbtnT_CompletelyRandom.setEnabled(b);
		chckbxRetainPokemonHabitat.setEnabled(b);
		chckbxRetainPokemonStrength.setEnabled(b);
		chckbxRetainTrainerStrength.setEnabled(b);
		chckbxRetainTypeSpecialties.setEnabled(b);
		chckbxUnevolvedStarters.setEnabled(b);
		chckbxAdvancedMovesets.setEnabled(b);
		chckbxNoWildLegendaries.setEnabled(b);
		chckbxAllPokemon.setEnabled(b);
		chckbxNoWobs.setEnabled(b);
		chckbxNoTrainLegendaries.setEnabled(b);
		chckbxTypeTrio.setEnabled(b);
		chckbx3EvoStarters.setEnabled(b);
		lblWildPkmnStrictness.setEnabled(b);
		sldrWildPkmnStrictness.setEnabled(b);
		lblTrainPkmnStrictness.setEnabled(b);
		sldrTrainPkmnStrictness.setEnabled(b);
	}
	
	private void writePKMN(RandomAccessFile p_accessor, int pkmnA)
	{
		//writes a 2-byte pkmn into ROM given pkmn nat dex number (1-indexed)
		try
		{
			int pkmnB = pkmnA;
			if (pkmnA > 251) 
				pkmnB = L_CONV[pkmnA-252]; //conv from nat dex to index #
			
			if (pkmnB < 256) 
			{
				p_accessor.writeByte(pkmnB);
				p_accessor.writeByte(0);
			}
			else
			{
				p_accessor.writeByte(pkmnB - 256);
				p_accessor.writeByte(1);
			}
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	private int readPKMN(RandomAccessFile p_accessor)
	{
		//reads a 2-byte pkmn in ROM, returns pkmn number
		try
		{
			int pkmnB = p_accessor.readUnsignedByte() + (p_accessor.readUnsignedByte() << 8);
			int pkmnA = pkmnB;
			if (pkmnB > 276)
				pkmnA = utility.indexOf(L_CONV, pkmnB) + 252; //convert from index # to nat dex format
			return pkmnA;
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
			return -1;
		}
	}
	
	private int replacePKMN(RandomAccessFile p_accessor, int iOff, boolean p_bHabitat, boolean p_bStrength, boolean p_bType, boolean p_bStarters, 
			boolean p_b3stage, boolean p_bAllPkmn, boolean p_bNoWobs, boolean p_bNoLegends, int iPKMN, int iLoBs, int iUpBs, int iType1, int iType2)
	{
		//replaces 2-byte pkmn in ROM w/ random pkmn, constrained by boolean conditions. iPKMN = -1 to read from ROM.
		//iPKMN and iRandPKMN are 1-indexed, iLoBs and iUpBs indicate lower/upper base stat limits
		//returns random pkmn
		try
		{
			if (iPKMN == -1)
			{
				p_accessor.seek(iOff);
				iPKMN = readPKMN(p_accessor);
			}
			
			if (p_bHabitat || p_bStrength || p_bType || p_bStarters || p_b3stage || p_bAllPkmn || p_bNoWobs || p_bNoLegends)
			{
				//limited random
				int iChange = (iUpBs - iLoBs) * 2 / 5 + 2; //ranges from 10 (100% strict) to 110 (0% strict)
				int numloops = 0;
				int iRandPKMN;
				
				while (true)
				{
					iRandPKMN = rng.nextInt(L_BASE_STAT.length) + 1;
					
					if ((L_HABITAT[iPKMN-1] == L_HABITAT[iRandPKMN-1] || !p_bHabitat) && 											//if habitats are equal (bHabitat set)
						((iLoBs <= L_BASE_STAT[iRandPKMN-1] && L_BASE_STAT[iRandPKMN-1] <= iUpBs) || !p_bStrength) &&				//if base stats within range (bStrength set)
						(((L_TYPE_1[iRandPKMN-1] == iType1 || L_TYPE_2[iRandPKMN-1] == iType1) || 									//if type matches (bType set) (2nd type less likely)
							((L_TYPE_1[iRandPKMN-1] == iType2 || L_TYPE_2[iRandPKMN-1] == iType2) && rng.nextInt(2) > 0)) || !p_bType || iType1 == -1) &&	
						(L_EVO[iRandPKMN-1] || !p_bStarters) &&																		//if unevolved (bStarters set)
						(L_EVO3[iRandPKMN-1] || !p_b3stage) &&																		//if 3 stage (b3stage set)
						(!lAllPkmn[iRandPKMN-1] || !p_bAllPkmn) &&																	//if pkmn not yet chosen (bAllPkmn set)
						((iRandPKMN != 202 && iRandPKMN != 360) || !p_bNoWobs) &&													//if not wobuffet/wynaut (bNoWobs set)
						(utility.indexOf(L_LEGENDARIES, iRandPKMN) == -1 || !p_bNoLegends) &&										//if not legendary (bNoLegends set)
						(iUpBs > 300 || iRandPKMN != 292))																			//Shedinja only appear very late in game
					{
						//print(L_POKEMON[iPKMN] + " (" + L_HABITAT[iPKMN-1] + ") : " + L_POKEMON[iRandPKMN] + " (" + L_HABITAT[iRandPKMN-1] + ")");
						//if criteria met, replace w/ randomized pkmn
						p_accessor.seek(iOff);
						writePKMN(p_accessor, iRandPKMN);
						return iRandPKMN;
						//else, keep looping
					}
					
					numloops++;
					if (numloops % 50 == 0)
					{
						iUpBs += iChange; //update upper/lower limits to increase flexibility
						iLoBs -= iChange; //to avoid potential infinite loop, if choices are constrained 
						if (iUpBs < 180)
							iUpBs = 180;
						if (iLoBs > 680)
							iLoBs = 680;
						if (numloops >= 500)
							p_bAllPkmn = false; //slacken requirements if no match
					}
				}
			}
			else
			{
				//absolute random (386 options)
				p_accessor.seek(iOff);
				int iRandPKMN = rng.nextInt(L_BASE_STAT.length) + 1; //excluding 'Random'
				writePKMN(p_accessor, iRandPKMN);
				return iRandPKMN;
			}
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
		return -1;
	}
	
	private int [] getTypeSpec(int iTrainerClass, int iTrainerSprite, int iTrainerNum)
	{
		int iType1 = -1;
		int iType2 = -1;
		if (iROMGame == 0 || iROMGame == 1) //Fire Red or Leaf Green
		{
			switch (iTrainerClass) //Trainer type specialties
			{
				case 0x3A: iType1 = T_BUG; break; 		//Bug Catcher - Bug type
				case 0x41: iType1 = T_ROCK; 
					iType2 = T_STEEL; break; 			//Hiker - Rock type, Steel type
				case 0x42: iType1 = T_POISON;
					iType2 = T_FIRE; break;			//Biker - Poison type
				case 0x43: iType1 = T_FIRE; break;		//Burglar - Fire type
				case 0x44: iType1 = T_ELECTRIC; break;	//Engineer - Electric type
				case 0x45: iType1 = T_WATER; break;	 	//Fisher - Water type
				case 0x46: iType1 = T_WATER; break;	 	//Swimmer[m] - Water type
				case 0x47: iType1 = T_FIGHTING; break;		//Cue Ball - Fighting type
				case 0x4A: iType1 = T_WATER; break;		//Swimmer[f] - Water type
				case 0x4B: iType1 = T_PSYCHIC; break; 	//Psychic - Psychic type
				case 0x4C: iType1 = T_ELECTRIC; break; 	//Rocker - Electric type
				case 0x4D: iType1 = T_PSYCHIC; break; 	//Juggler - Psychic type
				case 0x4F: iType1 = T_FLYING; break; 	//Bird Keeper - Flying type
				case 0x50: iType1 = T_FIGHTING; break;	//Black Belt - Fighting type
				case 0x53: iType1 = T_GROUND; break;	//Boss (Giovanni) - Ground
				case 0x5B: iType1 = T_GHOST; break;	 	//Channeler - Ghost
				case 0x5F: iType1 = T_FIGHTING; break;	//Crush Kin - Fighting
				case 0x60: iType1 = T_WATER; break;		//Sis and Bro - Water
				case 0x63: iType1 = T_FIGHTING; break; 	//Crush Girl - Fighting
				case 0x64: iType1 = T_WATER; break;		//Tuber - Water
				case 0x66: iType1 = T_GRASS; break;		//Ranger - Grass
				case 0x67: iType1 = T_GRASS; break;		//Aroma Lady - Grass
				case 0x68: iType1 = T_GROUND; break; 	//Ruin Maniac - Ground
			}
			switch (iTrainerSprite) //E4 and Gym Leader type specialties
			{
				case 0x70: iType1 = T_ICE; iType2 = T_WATER; break;		//Lorelai - Ice
				case 0x71: iType1 = T_FIGHTING; iType2 = T_ROCK;break;	//Bruno - Fighting
				case 0x72: iType1 = T_GHOST; iType2 = T_POISON;break;	//Agatha - Ghost
				case 0x73: iType1 = T_DRAGON; iType2 = T_FLYING; break;	//Lance - Dragon
				case 0x74: iType1 = T_ROCK; break;		//Brock - Rock
				case 0x75: iType1 = T_WATER; break;		//Misty - Water
				case 0x76: iType1 = T_ELECTRIC; break;	//Lt Surge - Electric
				case 0x77: iType1 = T_GRASS; break;		//Erika - Grass
				case 0x78: iType1 = T_POISON; break;	//Koga - Poison
				case 0x79: iType1 = T_FIRE; break;		//Blaine - Fire
				case 0x7A: iType1 = T_PSYCHIC; break;	//Sabrina - Psychic
				case 0x6C: iType1 = T_GROUND; break;	//Giovanni - Ground
			}
			switch (iTrainerNum) //Specific trainers - gym trainer type specialties
			{
				case 0x08E: iType1 = T_ROCK; break;			//Camper Liam - Pewter - Rock
				case 0x0EA: iType1 = T_WATER; break; 		//Swimmer Luis - Cerulean - Water
				case 0x096: iType1 = T_WATER; break;		//Picnicker Diana - Cerulean - Water
				case 0x08D: iType1 = T_ELECTRIC; break;		//Sailor Dwayne - Vermilion - Electric
				case 0x0DC: iType1 = T_ELECTRIC; break;		//Engineer Baily - Vermilion - Electric
				case 0x1A7: iType1 = T_ELECTRIC; break; 	//Gentleman Tucker - Vermilion - Electric
				case 0x10A: iType1 = T_GRASS; break;		//Beauty Tamia - Celadon - Grass
				case 0x084: iType1 = T_GRASS; break;		//Lass Kay - Celadon - Grass
				case 0x109: iType1 = T_GRASS; break;		//Beauty Bridget - Celadon - Grass
				case 0x0A0: iType1 = T_GRASS; break; 		//Picnicker Tina - Celadon - Grass
				case 0x192: iType1 = T_GRASS; break;		//Cooltrainer Mary - Celadon - Grass
				case 0x10B: iType1 = T_GRASS; break;		//Beauty Lori - Celadon - Grass
				case 0x085: iType1 = T_GRASS; break;		//Lass Lisa - Celadon - Grass
				case 0x125: iType1 = T_POISON; break;		//Juggler Nate - Fuchsia - Poison
				case 0x124: iType1 = T_POISON; break;		//Juggler Kayden - Fuchsia - Poison
				case 0x120: iType1 = T_POISON; break;		//Juggler Kirk - Fuchsia - Poison
				case 0x127: iType1 = T_POISON; break; 		//Tamer Edgar - Fuchsia - Poison
				case 0x126: iType1 = T_POISON; break;		//Tamer Phil - Fuchsia - Poison
				case 0x121: iType1 = T_POISON; break;		//Juggler Shawn - Fuchsia - Poison
				case 0x11A: iType1 = T_PSYCHIC; break; 		//Psychic Cameron - Saffron - Psychic
				case 0x119: iType1 = T_PSYCHIC; break; 		//Psychic Tyron - Saffron - Psychic
				case 0x1CF: iType1 = T_PSYCHIC; break;	 	//Channeler Stacy - Saffron - Psychic
				case 0x11B: iType1 = T_PSYCHIC; break;	 	//Psychic Preston - Saffron - Psychic
				case 0x1CE: iType1 = T_PSYCHIC; break;	 	//Channeler Amanda - Saffron - Psychic
				case 0x1D0: iType1 = T_PSYCHIC; break;		//Channeler Tasha - Saffron - Psychic
				case 0x118: iType1 = T_PSYCHIC; break;		//Psychic Johan - Saffron - Psychic
				case 0x0D5: iType1 = T_FIRE; break;			//Burglar Quinn - Cinnabar - Fire
				case 0x0B1: iType1 = T_FIRE; break;			//Super Nerd Erik - Cinnabar - Fire
				case 0x0B2: iType1 = T_FIRE; break;			//Super Nerd Avery - Cinnabar - Fire
				case 0x0D6: iType1 = T_FIRE; break;			//Burglar Ramon - Cinnabar - Fire
				case 0x0B3: iType1 = T_FIRE; break;			//Super Nerd Derek - Cinnabar - Fire
				case 0x0D7: iType1 = T_FIRE; break;			//Burglar Dusty - Cinnabar - Fire
				case 0x0B4: iType1 = T_FIRE; break;			//Super Nerd Zac - Cinnabar - Fire
				case 0x129: iType1 = T_GROUND; break;		//Tamer Cole - Viridian - Ground
				case 0x128: iType1 = T_GROUND; break;		//Tamer Jason - Viridian - Ground
				case 0x188: iType1 = T_GROUND; break;		//Cooltrainer Samuel - Virdian - Ground
				case 0x190: iType1 = T_GROUND; break;		//Cooltrainer Yuji - Viridian - Ground
				case 0x191: iType1 = T_GROUND; break;		//Cooltrainer Warren - Viridian - Ground
			}
		}
		else if (iROMGame == 2 || iROMGame == 3) //Ruby, Sapphire
		{
			switch (iTrainerClass)
			{
				case 0x36: iType1 = T_ROCK; break; 		//Hiker - Rock
				case 0x03: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Grunt - Water, Dark
				case 0x24: iType1 = T_FLYING; break;	//Bird keeper = Flying
				case 0x10: iType1 = T_WATER; break;		//Swimmer [m] - Water
				case 0x32: iType1 = T_FIRE; 
					iType2 = T_DARK; break;				//Magma Grunt - Fire, Dark
				case 0x1E: iType1 = T_FIGHTING; break;	//Expert - Fighting
				case 0x04: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Admin - Water, Dark
				case 0x11: iType1 = T_FIGHTING; break;	//Black Belt - Fighting
				case 0x02: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Leader - Water, Dark
				case 0x0B: iType1 = T_GHOST;
					iType2 = T_PSYCHIC; break;			//Hex Maniac - Ghost, Psychic
				case 0x05: iType1 = T_GRASS; break;		//Aroma Lady - Grass
				case 0x06: iType1 = T_GROUND; break;	//Ruin Maniac - Ground
				case 0x08: iType1 = T_WATER; break;		//Tuber - Water
				case 0x09: iType1 = T_WATER; break;		//Tuber - Water
				case 0x19: iType1 = T_FIRE; break;		//Kindler - Fire
				case 0x15: iType1 = T_BUG; break; 		//Bug Maniacs - Bug
				case 0x16: iType1 = T_PSYCHIC; break;	//Psychic - Psychic
				case 0x21: iType1 = T_WATER; break;		//Fishermen - Water
				case 0x23: iType1 = T_DRAGON; break;	//Dragon Tamer - Dragon
				case 0x25: iType1 = T_POISON; break;	//Ninja Boy - Poison
				case 0x26: iType1 = T_FIGHTING; break;	//Battle Girl - Fighting
				case 0x28: iType1 = T_WATER; break;		//Swimmer [f] - Water
				case 0x2B: iType1 = T_WATER;
					iType2 = T_FIGHTING; break;			//Sailor - Water, Fighting
				case 0x33: iType1 = T_FIRE;
					iType2 = T_DARK; break;				//Magma Admin - Fire, Dark
				case 0x35: iType1 = T_BUG; break; 		//Bug Catchers - Bug
				case 0x30: iType1 = T_GRASS; break;		//Ranger - Grass
				case 0x31: iType1 = T_FIRE;
					iType2 = T_DARK; break;				//Magma Leader - Fire, Dark
				case 0x39: iType1 = T_WATER; break;		//Sis and Bro - Water
			}
			switch (iTrainerSprite)
			{
				case 0x4F: iType1 = T_DARK; iType2 = T_POISON; break; 	//Sidney - Dark
				case 0x50: iType1 = T_GHOST; iType2 = T_PSYCHIC; break; //Phoebe - Ghost
				case 0x51: iType1 = T_ICE; iType2 = T_WATER; break;		//Glacia - Ice
				case 0x52: iType1 = T_DRAGON; iType2 = T_FLYING; break; //Drake - Dragon
				case 0x47: iType1 = T_ROCK; break;		//Roxanne - Rock
				case 0x48: iType1 = T_FIGHTING; break;	//Brawley - Fighting
				case 0x49: iType1 = T_ELECTRIC; break;	//Wattson - Electric
				case 0x4A: iType1 = T_FIRE; break;		//Flannery - Fire
				case 0x4B: iType1 = T_NORMAL; break;	//Norman - Normal
				case 0x4C: iType1 = T_FLYING; break;	//Winona - Flying
				case 0x4D: iType1 = T_PSYCHIC; break;	//Tate&Liza - Psychic
				case 0x4E: iType1 = T_WATER; break;		//Wallace - Water
				case 0x1D: iType1 = T_STEEL;
					iType2 = T_ROCK; break;				//Champion Steven - Steel
			}
			switch (iTrainerNum)
			{
				case 0x140: iType1 = T_ROCK; break;			//Youngster Josh - Rustboro - Rock
				case 0x141: iType1 = T_ROCK; break;			//Youngster Tommy - Rustboro - Rock
				case 0x0BF: iType1 = T_ELECTRIC; break;		//Guitarist Kirk - Mauville - Electric
				case 0x0C2: iType1 = T_ELECTRIC; break;		//Guitarist Shawn - Mauville - Electric
				case 0x047: iType1 = T_NORMAL; break;		//Cooltrainer Randall - Petalburg - Normal
				case 0x059: iType1 = T_NORMAL; break;		//Cooltrainer Mary - Petalburg - Normal
				case 0x048: iType1 = T_NORMAL; break;		//Cooltrainer Parker - Petalburg - Normal
				case 0x05A: iType1 = T_NORMAL; break;		//Cooltrainer Lori - Petalburg - Normal
				case 0x049: iType1 = T_NORMAL; break;		//Cooltrainer George - Petalburg - Normal
				case 0x05B: iType1 = T_NORMAL; break;		//Cooltrainer Jody - Petalburg - Normal
				case 0x04A: iType1 = T_NORMAL; break;		//Cooltrainer Berke - Petalburg - Normal
				case 0x28F: iType1 = T_FLYING; break;		//Picnicker Kylee - Fortree - Flying
				case 0x28E: iType1 = T_FLYING; break;		//Camper Terrell - Fortree - Flying
				case 0x082: iType1 = T_WATER; break;		//Beauty Olivia - Sootopolis - Water
				case 0x266: iType1 = T_WATER; break;		//Lass Crissy - Sootopolis - Water
				case 0x083: iType1 = T_WATER; break;		//Beauty Tiffany - Sootopolis - Water
				case 0x12D: iType1 = T_WATER; break;		//Pokefan Marissa - Sootopolis - Water
				case 0x081: iType1 = T_WATER; break;		//Beauty Bridget - Sootopolis - Water
				case 0x076: iType1 = T_WATER; break;		//Lady Brianna - Sootopolis - Water
				case 0x080: iType1 = T_WATER; break;		//Beauty Connie - Sootopolis - Water
				case 0x265: iType1 = T_WATER; break;		//Lass Andrea - Sootopolis - Water
			}
		}
		else if (iROMGame == 4) //Emerald
		{
			switch (iTrainerClass)
			{
				case 0x02: iType1 = T_ROCK; break; 		//Hiker - Rock
				case 0x03: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Grunt - Water, Dark
				case 0x06: iType1 = T_FLYING; break;	//Bird keeper = Flying
				case 0x08: iType1 = T_WATER; break;		//Swimmer [m] - Water
				case 0x09: iType1 = T_FIRE; 
					iType2 = T_DARK; break;				//Magma Grunt - Fire, Dark
				case 0x0A: iType1 = T_FIGHTING; break;	//Expert - Fighting
				case 0x0B: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Admin - Water, Dark
				case 0x0C: iType1 = T_FIGHTING; break;	//Black Belt - Fighting
				case 0x0D: iType1 = T_WATER;
					iType2 = T_DARK; break;				//Aqua Leader - Water, Dark
				case 0x0E: iType1 = T_GHOST;
					iType2 = T_PSYCHIC; break;			//Hex Maniac - Ghost, Psychic
				case 0x0F: iType1 = T_GRASS; break;		//Aroma Lady - Grass
				case 0x10: iType1 = T_GROUND; break;	//Ruin Maniac - Ground
				case 0x12: iType1 = T_WATER; break;		//Tuber - Water
				case 0x13: iType1 = T_WATER; break;		//Tuber - Water
				case 0x19: iType1 = T_FIRE; break;		//Kindler - Fire
				case 0x1C: iType1 = T_BUG; break; 		//Bug Maniacs - Bug
				case 0x1D: iType1 = T_PSYCHIC; break;	//Psychic - Psychic
				case 0x27: iType1 = T_WATER; break;		//Fishermen - Water
				case 0x29: iType1 = T_DRAGON; break;	//Dragon Tamer - Dragon
				case 0x2A: iType1 = T_POISON; break;	//Ninja Boy - Poison
				case 0x2B: iType1 = T_FIGHTING; break;	//Battle Girl - Fighting
				case 0x2D: iType1 = T_WATER; break;		//Swimmer [f] - Water
				case 0x2F: iType1 = T_WATER;
					iType2 = T_FIGHTING; break;			//Sailor - Water, Fighting
				case 0x31: iType1 = T_FIRE;
					iType2 = T_DARK; break;				//Magma Admin - Fire, Dark
				case 0x33: iType1 = T_BUG; break; 		//Bug Catchers - Bug
				case 0x34: iType1 = T_GRASS; break;		//Ranger - Grass
				case 0x35: iType1 = T_FIRE;
					iType2 = T_DARK; break;				//Magma Leader - Fire, Dark
				case 0x39: iType1 = T_WATER; break;		//Sis and Bro - Water
			}
			switch (iTrainerSprite)
			{
				case 0x24: iType1 = T_DARK; iType2 = T_POISON; break; 	//Sidney - Dark
				case 0x25: iType1 = T_GHOST; iType2 = T_PSYCHIC; break; //Phoebe - Ghost
				case 0x26: iType1 = T_ICE; iType2 = T_WATER; break;		//Glacia - Ice
				case 0x27: iType1 = T_DRAGON; iType2 = T_FLYING; break; //Drake - Dragon
				case 0x28: iType1 = T_ROCK; break;		//Roxanne - Rock
				case 0x29: iType1 = T_FIGHTING; break;	//Brawley - Fighting
				case 0x2A: iType1 = T_ELECTRIC; break;	//Wattson - Electric
				case 0x2B: iType1 = T_FIRE; break;		//Flannery - Fire
				case 0x2C: iType1 = T_NORMAL; break;	//Norman - Normal
				case 0x2D: iType1 = T_FLYING; break;	//Winona - Flying
				case 0x2E: iType1 = T_PSYCHIC; break;	//Tate&Liza - Psychic
				case 0x2F: iType1 = T_WATER; break;		//Juan - Water //case 0x36: iType1 = T_WATER; break; //Champion Wallace - Water
				case 0x51: iType1 = T_STEEL; iType2 = T_ROCK; break;	//Steven - Steel
			}
			switch (iTrainerNum)
			{
				case 0x140: iType1 = T_ROCK; break;			//Youngster Josh - Rustboro - Rock
				case 0x141: iType1 = T_ROCK; break;			//Youngster Tommy - Rustboro - Rock
				case 0x23B: iType1 = T_ROCK; break;			//Hiker Marc - Rustboro - Rock
				case 0x0BF: iType1 = T_ELECTRIC; break;		//Guitarist Kirk - Mauville - Electric
				case 0x0C2: iType1 = T_ELECTRIC; break;		//Guitarist Shawn - Mauville - Electric
				case 0x047: iType1 = T_NORMAL; break;		//Cooltrainer Randall - Petalburg - Normal
				case 0x059: iType1 = T_NORMAL; break;		//Cooltrainer Mary - Petalburg - Normal
				case 0x048: iType1 = T_NORMAL; break;		//Cooltrainer Parker - Petalburg - Normal
				case 0x05A: iType1 = T_NORMAL; break;		//Cooltrainer Alexia - Petalburg - Normal
				case 0x049: iType1 = T_NORMAL; break;		//Cooltrainer George - Petalburg - Normal
				case 0x05B: iType1 = T_NORMAL; break;		//Cooltrainer Jody - Petalburg - Normal
				case 0x04A: iType1 = T_NORMAL; break;		//Cooltrainer Berke - Petalburg - Normal
				case 0x28F: iType1 = T_FLYING; break;		//Picnicker Ashley - Fortree - Flying
				case 0x28E: iType1 = T_FLYING; break;		//Camper Flint - Fortree - Flying
				case 0x246: iType1 = T_PSYCHIC; break;		//Gentleman Nate - Mossdeep - Psychic
				case 0x248: iType1 = T_PSYCHIC; break;		//Gentleman Clifford - Mossdeep - Psychic
				case 0x082: iType1 = T_WATER; break;		//Beauty Olivia - Sootopolis - Water
				case 0x266: iType1 = T_WATER; break;		//Lass Crissy - Sootopolis - Water
				case 0x083: iType1 = T_WATER; break;		//Beauty Tiffany - Sootopolis - Water
				case 0x12D: iType1 = T_WATER; break;		//Pokefan Bethany - Sootopolis - Water
				case 0x081: iType1 = T_WATER; break;		//Beauty Bridget - Sootopolis - Water
				case 0x076: iType1 = T_WATER; break;		//Lady Brianna - Sootopolis - Water
				case 0x080: iType1 = T_WATER; break;		//Beauty Connie - Sootopolis - Water
				case 0x265: iType1 = T_WATER; break;		//Lass Andrea - Sootopolis - Water
				case 0x073: iType1 = T_WATER; break;		//Lady Daphne - Sootopolis - Water
				case 0x1F6: iType1 = T_WATER; break;		//Pokefan Annika - Sootopolis - Water
			}
		}
		int [] types = {iType1, iType2};
		return types;
	}
	
	private boolean setOffsets(String sROMType)
	{
		boolean bSuccess = true;
		if (sROMType.equals(FR_ENG_HEADER)) //English FireRed
		{
			//pkmn offsets
			iOffStart1 = FR_ENG_BULB;
			iOffStart2 = FR_ENG_SQRT;
			iOffStart3 = FR_ENG_CHAR;
			iOffMapBegin = FR_ENG_TANOBY_BEGIN;
			iOffMapEnd = FR_ENG_ALTERING_END;
			iOffTrainerBegin = FR_ENG_BEN;
			iOffTrainerEnd = FR_ENG_PAXTON;
			//move, evo offsets
			iOffLearned = FR_ENG_LEARNED;
			iOffEgg = FR_ENG_EGG;
			iOffTM = FR_ENG_TM;
			iOffEvo = FR_ENG_EVO_BULB;
			iOffObey1 = FR_ENG_OBEY_1;
			iOffObey2 = FR_ENG_OBEY_2;
			iOffNatDex = FR_ENG_NATDEX;
			//set rom type, lang
			iROMGame = 0;
			iROMLang = 1;
		}
		else if (sROMType.equals(FR_JAP_HEADER)) //Japanese FireRed
		{
			//pkmn offsets
			iOffStart1 = FR_JAP_BULB;
			iOffStart2 = FR_JAP_SQRT;
			iOffStart3 = FR_JAP_CHAR;
			iOffMapBegin = FR_JAP_TANOBY_BEGIN;
			iOffMapEnd = FR_JAP_ALTERING_END;
			iOffTrainerBegin = FR_JAP_BEN;
			iOffTrainerEnd = FR_JAP_PAXTON;
			//move, evo offsets
			iOffLearned = FR_JAP_LEARNED;
			iOffEgg = FR_JAP_EGG;
			iOffTM = FR_JAP_TM;
			iOffEvo = FR_JAP_EVO_BULB;
			iOffObey1 = FR_JAP_OBEY_1;
			iOffObey2 = FR_JAP_OBEY_2;
			iOffNatDex = FR_JAP_NATDEX;
			//set rom type, lang
			iROMGame = 0;
			iROMLang = 0;
		}
		else if (sROMType.equals(FR_FRA_HEADER)) //French FireRed
		{
			//pkmn offsets
			iOffStart1 = FR_FRA_BULB;
			iOffStart2 = FR_FRA_SQRT;
			iOffStart3 = FR_FRA_CHAR;
			iOffMapBegin = FR_FRA_TANOBY_BEGIN;
			iOffMapEnd = FR_FRA_ALTERING_END;
			iOffTrainerBegin = FR_FRA_BEN;
			iOffTrainerEnd = FR_FRA_PAXTON;
			//move, evo offsets
			iOffLearned = FR_FRA_LEARNED;
			iOffEgg = FR_FRA_EGG;
			iOffTM = FR_FRA_TM;
			iOffEvo = FR_FRA_EVO_BULB;
			iOffObey1 = FR_FRA_OBEY_1;
			iOffObey2 = FR_FRA_OBEY_2;
			iOffNatDex = FR_FRA_NATDEX;
			//set rom type, lang
			iROMGame = 0;
			iROMLang = 2;
		}
		else if (sROMType.equals(LG_ENG_HEADER)) //English LeafGreen
		{
			//pkmn offsets
			iOffStart1 = LG_ENG_BULB;
			iOffStart2 = LG_ENG_SQRT;
			iOffStart3 = LG_ENG_CHAR;
			iOffMapBegin = LG_ENG_TANOBY_BEGIN;
			iOffMapEnd = LG_ENG_ALTERING_END;
			iOffTrainerBegin = LG_ENG_BEN;
			iOffTrainerEnd = LG_ENG_PAXTON;
			//move, evo offsets
			iOffLearned = LG_ENG_LEARNED;
			iOffEgg = LG_ENG_EGG;
			iOffTM = LG_ENG_TM;
			iOffEvo = LG_ENG_EVO_BULB;
			iOffObey1 = FR_ENG_OBEY_1;
			iOffObey2 = FR_ENG_OBEY_2;
			iOffNatDex = LG_ENG_NATDEX;
			//set rom type, lang
			iROMGame = 1;
			iROMLang = 1;
		}
		else if (sROMType.equals(LG_JAP_HEADER)) //Japanese LeafGreen
		{
			//pkmn offsets
			iOffStart1 = LG_JAP_BULB;
			iOffStart2 = LG_JAP_SQRT;
			iOffStart3 = LG_JAP_CHAR;
			iOffMapBegin = LG_JAP_TANOBY_BEGIN;
			iOffMapEnd = LG_JAP_ALTERING_END;
			iOffTrainerBegin = LG_JAP_BEN;
			iOffTrainerEnd = LG_JAP_PAXTON;
			//move, evo offsets
			iOffLearned = LG_JAP_LEARNED;
			iOffEgg = LG_JAP_EGG;
			iOffTM = LG_JAP_TM;
			iOffEvo = LG_JAP_EVO_BULB;
			iOffObey1 = FR_JAP_OBEY_1;
			iOffObey2 = FR_JAP_OBEY_2;
			iOffNatDex = LG_JAP_NATDEX;
			//set rom type, lang
			iROMGame = 1;
			iROMLang = 0;
		}
		else if (sROMType.equals(LG_FRA_HEADER)) //French LeafGreen
		{
			//pkmn offsets
			iOffStart1 = LG_FRA_BULB;
			iOffStart2 = LG_FRA_SQRT;
			iOffStart3 = LG_FRA_CHAR;
			iOffMapBegin = LG_FRA_TANOBY_BEGIN;
			iOffMapEnd = LG_FRA_ALTERING_END;
			iOffTrainerBegin = LG_FRA_BEN;
			iOffTrainerEnd = LG_FRA_PAXTON;
			//move, evo offsets
			iOffLearned = LG_FRA_LEARNED;
			iOffEgg = LG_FRA_EGG;
			iOffTM = LG_FRA_TM;
			iOffEvo = LG_FRA_EVO_BULB;
			iOffObey1 = FR_FRA_OBEY_1;
			iOffObey2 = FR_FRA_OBEY_2;
			iOffNatDex = LG_FRA_NATDEX;
			//set rom type, lang
			iROMGame = 1;
			iROMLang = 2;
		}
		else if (sROMType.equals(RU_ENG_HEADER)) //English Ruby
		{
			//pkmn offsets
			iOffStart1 = RU_ENG_TREE;
			iOffStart2 = RU_ENG_TORC;
			iOffStart3 = RU_ENG_MUDK;
			iOffMapBegin = RU_ENG_PETAL_BEGIN;
			iOffMapEnd = RU_ENG_UNWATER_END;
			iOffTrainerBegin = RU_ENG_ARCHIE;
			iOffTrainerEnd = RU_ENG_EUGENE;
			//move, evo offsets
			iOffLearned = RU_ENG_LEARNED;
			iOffEgg = RU_ENG_EGG;
			iOffTM = RU_ENG_TM;
			iOffEvo = RU_ENG_EVO_BULB;
			//set rom type, lang
			iROMGame = 2;
			iROMLang = 1;
		}
		else if (sROMType.equals(RU_JAP_HEADER)) //Japnese Ruby
		{
			//pkmn offsets
			iOffStart1 = RU_JAP_TREE;
			iOffStart2 = RU_JAP_TORC;
			iOffStart3 = RU_JAP_MUDK;
			iOffMapBegin = RU_JAP_PETAL_BEGIN;
			iOffMapEnd = RU_JAP_UNWATER_END;
			iOffTrainerBegin = RU_JAP_ARCHIE;
			iOffTrainerEnd = RU_JAP_EUGENE;
			//move, evo offsets
			iOffLearned = RU_JAP_LEARNED;
			iOffEgg = RU_JAP_EGG;
			iOffTM = RU_JAP_TM;
			iOffEvo = RU_JAP_EVO_BULB;
			//set rom type, lang
			iROMGame = 2;
			iROMLang = 0;
		}
		else if (sROMType.equals(RU_FRA_HEADER)) //French Ruby
		{
			//pkmn offsets
			iOffStart1 = RU_FRA_TREE;
			iOffStart2 = RU_FRA_TORC;
			iOffStart3 = RU_FRA_MUDK;
			iOffMapBegin = RU_FRA_PETAL_BEGIN;
			iOffMapEnd = RU_FRA_UNWATER_END;
			iOffTrainerBegin = RU_FRA_ARCHIE;
			iOffTrainerEnd = RU_FRA_EUGENE;
			//move, evo offsets
			iOffLearned = RU_FRA_LEARNED;
			iOffEgg = RU_FRA_EGG;
			iOffTM = RU_FRA_TM;
			iOffEvo = RU_FRA_EVO_BULB;
			//set rom type, lang
			iROMGame = 2;
			iROMLang = 2;
		}
		else if (sROMType.equals(SA_ENG_HEADER)) //English Sapphire
		{
			//pkmn offsets
			iOffStart1 = SA_ENG_TREE;
			iOffStart2 = SA_ENG_TORC;
			iOffStart3 = SA_ENG_MUDK;
			iOffMapBegin = SA_ENG_PETAL_BEGIN;
			iOffMapEnd = SA_ENG_UNWATER_END;
			iOffTrainerBegin = SA_ENG_ARCHIE;
			iOffTrainerEnd = SA_ENG_EUGENE;
			//move, evo offsets
			iOffLearned = SA_ENG_LEARNED;
			iOffEgg = SA_ENG_EGG;
			iOffTM = SA_ENG_TM;
			iOffEvo = SA_ENG_EVO_BULB;
			//set rom type, lang
			iROMGame = 3;
			iROMLang = 1;
		}
		else if (sROMType.equals(SA_JAP_HEADER)) //Japanese Sapphire
		{
			//pkmn offsets
			iOffStart1 = SA_JAP_TREE;
			iOffStart2 = SA_JAP_TORC;
			iOffStart3 = SA_JAP_MUDK;
			iOffMapBegin = SA_JAP_PETAL_BEGIN;
			iOffMapEnd = SA_JAP_UNWATER_END;
			iOffTrainerBegin = SA_JAP_ARCHIE;
			iOffTrainerEnd = SA_JAP_EUGENE;
			//move, evo offsets
			iOffLearned = SA_JAP_LEARNED;
			iOffEgg = SA_JAP_EGG;
			iOffTM = SA_JAP_TM;
			iOffEvo = SA_JAP_EVO_BULB;
			//set rom type, lang
			iROMGame = 3;
			iROMLang = 0;
		}
		else if (sROMType.equals(SA_FRA_HEADER)) //French Sapphire
		{
			//pkmn offsets
			iOffStart1 = SA_FRA_TREE;
			iOffStart2 = SA_FRA_TORC;
			iOffStart3 = SA_FRA_MUDK;
			iOffMapBegin = SA_FRA_PETAL_BEGIN;
			iOffMapEnd = SA_FRA_UNWATER_END;
			iOffTrainerBegin = SA_FRA_ARCHIE;
			iOffTrainerEnd = SA_FRA_EUGENE;
			//move, evo offsets
			iOffLearned = SA_FRA_LEARNED;
			iOffEgg = SA_FRA_EGG;
			iOffTM = SA_FRA_TM;
			iOffEvo = SA_FRA_EVO_BULB;
			//set rom type, lang
			iROMGame = 3;
			iROMLang = 2;
		}
		else if (sROMType.equals(EM_ENG_HEADER)) //English Emerald
		{
			//pkmn offsets
			iOffStart1 = EM_ENG_TREE;
			iOffStart2 = EM_ENG_TORC;
			iOffStart3 = EM_ENG_MUDK;
			iOffMapBegin = EM_ENG_101_BEGIN;
			iOffMapEnd = EM_ENG_ALTER_END;
			iOffTrainerBegin = EM_ENG_SAWYER;
			iOffTrainerEnd = EM_ENG_MAY;
			//move, evo offsets
			iOffLearned = EM_ENG_LEARNED;
			iOffEgg = EM_ENG_EGG;
			iOffTM = EM_ENG_TM;
			iOffEvo = EM_ENG_EVO_BULB;
			iOffObey1 = EM_ENG_OBEY_1;
			iOffObey2 = EM_ENG_OBEY_2;
			//set rom type, lang
			iROMGame = 4;
			iROMLang = 1;
		}
		else if (sROMType.equals(EM_JAP_HEADER)) //Japanese Emerald
		{
			//pkmn offsets
			iOffStart1 = EM_JAP_TREE;
			iOffStart2 = EM_JAP_TORC;
			iOffStart3 = EM_JAP_MUDK;
			iOffMapBegin = EM_JAP_101_BEGIN;
			iOffMapEnd = EM_JAP_ALTER_END;
			iOffTrainerBegin = EM_JAP_SAWYER;
			iOffTrainerEnd = EM_JAP_MAY;
			//move, evo offsets
			iOffLearned = EM_JAP_LEARNED;
			iOffEgg = EM_JAP_EGG;
			iOffTM = EM_JAP_TM;
			iOffEvo = EM_JAP_EVO_BULB;
			iOffObey1 = EM_JAP_OBEY_1;
			iOffObey2 = EM_JAP_OBEY_2;
			//set rom type, lang
			iROMGame = 4;
			iROMLang = 0;
		}
		else if (sROMType.equals(EM_FRA_HEADER)) //French Emerald
		{
			//pkmn offsets
			iOffStart1 = EM_FRA_TREE;
			iOffStart2 = EM_FRA_TORC;
			iOffStart3 = EM_FRA_MUDK;
			iOffMapBegin = EM_FRA_101_BEGIN;
			iOffMapEnd = EM_FRA_ALTER_END;
			iOffTrainerBegin = EM_FRA_SAWYER;
			iOffTrainerEnd = EM_FRA_MAY;
			//move, evo offsets
			iOffLearned = EM_FRA_LEARNED;
			iOffEgg = EM_FRA_EGG;
			iOffTM = EM_FRA_TM;
			iOffEvo = EM_FRA_EVO_BULB;
			iOffObey1 = EM_FRA_OBEY_1;
			iOffObey2 = EM_FRA_OBEY_2;
			//set rom type, lang
			iROMGame = 4;
			iROMLang = 2;
		}
		else //no match
		{
			//utility.print("ERROR: NO VERSION / LANGUAGE MATCHED");
			bSuccess = false;
		}
		
		return bSuccess;
	}
	
	private int [] evolve(RandomAccessFile p_accessor, int iPkmnA)
	{
		int [] result = new int[2];
		try 
		{
			//check for new evolutions, update
			int [] lEvoPkmn = new int [5]; //max 5 evolution slots to choose from
			int [] lEvoLvls = new int [5];
			int iEvoPkmnN = 0, iEvoMethod, iEvoLvl, iEvoA, iEvoB, iPkmnLvl;
			int iPkmnB = iPkmnA; //convert to format B
			if (iPkmnB > 251)
				iPkmnB = L_CONV[iPkmnB - 252];
			p_accessor.seek(iOffEvo + (0x28 * (iPkmnB - 1))); //go to pkmn's place in evolution table
			for (int j = 0; j < 5; j++) //5 evolution slots
			{
				//get evolution variables
				iEvoMethod = p_accessor.readUnsignedByte(); //get method of evolution
				p_accessor.skipBytes(1);
				iEvoLvl = p_accessor.readUnsignedByte(); //get level of evolution
				p_accessor.skipBytes(1);
				iEvoB = p_accessor.readUnsignedByte() + (p_accessor.readUnsignedByte() << 8); //pkmn format B
				iEvoA = iEvoB;
				if (iEvoB > 276)
					iEvoA = utility.indexOf(L_CONV, iEvoB) + 252;
				
				//if pkmn doesn't evolve by level, assign evolution level
				if (iEvoMethod == 0x01 || iEvoMethod == 0x02 || iEvoMethod == 0x03) //evolve by happiness
					iEvoLvl = 25;
				else if (iEvoMethod == 0x05 || iEvoMethod == 0x07) //evolve by trade
					iEvoLvl = 36;
				else if (iEvoMethod == 0x06) //evolve by item (elemental stone)
					iEvoLvl = 32;
				else if (iEvoMethod == 0x0F) //evolve by beauty (feebas)
					iEvoLvl = 20;
				
				//add evolution to list
				if (iEvoB != 0)
				{
					lEvoPkmn[iEvoPkmnN] = iEvoA;
					lEvoLvls[iEvoPkmnN] = iEvoLvl;
					iEvoPkmnN++;
				}
				p_accessor.skipBytes(2);
			}
			
			if (iEvoPkmnN != 0)
			{
				int iRand = (iEvoPkmnN > 1) ? rng.nextInt(iEvoPkmnN) : 0;
				result[0] = lEvoPkmn[iRand]; //randomly select next evolution from options
				result[1] = lEvoLvls[iRand];
				return result;
			}
			else
			{
				result[0] = iPkmnA;
				return result; //if no evolutions, return same pkmn
			}
		}
		catch (IOException ioe)
		{
			ioe.printStackTrace();
			return result;
		}
	}
	
	public randomizer()
	{
		/**
		 * Create the application.
		 */
		initialize();
		rng = new Random();
		lAllPkmn = new boolean[386];
	}
	
	private void initialize()
	{
		//set variables
		bStarters = true;
		b3stage = false;
		bTrio = false;
		bStrength = true;
		bHabitat = true;
		bNoLegendWild = true;
		bNoWobs = true;
		bAllPkmn = false;
		bNoWobs = true;
		bTrainer = true;
		bType = true;
		bNoLegendTrain = true;
		bMovesets = true;
		iWildStrict = 75;
		iTrainStrict = 35;
		
		/**
		 * Initialize the contents of the frame.
		 */
		
		frmPokmonFireredleafgreenRandomizer = new JFrame();
		frmPokmonFireredleafgreenRandomizer.setTitle("Pok\u00E9mon 3rd Gen Reasonable Randomizer");
		frmPokmonFireredleafgreenRandomizer.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 11));
		frmPokmonFireredleafgreenRandomizer.getContentPane().setBounds(new Rectangle(20, 20, 20, 20));
		frmPokmonFireredleafgreenRandomizer.setBounds(100, 100, 575, 480);
		frmPokmonFireredleafgreenRandomizer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPokmonFireredleafgreenRandomizer.getContentPane().setLayout(null);
		
		//starter pokemon panel
		JPanel starters_panel = new JPanel();
		starters_panel.setBounds(10, 10, 245, 115);
		starters_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		starters_panel.setLayout(null);
		
		JLabel lblStarters = new JLabel("Starters:");
		lblStarters.setBounds(10, 10, 50, 14);
		lblStarters.setHorizontalTextPosition(SwingConstants.LEADING);
		lblStarters.setVerticalAlignment(SwingConstants.TOP);
		lblStarters.setFont(new Font("Tahoma", Font.BOLD, 11));
		starters_panel.add(lblStarters);
				
		cmbxPkmn_1 = new JComboBox(L_POKEMON); //pass string array as argument
		cmbxPkmn_1.setBounds(80, 30, 150, 20);
		starters_panel.add(cmbxPkmn_1);
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(starters_panel);
		cmbxPkmn_1.addActionListener(this);
		
		cmbxPkmn_2 = new JComboBox(L_POKEMON);
		cmbxPkmn_2.setBounds(80, 55, 150, 20);
		starters_panel.add(cmbxPkmn_2);
		cmbxPkmn_2.addActionListener(this);
		
		cmbxPkmn_3 = new JComboBox(L_POKEMON);
		cmbxPkmn_3.setBounds(80, 80, 150, 20);
		starters_panel.add(cmbxPkmn_3);
		cmbxPkmn_3.addActionListener(this);
		
		JLabel lblPokemon = new JLabel("Pok\u00E9mon 1:");
		lblPokemon.setBounds(10, 32, 70, 14);
		starters_panel.add(lblPokemon);
		
		JLabel lblPokmon = new JLabel("Pok\u00E9mon 2:");
		lblPokmon.setBounds(10, 57, 70, 14);
		starters_panel.add(lblPokmon);
		
		JLabel lblPokmon_1 = new JLabel("Pok\u00E9mon 3:");
		lblPokmon_1.setPreferredSize(new Dimension(50, 14));
		lblPokmon_1.setMinimumSize(new Dimension(50, 14));
		lblPokmon_1.setMaximumSize(new Dimension(50, 14));
		lblPokmon_1.setBounds(10, 82, 70, 14);
		starters_panel.add(lblPokmon_1);
		
		//wild pokemon panel
		JPanel wild_panel = new JPanel();
		wild_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		wild_panel.setBounds(10, 135, 245, 135);
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(wild_panel);
		wild_panel.setLayout(null);
		
		JLabel lblWildPokemon = new JLabel("Wild Pok\u00E9mon:");
		lblWildPokemon.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblWildPokemon.setBounds(10, 10, 85, 14);
		wild_panel.add(lblWildPokemon);
		
		rdbtnW_Unchanged = new JRadioButton("Unchanged");
		rdbtnW_Unchanged.setBounds(6, 30, 90, 20);
		wild_panel.add(rdbtnW_Unchanged);
		rdbtnW_Unchanged.addActionListener(this);
		
		rdbtnW_GlobalSubstitutions = new JRadioButton("Global substitutions");
		rdbtnW_GlobalSubstitutions.setBounds(6, 55, 130, 20);
		wild_panel.add(rdbtnW_GlobalSubstitutions);
		rdbtnW_GlobalSubstitutions.addActionListener(this);
		
		rdbtnW_LocalSubstitutions = new JRadioButton("Local substitutions");
		rdbtnW_LocalSubstitutions.setBounds(6, 80, 130, 20);
		wild_panel.add(rdbtnW_LocalSubstitutions);
		rdbtnW_LocalSubstitutions.addActionListener(this);
		
		rdbtnW_CompletelyRandom = new JRadioButton("Completely Random");
		rdbtnW_CompletelyRandom.setBounds(6, 105, 140, 20);
		wild_panel.add(rdbtnW_CompletelyRandom);
		rdbtnW_CompletelyRandom.addActionListener(this);
		
		ButtonGroup groupWild = new ButtonGroup();
		groupWild.add(rdbtnW_Unchanged);
		groupWild.add(rdbtnW_GlobalSubstitutions);
		groupWild.add(rdbtnW_LocalSubstitutions);
		groupWild.add(rdbtnW_CompletelyRandom);
		
		//trainer pokemon panel
		JPanel trainer_panel = new JPanel();
		trainer_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		trainer_panel.setLayout(null);
		trainer_panel.setBounds(10, 280, 245, 135); //264, 136, 284, 135
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(trainer_panel);
		
		JLabel lblTrainerPokemon = new JLabel("Trainer Pok\u00E9mon:");
		lblTrainerPokemon.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTrainerPokemon.setBounds(10, 10, 105, 14);
		trainer_panel.add(lblTrainerPokemon);
		
		rdbtnT_Unchanged = new JRadioButton("Unchanged");
		rdbtnT_Unchanged.setBounds(6, 30, 80, 20);
		trainer_panel.add(rdbtnT_Unchanged);
		rdbtnT_Unchanged.addActionListener(this);

		rdbtnT_GlobalSubstitutions = new JRadioButton("Global substitutions");
		rdbtnT_GlobalSubstitutions.setBounds(6, 55, 120, 20);
		trainer_panel.add(rdbtnT_GlobalSubstitutions);
		rdbtnT_GlobalSubstitutions.addActionListener(this);

		rdbtnT_LocalSubstitutions = new JRadioButton("Local substitutions");
		rdbtnT_LocalSubstitutions.setBounds(6, 80, 120, 20);
		trainer_panel.add(rdbtnT_LocalSubstitutions);
		rdbtnT_LocalSubstitutions.addActionListener(this);
		
		rdbtnT_CompletelyRandom = new JRadioButton("Completely Random");
		rdbtnT_CompletelyRandom.setBounds(6, 105, 120, 20);
		trainer_panel.add(rdbtnT_CompletelyRandom);
		rdbtnT_CompletelyRandom.addActionListener(this);

		ButtonGroup groupTrainer = new ButtonGroup();
		groupTrainer.add(rdbtnT_Unchanged);
		groupTrainer.add(rdbtnT_GlobalSubstitutions);
		groupTrainer.add(rdbtnT_LocalSubstitutions);
		groupTrainer.add(rdbtnT_CompletelyRandom);
		
		//Starter and General option panel
		JPanel option_panel = new JPanel();
		option_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		option_panel.setBounds(265, 10, 285, 115);
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(option_panel);
		option_panel.setLayout(null);
		
		JLabel lblOptions = new JLabel("Starter and General Options:");
		lblOptions.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblOptions.setBounds(10, 10, 250, 14);
		option_panel.add(lblOptions);
		
		chckbxUnevolvedStarters = new JCheckBox("Unevolved starters");
		chckbxUnevolvedStarters.setBounds(6, 30, 120, 20);
		option_panel.add(chckbxUnevolvedStarters);
		chckbxUnevolvedStarters.addActionListener(this);
		
		chckbx3EvoStarters = new JCheckBox("3-stage starters");
		chckbx3EvoStarters.setBounds(6, 55, 130, 20);
		option_panel.add(chckbx3EvoStarters);
		chckbx3EvoStarters.addActionListener(this);
		
		chckbxTypeTrio = new JCheckBox("Starter type trio");
		chckbxTypeTrio.setBounds(6, 80, 140, 20);
		option_panel.add(chckbxTypeTrio);
		chckbxTypeTrio.addActionListener(this);
		
		//Wild pokemon option panel
		JPanel wild_opt_panel = new JPanel();
		wild_opt_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		wild_opt_panel.setBounds(265, 135, 285, 135);
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(wild_opt_panel);
		wild_opt_panel.setLayout(null);
		
		JLabel lblWildOptions = new JLabel("Wild Pok\u00E9mon Options:");
		lblWildOptions.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblWildOptions.setBounds(10, 10, 250, 14);
		wild_opt_panel.add(lblWildOptions);
		
		chckbxRetainPokemonStrength = new JCheckBox("Retain PKMN strength");
		chckbxRetainPokemonStrength.setBounds(6, 30, 140, 20);
		wild_opt_panel.add(chckbxRetainPokemonStrength);
		chckbxRetainPokemonStrength.addActionListener(this);
		
		chckbxRetainPokemonHabitat = new JCheckBox("Retain PKMN habitat");
		chckbxRetainPokemonHabitat.setBounds(6, 55, 130, 20);
		wild_opt_panel.add(chckbxRetainPokemonHabitat);
		chckbxRetainPokemonHabitat.addActionListener(this);
		
		chckbxAllPokemon = new JCheckBox("All Pokemon");
		chckbxAllPokemon.setBounds(6, 80, 100, 20);
		wild_opt_panel.add(chckbxAllPokemon);
		chckbxAllPokemon.addActionListener(this);
		
		chckbxNoWildLegendaries = new JCheckBox("No Legendaries");
		chckbxNoWildLegendaries.setBounds(146, 30, 120, 20);
		wild_opt_panel.add(chckbxNoWildLegendaries);
		chckbxNoWildLegendaries.addActionListener(this);
		
		chckbxNoWobs = new JCheckBox("No Shadow Tag");
		chckbxNoWobs.setBounds(146, 55, 120, 20);
		wild_opt_panel.add(chckbxNoWobs);
		chckbxNoWobs.addActionListener(this);
		
		lblWildPkmnStrictness = new JLabel("Strictness: 75");
		lblWildPkmnStrictness.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblWildPkmnStrictness.setBounds(10, 106, 150, 14);
		wild_opt_panel.add(lblWildPkmnStrictness);
		
		sldrWildPkmnStrictness = new JSlider(JSlider.HORIZONTAL, 0, 100, 75);
		sldrWildPkmnStrictness.setBounds(90, 105, 180, 15);
		wild_opt_panel.add(sldrWildPkmnStrictness);
		sldrWildPkmnStrictness.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				lblWildPkmnStrictness.setText("Strictness: " + sldrWildPkmnStrictness.getValue());
				iWildStrict = sldrWildPkmnStrictness.getValue();
			}
		});
		
		//Trainer pokemon option panel
		JPanel trainer_opt_panel = new JPanel();
		trainer_opt_panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		trainer_opt_panel.setBounds(265, 280, 285, 135);
		frmPokmonFireredleafgreenRandomizer.getContentPane().add(trainer_opt_panel);
		trainer_opt_panel.setLayout(null);
		
		JLabel lblTrainerOptions = new JLabel("Trainer Pok\u00E9mon Options:");
		lblTrainerOptions.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTrainerOptions.setBounds(10, 10, 250, 14);
		trainer_opt_panel.add(lblTrainerOptions);
		
		chckbxRetainTrainerStrength = new JCheckBox("Retain Trainer strength");
		chckbxRetainTrainerStrength.setBounds(6, 30, 140, 20);
		trainer_opt_panel.add(chckbxRetainTrainerStrength);
		chckbxRetainTrainerStrength.addActionListener(this);
		
		chckbxRetainTypeSpecialties = new JCheckBox("Retain type specialties");
		chckbxRetainTypeSpecialties.setBounds(6, 55, 134, 20);
		trainer_opt_panel.add(chckbxRetainTypeSpecialties);
		chckbxRetainTypeSpecialties.addActionListener(this);
		
		chckbxNoTrainLegendaries = new JCheckBox("No Legendaries");
		chckbxNoTrainLegendaries.setBounds(6, 80, 120, 20);
		trainer_opt_panel.add(chckbxNoTrainLegendaries);
		chckbxNoTrainLegendaries.addActionListener(this);
		
		chckbxAdvancedMovesets = new JCheckBox("Advanced movesets");
		chckbxAdvancedMovesets.setBounds(146, 30, 125, 20);
		trainer_opt_panel.add(chckbxAdvancedMovesets);
		chckbxAdvancedMovesets.addActionListener(this);
		
		lblTrainPkmnStrictness = new JLabel("Strictness: 35");
		lblTrainPkmnStrictness.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblTrainPkmnStrictness.setBounds(10, 106, 150, 14);
		trainer_opt_panel.add(lblTrainPkmnStrictness);
		
		sldrTrainPkmnStrictness = new JSlider(JSlider.HORIZONTAL, 0, 100, 35);
		sldrTrainPkmnStrictness.setBounds(90, 105, 180, 15);
		trainer_opt_panel.add(sldrTrainPkmnStrictness);
		sldrTrainPkmnStrictness.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				lblTrainPkmnStrictness.setText("Strictness: " + sldrTrainPkmnStrictness.getValue());
				iTrainStrict = sldrTrainPkmnStrictness.getValue();
			}
		});
		
		//Menu bar
		JMenuBar menuBar = new JMenuBar();
		frmPokmonFireredleafgreenRandomizer.setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		mntmOpen = new JMenuItem("Open");
		mnFile.add(mntmOpen);
		mntmOpen.addActionListener(this);
		
		mntmSave = new JMenuItem("Save");
		mnFile.add(mntmSave);
		mntmSave.addActionListener(this);
		
		mntmClose = new JMenuItem("Close");
		mnFile.add(mntmClose);
		mntmClose.addActionListener(this);
		
		mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		mntmExit.addActionListener(this);
		
		//initially set unchanged buttons
		rdbtnW_CompletelyRandom.setSelected(true);
		rdbtnT_CompletelyRandom.setSelected(true);

		chckbxUnevolvedStarters.setSelected(bStarters);
		chckbx3EvoStarters.setSelected(b3stage);
		chckbxTypeTrio.setSelected(bTrio);
		chckbxRetainPokemonStrength.setSelected(bStrength);
		chckbxRetainPokemonHabitat.setSelected(bHabitat);
		chckbxAllPokemon.setSelected(bAllPkmn);
		chckbxNoWildLegendaries.setSelected(bNoLegendWild);
		chckbxNoWobs.setSelected(bNoWobs);
		chckbxRetainTrainerStrength.setSelected(bTrainer);
		chckbxRetainTypeSpecialties.setSelected(bType);
		chckbxNoTrainLegendaries.setSelected(bNoLegendTrain);
		chckbxAdvancedMovesets.setSelected(bMovesets);
		
		//initially set buttons to disabled
		setAllEnabled(false);
	}
}