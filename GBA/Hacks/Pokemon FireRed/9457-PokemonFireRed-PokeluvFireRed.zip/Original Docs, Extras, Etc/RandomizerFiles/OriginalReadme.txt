----------------------------------------------------------------

             Pokemon 3rd Gen Reasonable Randomizer
                          Version 1.3
                        January 7, 2013

----------------------------------------------------------------

================================================================
|                            About                             |
================================================================

     The Reasonable Randomizer is a Java program that can modify 
the starter pokemon, wild pokemon, trainer pokemon and movesets 
of any pokemon game from the 3rd gen. It works with FireRed, 
LeafGreen, Emerald, Ruby and Sapphire, and with English, Japanese
and French ROMs. The Reasonable Randomizer is different from 
other randomization programs in that it offers options for 
limited randomization, which means it won't simply pick any
random pokemon from Bulbasaur to Deoxys, but instead limits the
random pokemon to choose from based on factors such as 
evolution state, pokemon strength, pokemon habitat, and type
specialties (all this stuff will be explained in the rest of the
readme). This randomizer also allows you to choose between 
basic and advanced random movesets. 

================================================================
|                          How to Use                          |
================================================================

(1) Download the zip folder (which you've probably already done,
    since you're reading this).
(2) Unzip the zip folder. You can do this on Windows by right
    clicking on the folder, then clicking 'Extract All'.
(3) Double click on the randomizer java file to run the program.
(4) Choose a ROM to modify by clicking on File -> Open, then
    navigating to the ROM and selecting it.
(5) Choose your randomization options on the user interface.
(6) To modify the ROM, click on File -> Save.
(7) Now you can click on File -> Close to close the current ROM
    and randomize another one, or you can exit the application.

If you are unable to open the randomizer, odds are that you
don't have Java installed on your computer. To get Java installed,
all you have to do is go to this website, and download Java:

http://java.com/download 

================================================================
|                         Starter Pokemon                      |
================================================================

You can either select one of the 386 pokemon as your starters, 
or you can choose the 'Random' option at the top of the list to
get a random starter. Starter pokemon randomization can be
customized using the option boxes on the right side:

 - Unevolved starters - this limits the randomized starters to
        only pokemon that haven't evolved. This includes pokemon
        that do not evolve, like Delibird and Registeel. 
 - 3-stage starters - this is a stricter version of the
        'unevolved starters' option. It limits your randomized
        options to pokemon that haven't evolved, and are first
        in a 3-stage evolution family. If you choose this option
        you'll be getting pokemon like Bulbasaur and Ralts.
 - Starter type trio - the type trio option makes it so that
        each randomized starter has a type advantage over 
        another starter, similar to how Bulbasaur-Charmander-
        Squirtle is set up. An example of a set of starters
        that can be produced using this option and the 3-stage
        starters option is Bellsprout-Pidgey-Geodude. This will
        also cause your rival to pick a pokemon with a type
        advantage against your own starter. 

================================================================
|                           Wild Pokemon                       |
================================================================

There are 4 options for how the wild pokemon are randomized:

 - Unchanged - leaves the wild pokemon as they normally are. 
 - Global substitutions - for each pkmn species that appears in
        the wild, another species is used to consistently replace
        it. For example, the program might change all the wild
        Zubats in the game into Flaffy's. 
 - Local substitutions - this option causes all pkmn of the same
        species in the same area to change into a single species.
        This might cause the program to change all the Zubats in 
        Granite Cave into Quagsires, while changing all the Zubats
        in Shoal Cave into Combuskens. 
 - Completely Random - this gives every encounter slot a 
        different pokemon. This would cause every grassy area to
        hold 12 different pokemon, each with a different chance
        to be encountered.

There are also 5 additional options in the Options box for 
customizing wild pokemon randomization:

 - Retain PKMN strength - this makes it so that every pokemon that
        is replaced has roughly the same strength as the pokemon
        that is replacing it. This means that it will be very
        unlikely to find pokemon like Groudon in Route 101 and 
        pokemon like Weedle in Cerulean Cave. I implemented this
        by comparing the base stat total of the wild pokemon to
        the BST of the randomized pokemon. This is a flexible
        constraint, however, so while you are very unlikely to find
        pokemon with disproportionate power to their region, it
        is still possible.
 - Retain PKMN habitat - this causes the randomizer to replace
        wild pokemon with pokemon that have the same habitat.
        Selecting this option means that you won't find, say,
        wild Blaziken while fishing, or wild Horsea in the middle
        of a cave. 
 - All Pokemon - select this option if you want all 386 pokemon
        to appear in the wild. The randomizer will keep a tally
        of all the pokemon that have been included in wild regions
        and strongly discourages duplicates from appearing. This,
        of courses, does not take into account shadow tag 
        pokemon or legendaries if you choose those options as
        well. I'm 99.9% sure that this approach will work, but
        the randomizer is probabilistic, so there's a slim
        chance that it might miss a pokemon or two. Another thing
        to keep in mind is that this option severely constrains
        the pool of Pokemon to choose from, so the amount of 
        highly powerful pokemon in the wild will increase. If
        you select the 'Global substitutions' option, it will
        take precedence over this option, so not all pokemon
        will be available. 
 - No legendaries - this does exactly what it says; it prevents
        the program from substituting legendaries for the wild
        pokemon. I defined legendaries to include both major
        legendaries (i.e. Rayquaza) and minor legendaries
        (i.e. Entei). 

Within each region, the strength constraint for randomized pkmn
is shifted based on the appearance percentage of its slot. Don't 
be surprised if you see unusually powerful pokemon appearing 
on rare occasions.

================================================================
|                         Trainer Pokemon                      |
================================================================

The 4 options for how trainer pokemon are randomized are the
same as the options for wild pokemon. The only difference is
that for local subs, instead of conserving pokemon in a given 
region, the program conserves pokemon for a given trainer. 

There are 4 additional options in the Options box for 
customizing trainer pokemon randomization:

 - Retain Trainer strength - This is basically the same concept
        as the 'Retain PMKN strength' option, only with trainer
        pokemon. It means that Youngster Joey won't end up with,
        say, a Ho-Oh, while Lance doesn't get pokemon like 
        Rattata (that would be really disappointing). Again, it
        uses base stat total as a metric for comparing pokemon
        strength. 
 - Retain type specialties - type specialist trainers are gym
        leaders, elite 4 trainers, and a few other trainers that
        use a specific type of Pokemon. Choosing this option
        will cause these trainers to only recieve pokemon that
        match their type specialty. I gave elite 4 trainers two
        different type specialties, since they tend to specialize
        in extremely rare types. 
 - No legendaries - this option is the same as it is for wild
        pokemon; it prevents trainers from getting legedaries. 
 - Advanced movesets - normally, when this option is not selected,
        the program will give certain trainer pokemon basic
        movesets, which are just random movesets cobbled together
        from the pokemon's naturally learned moves, TM moves,
        egg moves, and tutor moves. Sometimes this works, but
        other times you end up with nonsensical movesets, like a
        Nosepass with Mimic, Toxic, Sunny Day and Rock Throw. The
        advanced movesets option allows some pokemon to get
        predefined movesets that are strategically coherent. I 
        basically used Battle Factory movesets as the advanced
        movesets, as well as Smogon for legendaries. You can find
        them here: http://www.smogon.com/forums/showthread.php?t=15426
        Just as a warning, the advanced movesets can be pretty
        tough, especially in the hands of a gym leader / E4
        trainer. Here's a sample of one of the movesets in the
        database:

        Metagross
         * Shadow Ball
         * Earthquake
         * Psychic
         * Ice Punch

The rival's main pokemon will automatically be retained throughout
the game, and the program will update its evolution state. In 
addition, rematch trainers keep their pokemon, and the program
keeps track of their evolutions as well. However, the rival's
supporting pokemon are changed every time, kind of like N in B/W.
Another thing is that the strength constraint is shifted based 
on the AI level of the trainer, this way gym leaders and the 
like will have more powerful pokemon.

================================================================
|                       Acknowledgements                       |
================================================================

Artemis251 - For creating the Pokemon Emerald Randomizer, the
        project that inspired me to make the Reasonable
        Randomizer. 

LU-HO - For creating AdvanceMap, which was instrumental in 
        debugging wild pokemon randomization. 

The guys who made TrPET - TrPET was tremendously helpful to me
        for visualizing trainer pokemon, and their movesets.

HackMew - For his Advance Starter program, which helped me
        analyze starter pokemon randomization. 

FinalZero - For creating the Egg Move Editor, without which I 
        could not have figured out the egg move data. 

Peterko - For meticulously finding all the battle factory 
        movesets, the basis for the 'advanced movesets' option.

I'd also like to thank the people in communities like 
Pokecommunity, ProjectPokemon, and Romhack.me, for the knowledge
that they've disseminated into the public. Without their prior
work, I probably would not have been able to create the
Reasonable Randomizer. Also, I'd like to thank everyone on
Reddit and Pokecommunity who used the randomizer and gave
valuable feedback and advice. 

================================================================
|                           Contact                            |
================================================================

If you find a bug or want to give suggestions to improve the
randomizer, please email me at victorge381@gmail.com.

================================================================
|                       Version History                        |
================================================================

Version 1.0 - December 21, 2012
----------------------------------------------------------------
Initial release.

Version 1.1 - December 23, 2012
----------------------------------------------------------------
Revamped UI. Cleaned up code. Added no legendaries option. 
Altered parameters to reduce powerful pkmn in low level areas.

Version 1.2 - January 4, 2013
----------------------------------------------------------------
New features! 3-stage starters, starter type trios, all pokemon
in wild, and no shadow tag pkmn. Implemented obedience check
removal for mew and deoxys, gym trainer type specialties, and
the rival selecting different pokemon. 

Version 1.3 - January 7, 2013
----------------------------------------------------------------
Implemented sliding scale of strictness, fixed errors with the 
rival pokemon, fixed problem w/ non-kanto evolutions in FR/LG.