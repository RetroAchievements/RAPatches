Use with:

(No Intro)
File:               Pokemon Mystery Dungeon - Red Rescue Team (Europe) (En,Fr,De,Es,It).gba
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              C1D18FE4
MD5:                9837DA1FDFE900C52F2109D9718D4E85
SHA1:               AFEE3B060DD5FD4A68AFB1B003456AEF3A2AF073
SHA256:             0F9D125D513D9CBA628D97E2C345382EBA9BA73B402B24A8FDD81F604C14CBCD