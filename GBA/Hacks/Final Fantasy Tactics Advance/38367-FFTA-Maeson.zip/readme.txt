Use with:

(No Intro)
File:               Final Fantasy Tactics Advance (USA, Australia).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              5645E56C
MD5:                CD99CDDE3D45554C1B36FBEB8863B7BD
SHA1:               4AC05441F4DE70A4EC3DD932116346C61B8783D9
SHA256:             43FC8204C6DCEEE58828AEBC7AF0C72EB807E99F35AD641C8BB0A4FA8B6EDC19