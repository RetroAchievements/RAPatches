Use with:

(No Intro)
File:               Final Fantasy Tactics Advance (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              5645E56C
MD5:                CD99CDDE3D45554C1B36FBEB8863B7BD