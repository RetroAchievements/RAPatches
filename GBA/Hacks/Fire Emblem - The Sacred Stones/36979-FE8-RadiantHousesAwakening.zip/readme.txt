Use with:

(No-Intro)
File:               Fire Emblem - The Sacred Stones (USA, Australia).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              A47246AE
MD5:                005531FEF9EFBB642095FB8F64645236
SHA1:               C25B145E37456171ADA4B0D440BF88A19F4D509F
SHA256:             638CDA9D9B72657220FBF7E7A500CD3B64D9686C36E8A56FCA69D26D13886F2F