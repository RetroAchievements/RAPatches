Apply patch to a vanilla US FE8 ROM.

The contents of the ZIP file are as follows:
- Two patches. The standard one has all UI colors swapped from blue to red and viceversa for flavor (you are playing as the bad guys, after all). However, I know a lot of people hate when hacks do that, as it can be difficult to get rid of the “blue good, red bad” muscle memory from regular FE. Therefore, for those of you who prefer convenience over flavor, I’ve also included an alternate version of the patch that maintains vanilla’s overworld sprite palettes and battle forecast colors.
- The guide. An excel file containing all unit information, recruitments and a list of all special conversations in the game. Also, for curiosity's sake, there's a section with all the origins of the background characters turned playable. Just to prove that they're not complete OCs - just mostly.
- Readme. Basically just this section and the three sections below, but in a text file.

Known issues and things to note:
- If you promote too many units to distinct classes, the prepscreen will start to glitch out at the bottom. I'm not sure exactly how many different classes you can have before the glitch appears, but it's possible to finish the main campaign without encountering it. Either way, it's a merely visual issue, so I would recommend not letting it worry you too much.
- In the postgame, under certain circumstances, the game might crash if you look at the status screen while on the world map. Be careful with that.
- The main campaign has been exhaustively playtested and the postgame has also gotten a decent amount of testing. Skirmishes have been looked at by one tester, and I'm pretty sure the Tower of Valni is mostly uncharted territory.
That being said, there's always stuff that slips through the cracks, so please keep an eye out for any possible problems (especially if you try going through the Tower) and do not hesitate to give me a shout if you encounter anything that seems out of the ordinary!

Special thanks:
Dr Shaky Jones, whose keen mind for numbers and map design was a huge help in fine-tuning many aspects of the hack.
Pengaius, for doing two playest runs for the price of one, plus a run of the postgame. And for pushing me to buff Zabba. She deserves it.
Jotari, for playtesting and for giving me a number of cool ideas for the hack, chief among them the playable pupil.
ReedRacer, for playtesting of both the campaign and the postgame and proofreading.
Tsunny, Tru, Res and Mibbles for additional playtesting and suggestions.

Parrhesia, Retina, Contro and SubwayBossEmmett for helping me with a number of hacking-related issues I had.
7743 for creating FEBuilder and making it that much simpler to make things like this.
The talented artists and computer wizards in the community, as credited below, for all the free stuff I used in this hack.

Credits:

Patches
Anti huffman by Hextator
Remove pierce by Brendor
Remove Easy Mode by Nintenlord
Move display fix by circles
Character/Class level cap editor by 7743
Unique battle music per unit by 7743
Fix weak promoted enemies by Gryz
Battle Stats with Anims Off ver2 by Vesly
Enable Faster Movement By Holding A by Gryz
Fix CAM1/CAMERA2 going out of bounds by Stan
Actions after talk (contemporary style) by 7743
Actions after support (contemporary style) by 7743
HP bars with warnings by Circles and Tequila
Growth display by Tequila
Danger zone display by Circles
Show heal amount by Circles
Steal with full inventory by Vesley
Add event: Split Menu by Stan, Circleseverywhere
Additional AI: Talk AI by aera
Allow 3 or more trainee to be regist by 7743
ModularMinimugBox by Zane (Runabox, slightly modified)
Weapon lock ex by 7743
Skip World Map Fix (For World Map Users) by Stan
Autocursor Fix by Venno
Modify S rank limits by Tequila
Switch:Animation on / off with L button by aera
Boss animation ON by aera, ported by 7743
When Boss animation ON, start animation with background by 7743
Unlock OP class reel fully by Kirito
Move the gray palette for preparation from the menu palette by 7743
Switch Portrait images by class, chapter, flag by 7743
C1 command by Hextator
SOUND_NIMAP2 by Alusq
drumfix by Circles
16 tracks/12 sounds by Agro/Bendor
Set whether transporter can be used for each map by 7743
Add Event: Send unit's all items to transporter by 7743
Convert Chapter Titles to Text_ver2.1 by Circles, 7743
Fixes the world map chapter ID being loaded instead of the actual chapter ID by ???
AddEvent: Set and Get Unit Status by 7743
Character Custom Animation by EA ver 2 by 7743
Monster Weapon display fix by Brendor
Add Event: GetSupportLevel, SetSupportLevel, ClearSupportLevel by 7743
Saving in the Tower and Ruins by Circleseverywhere
Great Shield First and Last Class by Chap@FE8_GIRLS
Great Shield Activation Rate by aera
Pierce First and Last Class by Chap@FE8_GIRLS
Change Skill Pierce activation rate from LV to Skill by aera
Convert Chapter Titles to Text_ver 2.1 Support Lat1 by Circles
Allows detailed setting of weapons held by summoned units by 7743
Allow to summon multiple classes by 7743
Fix the weapon level of the Summoned Phantom's weapon level of the possessed weapon by 7743
Lose Weapon Ranks on Promotion by Venno
Sure Strike Skill First and Last Class by Chap@FE8_GIRLS
Doubling the activation rate of Skill Sure Strike by Aera
Fixed sound of Aircalibur from Aera's data
NosResire by SME
Prevent uncounterable items from becoming forced range animations by Venno
Continue Battle BGM Between Map and Combat by 7743
Multiple vulnerary by 7743
Tequila/Lord Reyson by Tequila/Lord Reyson
Add Event: Change Edition by 7743
Define multiple classes that can discover desert treasures by 7743
Floor terrain of branch Prmotion by 7743
Floor terrain of forced Prmotion by 7743
Weapon LV up when destroyed by FEGirls Chap
Adjust Mode Coefficient Experience Gain by Venno
Toggle New Game Text by Circles
Change support conversation to 5 people instead of 5 times by aera
Remove Support Viewer by aera
Remove prep support room theme by GigaExcalibur
Change duration of bad status effect by Sme
Ignore changing music with flag 0x82 (fight with the Deamon King) by Venno
Preparation Screen: Do not special for final chapter by 7743
Skip:Game Opening Demo by Fati
Define multiple classes that prohibit additional effects such as poisons bad status by 7743
Silencer-Immune Class by aera
These class force the staff to hit 0% and deactivate it by 7743
Change "Config" to "Status" in the Prepare submenu by 7743
Set Preparation BGM By Chapter https://github.com/ngmansion/FE8/tree/master/RePreparation Port by 7743.
Prevent exchange of valuables ListVersion by Vesly, Orignal:Circle https://feuniverse.us/t/fe7-fe8-trading/632  trade_fix, Pawkkie Fix GiveAll https://discord.com/channels/144670830150811649/235253973588639747/881615476923441192
Add Event: Autolevel Player Unit by Shuusuke and Vesly
Switch the death Quote for each unit who is killer by 7743
Move the battle prediction palette from the menu palette by 7743
Add Event: Give the unit experience points by 7743, Vesly, aera
Custom HandAxs by 7743 based on Huichelaar's Custom Thrown Weapon Animations
Add Event: Set Unit State Conditions (UNCM) by Tequila
Steal at any speed by Contro
Fixed glitch that prevented cavalry's CANTO move again after open menu by 7743
Range-Animated Weapons List by Circles
DSFE STYLE AVOID Do NOT double the speed for avoid rate calculation by GratedShtick
Berserk Unit Battle Animation by laqieer
Fixed sound of the Dragon Stone from aera's data
ExModularSave with Supply 200 by Stan, Gamma Supply Expansion, Vesley
Sound Room 100% Unlocked by 7743
Set Preparations Store Pricing by aera

Animations
F Rogue Ponytail by Temp
Sword, axe and handaxe knight by TheBlindArcher
Axe and sword knight map sprites by Aggro
Chained Sword general by Knabepicer
Axe bonewalker by Vilkalizer, Orihara_Saki
Handaxe (slim) bonewalker by Vilkalizer, Orihara_Saki
Female fighter long haired by Black Mage
Female fighter map sprite by Pikmin
Female journeyman by Gavvv333
Female warrior long haired by Temp, repalette and long-haired edit by Pushwall
Female warrior map sprite by FEGirls
Male falcoknight by Camus_Regan, repalette by Jeorge_Reds
F merc by TheBlindArcher
F merc map sprites by Aggro
Demon King playable animations by SHYUTERz
Strong guy by TytheBub
Boxer map sprites by ShadowAllyX
Marshall by Nuramon
Bow wyvern knight by ltranc
Axe wyvern knight by St Jack
Vanilla FE7 female mage fix by Shin19 (long-haired edit by me)
Vanilla pupil fix by Blazer (female edit by me)
Pirate repal by Wan
Dracozombie fix by Marlon0027, Orihara_Saki
Female Cyclops by Alexsplode

Music
Shadow Dragon - Clash of Two Virtues by Sme
Mystery of the Emblem - Reign of Despair by Alusq
Shadow Dragon - Footsteps of Fate by UnitedStars111
Three Houses -Indomitable Will by Azula
FFT - Anxiety by Alusq
Castlevania OoE - Stones Hold a Grudge by Psyche
Castlevania OoE - Sorrow's Distortion by Dolkar
Castlevania OoE - Welcome to Legend by Psyche
Castlevania PoR - Dance of Sadness midi by Pakillo https://www.vgmusic.com/file/741a210372ca539db9fca58c86624d17.html, adapted to GBAFE by me
Elfen Lied - Lilium midi found here https://bitmidi.com/elfen-lied-lilium-mid, adapted to GBAFE by me
M&L PiT Serious Trouble! by Norikins
Valkyrie Profile - The Unfinished Battle with God Syndrome by SaXor the Nobody
Valkyrie Profile - Hurried Decay of Life Force by Psyche
FE14 - End of All by Leche
Bomberman Hero - Redial by Sme
Corpse Party - BGM 10 by 7743
Castlevania OoE - An Empty Tome by Psyche
Heroic Struggle LaL - TrikkiNikki

Portraits
Mauthe Doog portrait (modified Princess Wolfy) by CanDy
Skeleton by L95, Alexsplode
Spider by An odd Dutch Introvert
Cyclops by L95, Alexsplode (female edit by me)
Mogall by L95
Lagdou Ruins Boss 8 by HusbandoEmblem

All other assets unlisted above, including portraits, all custom item icons, edited backgrounds and the following animations: female revenant and pupil, FE6-style FE7 bishop, Lilina-style FE7 mage, mage dancer, mage bard and sword and bow gargoyle, were made by me.