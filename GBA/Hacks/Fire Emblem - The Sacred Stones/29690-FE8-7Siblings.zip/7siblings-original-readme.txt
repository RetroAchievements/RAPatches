7 Siblings is an FE8U romhack made by WarPath with support from the FEU community. The following readme contains relevant information a player may want to know before starting the game.

*Core Features/General Notes*

⁃ The game features 29 chapters: a prologue, 20 numbered chapters, an endgame, and 7 Gaiden chapters sprinkled in between. All Gaidens are unlocked automatically and are labeled as such due to being side stories from the main action in some form.

- The large majority of game graphics have been overhauled, from the title menu to all in-game menus to character portraits and class animations. Additionally, nearly all music has been overhauled from vanilla FE8. Shoutout to the community for helping make this possible.

⁃ The game features an easy mode, a normal mode, and a hard mode, with the only substantial changes between modes being enemy strength. Hard mode is what the hack was primarily designed around and would be recommended for most romhack veterans. Normal and easy are just somewhat nerfed versions of this mode and have received less testing.

- The hack also features Classic (defeated units are gone permanently) and Casual (defeated units return in the next chapter) modes which are selected after selecting difficulty. The game is balanced with Classic and permadeath in mind, but Casual is there for anyone who doesn't want the stress of permadeath. You should be fine letting a fair number of units die on Classic, although this game is definitely not designed for a true Ironman run from a blind player, especially on the highest difficulty.

- Arianna, Scott, and Nancy are global GameOver units. Other units may be GameOver units in their joining chapters or a subsequent chapter in which they
are force deployed. Arianna has access to the Supply starting in Ch. 2.

- Supports are functional in terms of gameplay, but there are no conversations. I may write them eventually, and I may not. Depends on how I feel.

- Support Viewer and Sound Room are 100% unlocked from the start. The Link Arena is disabled because it was pretty broken and I didn't care to put the time in to fix it. 

- It's recommended that if you are playing this hack on emulator, that you use the mGBA emulator if it is available to you on your platform. This hack was primarily tested using mGBA. A bit of testing was done using real hardware as well, and in that limited sample size, the game seemed to have no problems running on real hardware.

*Mechanical Tweaks of Note*
This list is not exhaustive, but may help answer common questions players have while/before playing.

- The difficulty (Easy/Normal/Hard) and mode (Casual/Classic) of the save file can be viewed in the upper-right of the status chapter status screen.

⁃ The game does not feature the community-made FE8 skill system, and distribution of vanilla “skills” is as follows:

*Thieves can steal, have enhanced fog vision, and can use lockpicks.
*Assassins have all the same abilities as thieves, but do not require lockpicks to open locks. Assassins do not have Lethality.
*All mounted units should have Canto.
*Player berserkers, swordmasters, halberdiers, and snipers have +15 critical boost, while enemies of these classes do not.
*Bishops do have Slayer, but Slayer is only 2x effectiveness unlike vanilla (all other effectiveness is still 3x, don't worry).
*Summoners can... wait for it... summon.
*All other vanilla “skills” (Great Shield, Pierce, etc.) are wiped from the game.

⁃ There are no split promotions in this hack, each tier 1 class only has a single set promotion.

⁃ Most units promote with Master Seals, and traditional FE GBA class-specific promotion items are not present. Arianna and Scott promote with Officer Seals.

⁃ Supports build in the FE9 style, as in support points are granted for units being deployed on the same map together, and supports are triggerable after a certain number of shared maps. Putting units
next to each other on the map does nothing to help build supports. Limits on number of supports (5 conversations/levels total) and support bonuses by affinity are unchanged from vanilla FE8.

⁃ The Swordslayer should no longer have any effectiveness, it’s simply a more powerful Swordreaver.

- S-Rank weapon level bonuses have been removed. This was mainly due to the fact that some later enemies have S-ranks, and having them run around with 5 crit wasn't the best.

⁃ Gargoyles/Deathgoyles are treated as dragons/wyverns in terms of effectiveness, in addition to being monsters and flyers.

- Vulneraries now heal for 15 HP.

⁃ Certain items exist that give passive boosts for being within a unit’s inventory. These effects do stack if buffing the same stat. Most (but not all) can either be found in Gaiden chapters or are given
as rewards for satisfying certain conditions in Gaiden chapters. The boosts from these items are stackable.

- Global enemy range can be viewed on maps by pressing select, and turned off once again by pressing select.

⁃ Growths can be viewed on the stat screen by pressing select. Press select again to switch back to the stat view.

⁃ Talks can be viewed on the status screen as well, and talk bubbles appear above units a selected unit can talk to when on the map.

- Talk/Support does not end a unit's turn, similar to modern FE.

- Enemies with droppable items will flash an icon indicating as such.

- Player HP cap is now 80 for promoted classes as opposed to 60.

- The supply capacity is now 200 as opposed to the vanilla 100.

- Certain items that would normally be stealable have been hard-coded to be unstealable. These items will be marked as "Unstealable" in their description to signify this.

- Thieves and Assassins can now steal with a full inventory, and upon doing so, you will be asked to select an item to send to the convoy/discard if the convoy is full. 

- A couple units will occassionally be absent from the deployment menu for a single chapter for story reasons. When this happens, their gear will be transferred to the convoy for you to use.

- The preps armory features the same price for basic items as you would have in a regular armory - no upcharge for the basics in a pinch. The glitch where viewing in-map shop inventories shows incorrect inflated prices has also been fixed.

- If animations are on, they can be skipped by holding L before the beginning of combat, and can be sped up while they are playing by holding the R button similar to how modern FE allows combat animations to be sped up.

- Units can make an unlimited number of trades per turn, as this hack uses what is commonly referred to as "Thracia trade."

- When enemies auto-level to gain stats, their stats will be fixed at each level and there will be no random variation between the stats of enemies of the same level and class in the same map.

*Recruitment (Spoiler Warning)*
Most recruitments are pretty straightforward and few are even missable at all, but the following guide may be of interest to some. Joining class listed in parentheses.

Arianna (Huntress) - Joins automatically at start of Prologue
Scott (Privateer) - Joins automatically at start of Prologue
Weston (Sword Knight) - Joins automatically Turn 1 of Ch. 1
Sarah (Pegasus Knight) - Joins automatically Turn 1 of Ch. 1
Kayla (Cleric) - Joins automatically at start of Ch. 2
Will (Mage) - Talk with Kayla or Scott in Ch. 2, or complete the chapter with Will alive
Sammy (Lance Armor) - Joins automatically at start of Ch. 3
Keegan (Sword Thief) - Talk with Will in Ch. 3, or complete the chapter with Keegan alive
Andrew (Monk) - Joins automatically at start of Ch. 4
Katie (Blademaiden) - Talk with Arianna in Ch. 4, or complete the chapter with Katie alive
Nancy (Hero) - Joins automatically at start of Ch. 5x
Luke (Axe Knight) - Joins automatically at start of Ch. 5x
Serah (Medic) - Joins automatically at start of Ch. 5x
Kristia (Shaman) - Talk with Nancy in Ch. 5x, or complete the chapter with Kristia alive
Michelle (Myrmidon) - Joins automatically at start of Ch. 6
Jeremiah (Wyvern Knight) - Joins automatically at the start of Ch. 7
Jordan (Dark Mage) - Joins automatically at the start of Ch. 7
Ariel (Bow Thief) - Joins automatically at the start of Ch. 7
Emily (Mage Knight) - Joins automatically at the start of Ch. 8
Joe (Warrior) - Joins automatically at the start of Ch. 8 (post-preparations)
Brandon (Captain) - Joins automatically at start of Ch. 9x
Nikko (Axe Armor) - Joins automatically at start of Ch. 9x
Reilly (Soldier) - Joins automatically at start of Ch. 9x
Wade (Bishop) - Joins automatically at start of Ch. 9x
Cale (Berserker) - Joins automatically at start of Ch. 13
Ryan (Great Knight) - Joins automatically at start of Ch. 13x
Nike (Swordmaster) - Joins automatically at start of Ch. 13x
Shelton (Bow Knight) - Joins automatically at start of Ch. 13x
Alex (Lance Knight) - Talk with any player unit in Ch. 16
Johann (Fighter) - Talk with any player unit in Ch. 16
Kjetil (Mercenary) - Talk with any player unit in Ch. 16
Lydia (Warrior) - Joins automatically at start of Ch. 17x
Christine (Valkyrie) - Joins automatically at start of Ch. 17x
Alyssa (Assassin) - Joins automatically at start of Ch. 17x
Reid (Bard) - Joins automatically at start of Ch. 17x
Moses (Griffon Knight) - Joins automatically at start of Ch. 19
Meredith (Night Wing) - Joins automatically at start of Ch. 20

??? - There is one more secret unit, but I'm going to leave their recruitment conditions up to the player to find out... 

*Known Glitches*

- Skipping events with B/Start may lead to some incorrect music playing during cutscenes.

- Scrolling through units with R/L in the support viewer causes the transparency of certain UI elements to change in odd ways. This is purely visual.

*Credits*

Assets used or adapted from the following users:

Mugs- Nickt, Eldritch Abomination, Memai, Blueyguy, Capibarainspace, FEier, GabrielKnight, LaurentLacroix, Marlon0024, Vilk, AmBrosiac, DerTheVaporeon,
MiguelRojo, Serif, MrGreen3339, Nobody, WAve,Zorua, MrKarkino, Tobiki, Zarg, Zmr, Auto, RandomWizard, Levin, Melia,CobyTheGoober, caringcarrot, Atey, Mewiyev, Ecut, BoneManSeth, JiroPaiPai, Dutch Introvert, Garytop

Map Sprites- FEGirls, RobertFPY, StreetHero, FE7if, Ash3wl, L95, Agro, team SALVAGED, Nuramon, Blademaster, BlueDruid, Pikmin1211, Teraspark, flasuban, team SALVAGED, N426, Smug_Mug, ArcherBias,
ZoramineFae

Animations- St jack, beccarte, Keks_Krebs, SD9K, Glenwing, DerTheVaporeon, Andy, Jj09, GabrielKnight, Maiser6, Greentea, Raspberry, BwdYeti, Pikmin1211, MK404, Temp, Orihara_Saki, TBA, flasuban, team
SALVAGED, shadowofchaos, Jeorge_Reds, Sme, Shtick, Ayr, Teraspark, Eldritch Abomination, Red Bean, Zelix, Wan, Tristan_Hollow, L95

Spells- Arch, BwdYeti, MikeySeregon, Blazer, HyperGammaSpaces, Seal

Music- A_Reliable_Chair, SaXor_the_Nobody, Pikmin1211, Sme, Tristan_Hollow, MrGreen3339, Pandan, Scraiza, MeatOfJustice, Dolkar, Alusq, CivilYoshi, DerTheVaporeon, Devisio

Item Icons- LordGlenn, Zelix, Lisandra_Brave, Ereshkigal, GabrielKnight, Zarg, Seal

Tilesets/Palettes- Sme, Flasuban, Zoramine, Pandan, WAve, Nickt, GFE1R team, Venno, Peerless, knabepicer

Class Cards- Seal, Blademaster, MeatOfJustice, L95, RobertFPY, DerTheVaporeon, Flasuban, Melia, Ghast, Shtick, EldritchAbomination, team SALVAGED

Backgrounds- WAve, Seal, HeartHero, Norma2D

Fonts- Btsamm, Scraiza

Tools/Patches/ASM- 7743, Zane, Venno, HyperGammaSpaces, Tequila, Huichelaar, Vesly, Scraiza, Snakey1

Special Thanks/Project-Specific Help

Map Support- A_Reliable_Chair, Scraiza, Snakey1, Pandan

Playtesting- Pandan, A_Reliable_Chair, knabepicer, Rivian, LegendOfLoog, Dainn, Kyrads, Pushwall, sdaht

Palettes- Pushwall, Pikmin1211

Tech Support- Pikmin1211, HyperGammaSpaces

If I’m missing anyone, let me know! Thanks to everybody at FEU for supporting the project.