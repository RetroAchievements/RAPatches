Use with:

(No Intro)
File:               Megaman - Battle Network 6 - Cybeast Falzar (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              DEE6F2A9
MD5:                1E8C774BA210D1C55113531C7360C737
SHA1:               0676ECD4D58A976AF3346CAEBB44B9B6489AD099
SHA256:             A37C1028ADB72082B51E142321FA437967BC54B6F46730A53F6581AD455AD670