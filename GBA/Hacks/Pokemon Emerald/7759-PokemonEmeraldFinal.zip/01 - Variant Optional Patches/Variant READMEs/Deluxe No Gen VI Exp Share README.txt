Pick one of these three patches depending on which wild encounter list you want. Vanilla wilds... Has the Vanilla Wilds, Vanilla Wilds Plus includes version exclusives from Ruby/Sapphire. New Wilds has all 386 pokemon available. Do NOT patch more than one of these main patches to the same ROM. Do optional patches after.

Deluxe contains the Generation 4 additions like new moves, abilities, and evolutions.

This one also does NOT have the Gen VI Exp Share, the Exp Share functions as normal.