The Gen4-lite Movesets gives every Pokemon its levelup set from the Gen 4 games, minus the moves that didn't exist in Gen 3.

The main appeal of this is the additional coverage given to many Pokemon, for example, Psyduck does not get a single attacking water move until level 50 in Emerald. With the Gen4-lite Movesets, Psyduck gets Water Gun at level 9.