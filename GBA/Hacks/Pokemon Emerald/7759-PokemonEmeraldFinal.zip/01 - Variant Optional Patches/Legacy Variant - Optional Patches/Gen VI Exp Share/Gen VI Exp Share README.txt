The Gen VI Exp Share makes the regular Exp Share give experience to your entire party.

NOTE: You need to have the item in your bag *not* held by a Pokemon!