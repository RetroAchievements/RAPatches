The Lore-Friendly Evos option makes the trade evolutions more in line with the vanilla method. This usually means levelup while holding the same item meant to be held while trading.

The evolutions are listed in the Documentation Folder.