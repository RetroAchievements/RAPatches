These are pre-configured PGE utilities as well as .toml files for HexManiac.

HexManiac was used to expand the tutors so if you wish to edit anything about tutors, use HexManiac, for all other edits use PGE