How to compile your own version of the randomiser

1) Make your modifications to the files using a code editor such as SublimeText.
2) Open Command Line/Terminal & navigate to the Source folder.
3) Type "javac *.java" and hit enter. This will create a bunch of .class files
4) Type "jar cfm randomizer.jar Manifest.txt *.class" and hit enter. This will create your randomizer.jar

On Mac you may not be able to run the .jar by double-clicking.
But you can still open it via Terminal by typing "java -jar randomizer.jar"