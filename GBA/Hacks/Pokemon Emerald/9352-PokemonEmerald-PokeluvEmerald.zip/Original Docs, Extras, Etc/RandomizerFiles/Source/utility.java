
public class utility {

	static boolean bDebug = true;
	
	public static void main(String[] args) {
		
	}
	
	public static int indexOf(int [] array, int value)
	{
		for (int i = 0; i < array.length; i++)
		{
			if (array[i] == value)
				return i;
		}
		return -1; //-1 by default
	}
	
	public static int indexOf(boolean [] array, boolean value)
	{
		for (int i = 0; i < array.length; i++)
		{
			if (array[i] == value)
				return i;
		}
		return -1; //-1 by default
	}
	
	public static int count(boolean [] array, boolean value)
	{
		int count = 0;
		for (int i = 0; i < array.length; i++)
		{
			if (array[i] == value)
				return i;
		}
		return count;
	}
	
	public static void print(String msg)
	{
		//prints message, only if debugging
		if (bDebug)
			System.out.println(msg);
	}
}
