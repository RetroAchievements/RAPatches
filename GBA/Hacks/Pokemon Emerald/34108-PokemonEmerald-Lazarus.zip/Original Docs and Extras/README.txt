-- HOW TO PATCH & PLAY POKéMON LAZARUS --

1. Download Pokémon Lazarus from the official Nemo622 Ko-Fi page. This is the *only* official way to obtain the game files!

2. Find the "Pokémon Lazarus Patch.bps" file in the download.

3. Obtain a Pokémon Emerald TrashMan ROM file. If you don't know what this is, Google will be your friend!

4. Go to https://www.romhacking.net/patch/

5. Enter your Pokémon Emerald TrashMan ROM file into the "ROM file" dropbox

6. Enter the Pokémon Lazarus Patch.bps file into the "Patch file" dropbox

7. Select "Apply patch" button to download the patched ROM file! This is Pokémon Lazarus!

8. Load up a GBA emulator and enjoy! :)


For more information, please join my ROM Hack Development Discord with this join link:
https://discord.gg/XACTMjNZgw

Remember, there are multiple documentation files included in the Pokémon Lazarus download, all of which contain important information about your adventure through the Ilios Region (Item locations, Wild Encounters, information about new mechanics, and more)!

Have fun playing Pokémon Lazarus!