For installation help join the Discord and check out the:
#patch-notes and #faq channels

You must use a patcher and apply your choice of .ups patch to an unmodified Pokémon Emerald ROM

https://rogue.discord.pokabbie.com or use code XGyB9gTb8E under Join a Server



===Version Differences===

=EX Version= <-- Recommended Version
This version contains modern improvements 
e.g. new Pokémon, battle items, abilities, fairy type, physical/special split etc.

=Vanilla=
Just standard Pokemon Emerald battle mechanics with no fundamental changes
(Does include small QoL changes but nothing which will majorly affect gameplay)