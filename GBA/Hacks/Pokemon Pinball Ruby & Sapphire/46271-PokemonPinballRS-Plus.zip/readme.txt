Use with:

(No Intro)
File:               Pokemon Pinball - Ruby & Sapphire (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              B992A3C0
MD5:                BA6D0FBFF297B8937D3C8E7F2C25FA0F
SHA1:               9FEC81CE2C5DF589E0371A0BF2F92A5FE8DB730B
SHA256:             1A2BBB845456873DE0E50BA01383977D7B3500F85DCEAC929C5FB0111389D9A1