Use with:

(No Intro)
Pokemon - Ruby Version (USA).gba
MD5 - 53d1a2027ab49df34a689faa1fb14726
CRC - F0815EE7