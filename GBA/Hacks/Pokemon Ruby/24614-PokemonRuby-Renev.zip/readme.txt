Use with:

(No Intro)
File:               Pokemon - Ruby Version (USA, Europe) (Rev 1).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              61641576
MD5:                E0503182A2E699678BCF25A6897A24D6
SHA1:               610B96A9C9A7D03D2BAFB655E7560CCFF1A6D894
SHA256:             0D80909998A901C7EDEF5942068585BC855A85AEC7E083AA6AEFF84A5B2F8EC0