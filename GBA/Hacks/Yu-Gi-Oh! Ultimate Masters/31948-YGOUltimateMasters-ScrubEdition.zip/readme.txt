Use with:

(No-Intro)
File:               Yu-Gi-Oh! - Ultimate Masters - World Championship Tournament 2006 (USA) (En,Ja,Fr,De,Es,It).gba
Size (Bytes):       33554432
CRC32:              f968a196
MD5:                b8a7c976b28172995fe9e465d654297a
SHA1:               9689337d6aac1ce9699ab60aac73fc2cfdccad9b