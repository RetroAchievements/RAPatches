Use with:

(No-Intro)
File:               Yu-Gi-Oh! - The Eternal Duelist Soul (USA).gba
Size (Bytes):       8388608
CRC32:              dfd07a36
MD5:                ec3f000ffde5754cb164a05d2d6f9053
SHA1:               510fbba212aca9bab95ea12f8fd933e62ee34dea