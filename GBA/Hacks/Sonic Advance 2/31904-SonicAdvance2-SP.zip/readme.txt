Use with:

(No-Intro)
File:               Sonic Advance 2 (USA) (En,Ja,Fr,De,Es,It).gba
Size (Bytes):       16777216
CRC32:              7efee7f7
MD5:                3fb865c5f142a8fc1f82105bfc6b8935
SHA1:               7bcd6a07af7c894746fa28073fe0c0e34408022d