Use with:

(No Intro)
File:               Castlevania - Aria of Sorrow (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              35536183
MD5:                E7470DF4D241F73060D14437011B90CE
SHA1:               ABD71FE01EBB201BCC133074DB1DD8C5253776C7
SHA256:             910F88D3701E6C9F99C0D63660C14C61D8B79B0C17BFD7B35A15185BE36430A5