Use with:

(No Intro)
File:               Castlevania - Aria of Sorrow (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              35536183
MD5:                E7470DF4D241F73060D14437011B90CE