﻿Mod Name: Castlevania Aria of Sorrow: Reprise (Roguelike/Endless Mode)
Author: Xanthus
Latest Release: .61b - 3/7/23
Other Credits:
	LagoLunatic for DSVania Editor!
	Dev Anj for LCK/INT fix patches
	FuseCV for the Kicker Skeleton without Malphas patch

Description:
A roguelike mod for Aria of Sorrow which allows for endless randomized gameplay,
along with extensive new features, effects and rebalancing!
Rooms, enemies, items, and shop are randomized.
Some equipment and souls have new effects. Full feature list below!

Discord to stay up to date and give feedback:
https://discord.gg/PytA9rr6nz

Install:
Apply the patch to a Castlevania Aria of Sorrow (USA) ROM using an IPS patching utility like Floating IPS.

Main Features:
	- Randomized rooms, aside from the intro room and the lobby room. There are currently around 52 heaviliy customized rooms.
		- There are four generated areas (one for each direction from the lobby), each contains rooms from two areas.
		- When you defeat a boss, all areas / rooms, as well as the shop are re-randomized.
		- There are 12+ randomized effects (e.g. poisonous enemies, higher knockback, or souls are disabled).
		- Game can be played endlessly with increasing difficulty, or you can leave the castle after Graham to end the game.
	- Almost all enemies are randomized, areas found later in Aria of Sorrow will have more difficult enemies.
	- Weapons, Armor, and Accessory pickups are spawned in a mostly progressive order with some randomization.
		- Note: You must pick them up for better equipment to spawn.
	- Soul item pickups are randomized, aside from "progression" souls.
	- New Item: Charon’s Obol. After you use this item, the next enemy killed will drop their soul.
	- New Item: Book of Return. Use this to teleport back to the lobby room.
	- New pickups: Pink and blue soul canisters that permanently increase your stats ( STR, INT, HP, MP, etc.)
	- New randomized breakable walls will increase XP.
		- Hidden along the left or right walls of ~25% of rooms.
		- Spawns particles about every 8 seconds, or can be seen with Peeping Eye / Skull necklace.
	- New Equipment and Soul effects / balancing (full details in Balance section)
		- Final Strike - Adds extra damage if it will kill
		- Pierce - Penetrates DEF if you hit on the first frame of a fully extended spear.
		- Soft landing - Not affected when falling at high speeds / dive kicking.
		- MP Refund - Get MP back after using red souls.
		- Max MP / HP effects.
		- Short invulnerability on hit effect.
	- Julius mode: Hold L while hitting start on the file name entry screen.
	- Custom difficulty: For easy mode, either use a cross for the first character of your filename/seed, or hit start
		while hovering over cross with an empty filename to randomize an easy seed. For hard mode, do the same
		with the skull.
	- Includes patches authored by Dev Anj to make LCK more impactful, and INT improves red souls instead of STR.
	- Includes patch authored by FuseCV to allow for Kicker Skeleton without Malphas.

Balance details:
	* General:
		* Resistance for enemies reduces damage to 25% instead of 50%.
		* Soul / Item drop chances increased by 2x.
		* Limits quantity for pickups / buying to 5.
		* Selling gives 25% of the price rather than 50%.
		* Minimum damage you take is either 5, or 2x the difficulty counter
			(number to the lower right of hp) if it's higher.
	* Equipment/Items:
		* All spears have Pierce effect
			* If you hit with the first frame a spear is fully extended, penetrate enemy DEF
		* Final Strike effect (adds extra damage if it will kill).
			* Hammer: +100% final strike
			* Warhammer: +150% final strike
			* Tallhammer: +200% final strike
			* Battle Axe: +50% final strike
			* Death's Scythe: +100% final strike.
		* MP Refund for red souls on Pendant (2 MP), Silk Robe (5 MP), Elven Robe (10 MP)
		* Heart pendant gives double MP when you pick up hearts.
		* Cloak + 20 Max MP
		* Crimson Cloak +40 Max MP
		* Scarf: +20 Max HP
		* Red Scarf: +40 Max HP
		* Dainslef: +40 Max MP
		* Soft Landing effect on Gym Clothes, Ninja Suit, and Black cloak.
		* Samurai armor - Any weapon will cancel on landing. Nerfed DEF from 20 to 18.
		* Skull necklace has Peeping eye ability.
		* Rapier and Estoc have Slashing(Sword) type removed.
		* Meat Strip gives 50 HP instead of 29 HP.
		* Some items have altered prices.
	* Souls:
		* Zombie Officer Soul actually heals you 5 hp when you jump out of knockback.
		* Succubus only heals 2 HP on hit
		* Final hitbox range of bat soul increased
		* Witch / giant ghost blue souls will destroy tiny devil projectiles when reflected.
		* Ukoback soul spawns a little further from Soma
		* Great armor soul sets STR to 150% instead of 120%. MP cost reduced from 60 to 30.
		* Medusa head soul will cancel all momentum after you un-pause. (Momentum is no longer stored)
		* Ghost Dancer and Gremlin give +8/+16 luck instead of +4/+8
		* +50% Final Strike added to the Dead Crusader Yellow Soul
		* Red Crow: +40 Max MP
		* White Dragon: +40 MaxHP
		* Soft Landing effect on Quezlcoatl and Gorgon Yellow souls
		* Invulnerability on hit on Ghost Dancer and on Nemesis (while it's active)
		* Dead Crusader - +50% Final Strike effect.
		* Rush souls cost 50MP instead of 30 MP.
		* Weretiger: Hold jump to gain height in midair when doing an uppercut.
		* Giant bat: More MP cost (30 MP)
	* Enemies:
		* Iron Golem health is reduced.

Room Randomization details:
	- Aside from the castle entrance and the central lobby room, rooms are randomized each time you go through a new door.
	- Each direction from the lobby is a different generated area, containing rooms from two areas.
		- The areas that are chosen are limited based on difficulty and how many bosses you've defeated (starting with lower difficulty areas).
		- Higher difficulty areas have more difficult enemies
		- If the randomizer fails to randomize to a room not visited recently, it will randomize to a room from Castle Corridor.
	- There is a counter showing how many rooms have been cleared (at least 1 enemy killed in a room)
	- There is a limit to how many rooms each generated area can hold. If you reach the limit, you'll find a dead-end Chaos room.
	- When you defeat a boss, all directions from lobby are randomized. More difficult areas will be added to the area randomization pool.
	- At certain distances from the lobby, you'll find 4-way branching rooms which contain a Book of Return.
	- List of Room Modifiers (occur after 4-way branching rooms):
		- Poisonous enemies
		- Cursed enemies
		- Petrifying enemies
		- Theif enemies (lose gold each time you take damage)
		- Double hp enemies
		- Winged swarm (room has 4 respawning winged skeletons, enemies changed to bats)
		- Ghost swarm (room has 4 respawning Ghosts, enemies changed to more Ghosts)
		- Red souls disabled
		- High knockback
		- Heavy landing (always land as if you have high falling speed)
		- Spectral Enemies (spawns invincible, transparent enemies)
			- Spectral Tiny Devil
			- Spectral Crow
		- Poisonous Hearts (Hearts apply poison and 10 damage)
		- Cursed Gold (Gold applies curse and 10 damage)

Known Bugs / Issues:
- Rare sprite glitches where an enemy or special object (like a moving platform) will have an all-black sprite, or using armor souls will have glitched sprites.

Roadmap/ Wishlist for future features:
	- More rooms!
	- More soul fixes / balancing / new effects.
	- Store high score
	- Add souls to the shop.
	- Custom entities for more variety
	- (Maybe) multiple lobby rooms and a method for traveling between them.
	- (Maybe) Some type of randomization within a room (allowing for enemies / items to spawn in different locations)
	- (Maybe) update Kicker without Malphas patch so that you can’t use kicker to swim underwater before you get Skula

Rom/ISO information:
Rom: Castlevania: Aria of Sorrow (USA)
UNMODDED MD5: E7470DF4D241F73060D14437011B90CE
UNMODDED SHA-1: ABD71FE01EBB201BCC133074DB1DD8C5253776C7

MODDED MD5: 77FB2C41CFE3EA3412F72F52B9B75754
MODDED SHA-1: 57C69497FDF5ACCFD737E411C4C6DD81AC783ECE
