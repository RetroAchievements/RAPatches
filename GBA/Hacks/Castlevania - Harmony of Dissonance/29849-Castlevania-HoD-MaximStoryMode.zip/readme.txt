Use with:

(No Intro)
File:               Castlevania - Harmony of Dissonance (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              88C1B562
MD5:                EA589465486D15E91BA94165C8024B55
SHA1:               B90DA0D9BE0B3A0893CD9E2C399056BCF9579E21
SHA256:             85E0A40DE22783BADBBC95D6BCAD68A3A25D0916C4111956213F8281358A61DB