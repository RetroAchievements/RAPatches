Use with:

(No-Intro)
File:               Pokemon - Sapphire Version (USA, Europe) (Rev 2).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              9CC4410E
MD5:                9BC2B765CA6997175FAC51E6CDC29089
SHA1:               89B45FB172E6B55D51FC0E61989775187F6FE63C
SHA256:             02CA41513580A8B780989DEE428DF747B52A0B1A55BEC617886B4059EB1152FB