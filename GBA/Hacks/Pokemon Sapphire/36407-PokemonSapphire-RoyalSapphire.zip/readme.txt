Use with:

(No Intro)
File:               Pokemon - Sapphire Version (USA, Europe) (Rev 1).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              BAFEDAE5
MD5:                3A32FD98B065283D09EEBA1CE0542888
SHA1:               4722EFB8CD45772CA32555B98FD3B9719F8E60A9
SHA256:             2F680A43E5C57AEDE4CB3B2CB04F7E15079EFC122C88EDAACFD6026DB6E920AC