Use with:

(No-Intro)
File:               Pokemon - LeafGreen Version (USA, Europe) (Rev 1).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DAFFECEC
MD5:                9D33A02159E018D09073E700E1FD10FD
SHA1:               7862C67BDECBE21D1D69CE082CE34327E1C6ED5E
SHA256:             2F978F635B9593F6CA26EC42481C53A6B39F6CDDD894AD5C062C1419FAC58825