Use with:

(No-Intro)
File:               Pokemon - LeafGreen Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              D69C96CC
MD5:                612CA9473451FA42B51D1711031ED5F6
SHA1:               574FA542FFEBB14BE69902D1D36F1EC0A4AFD71E
SHA256:             78D310D557CEEBC593BD393ACC52D1B19A8F023FEC40BC200E6063880D8531FC