Use with:

(No Intro)
File:               Harvest Moon - Friends of Mineral Town (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              8E923168
MD5:                80355C831A7A25B0F70DC021EBD344F1
SHA1:               A2FC3574F0A65A4FCF7682FB274B9D7EEBDEF963
SHA256:             CA6CEBE7211B6F2693AF210709F76222204BF9F7621DEC08B30CA268117460DD