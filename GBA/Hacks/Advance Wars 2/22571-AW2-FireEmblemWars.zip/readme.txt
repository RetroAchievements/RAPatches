Use with:

(No Intro)
File:               Advance Wars 2 - Black Hole Rising (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              5AD0E571
MD5:                46599031EF71117C587BD3666C326C07
SHA1:               14DD0B22C894865867AFF89E8116B2DFFAE25605
SHA256:             EF3CC89273F9DF88020F07751EA6306B25C39DF01893822FE431550EEDF9B134