Fire Emblem: Requiem
Version: v1.4.1
Author: Sacred Blaze

WARNING: Some events and stuff have been shifted in this patch, so this might cause some issues if you try and resume a playthrough on this new patch.

CHANGES:
(1.1)
Fixed some text errors, such as Clive's unit description, Bow Cavaliers class description.
More Promotion Items:
Andrei comes with a heros crest in chapter 15.
Elysian Whip chest in Ch19 is now changed to another Heros Crest.
Secret Shops in Ch 19 contain promotion items.
Elysian Whip is dropped in chapter 19x by pegasus knight in top left corner.
(1.2)
Some text errors fixed.
Deployment count raised on certain chapters (16,19,19x)
Some minor enemy changes. Positions, classes and such.
Marco and Katarina can now promote using the Earth Seal (Power Crest) obtained on chapter 18.
A Rank light tome, Light Cage has now been buffed in power.
Some character bases and growths changed slightly. (Nothing too major, don't worry)
Halberdiers (Emilia) and Snipers (only Linda and Danielle) now have innate +15 critical.
Weapon Ranks upon promotion raised to D for most classes, C for some others.
(1.3)
As always, text errors fixed.
Chest/Door Keys now have more availability outside of secret shops and using Edward. (Still not enough to get all chests without those two methods though)
Thieves on chapter 17 have had their speed reduced to make stealing from them viable. (You'll still need to get Edward's speed up at least a little)
Some character rebalancing. Mostly raising resistance of certain characters, but some growth changes as well.
Boss changes. Bran and Shel are slightly modified, Matthias made significantly better and no longer drops weapon. (given at the end of the level instead)
Ash hard mode is now basically done. Not very different from the main game - stage by stage or turn by turn, but the raised enemy stats, promoted enemies and bosses pose more of a threat than they did in normal, especially in late game.
I doubt many used him on their first playthrough, but Kenrick seemed to have an experience bug on his class and some growths that did not fit those on the sheet provided. Has now been fixed.
Chapter 12 village now fixed.
(1.3.1)
Not really much of note.
Enemy AI and position changes on some stages in the mid-game (15-18)
Shops added to chapter 21 with Steel and Silvers, throwing weapons and Magic and staves.
Some small character rebalances.
(1.4)
New/Revamped portraits. (Mostly)
New map for chapters 6 and 19.
Changes in enemy composition, levels and positioning throughout the later chapters.
A couple more stealable items have been added to some (later) chapters, so lookout for them.
Small rebalances and changed boss stats. As always, nothing major.
Some dialogue changes here and there.
Certain supports are now easier to build.
(1.4.1)
To be added


To play simply follow these steps:

1) Extract files from .rar file (Right-click -> Extract here)
2) Open NUPS and select "Apply an UPS patch to a file"
3) Select a clean FE7 ROM as well as Requiem patch
4) Apply the patch

IMPORTANT:
See bugs section the topic post for more details if you encounter the issue below.
There is a certain bug that you may encounter in Ch.15 (The Dark Path) that may cause the following characters stats to break (By increasing them randomly):

Valentine
Andrei
Kane
Isaac

There are a few things that you can do about this however:

1. Make sure to screenshot these four characters stats (if you plan to use them) in Ch.8 (A Rise and a Fall)
and then if you know how to use them you could use cheat codes in an emulator to make their stats what they once were.

2. Ignore it and keep on playing. If you want to play that way, I'm not (and I couldn't anyway) stopping you.

3. Perhaps try and help me figure out why this is happening. The problem with trying to fix it is that firstly, it doesn't always occur; secondly, it doesn't happen to every character everytime and thirdly, that it seemingly has nothing to do with their Nightmare stats. So I'm at a bit of loss on what to do.


Hopefully this doesn't happen to you if you plan to use any of these four, but even with that being said, for me, it's never actually broken a character stats to the point where they can easily steamroll the game, so you could therefore just follow option 2 anyways.