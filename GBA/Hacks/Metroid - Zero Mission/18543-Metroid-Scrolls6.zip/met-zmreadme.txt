Use with:

Metroid - Zero Mission (USA).gba (No-Intro)
ebbce58109988b6da61ebb06c7a432d5
5C61A844
