Use with:

(No-Intro)
File:               F-Zero - Maximum Velocity (USA, Europe).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              BD5E9798
MD5:                55C14323547AA4F83E5EEDE98D0417F3
SHA1:               8A08E29EC987F9CBDDE21C34D5F7657AA7BA0BE6
SHA256:             50C211F4299818F7C61F5E7AD521E1E086D039452773835C8584BE7C65C29560