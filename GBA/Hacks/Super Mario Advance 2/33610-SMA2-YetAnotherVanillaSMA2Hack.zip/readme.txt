Use with:

(No Intro)
File:               Super Mario Advance 2 - Super Mario World (USA, Australia).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              5206880A
MD5:                2F660377581B7E48C06131F56C791B72
SHA1:               5101DDF223D1D918928FE1F306B63A42ADA14A5E
SHA256:             63D9FFF04C635990A5C205A99EA64BFA698AA5CB9EC1333360063BBEE949A4F3