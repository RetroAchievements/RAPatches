Use with:

[No Intro]
WarioWare - Twisted! (USA).gba
md5: 89579f4dfe1ed24a7cd16a6a61a72a17
CRC: CB4E844B