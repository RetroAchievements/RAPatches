Use with:

(No-Intro)
File:               Golden Sun - The Lost Age (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              606A1C4D
MD5:                8EFE8B2AAED97149E897570CD123FF6E