Use with:

No Intro
Tales of Phantasia (Europe) (En,Fr,De,Es,It).gba
c3439dfd940adeab78b4f9d13599fd49
FA172A4A