Use with:

(No Intro)
File:               DK - King of Swing (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              F93B73D9
MD5:                1D8B145985BB38F9DE77405C9F1FA60B
SHA1:               80717DCDB1844F826DA116C9278DFD1386C92FC1
SHA256:             E19A05E73A548D7C17C8E3B8258069BB0109892962289895FA35E55A0C5E57C3