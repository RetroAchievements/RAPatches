Use with:

(No Intro)
File:               Wario Land 4 (USA, Europe).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              D6141609
MD5:                5FE47355A33E3FABEC2A1607AF88A404