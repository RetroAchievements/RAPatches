Use with:

No Intro
Mega Man Zero 3 (USA).gba
aa1d5eeffcd5e4577db9ee6d9b1100f9
2784F3F2