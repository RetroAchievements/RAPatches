Use with:

Fire Emblem - The Sacred Stones (USA, Australia).gba (No-Intro)
005531fef9efbb642095fb8f64645236
A47246AE
