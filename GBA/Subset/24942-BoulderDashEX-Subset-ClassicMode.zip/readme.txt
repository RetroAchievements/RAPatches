Use with:

(No Intro)
File:               Boulder Dash EX (Europe) (En,Fr,De).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              D41866A9
MD5:                70ED2328306FA863BF144B7FDCDBFDFD