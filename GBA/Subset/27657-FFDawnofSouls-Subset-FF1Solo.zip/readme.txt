Use with:

Final Fantasy I & II: Dawn of Souls (USA).gba
RA Hash: 5d29999685413c4d2bec10d3160f6ee6