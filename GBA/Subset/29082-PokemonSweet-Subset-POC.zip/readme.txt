Use with:

(No Intro)
File:               Pokemon - FireRed Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DD88761C
MD5:                E26EE0D44E809351C8CE2D73C7400CDD
SHA1:               41CB23D8DCCC8EBD7C649CD8FBB58EEACE6E2FDC
SHA256:             3D0C79F1627022E18765766F6CB5EA067F6B5BF7DCA115552189AD65A5C3A8AC


Or

(No Intro + RAPatch)
File:               Pokemon FireRed - Sweet Version (v1.0) (Ephraim225).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              326F3C55
MD5:                D1E174606AC4404499087626E8B60A7D
SHA1:               F8BCCEDE866F4E8F5A2E3B567A2F2F45AA666C88
SHA256:             3C862942E71CBC83C3EB4BB1DACD95BE41E91EAEFA0874EE7A8B61F1142315A8