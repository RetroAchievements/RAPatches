Use with:

(No Intro)
File:               Final Fantasy V Advance (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              7A24AB0C
MD5:                9ED82843CC54876362BE56FACCB15D75