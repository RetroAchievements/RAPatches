Use with:

(No Intro)
File:               Kingdom Hearts - Chain of Memories (Europe) (En,Fr,De,Es,It).gba
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              772D97FB
MD5:                D369F791D86A969778D2C3A5278D544C
SHA1:               8DB73586CDB11B3795907EDEBF43228DBCD3E6B2
SHA256:             A28761AFF292E7F7A5D6DCFF1C1BA11EEFDBE15836EC0DEB8BE275FEC0519BD4