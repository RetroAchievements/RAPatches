Use with:

(No Intro)
File:               Pokemon - Emerald Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              1F1C08FB
MD5:                605B89B67018ABCEA91E693A4DD25BE3
SHA1:               F3AE088181BF583E55DAF962A92BB46F4F1D07B7
SHA256:             A9DEC84DFE7F62AB2220BAFAEF7479DA0929D066ECE16A6885F6226DB19085AF

(No Intro + RAPatches)
System:             Nintendo - Nintendo Entertainment System
Path:               Downloads
Archive:            
File:               Pokemon Emerald - Emerald Rogue (v2.0.1a-EX) (Pokabbie).gba
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              90AC3AF7
MD5:                F595619A4920FC30D65BB31FDCD6B59B
SHA1:               08A03C4BE7B359024C44ADD7C11A4996BABCEAA0
SHA256:             514D29951DF8862A54381F454DF0C81FA4383706F2AD1A8F5DF626842E32CC34