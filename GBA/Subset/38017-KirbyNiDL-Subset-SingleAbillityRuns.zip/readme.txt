Use with:

(No Intro)
File:               Kirby - Nightmare in Dream Land (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              20EF3F64
MD5:                35AE64B0F27E60107C14AB956F6CDF70
SHA1:               37A476567D133C146FEE6B5E2EB0B07A215DA6B0
SHA256:             CAA4E11B6102257939297710DC4B49F6CEC307DE67838B2E7B7627E81B155DB8