Use with:

(No Intro)
Castlevania - Aria of Sorrow (USA).gba
e7470df4d241f73060d14437011b90ce
35536183