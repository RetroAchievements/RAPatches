Mario & Luigi - Superstar Saga (USA) [Subset - Perfect Dodges]
CRC:
MD5:4e0fa9ae471d3d3033ecf7e08a4d5b1a

Use with: Mario & Luigi - Superstar Saga (USA).gba

Save File:
(See forum for same details)
Required Save File for after Queen Bean:
After the fight with Queen Bean you are given a tutorial about Badges and are given a free Badge which is forcefully equipped to Mario as part of the tutorial. This badge gives Mario a +8 to his POW, which will consistently push his POW over the minimum for the Level/POW caps of defeating enemies. Badges also cannot be unequipped; because of this I will have provided a save file which has the badge removed and Marios' POW stat readjusted. Mario and Luigi will begin at level 8 with their Minimum POW (No bonuses added, only level up POW increases). Any achievement requiring you to defeat an enemy or boss below level 8 will need to be done on a fresh save file.