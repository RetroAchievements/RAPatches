Use with:

(No Intro)
File:               Shining Force - Resurrection of the Dark Dragon (Europe) (En,Fr,De,Es,It).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              07B06994
MD5:                17A986AF456ED994F556F23C330666A8
SHA1:               CBE41FBE05E3212C301487A87F6A654C2814196E
SHA256:             8A8485E100D9747E44E3A4255058AF7CC2A425709A7172FCDDD05AD87CC2C1E1