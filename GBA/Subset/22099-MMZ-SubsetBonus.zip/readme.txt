Use with:

(No Intro)
File:               Mega Man Zero (USA, Europe).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              9707D2A1
MD5:                B24A17D080A01A404CBF018BA42B9803