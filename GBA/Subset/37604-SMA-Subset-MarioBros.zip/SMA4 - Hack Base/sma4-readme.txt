Use with:

(No Intro + RAPatch)
File:               Super Mario Advance 4 - Super Mario Bros. 3 (USA) (Rev 1) (Switches - RetroAchievements Edition).gba
BitSize:            31 Mbit
Size (Bytes):       4160784
CRC32:              CE860480
MD5:                D904485BE937FB3E30E4DA5019E34A71
SHA1:               A726C7DB3F177FFFE963F5AEB047C8F7151F3DE3
SHA256:             BD13CBB6D8C1717BB4B7776AF58DECEB787241120E62A4D91A31F55CA3FF3E2C