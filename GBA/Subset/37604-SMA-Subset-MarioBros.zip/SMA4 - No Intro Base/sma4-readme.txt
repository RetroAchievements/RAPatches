Use with:

(No Intro)
File:               Super Mario Advance 4 - Super Mario Bros. 3 (USA, Australia) (Rev 1).gba
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              88DAB27F
MD5:                605286B3AEDEFFBA70BF46B834B120B1
SHA1:               532F3307021637474B6DD37DA059CA360F612337
SHA256:             53EC98FC672D94E3962BA854805CE5005E07E10A4C7ED4E7DBEC7A2CA7846562
