Use with:

(No Intro)
Pokemon - Sapphire Version (USA, Europe) (Rev 2).gba
bec888af544cd36872e422c4cfb1dc74