Use with:

(No Intro)
File:               Fire Emblem - Fuuin no Tsurugi (Japan).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              D38763E1
MD5:                8643FE7632D4895DCAACA230475E70FB
SHA1:               A57095DA867DE4D585C33D4394712986245FE6CA
SHA256:             E62288883544705B18F1A0753896FDD865A628FB4589135813B16A972A4C1557

(No Intro + RAPatches)
File:               FE6 - Project Ember (HM) (v1.85) (Brunhilda).gba
BitSize:            193 Mbit
Size (Bytes):       25355392
CRC32:              636F7B05
MD5:                861A0C1D7C5C7FA3DCAAF4A400743461
SHA1:               6F2CA015FA35C54B3EC67265E487B58711E426B3
SHA256:             F481E1521CCD9F413DE3960D73598FF52EEAD8EF8F8E64A71DA3CFF8271B0EDE