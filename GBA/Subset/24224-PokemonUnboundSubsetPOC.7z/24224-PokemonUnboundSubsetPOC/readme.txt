Apply Pokemon Unbound [Subset - Professor Oak Challenge].bps 
to "Pokemon FireRed - Unbound (v2.1.1,1) (Skeli).gba"
(hash: 9cad8e771940e7f7094d13911552cef0)

or

Apply FireRed - Pokemon Unbound [Subset - Professor Oak Challenge].bps
to "Pokemon - FireRed Version (USA, Europe).gba"
(hash: e26ee0d44e809351c8ce2d73c7400cdd)