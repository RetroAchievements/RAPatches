Use with:

(No Intro)
File:               Pokemon - FireRed Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DD88761C
MD5:                E26EE0D44E809351C8CE2D73C7400CDD

File:               Pokemon - LeafGreen Version (USA).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              D69C96CC
MD5:                612CA9473451FA42B51D1711031ED5F6

Included save files will start you in your bedroom with all Mystery Gift event items claimed.