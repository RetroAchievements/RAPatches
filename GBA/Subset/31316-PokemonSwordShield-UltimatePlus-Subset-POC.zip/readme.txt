Use with:

(No Intro)
File:               Pokemon - FireRed Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              DD88761C
MD5:                E26EE0D44E809351C8CE2D73C7400CDD
SHA1:               41CB23D8DCCC8EBD7C649CD8FBB58EEACE6E2FDC
SHA256:             3D0C79F1627022E18765766F6CB5EA067F6B5BF7DCA115552189AD65A5C3A8AC

(No Intro + RAPatches)
File:               Pokemon FireRed - Sword and Shield Ultimate Plus (En) (v1.1.7) (PCL.G).gba
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              92D835CA
MD5:                62A7878D1B2B2CF2F7ADDBDEBB0FBEB5
SHA1:               80C836E9FD5211EA16CC54EE73F24EB5D690BD3C
SHA256:             6EF8DC4AB9046BCA6D9A922D88307E92B0228233C012A45A7AE476882FFD92A4