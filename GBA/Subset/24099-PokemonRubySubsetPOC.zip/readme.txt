Use with:

(No Intro)
Pokemon - Ruby Version (USA).gba
RA Hash: 53D1A2027AB49DF34A689FAA1FB14726