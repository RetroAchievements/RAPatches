Use with:

(No Intro)
File:               Megaman - Battle Network 3 - White Version (USA).gba
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              0BE4410A
MD5:                68817204A691449E655CBA739DBB0165
SHA1:               FF45038AE6D01CDE4EAE25A02DCB8BED29E07A6F
SHA256:             A161AA80E9EE7E07E85BDA5D1C93AD3D1415E35AEE88380FE117997EBAF6C1C2