Use with:

(No Intro)
e-Reader (USA).gba

RA Checksum:
e71b45bbbe488cc268ef4cfceb92284a [RAVBA]
7b17e51d5a61780f9823203c6254ed8f [Libretro]

CRC32 Checksum:
8B27CD67