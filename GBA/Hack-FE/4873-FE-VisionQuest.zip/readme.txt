Use with:

(No Intro)
File:               Fire Emblem - The Sacred Stones (USA, Australia).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              A47246AE
MD5:                005531FEF9EFBB642095FB8F64645236