Use with:

(No Intro)
File:               Fire Emblem (USA, Australia).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              2A524221
MD5:                F1A1B9742FCD467A531DD4314C4E7D19