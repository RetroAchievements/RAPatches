Use with:

(No-Intro)
Fire Emblem - The Sacred Stones (USA, Australia).gba
005531fef9efbb642095fb8f64645236
A47246AE
