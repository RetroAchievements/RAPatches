﻿Application instructions:
This is an IPS Patch, made for applying on a Pokemon Fire Red v1.0 ROM.  If, and only if, you are experiencing problems with the first patch (namely a black screen in Indigo Plateau), apply the Black Screen Fix patch on top of it.

A quick list of modifications:
-Some Gym Leaders have been altered in minor ways.
-No more Pokemon that don't match a Gym Leader's type, or can't use the Leader's TM.
-SelfDestruct has been restored on most normal battles.
-Running Shoes can be used indoors.
-Trainer Facing Fix has been implemented.
-Intros before Professor Oak and the “previously on your quest” journals have been rid of.
-LeafGreen's Pokemon location differences have been incorporated into FireRed, and the rest have been added to make all the first 251 available.  For the most part this just combines the two, but there are some differences.
-Mankey can no longer be caught before Brock.
-Some less than useful trades have been updated.
-A new “stone” has been created for trade evolutions, these are in place of the Escape Ropes of Rocket Hideout, Silph Co., and Pokemon Mansion.  Also purchasable, but a high price.
-Made the Old Rod a bit more useful than for catching Magikarp.
-Some minor item ball switching.
-Some new item stores have been created, which sell Berries and Hold Items.  They won't necessarily be cheap though!
-Various minor Mart list changes.
-Altering Cave has more of a use now, and has minor aesthetic changes.
-New Pokemon Sprites.
-Decapitalization of text.

Trainer Changes:
-A few trainer class name alterations have been done. Cooltrainer is now Ace Trainer, Cool Couple is now Ace Duo (because Cool=Ace nowadays, Ace Duo is the new canon name for Cool Couple according to X/Y), and Gamers are back to Gamblers.  All references to gambling have been restored on these trainers.

-SelfDestruct is a move that was rid from a whole bunch of trainer lineups for seemingly no real reason except to make the game easier.  These Pokemon have been restored to their normal movesets for the level.
 -This effects most trainers.  A couple, for example Gideon, have been done partway because of custom movesets.

-Fixed Cooltrainer Owen, a trainer with a Nidorino that has Nidorina's moveset and vice versa.

-One or two final rematches have a minor change of Pokemon one evolution step higher, if the level allows it.  Example: Camper Chris in the last rematch team has an Arcanine but still a Charmeleon both at Level 54, they're equal now.

-One or two later Cooltrainers and Black Belts have one Pokemon evolved to a Machamp or Golem.

-Some non-important postgame island traners have some very small changes to their lienups to include more Generation 2 Pokemon that fit in with their theme.  These are mostly simple substitutions, difficulty is definitely not the focus here though they may or may not have a stronger team.  Ruin Maniacs were given a bit more treatment than the others due to their simularities with Hikers, though they still deviate much at all.

Gym Leader Changes:
-Lt. Surge's Raichu knows Mega Punch instead of Quick Attack, and Thunderbolt instead of Thunder Wave.  This is a callback to Yellow; it's also rather odd that his Pikachu and Raichu have the exact same moveset.

-Erika's Tangela has a TM move instead of Constrict, and Sleep Powder instead of Poisonpowder.

-Sabrina's Venomoth has been replaced with a Hypno.  Venomoth's original RBY purpose was to spread status.  This game's version was far worse and needed to be dealt with, not to mention it's neither Psychic nor can learn Calm Mind.  Rest assured that Hypno earns it's purpose plenty, it needed a Tutor move for this. (Slowbro was tossed around a lot in here, it didn't really pan out due to it's moveset at this point in the game.)

-Koga's second Koffing is now a Venomoth (you know how Koga's always bragging about sleep while he never even had one sleeper?  Fixed.), and takes more advantage of TM moves in both this and Weezing (not much here, just both know Sludge Bomb and Weezing has a coverage move to make it a little meaner at least).

-Blaine was changed a little more than the others because he was an especially bad case:
 -Growlithe is replaced with a Ninetales (another callback to Yellow, and it works so well!)
 -Ponyta was replaced with Magmar (a call forward to GSC)
 -Added a TM move to Arcanine (once again, just a coverage move.)

-Giovanni's more changed in movesets:
 -Dugtrio uses Relearners and a TM.
 -Both Nidoqueen and Nidoking have Poison Sting upgraded and an elemental TM.
 -The last Rhyhorn is now a Rhydon, and exchanges Rock Blast for a Tutor move.  Why it was never evolved, I'll never know.

Elite Four Changes:

-Bruno's Onixes are now a Primape and Poliwrath, respectively, and Machamp has Rock Tomb replaced with a Tutor move.
 -In the rematch, they are a Poliwrath and Hitmontop.  Machamp has Brick Break replaced with another TM, and Hitmonlee has it's STAB back.

-Champion has some modifications to his Pokemon's movesets, mostly using TMs and Tutors.

-All rematch battles utilize holding items a little more, and are a bit harder in general when it comes to movesets thanks to minor changes.  These are after all, supposed to be the final five battles in the game.  They weren't changed that much, as for the most part things were initially pretty good for the final versions.

Important Battle Changes:
-The rival battles before Nugget Bridge have un-weirded themselves: Pidgeotto is now a Pidgey and  the starter is evolved.

-In the second-to-last battle, his Pidgeot has Aerial Ace instead of Wing Attack (same power, better move.) and Secret Power instead of Gust.  His stone evolutions have also been done one battle early.

-Rocket Admins' movepools are changed a little, if only for the sake of being more unique.

-Gideon has a Porgygon2 instead of a Porygon.  As it really should've been.

Pokemon Location Changes:

-This isn't going to be so detailed as to require a full location list.  Outside of what is mentioned below, if it's in LeafGreen you'll find it in this version of FireRed, if you're stumped look it up in your Pokedex.  Slowpoke is a special case however: due to how many Water-Types had to be dealt with, you'll find it surfing on the water as opposed to fishing.
 -Speaking of fishing, try using the Old Rod more when you get it: depending on where you cast, you'll probably find a Tentacool, Goldeen, or Poliwag.

-Route 22 no longer has Mankey, instead it has both Nidorans just like in the orignal Red/Blue.  Mankey made the beginning far too easy to be warranted (even though the games even gave Charmander Metal Claw specifically for this reason, odd), but the male version is still really useful for getting through this area.

-Mew is found where Moltres used to be in Red and Blue.

-Grimers were made easier to obtain in Celadon City's lake so you can get one earlier.  Try it with a Good or Super Rod!

-Berry Forest (rarely) and Pattern Bush have Pinsir and Scyther, in case you missed them.

-Treasure Beach has Omanyte and Kabuto available by fishing with a Super Rod.
 -Kangaskhan are also very rarely found in the grass.

-Tauros can rarely be found on Kindle Road.

-Chansey can be found very rarely at Cape Brink.

-Encounter events for the three legendary dogs are scattered about the postgame islands.  They're pretty easy to find.

-As for the Generation 2 Pokemon that are unobtainable in both FireRed and LeafGreen:
 -Memorial Pillar has the starter trio, Hoothoot, and Miltank.
 -Pattern Bush has Shuckle.
 -Fishing in Outcast Island gets you Chinchou, Lanturn, and Corsola. 
 -Altering Cave has Mareep, Aipom, Pineco, Gligar, Teddiursa, Houndour, Stantler, Smeargle, Snubbull, Sudowoodo, Sunkern, and Girafarig.  It also houses Celebi, and it's guarding the gate to the only ticket event that pertains to this hack at all.

-For trade evolution a new item was created for this, the Evo Kit.  These are purchasable at Celadon Dept. Store on the same floor as elemental stones, but it costs far more due to the power of the item.  Every single Pokemon that evolves by a trade, hold items required or not, will evolve by using this.  National Pokedex upgrade requirement still applies.

-Eevee evolves into Espeon and Umbreon using Sun and Moon Stones, respectively.

Trade Changes:
-The trade for a Jynx now asks for a Poliwrath instead of a Poliwhirl, to avoid exploiting the new Old Rod tables.  You can still get a Jynx earlier than vanilla, but not before Rock Tunnel.

-The Nidoran trade before Vermilion now will trade you a Growlithe for your Nidorino.

-The Nidorina trade in the guardhouse next to a Snorlax now trades you a Koffing for your Dugtrio (I made this a hard bargain on purpose: Koffing is actually pretty powerful in points this early.  Dugtrios are still available in Digglet's Cave.)

-The Lickitung trade at the bottom of Cycling Road now asks for a Cloyster instead of a Golduck.

-The Cinnabar Island trades allow you to obtain the starters.

PokeMart Changes and new Marts:
-Celadon Dept. Store's Wiseman Gifts sells Sun Stones, Moon Stones, and Evo Kits.

-Two Island's final Mart list (after you complete the Ruby/Sapphire quest) now also sells every custom Ball, all flutes, and the Shell Bell.

-Three Island's Mart sells TinyMushrooms instead of Escape Ropes.
 -There is also a new Mart next to it that sells all berries.

-A Mart was added in Cinnibar Island's PokeMart that sells type-enhancing hold items. (SilverPowder, Black Belt, etc.)

-Seven Island's Trainer Tower PokeMart sells all TMs.
 -A new Mart next to this sells all other Hold Items (BrightPowder, Choice Band, King's Rock, Focus Band, etc.) and specific Pokemon stat enhancing items (more of an ease-of-life addition, though they are priced high: no need to Thief forever for these anymore!)

Misc. Changes:
-You can now go back up to Mt. Moon after leaving.

-Trainer Facing Fix has been implimented, as was long fixed in previous games.

-Geodude, Voltorb, and Electrode no longer float.

-Zubat, Golbat, and Crobat have had Astonish and Supersonic switched back around.  This moveset placement was specific to FR/LG solely for easier difficulty with randomly enocuntered Zubats.

-The "Game Freak Presents" part of the intro has been fixed, as later illerations of FireRed fixed.

-The glitch that presented you with faulty IVs on roaming encounters has been fixed (it's not a huge deal here as the roaming dogs are all present on postgame islands, but it's there if you need it.)

-The glitch that cuts off Pokemon species names in the Pokedex has been fixed.

-Glitches pertaining to game saves (white screen, 1M sub-circuit, Elite 4 save bug) have been fixed.  This should also make it much more usable in certain flashcarts, though I haven't tested such functionality.  PLEASE NOTE: This also removes the backup memory for when something corrupts, so when you save make sure it's completely done saving or your file is gone.

-When generating a new save, the game will now use all wallpapers in the Box system, meaning the first four are no longer cycled and every PC Box looks unique. 
-Mew now always obeys.

-Whenever you jump off a ledge while running, it now shows a running animation proper.

-The intro before Professor Oak appears is gone.

-Prof. Oak's tutorial text during your first Rival battle is gone.

-Options now have the L/R button options at "LR" instead of "Help" at default.

-The introductory text that tells you your previous movements whenever you continue a game is gone.

-Altering Cave's tilemap was switched around to match events attatched to it, and a warp was added there.

-TM01 and TM36 have switched places, making Sludge Bomb and Poison-Types in general far more useful during the last half of the game.

-Escape Ropes in Pokemon Mansion, Silph Co., and Rocket Hideout have been replaced by Evo Kits.

-The Revive behind the Cut tree on Two Island now is HM08 Dive.

-Running indoors is now possible.

-New Pokemon sprites taken from later games, colored as the original art.

-Items' prices have been balanced (raised a bunch in almost every case) to acount for being sold.  Dragon Scales and Up-Grades now also act as Nuggets in sell price.

About the optional content:

-Drunk Old Man restores the drinking references to the Old Man blocking the road at the beginning of the game.  This is done a bit more like what a localization would've done with the reference so only the dialog of the old man lying out on the ground is completely changed, but the intent is restored in the other parts of the event.  Thanks a bunch to a blog named Kantopia for the translation comparisons.

-Black Jynx replaces the Jynx sprites with a recolored version of the original Fire Red sprite to the tune of the more controversial version in the first and second generations of Pokemon, made by ShadowOne333 with sprite edits by SCD.  You have been warned: not even in Japan did FireRed have a black Jynx.

-No Running Flag removes the flag check for Running Shoes and deletes the event that gives them to you.  In other words, you can run from the very beginning of the game!

-Level 1 Eggs makes all hatched Pokemon Level 1 instead of 5, like in later games.  Optional because some might not find this an improvement.

-New Repel System brings in the prompt for using another Repel after one is gone, like in Black/White 2.

-New Hidden Power locks Hidden Power at 60 power like in the newest games instead of a variable, handy for those who don't enjoy gambling or breeding.  Optional because some do like to do just that.

-New Light Ball updates Light Ball so that it raises Attack as well as Special Attack.  The reason for this is because Pikachu's Special pool consists of only it's Electric staples and possibly Hidden Power.

-Permadeath ends your game and deletes your save upon whiting out.  Perfect for Nuzlockes!

-Moveset Alterations adds various event moves to Pokemon movepools, mostly for the Move Relearner's usage.  It also enables stone evolutions to learn their formerly lost movepools.  There's a readme doc with more detailed information.
 -Abridged Moveset Alterations only adds the stone evolution movesets.  Do not apply both of these at the same time.

-Alt. Champion Rematch replaces the final Rival battle's rematch team with a completely different one, replacing every single Pokemon (Exeggutor and Heracross are still present, but they are different setups.)  It also uses the Generation 2 trio for the starter.  This was originally born out of wondering what the logic behind this team actually was; the original doesn't change a whole lot, and what changes there were outside of Heracross's inclusion are arguably worse.  Optional because it's so radical compared to my more minor changes.

-Old Evolution Unlock enables evolving Pokemon past 151 without the National Dex.  You do not get the National Dex by doing this.  This patch is optional because it doesn't lend very well to the original experience, especially because the Evo Kit exists.  Note that this is seperate from 251 Regional Dex Mode.  Use this only if you plan on nuzlocking with your favorite Hoenn Pokemon or something, there's a better patch for enabling Generation 2 evolutions below.

About 251 Regional Dex Mode:
This is a patch that extends the Regional Pokedex itself to 251 Pokemon, and some Trainers use newer Evolutions.  Basically, this enables all 251 Pokemon to be used and viewed via Pokedex in their entirety.  Optional for reasons which may be obvious.  Note that you do not need the Unlocked Evolutions patch for this, as that is a different method and works for all 386 Pokemon, nor does it enable looking at new evolutions in the Pokedex at all.

-Erika now has a Bellossom instead of a Vileplume, it knows Secret Power instead of Stun Spore and Magical Leaf instead of Acid (to account for lack of STAB).
-Sabrina now has a Slowking instead of a Hypno (the accelerated learning rate makes this somewhat more doable), and the Alakazam now knows the tutor move instead of Future Sight.
-Agatha now has a Crobat instead of a Golbat during the first battle.
-Some Kanto Cooltrainers have an updated evolution (Steelix instead of Onix, Blissey instead of Chansey, etc.)

Notices:
-Menus and yes/no/close choices are not decapitalized.  This is not a bug, it's done by personal preference.
-Altering Cave's picture still appears.  It's not exactly a bug because the game is doing what it's supposed to be doing, but it can feel pretty annoying going to and from the event.  I might change the header for the Altering Cave map later so this doesn't happen.
 -Speaking of which, If I do I might change the outside appearance of it to be white, matching the inside.
-Do not cross this with Throwback, it flat-out won't work.

Credits, etc.:
I do not particularly care about using this for your own hack, but you might want to take into account the free space used via a Hex Editor if you do.  Also some credit would be nice to have, both to me and to those whom I found their information to be useful.  


Tools Used:
G3T
Advance Map 1.92 and XSE
HxD
Text Hex Convert
Unnamed Trainer Editor
An ASM compiler

Thanks:
Game Freak for making such a great remake to the original Pokemon games.
Jambo51 for the Trainer Facing Fix and information on the Pokedex limiters.
Shiny Quagsire for information pertaining to the Running Shoes.
KDS for the ASM used in the New Light Ball patch and information pertaining to New Hidden Power.
Darthatron for the BW2 Repel system
Hackmew for the information about running indoors, Pokedex Glitch, and the IV glitch.
Spherical Ice and Sky High for information about the Pokemon Box wallpaper hack.
MrDollSteak and his group for the Pokemon Sprites.  The DS-Style 64x64 Sprite Resource's set is used in the old sprite set.
diegoisawesome for information pertaining to removing the intros.
daniilS for information pertaining to the ledge jump modification and permadeath patch.
AmineX for the game save fix.
SCD for the sprites used in the Black Jynx patch.
ShadowOne333 for putting together the newest Black Jynx patch.


Questions or Comments?  Found a bug?  Shoot a message over to Chronosplit on Romhacking.net!
