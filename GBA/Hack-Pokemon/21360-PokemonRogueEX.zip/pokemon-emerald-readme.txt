Use with:

(No Intro)
File:               Pokemon - Emerald Version (USA, Europe).gba
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              1F1C08FB
MD5:                605B89B67018ABCEA91E693A4DD25BE3