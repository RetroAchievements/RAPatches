Use with:

No Intro
Pokemon - LeafGreen Version (USA).gba
612ca9473451fa42b51d1711031ed5f6
D69C96CC