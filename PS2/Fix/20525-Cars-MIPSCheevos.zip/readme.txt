Use with:

(Redump)
File:  Disney-Pixar Cars (USA).iso
CRC32: B1B5E6FF
MD5:   6b9cb504909b0112bc8eb2a3fba5b134