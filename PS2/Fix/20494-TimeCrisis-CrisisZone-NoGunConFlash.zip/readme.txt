Use with:

(Redump)
Time Crisis - Crisis Zone (USA).iso
md5: 4d97ad8a29735ebbf7e2b66b0bb6fbf6
crc: 8733CA63