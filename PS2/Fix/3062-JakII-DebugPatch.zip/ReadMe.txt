Base version:

Jak II (USA) (En,Ja,Fr,De,Es,It,Ko) (v1.00).iso
RA Hash:  611dc2054ab54fdee5f8af17f16cc0a3
