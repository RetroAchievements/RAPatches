Use with:

(Redump)
Time Crisis II (USA).bin
md5: ae422fa4614592909d3961bc16651dcb
crc: 00F8D4F9