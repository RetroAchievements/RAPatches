Use with:

(Redump)
File:               Skateboard Madness - Xtreme Edition (Europe).bin
BitSize:            1 Gbit
Size (Bytes):       153505632
CRC32:              9F6F1805
MD5:                1F028A97B6E218114E698194C38207DA
SHA1:               7ABEB0C67EA84E7FEEF05262D0E157FC64448730
SHA256:             FA04447FEE069762D4E4097608729D14238F2F7C14E93AEF48CC9DF1469AA2CB