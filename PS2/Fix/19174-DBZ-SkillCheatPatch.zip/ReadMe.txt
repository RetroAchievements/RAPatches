Base game

Dragon Ball Z - Budokai 2 (USA) 
RAHash: 9358fc389ad2873c0a15653de9b1ce68