Base Version:

Redump
Transformers (USA).iso
MD5: 0662529bcfd29553d3193d952d380d1e
CRC32: 5a8a6dbb
RA Hash: 5ba6567a2382f77633d56523abce865f