Use with:

(Redump)
File:               Pinocchio (Europe) (En,Fr,De) (RA Compatability).bin
BitSize:            680 MB
Size (Bytes):       690657744
CRC32:              92C9C374
MD5:                5EC969E256E480B95722BE4A336E8E80
SHA1:               16605055AA94E8B3D96F551B594B15C2E578BF9E
SHA256:             96A2083A05E749D3C7D7FDF21670FA7C949752114114DE9FEFB3F3BC4EF417F4