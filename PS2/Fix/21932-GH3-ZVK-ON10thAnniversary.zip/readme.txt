Use with:

(Lost Level Archive)
File: GH3 ZV K-ON! Tuned UP! 10th Anniversary (2nd Version).iso
MD5:  228ce422f0b85012284e187f1da52b76
CRC:  013D6FCB