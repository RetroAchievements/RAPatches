Use with:

(Redump)
I-Ninja (Europe) (En,Fr,De,Es,It).iso
md5: b1f8528f17435b05445f5db8e28b119b
crc: 0A538801