Use with:

(Redump)
Legend of Spyro, The - Dawn of the Dragon (USA) (En,Fr,De,Es,It,Nl).iso
md5: b1f0b9d07b155f7e551869bb7f04f5b5
crc: 65D306A1