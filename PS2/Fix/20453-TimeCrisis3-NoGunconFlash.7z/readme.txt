Use with:

(Redump)
Time Crisis 3 (USA).iso
md5: d5cc226c6bb6c9a8342deb2a302c5c64
crc: 788553FA