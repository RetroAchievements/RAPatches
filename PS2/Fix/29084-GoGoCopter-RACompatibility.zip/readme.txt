Use with:

(Redump)
File:               Go Go Copter - Remote Control Helicopter (Europe) (En,Fr,De).bin
BitSize:            5 Gbit
Size (Bytes):       722306256
CRC32:              8082A748
MD5:                B86ED70C6830C8CEB25F3BE34D102687
SHA1:               C20420A7B808A2BB9C139A62EB25554FC8E8E658
SHA256:             7E226A0E6C7CFA8B22EA41548A3C0AC672165F0C4CFAB49C4EEBDB148661E4F2