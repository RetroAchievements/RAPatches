FILE "Hansel and Gretel (Europe) (En,Fr,De) (RA Compatibility).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
