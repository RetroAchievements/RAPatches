FILE "Peter Pan (Europe) (En,Fr,De) (RA Compatibility) (v0.1) (pinguupinguu).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
