Use with:

(Redump)
File:               Transformers (USA).iso
CRC32:              5A8A6DBB
MD5:                0662529bcfd29553d3193d952d380d1e