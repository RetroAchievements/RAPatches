Use with:

(Redump)
File:               Snow White & the 7 Clever Boys (Europe) (En,Fr,De).bin
BitSize:            1 Gbit
Size (Bytes):       627445392
CRC32:              8D02FD83
MD5:                0837396EDE729E5B414F9E49A055B019
SHA1:               60B65880CA3BD283469CFA240BD3529453191C0C
SHA256:             70425ED2F1EFB93CA55490D0EFDF83E4B190987429895882A3D9B4F5A28CD3D9