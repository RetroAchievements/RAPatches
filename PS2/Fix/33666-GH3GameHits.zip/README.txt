Use with:

(Lost Level Archive)
File: Guitar Hero III - Game Hits (v1.0) (Beto Luvas).iso
MD5:  D1E25199E2E83CD21522CC2DE6EDBBD2
CRC:  66BF942F