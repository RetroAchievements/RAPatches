Use with:

(Redump)
Dark Cloud (USA).iso
MD5: b500237e456cd2722cf9189b7b34ad0a
CRC: FE4ADB70