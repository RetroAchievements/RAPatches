Use with:

(Redump)
Disney's The Haunted Mansion (USA).iso
md5: 7287aee3d486f813dca048377b84d9f5
crc: 652CAA1D