Base version:

Jak 3 (USA) (En,Fr,De,Es,It,Pt,Ru).iso
RA Hash: 445a6eba948ddc8ceefc036ea74c00e0