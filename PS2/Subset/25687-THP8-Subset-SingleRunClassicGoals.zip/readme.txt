Use with:

Redump
File: Tony Hawk's Project 8 (USA).iso
MD5: 94baef032b42719acdf6449b7bb2791c
CRC-32: 37efa74f