Use with:

(Redump)
File:               Xenosaga Episode III - Also sprach Zarathustra (USA) (Disc 1).iso
Size (Bytes):       3923804160
CRC32:              cfd0d722
MD5:                a1fa0f0388b19220cb1115c998600586
SHA1:               30a887e6942cef57099bc9c84de5b39974e62f9a

File:               Xenosaga Episode III - Also sprach Zarathustra (USA) (Disc 2).iso
Size (Bytes):       4515954688
CRC32:              1855b442
MD5:                3bdd9a387aa259d11f39d81158b1972d
SHA1:               9902a798f2f4a7d7a4af6078ec3e5ec5107d5450

