Use with:

Redump
Pac-Man World 2 (USA) (v1.00).iso
MD5: b79c4f9ea9bbaec0edf884f963cc9022
CRC32: dd16b5ce
RA Checksum: 8ffd544a22cc814fd340cae387d18eb1