Use with:

(Redump)
File:               Battlefield 2 - Modern Combat (USA).iso
Size (Bytes):       3614113792
CRC32:              7EF88D2B
MD5:                7c2e28907800529b686de0f4cba286e2