Use with:

Redump
Dynasty Warriors 6 (USA).iso
MD5: e01cf15af84c3a1efb42a06a64ad6436
CRC32: a3971331
RA Checksum: 0f47fb08279267bcb5787e07bd475518

UNDUB Version: 
Dynasty Warriors 6 (U) UNDUB v1.0.iso
MD5: a419289b3b3752a6b6697011438b2424
CRC32: fc23e9aa
RA Checksum: 0f47fb08279267bcb5787e07bd475518 <Same Checksum>

Save before leaving each level if you've reached max character level. don't save after the level is over... Load that in-game save in the subset... Finish the level, then return back to the main game. 