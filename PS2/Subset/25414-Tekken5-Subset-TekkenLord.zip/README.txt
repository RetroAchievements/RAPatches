For use with:
Tekken 5 (USA) 
RA Hash:2035c46c67113e96a91f84e209e6f6dc