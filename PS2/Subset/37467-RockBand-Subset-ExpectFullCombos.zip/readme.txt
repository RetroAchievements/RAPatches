Use with:

(Redump)
Rock Band (Europe, Australia) (En,Fr,De,Es,It) 
MD5: baa0c750cd811b881211674a0aa9126e
CRC: 1E549FAA