Use with:

Redump
Shinobi (USA) (En,Ja).iso
MD5: 1f3cd260e7e083d3e4c9269b9e3469cd
CRC-32: 0ce7efc0