Use with:

(Redump)
Grand Theft Auto - Vice City Stories (USA).iso
md5: 3bf85783142bd4ebf8535b29d4251a67
crc: 69C1139C