Use with:

Redump
Shin Megami Tensei - Persona 4 (USA).iso
CRC: 66E20DE9
MD5: 7419b3f9c1d68585960c8c32aab5c758

Redump + Undub
Shin Megami Tensei - Persona 4 (USA) (Undub).iso
CRC: ADF6F564
MD5: f3eb678e0eac6ae0594e184b4f2a6731