Use with:

(Redump)
File:               Naruto - Ultimate Ninja (USA).iso
Size (Bytes):       1515290624	
CRC32:              94729938
MD5:                4efad49490663b31b74a32f6e4e85d56