Use with:

Redump
File: Tony Hawk's Pro Skater 4 (USA) (v2.01).iso
MD5: 7d7cf01d5b3da4e8ec716883563b050b
CRC-32: f61a55dd