Use with:

Redump
Guitar Hero (USA).iso
===========================================
Document		Algorithm	Checksum			Checksum/Digest
"Guitar Hero (USA).iso"	"CRC (32 bit)"	1032956258			3D91A962
"Guitar Hero (USA).iso"	"MD5 (128 bit)"	FF4DD0C598DCF42096B9D52F8590A9A8
===========================================
RA Hash: b0e9cceeacc51c1d827f569b82ed7060




