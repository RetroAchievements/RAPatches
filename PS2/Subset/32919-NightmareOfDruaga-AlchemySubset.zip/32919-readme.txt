Use with:

Redump
Nightmare of Druaga, The - Fushigino Dungeon (USA).iso
MD5: 59627d03e9b2af7a04c70ee32727b321
CRC-32: 5EBBD466