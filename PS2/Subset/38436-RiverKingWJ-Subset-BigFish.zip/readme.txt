Use with:

(Redump)
File:  Harvest Fishing (Europe).iso
CRC32: d4adc517
MD5:   a0bd51fe3904858c29047066a9a478f8

File:  River King - A Wonderful Journey (USA).iso
CRC32: 6ea1c04e
MD5:   6fdfcce25ced8a786d19e45b7e02c410

File:  Kawa no Nushi Tsuri - Wonderful Journey (Japan).iso
CRC32: 79cd3535
MD5:   77856b0413adb509577539bce7e156e6