Use with:

(Redump)
Grand Theft Auto - San Andreas (USA) (v1.03).iso
c383c015065f8060343032480928d08d
1c5e0eee