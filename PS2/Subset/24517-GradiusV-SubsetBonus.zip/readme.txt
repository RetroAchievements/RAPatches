Use with:

(Redump)
Gradius V (USA).bin
MD5: bed560ec8de61e192371c3b16df911fa
CRC: CD10C7F2