Use with:

(Redump)
File:               Vib-Ripple (Japan).bin
Size (Bytes):       113559264		
CRC32:              1eeb56e0
MD5:                a3674543acd7a73e70309a09bfc4bba0