Use with:

(Redump)
Shin Megami Tensei - Persona 3 FES (USA).iso
MD5: 4b16317a11f3089090748b7eca2acbaf
CRC: 9E15FB39