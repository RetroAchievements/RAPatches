Use with:

(Redump)
File:               Dot Hack Part 3 - Outbreak (USA).iso
BitSize:            28 Gbit
Size (Bytes):       3808460800
CRC32:              9B889BD0
MD5:                2847F78A17F87E6C9772029B5CAAD4F6