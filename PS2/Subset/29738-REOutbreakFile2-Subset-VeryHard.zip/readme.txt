Use with:

(Redump)
Resident Evil - Outbreak - File 2 (USA).iso
51af13298e1a761eb5776bb215eb8179
9E69477A