Use with:

(Redump)
File:               Dot Hack Part 2 - Mutation (USA).iso
BitSize:            27 Gbit
Size (Bytes):       3748757504
CRC32:              8C55C266
MD5:                75C2CFDAB4A880833CAF7D3FD2F4E0B9