Use with:

(Redump + RAPatches)
https://github.com/RetroAchievements/RAPatches/raw/refs/heads/main/PS2/Translation/English/2780-KingdomHeartsFinalMix-English.7z
File:               Kingdom Hearts - Final Mix (Japan) (En) (2025-05-09) (Crazycatz00).iso
Size (Bytes):       3542579200
CRC32:              526FE16C
MD5:                8a68b25a543e8816307853361a0dccce

(Lost Leverl Archives)
File:               Kingdom Hearts - Final Mix (Japan) (En) (v2.2.1) (Crazycatz00).iso
Size (Bytes):       3542579200
CRC32:              526FE16C
MD5:                8a68b25a543e8816307853361a0dccce