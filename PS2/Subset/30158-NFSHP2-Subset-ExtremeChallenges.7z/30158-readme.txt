Use with:

Redump
Need for Speed - Hot Pursuit 2 (Europe, Australia) (En,Fr,De,Es,It,Sv) (v2.00)
MD5: 3bd0dff031be174427aa0a5332b6df36
CRC32: 6b8e7ce9
RA Checksum: b49c3351f3181673ca4f682cb04fbd6b

Redump
Need for Speed - Hot Pursuit 2 (USA)
MD5: 46d29850b0be374d7cd28a7ce71b6f73
CRC32: 2da6b351
RA Checksum: bf5ebb8efbeaa90821ed404132fb2eab
