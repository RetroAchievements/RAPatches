Use with:
Redump
Tony Hawk's Underground (USA).iso
MD5: 39ed88773503866f9223f937d1ffd37d
CRC-32: 2c33fa15

Intructions:
1. Apply the Tony Hawk's Underground (USA) [Subset - RAdical Custom Goals & Gaps].xdelta patch to the Tony Hawk's Underground (USA).iso with the xdelta program.
2. Copy a memory card file with custom content to the PCSX2/memcards directory, and ensure PCSX2 has the memory card inserted.
3. Start the game and load the custom content in the Create / Play Goals menu.