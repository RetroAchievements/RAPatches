Use with:

Yakuza 2 (USA).iso
md5: 0c463653e86ab8a9bbd64c2991a44032
crc: 0EDA9DF2