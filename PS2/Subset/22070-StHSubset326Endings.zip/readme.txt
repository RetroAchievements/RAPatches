Use with:

REDUMP
Shadow The Hedgehog (USA).iso
MD5: 19b9dee202d83312a23b795ba0544234
CRC32: 9aaef11d
RA Checksum: 1d42018f00f13dc6b44adbcdf1db0622