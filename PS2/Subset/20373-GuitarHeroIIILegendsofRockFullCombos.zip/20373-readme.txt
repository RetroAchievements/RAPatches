Use with:

Redump
Guitar Hero III - Legends of Rock (USA).iso
===========================================
Document				        Algorithm	Checksum	Checksum/Digest
"Guitar Hero III - Legends of Rock (USA).iso"	"CRC (32 bit)"	168814355	0A0FE713
"Guitar Hero III - Legends of Rock (USA).iso"	"MD5 (128 bit)" 8885121810376D7C21845B7805FA8084
===========================================
RA Hash: b70f414d13dc1db98c6d0e975fda6723