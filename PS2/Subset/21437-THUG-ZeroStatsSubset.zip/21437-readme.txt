Base:
Redump
Tony Hawk's Underground (USA).iso
CRC-32: 2c33fa15

Intructions:
Apply the Tony Hawk's Underground (USA) [Subset - Zero Stats].xdelta patch to Tony Hawk's Underground (USA).iso with the xdelta program. Copy the Mcd001.ps2 memory card file to your PCSX2/memcards directory.