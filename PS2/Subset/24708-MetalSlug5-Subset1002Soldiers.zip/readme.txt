Use with:

(Redump)
Metal Slug 5 (USA).iso
MD5: 06f1390d7e909e11c4dfeda31e0dfc22
CRC: 70F8BB69