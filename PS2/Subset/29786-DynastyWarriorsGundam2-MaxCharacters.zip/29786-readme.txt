Use with:

Redump
Dynasty Warriors - Gundam 2 (USA).iso
MD5: 742229373c8b52e81270c2192959c14b
CRC32: 693da105
RA Checksum: f87678b63edbd1f2d0c632185d7ad912

Does not work with Undub, Sorry about that.  (Save your near Maxes for Core + Subset) 