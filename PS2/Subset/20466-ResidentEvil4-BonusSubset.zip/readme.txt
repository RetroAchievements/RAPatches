Use with:

(Redump)
Resident Evil 4 (USA).iso
MD5: 84330d2465d55ae391000a475ef4ac76
CRC: 12C8B35C