Use with:

(Redump)
File:               Dot Hack Part 1 - Infection (USA).iso
BitSize:            19 Gbit
Size (Bytes):       2598567936
CRC32:              DA0304B4
MD5:                ECA5B2C41B7833EE38D489002C7AABC4