Base:
Redump
Pac-Man World 2 (USA) (v1.00).iso
CRC-32: dd16b5ce

Intructions:
Apply the Pac-Man World 2 (USA) (v1.00) [Subset - Sue's Arcade].xdelta patch to Pac-Man World 2 (USA) (v1.00).iso with the xdelta program.