Use with:

(Redump)
Shin Megami Tensei - Persona 3 FES (USA).iso
MD5: 4b16317a11f3089090748b7eca2acbaf
CRC: 9E15FB39



(Redump + RAPatches/Lost Level Archive)
Shin Megami Tensei - Persona 3 FES (USA) (Direct Commands) (v1.1) (TGE) (Undub - Original BGM) (v1.01) (Fei).iso
CRC: 7b41861db8d5314c1c80ec918f6e14ef
MD5: DA576993
https://archive.org/download/rapatches-misc.-collection/Sony%20-%20PlayStation%202/

(Redump + RAPatches/Lost Level Archive)
Shin Megami Tensei - Persona 3 FES (USA) (Direct Commands) (v1.1) (TGE) (Undub - Remix BGM) (v1.01) (Fei).iso
CRC: dfdc589575a1c6384de1227ef25d7940
MD5: 45241FD4
https://archive.org/download/rapatches-misc.-collection/Sony%20-%20PlayStation%202/

(Redump + RAPatches/Lost Level Archive)
Shin Megami Tensei - Persona 3 FES (USA) (Direct Commands) (v1.1) (TGE).iso
CRC: 5f045361d394575915a443944a8699ef
MD5: FFC1D7B5
https://archive.org/download/rapatches-misc.-collection/Sony%20-%20PlayStation%202/

(Redump + RAPatches/Lost Level Archive)
- Shin Megami Tensei - Persona 3 FES (USA) (Es) (v1.1b) (TraduSquare).iso
- CRC: 5f045361d394575915a443944a8699ef
- MD5: FFC1D7B5
- https://github.com/RetroAchievements/RAPatches/raw/refs/heads/main/PS2/Translation/Spanish/2657-SMT-Persona3-Spanish.zip

(Redump + RAPatches/Lost Level Archive)
Shin Megami Tensei - Persona 3 FES (USA) (Undub - Original BGM) (v1.01) (Fei).iso
CRC: afb5ba7e16953b6e6890bb56a7ec5eaa
MD5: 700B46B2
https://archive.org/download/rapatches-misc.-collection/Sony%20-%20PlayStation%202/

(Redump + RAPatches/Lost Level Archive)
Shin Megami Tensei - Persona 3 FES (USA) (Undub - Remix BGM) (v1.01) (Fei).iso
CRC: 9b89f172c98f09394313fc9d177fe2cb
MD5: A6DE40DA
https://archive.org/download/rapatches-misc.-collection/Sony%20-%20PlayStation%202/

