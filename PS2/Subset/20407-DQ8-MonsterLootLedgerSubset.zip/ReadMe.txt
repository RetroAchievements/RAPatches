Filename: Dragon Quest VIII - Journey of the Cursed King (USA) - Monster Loot Ledger Subset.xdelta
CRC:11B65AB1
MD5:261a9cba1640c26889e2f25a5bf463b7

For use on Dragon Quest VIII - Journey of the Cursed King (USA).iso