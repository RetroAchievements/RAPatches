Use with:

(Redump)
Monster Hunter (Japan).iso
md5: 8d8e50010fd2516d8bf2d3073e1603b1
crc: B5EDCC25

(Redump + RAPatches)
Monster Hunter (Japan) (En) (v9) (MH Oldschool).iso
md5: f9e2de8b3ea4a23b90063f20d69f6e8d
crc: 8827CFD4