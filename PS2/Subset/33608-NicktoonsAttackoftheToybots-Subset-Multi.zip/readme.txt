Use with:

(Redump)
File: Nicktoons - Attack of the Toybots (USA).iso
MD5:  b94c5bd52baeedbc7635b52c3417c1f5
CRC:  25afb651