FILE "RC Revenge Pro (USA) [Subset - RA Dev Tracks].bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
