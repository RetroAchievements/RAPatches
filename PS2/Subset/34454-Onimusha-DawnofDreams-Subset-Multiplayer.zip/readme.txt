Use with:

(Redump)
File:  Shin Onimusha - Dawn of Dreams (Japan) (En,Ja) (Disc 1) (PlayStation 2 the Best).iso
CRC32: DEE93128
MD5:   32afe6ea650ee92548684613e14c2b85

File:  Shin Onimusha - Dawn of Dreams (Japan) (En,Ja) (Disc 2) (PlayStation 2 the Best).iso
CRC32: EDE05373
MD5:   4622cd802c730abf913d7318b16b85b6

