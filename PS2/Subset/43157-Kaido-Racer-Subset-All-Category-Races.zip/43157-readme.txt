Use with:

Redump
Kaido Racer (Europe) (En,Fr,De,Es,It)
MD5: ad0adf3f0662f7fcd29f6b2391168a8a
CRC: F7780E06
RA Checksum: b9d1784dc5c5b9301f26f826f6c5f07b