Use with:

(Redump + RAPatches)
Dragon Quest V - Bride of the Sky (Japan) (En-DQ) (v1.2) (DQ Translations).iso
MD5: 6015480cd73d80417a0e483c71c4a0d2
CRC: D36DCC95