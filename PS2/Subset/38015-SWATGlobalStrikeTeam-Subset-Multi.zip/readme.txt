Use with:

(Redump)
File:  SWAT - Global Strike Team (USA).iso
CRC32: 8FC54DA5
MD5:   805b7631471d96875d4870044d6fb10e