Use with:

(Redump)
Shadow Hearts (USA).iso
MD5: c2782ace8bd69ddae0b0b77d285c4373
CRC: 68ED77E2

Shadow Hearts (Europe) (En,Fr,De).iso
MD5: e2af4a3095c149c2dc25dcdb71607f8e
CRC: CEC61F3B