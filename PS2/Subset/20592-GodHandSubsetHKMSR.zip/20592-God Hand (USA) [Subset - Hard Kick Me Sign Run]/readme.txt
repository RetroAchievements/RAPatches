God Hand (USA) [Subset - Hard Kick Me Sign Run].xdelta
CRC:36ACBCDD
MD5:ff91d5cd6a45ee562109993f9a47028c

Use with: God Hand (USA).iso