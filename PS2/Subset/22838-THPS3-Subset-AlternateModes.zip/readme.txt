Use with:

(Redump)
Tony Hawk's Pro Skater 3 (USA).iso
md5: cdad22713141f2e313526071c4e6c0fe
crc: bb830d5d