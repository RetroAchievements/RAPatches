Use with:

(Redump)
File:               Dot Hack Part 4 - Quarantine (USA).iso
BitSize:            33 Gbit
Size (Bytes):       4458315776
CRC32:              C6453825
MD5:                7277C0BD0905EC307B9216F9F8DE4D1A