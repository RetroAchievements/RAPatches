Use with:

(Redump)
File: Formula One 06 (Europe, Australia) (En,Fr,De,Es,It,Pt,Fi)
MD5:  f8af97e751bd392c6bb575f070ec7d8a
CRC:  DE5021A1