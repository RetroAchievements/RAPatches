Base:
Redump
Tony Hawk's Underground (USA).iso
CRC-32: 2c33fa15

Intructions:
Apply the Tony Hawk's Underground (USA) [Subset - RAdical Custom Goals].xdelta patch to Tony Hawk's Underground (USA).iso with the xdelta program. Copy the desired memory card file to your PCSX2/memcards directory.