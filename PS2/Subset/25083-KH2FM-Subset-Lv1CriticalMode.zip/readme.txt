Use with:

KH2FM.iso (this must be already patched with the English patch made by Crazycatz00, v0.99.1522.0425r: https://crazycatz00.x10host.com/KH/kh2_patches.html)
c023491a8e0fca9cd23077355e989d12