Use with:

(Redump)
Metal Gear Solid 2 - Substance (USA).iso
MD5: 18e455d228247f84afd5e6454a75cb6f
CRC: 574B821F