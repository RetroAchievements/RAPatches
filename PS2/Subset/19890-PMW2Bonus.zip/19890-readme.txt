Base:
Redump
Pac-Man World 2 (USA) (v2.00).iso
CRC-32: 8ad2c3f1

Intructions:
Apply the Pac-Man World 2 (USA) (v2.00) [Subset - Bonus].xdelta patch to Pac-Man World 2 (USA) (v2.00).iso with the xdelta program.