Use with:

(Redump)
File	Dirge of Cerberus - Final Fantasy VII (USA).iso
CRC32:	5AB0E4AB
MD5:	d6c91ef6da2c0faa9e4d2da3e077d050