Use with:

Dragon Ball Z - Budokai 2 (USA) (Skill Cheat Patch)  
RA Hash: C2A0157C94A7E6AC4092A35A01F708AB