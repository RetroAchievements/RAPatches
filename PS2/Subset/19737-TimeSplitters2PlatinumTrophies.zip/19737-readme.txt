Use with:

(Redump)
TimeSplitters 2 (USA).iso
MD5: c5af61b889429c170847dbfe9e3575bf
CRC: F439FBFC
RA Hash: 56ff8d862dfc33bfc2017b76a599cd5e