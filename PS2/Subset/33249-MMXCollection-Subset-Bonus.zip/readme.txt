Use with:

(Redump)
File: Mega Man X Collection (USA).iso
MD5:  c11aa78f53581f4c25082c9a96b9dc74
CRC:  96670557