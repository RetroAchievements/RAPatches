Use with:

(Redump)
File:               Mortal Kombat - Shaolin Monks (USA).iso
Size (Bytes):       3495460864
CRC32:              BF58984F
MD5:                29814fa04d11ed605a89f3b820e756b0