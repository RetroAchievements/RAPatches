Use with:

(Redump)
Shin Megami Tensei - Persona 4 (USA).iso
MD5: 7419b3f9c1d68585960c8c32aab5c758
CRC: 66E20DE9