Use with:

(Redump)
File:               Harry Potter and the Chamber of Secrets (USA).bin
BitSize:            4 Gbit
Size (Bytes):       645823920
CRC32:              2E446506
MD5:                F20AC8DFD9DF9500CF18CDF594A5A987
SHA1:               62699589B4F1E6544CA56E3CB499628D4E5C7C65
SHA256:             5BEC8EDABE3326015F5B930762E03241F459DC4D605B4375679964BBCCCD0AB3