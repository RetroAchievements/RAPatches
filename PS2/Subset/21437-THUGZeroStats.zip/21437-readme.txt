Use with:

Redump
Tony Hawk's Underground (USA).iso
CRC-32 Checksum: 2c33fa15

Patch by: Bartis1989