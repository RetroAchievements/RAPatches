Use with:

(Redump)
File:  DOA2 - Hardcore (Japan) (En,Ja,Fr,De,Es,It).iso
CRC32: 6F1D012F
MD5:   7817c13465d96b192f7b2938ab820a25