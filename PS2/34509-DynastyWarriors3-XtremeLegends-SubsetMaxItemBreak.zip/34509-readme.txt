Use with:

Redump
Dynasty Warriors 3 - Xtreme Legends (USA).iso
MD5: a23bba03ad722b382791bebc52e2317f
CRC32: deeec302
RA Checksum: cad5e43ebaee5907dc9e2159b775d100

Save before leaving each level if you're item breaking.  If you get a max level item break, don't save... Load that save in the subset... Finish the level, then return back to the main game. 