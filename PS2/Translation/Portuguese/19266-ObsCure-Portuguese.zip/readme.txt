Use with:

(Redump)
file: ObsCure (USA) (En,Fr,Es).iso
md5:  433f46abe06b4c9ca6acd894d46c7196
crc:  260936A4