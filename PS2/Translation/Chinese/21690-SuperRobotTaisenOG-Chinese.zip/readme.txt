Use with:

(Redump)
File: Super Robot Taisen OG - Original Generations (Japan, Korea).iso
CRC:  02024BA7
MD5:  5f8ef32e8497c403c3a39fbabc4f90ec
