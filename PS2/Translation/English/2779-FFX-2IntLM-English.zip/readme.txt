PROJECT TEAM:
 ⚜︎Romhacker & Transtion: Gledson999
 ⚜︎Tools: Gledson999, Gdkchan and Nameless
 ⚜︎Bug Fix & Special Thanks: kr_ps2
 ⚜︎Battle star position system: Denim

WEBSITES:
 🌎retro-jogos.com

TRANSLATION STATUS:
 ✔️Menu: 100%
 ✔️Missions: 100%
 ✔️Event Texts: 100%
 ✔️Textures & Images: 100%

How to apply the translation:
 ▶︎Download FFX_ISOPatcher.exe and run the program.
 ▶︎Click the Open ISO button and select the Final Fantasy X-2 International + Last Mission (*.iso) image.
 ▶︎Click the Apply Patch button and wait for the patch to be applied.