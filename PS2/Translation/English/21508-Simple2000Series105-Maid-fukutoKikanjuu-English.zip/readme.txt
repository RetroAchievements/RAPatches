Use with:

(Redump)
File:               Simple 2000 Series Vol. 105 - The Maid-fuku to Kikanjuu (Japan).bin
BitSize:            1 Gbit
Size (Bytes):       229642224
CRC32:              734E75E7
MD5:                51975FB2548CE5E4380ADF9D40E8C290
SHA1:               CA87965D3EF9846BFCFAA2B33E97CE1CD5AC834A
SHA256:             480629EF799EDDC2A1FB4A88EA111C7E72DAE5B7D8521EA097C378380C225EB1