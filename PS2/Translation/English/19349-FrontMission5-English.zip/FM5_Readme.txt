FRONT MISSION 5: SCARS OF THE WAR
FAN TRANSLATION PROJECT, BETA PATCH NOTES
By Front Mission Series: The Fan Translation Project

---------------------
VERY IMPORTANT NOTICE
---------------------

The patch translates everything into English. There is just one
thing that hasn't been inserted and that is...

EVENTS:

- Event 01 with English subtitles

Due to sound issues, we could not insert this into the game. We could
do it, but there would be no sound playing and we feel this would take
away from the experience.

However, we have a workaround solution for this. To see this event, please
go to YouTube and check LegaiaRules' account. The video will be up with the
appropriate title on this user account.

ENGLISH PACKAGING:

If you have not already done soon, the team has uploaded a complete English
package of the game at frontmission.info. The package includes the DVD box
cover, disc label, and instruction manual. Please enjoy our gifts to you!

OTHER:

On a final note, due to countless inquiries that we have received, you MUST
PLAY THROUGH THE PREVIOUS FOUR FRONT MISSIONS TO TRULY UNDERSTAND WHAT GOES
ON IN FRONT MISSION 5: SCARS OF THE WAR! We cannot stress this enough after
realizing the 100s of connections, easter eggs, and such that are placed in
the game. Here is a quick breakdown of Front Mission 5's story and its 
relation to the other installments:

(Standalone)
Front Mission 5: Scars of the War - 50%

(Connections)
Front Mission 1st - 20%
Front Mission 2 - 20%
Front Mission 3 - 7.5%
Front Mission 4 - 2.5%
Optional Bonus:
Front Mission 2089: Border of Madness (remake of 2089 and 2089-II) - 2.5%

If you have not played any of these installments and don't have the time to
tackle them all, you only really need Front Missions 1st, 2, and 3. These
three have the most plot relevance and spoiler material in the game, the
first two in particular. Front Mission 4 is not really necessary unless you
want to see how some situations come to be.

Aside from connections, the following installments are referenced:

Front Mission: Alternative
Front Mission 2089: Border of Madness
Front Mission 1st
Front Mission 2
Front Mission 3
Front Mission 4

DO NOT fret if you can't find Front Mission 2 or can't understand it; this
is our NEXT project!

------------------------------------------------------------------------------
GENERAL INFORMATION
------------------------------------------------------------------------------

UPDATES
-------

General information on the project can be found on the following link:

http://frontmission.info/

------------------------------------------------------------------------------
DISCLAIMER
------------------------------------------------------------------------------

We do not condone piracy in any form. We intend to respect Square Enix
copyrights as fully as possible. This is a purely voluntary, not-for-profit
localization effort. We do this for love, not profit, of the series. we hope
Square Enix will have empathy and understanding on this matter.

*********************************
PLEASE READ THE FOLLOWING SECTION
*********************************

Team's Note:

We do not encourage distribution of patches through BitTorrent or other 
means. This is very disrespectful to us and the hard work we put into the
project. Basically, this is plagiarism. If any sort of patch or patched
copy is found outside of frontmission.info, we WILL NOT MAKE FUTURE PATCHES
AVAILABLE ON THE DOWNLOADS SECTION! That means when we release future 
patches, you will have to prove to us that you will refrain from this sort
of action. Respect the team, do not attempt to distribute patches or 
patched copies outside of frontmission.info, and all will be well.

Likewise, please refrain from selling patches or patched copies of the 
game. This is illegal and will likely attract unwanted attention(namely 
Square Enix). We DO NOT want to encounter any form of legal trouble so 
keep this in mind.

-----------------------
VERY IMPORTANT REMINDER
-----------------------

KEEP THIS PATCH AND ANY PATCHED IMAGES OF THE GAME OFF THE INTERNET IF YOU
WANT TO SEE ANY OTHER FRONT MISSIONS TRANSLATED BY US AND DON'T WANT SQUARE
ENIX TO CEASE-AND-DESIST US! IF YOU WANT TO SEE FRONT MISSION 2 AND ANY 
OTHER JAPANESE-ONLY FM GAMES, RESPECT OUR REQUESTS!

*****************************
PLEASE READ THE ABOVE SECTION
*****************************

------------------------------------------------------------------------------
CREDITS
------------------------------------------------------------------------------

Team's Note:

For privacy(and safety) reasons, names given are based on our online names
from GameFAQs or other forums. While everyone on the team multi-tasks, only 
their primary role is listed below. These are also listed in the in-game
and instruction manual credits sections.

----------
MANAGEMENT
----------

Project Manager:
LegaiaRules

Website Manager:
IcemanUK

-----------
TRANSLATION
-----------

Translator Lead:
Vicious_KAT

Translators:
BRPXQZME
ArkGear
LegaiaRules
mahoryu
silverfox
wswingley
slavikcc


-------
EDITING
-------

Editing Lead:
mikklo
slavikcc

Editors:
LegaiaRules
mahoryu
inihility
Vicious_KAT
Snarkles

GUI Artist:
Peter08101985

Military Advisor:
willchu

Political Advisor:
slavikcc

-----------
PROGRAMMING
-----------

Programming Lead:
AK_Clan_ER

Programmers:
bayfield
w_z

----------------------
QUALITY ASSURANCE (QA)
----------------------

QA Lead:
Dunan Mithryn

QA Analysts:
FBMWhite
SlamVook

--------------
SPECIAL THANKS
--------------

Individuals:
- MoxHypKa for assistance in locating text assets, the subtitles
in the Epilogue screen, and good feedback on the patches
- Djinn for assistance in change the Winning/Losing Condition
GUI files into a readable format, in which they could be edited
- HoRRoR for help on manipulating with pointers and the font
tables

Others:
- Toshiro Tsuchida for creating the Front Mission series
- Square Enix for developing the Front Mission series
- GameFAQs community for their support
- Romhacking.net community for their support
- shedevr.org.ru community for their ROM hacking advices
...and all fans who support this project