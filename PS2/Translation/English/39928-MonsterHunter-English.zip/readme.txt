Use with:

(Redump)
Monster Hunter (Japan).iso
md5: 8d8e50010fd2516d8bf2d3073e1603b1
crc: B5EDCC25


Monster Hunter (Japan) (En) (v9) (MH Oldschool) (MH1JPlus) (v4.2) (Nikki) is to be used on
Monster Hunter (Japan) (En) (v9) (MH Oldschool).iso