Use with:

(Redump)
Jojo no Kimyou na Bouken - Ougon no Kaze (Japan).iso
MD5: f77bd1415b1202af55a23a2f6091a1bb
CRC: 79A4677D