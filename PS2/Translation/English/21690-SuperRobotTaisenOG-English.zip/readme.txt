Use with:

(Redump)
Super Robot Taisen OG - Original Generations (Japan, Korea).iso
MD5: 5f8ef32e8497c403c3a39fbabc4f90ec
CRC: 02024BA7