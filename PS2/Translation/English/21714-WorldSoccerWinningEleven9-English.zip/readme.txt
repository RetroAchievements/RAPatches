Use with:

(Redump)
File: World Soccer Winning Eleven 9 (Japan).iso
MD5:  dcc1b1d2e488a85c3999a7a1869848ff
CRC:  D1BE47DF