Use with:

(Redump)
Tales of Destiny 2 (Japan, Asia).iso
MD5: 57cc3626a9cdc44bcde55efde9d22e78
CRC: 359DE692