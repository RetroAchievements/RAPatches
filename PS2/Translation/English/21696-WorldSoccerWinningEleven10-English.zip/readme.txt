Use with:

(Redump)
File: World Soccer Winning Eleven 10 (Japan).iso
MD5:  1fe4196688192550d92ffc0e93803f5c
CRC:  4C85231F