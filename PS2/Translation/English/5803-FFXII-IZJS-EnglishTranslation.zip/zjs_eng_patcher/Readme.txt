FFXII Int: ZJS English Conversion Patch by ffgriever v0.23

Usage: zjs_repack [-h] [image_eng [image_zjs [image_output]]]

You can just make sure that you have "ff12us.iso" and "ff12zj.iso" in the
same directory as the main executable. Then just double click the patcher
and wait until it's done. You can specify the required filenames, if you
want to (you can specify only the first one, first two or all of them).
The default output file is "ff12engzjs.iso".

MAKE SURE YOU HAVE ENOUGH FREE SPACE ON HDD AND THAT YOU HAVE READ/WRITE
PERMISSIONS. MAKE ALSO SURE, THAT THE "TEMP" DIRECTORY IS IN PLACE, AS WELL
AS ADDITIONAL, MODIFIED FILES. IT'S ADVISED TO LOG THE PATCHING PROCESS INTO
A FILE.


Known issues (US version):

    * Some items have wrong or missing descriptions.
    * Some missing npc names (shop clerks in bhujerba).
    * Wrong names in Pharos, when you look at the map for the first time.

PAL/UK version (all the above, plus)

    * Missing text in bhujerba, when you're asked to press square button for the
      first time.


Other language versions (PAL). Note, that these are not "officially" supported yet.
Right now I do fixes for them only if they do not require too much work and can be
made without examining the game itself (I do not own any of these right now):

    * Dead loop in fighting tutorial in german version.
    * Locations that had to be manually edited are in english. The same for menu
      files and such.
    * All images are in english (guessing here, as I had only ff12french report).
      This means that fr/de/spa/ita versions contain all the english images in the
      usual places, while the localized images are (most likely) somewhere else.
      This means that I will have to somehow obtain these versions and search for
      the images.



Please report if you found any other problems (though, I'm most interested
in freezes and misplaced dialogs right now).


Version History:

v0.23:
  garamsythe waterway missing line added (vaan examining insurgence corpses)
  
v0.22a:
  an updated patcher binary

v0.22:
  translated japanese trial mode texts (begin/continue gfx)
  
  sky pirate's den name gfx is now copied from the donor

v0.21:
  fixed japanese text in menu
  
  fixed japanese overlays in intro movie
  
  added one missing file (items and such)
  
  added smaller font, so most of the "too long name" issues should be
  fixed now; the font is a bit less readable, so if you have a problem
  with it, there is the old file in bin/font_big (replace the one in
  bin with it); anyway, I *really* recommend disabling anti flicker
  filter for the smaller font, as it makes it sometimes unreadable
  
  some additional fonts will be copied properly now

v0.20:
  morningstar (psx-scene forums) fixed the hunt description text
  wrapping. Now it should look much better.
  
  fixed garbage instead of name on the map when you leave Barheim Passage
  with Basch (for the first time, just after killing mimic queen).
  
  fixed Japanese names displayed on world map when Basch/Fran
  describes the way.
  
  fixed in-battle descriptions of some items.
  
  fixed Japanese subtitles in outro movie.
  
v0.19:
  Fixed hunt descriptions/status. Doesn't always look really nice, but
  at least it is all visible now. Did some simple automatic text
  rewrapping. If anyone wants to do it by hand, contact me.
  
  Some minor changes in the patcher. Hope this will fix the "couldn't
  write section" problem that some people had reported.
  
v0.18:
  Fixed some license related stuff at Sandsea.
  
  Added missing guest info displayed just after Amalia joins the party
  as a guest in Garamsythe Waterway.
  
  Corrected or changed names of many items (thanks DarknessSavior and
  Tauwasser).
  
  Fixed some magic desctiptions.
  
  Fixed some gambit names and gambit descriptions.
  
  Fixed some item descriptions.
  
  Fixed garbage characters displayed in menu after elemantal icons.
  
  Fixed wrong word order in equipment desctiptions "SapImmune:",
  "Poision, CurseEquip", "WaterHalf Damage:", etc. This one was actually quite tricky.
  I had to make some neat assembler hack to make it work properly and not screw
  everything else (if done the easy way, it would completely block most of the menus,
  so they would be greyed out). Good thing is that I used some internal mechanisms,
  so I didn't have to rewrite all the print functions (hehe, I have already rewritten
  some of them, but then I found an easier way).
  
v0.17:
  Fixed some additional fmv problems that occurred if FF12UK was used as
  text donor.
  
  Fixed some text/audio desyncs that occurred if FF12UK was used as text
  donor.
  
  The new game shouldn't freeze anymore if started in 16:9 mode (temporary
  solution, in fact I just reverted one of the changes).
  
  Fixed a bug that made it impossible to obtain some magic spells if the
  jars in Royal Palace were opened.
  
v0.16a:
  Replaced one japanese file that accidentally got into the patch instead
  of the english translation. Fixed bug in Strong Mode text.

v0.16:
  Fixed freeze in Necrohol of Nabudis (Door of Despair bug).
  
  Fixed some buy/sell messages.
  
  Added some missing window title headers (INFO, WARRNING, etc.).
  
  Added some missing translations regarding Trial Mode, Strong Mode,
  Weak Mode and other minor texts.
  
  Fixed location names (mostly Pharos and further).
  
  Corrected some names and descriptions (thanks DarknessSavior for class
  info translation) - they're not final yet.
  
  Tracked and patched over 1000 images. Now all most important images
  should be in english (or whatever language version you used - except
  for the ones I had to edit manually as they will always be in english).
  This includes Marquis Halim Ondore's memories, hunt starts and ends,
  city names, dates, battle messages, espers and many, many more.
  
v0.15:
  Fixed issue during Remora fight.
  
  Found place where space width is stored and changed it to a proper value.
  This should fix the appearance of all the bestiary entries and make the
  dialogs easier to read.
  
  Minor changes in names and descriptions.
  
v0.14:
  Fixed freezes and other bugs in bestiary (yet again).
  
  Intro fix for PAL/UK version.
  
  Changes in compression routine.
  
v0.13a:
  Fixed animation bugs that occurred when PAL version of FF12 was used.
  
v0.13:
  Fixed Sochen Cave Palace bugs.
  
  Fixed some Battle Log messages.
  
  Fixed freezes and other bugs in bestiary.
  
  Some minor fixes in names.
  
  Added some missing map targets.
  
v0.12:
  Added proper names for all the licenses. Added missing ones.
  
  Added missing items.
  
  Added translated license board names and descriptions (temporary).
  
  Added placeholders for missing gambits.

v0.11:
  Fixed a bug in Rabanastre Southern Plaza (this caused eg. Cartographer
  Moogle to sell you one map over and over, until you ran out of gil).
  
  Fixed a bug in Nalbina Dungeon, that caused the game to freeze when you
  were about to reclaim your inventory from the confiscatory.

v0.10:
  First public release.