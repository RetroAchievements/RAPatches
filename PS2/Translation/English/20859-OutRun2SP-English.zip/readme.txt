Use with:

(Redump)
File:               OutRun 2 SP (Japan).iso
Size (Bytes):       2627534848
CRC32:              1B6C4F3F
MD5:                f3f73f6b7c7b9eb4a76a50fdbe72d6d2