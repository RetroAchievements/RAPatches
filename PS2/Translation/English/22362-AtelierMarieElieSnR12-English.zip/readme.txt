Use with:

(Redump)
File:               Atelier Marie + Elie - Salburg no Renkinjutsushi 1 & 2 (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1455587328
CRC32:              879471A8
MD5:                973CFFDBC7439162D7C3E941F00F9EC8
SHA1:               DFF81514D7F72A6A390A6D13BE1DA2C4CD2ABD2C
SHA256:             FAC545D52AA83792ADBB0A710078FD81D418178E3125BBA1BA0EBF4714885708