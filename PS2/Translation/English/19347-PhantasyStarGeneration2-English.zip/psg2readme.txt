Use with:

(Redump)
File:               Sega Ages 2500 Series Vol. 17 - Phantasy Star Generation-2 (Japan).bin
BitSize:            823 Mbit
Size (Bytes):       107999136
CRC32:              B3D3CFDA
MD5:                6694F8F11183D5E703942985EBBD0966
SHA1:               5D7F44113C74FFE8D2927577245BEE0CF4C2C2AD
SHA256:             C618084A791D37A3F9EA2272E0D228B7ACADF774D99BD4545E54F695ACB2B79A