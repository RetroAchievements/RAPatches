Use with:

(Redump)
File:               Ginga Ojousama Densetsu Yuna - Final Edition (Japan).bin
BitSize:            4 Gbit
Size (Bytes):       610433376
CRC32:              3AE39FD8
MD5:                B5779DA816FA7DFE524117F00B7648E0
SHA1:               AA739893D453C9CDBF740058DB4E582EADEA0D0C
SHA256:             FC2DAA1C9A869F7C15B30F7A70E8439D8404351EF383621D7C867F142CAF7002