Use with:

(Redump)
File: Namco x Capcom (Japan).iso
MD5:  b95ff07ca718f429e6a55f91a3a6e13e
CRC:  15FB7052