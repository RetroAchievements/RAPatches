Use with:

(Redump)
File: Dragon Quest & Final Fantasy in Itadaki Street Special (Japan).iso
MD5:  ae3989e5d7a0c9881268ca9dcbeba1b6
CRC:  7D87FC6E