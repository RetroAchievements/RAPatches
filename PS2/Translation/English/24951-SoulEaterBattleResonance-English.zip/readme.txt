Use with:

(Redump)
File:               Soul Eater - Battle Resonance (Japan).iso
BitSize:            9 Gbit
Size (Bytes):       1233616896
CRC32:              5C48949C
MD5:                EE187BED867ACFFA2D32217933959CD4
SHA1:               326C49860A4EDC7F56D016F9ED9B38B81E5A1BDF
SHA256:             D52CE66B38C68ED6C00E29D890177CB66640F33334C54AB8D8D722542BDF39C8