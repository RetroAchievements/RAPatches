Use with:

(Redump)
File:  Rockman - Power Battle Fighters (Japan).bin
MD5:   690cd03f6aba4861e22f1ca996f46422
CRC32: 7DBDBE18