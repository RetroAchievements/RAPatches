___________                             ________               
\__    ___/___________    ____   ______/  _____/  ____   ____  
  |    |  \_  __ \__  \  /    \ /  ___/   \  ____/ __ \ /    \ 
  |    |   |  | \// __ \|   |  \\___ \\    \_\  \  ___/|   |  \
  |____|   |__|  (____  /___|  /____  >\______  /\___  >___|  /
                      \/     \/     \/        \/     \/     \/ 

---------------------------------------------------------------------

Rogue Hearts Dungeon English Patch Beta V 1.1




FAQ/Notes section:

This is a complete English Translation For The Ps2 Game Rogue Hearts Dungeon.(SLPM_667.36 release)
This is the first beta release of the patch, so expect some typos or in game visual errors, however it doesn't bring up lots because it was tested.
For more information about bugs, jump to known bugs section.

Contact Information And Misc:

To contact me about this release send an email to: tgen.translations@gmail.com
If you think that my work is worth a donation you can send paypal donations over
to that same account, you will truly help me.



Changelog V1.1:



-Translated miscellaneus text in medal exchange. 
-Reordered medal menu exchange to be readable, still some bugs, see bugs section.
-Created a disclaimer splash screen.
-Changed patch type to xdelta, use deltapatch to apply.




This is what this patch translates:

-Story Text

-Menu Text
 
-Items/Gear

-System Messages

-Map Display Menu

-Miscellaneus Messages

-Bestiary

This is what is NOT Translated:

-Opening video.

-Ending Video (Contains just credits)

-------------------------------------------------------
FAQ:

Q-Why Rogue Hearts Dungeon?
A-It is a well made Rogue Game, and must be transated for all the Roguelike franchise fans.

Q-Can I use my old saved file from the japanese disc with
this translation?
A-Yes, you can.

Q-Can I translate this patch to my own language or make an addendum?
A-Yes, I hereby give you permission to make modifications to this translations always to polish it or to translate it to another language ;)

Q-Why did you change patch filetype?
A-I made some fixes to the game which requires another patcher.

---------------------------------------------------------------
INSTRUCTIONS:

1-Rip an image out of your original disc using DVDDecrypter of the version
of the Disc with the ID SLPM_667.36.
The output needs to be a .iso file with 1.450.672.128 bytes in disk.

2-Download Delta Patcher. You can download the tool from for example this site:
https://www.romhacking.net/utilities/704/

3-Apply The xdelta patch to the iso.

4-Burn the image into a high quality blank dvd at 4x speed or less.
-------------------------------------------------------------
COMPATIBILITY

This translation works with the last version of pcsx2,hdloader,Open Ps2 Loader
modchip and Swap Magic on all region consoles.

----------------------------------------------------------------
KNOWN BUGS

This game lacks a vwf, so the letters and ugly and big, but it's playable.

Due to some nasty ram problems that have this game you can see in data options of main menu the @ icon.
Don't worry this will not affect the gameplay.

In the medal exchange screen the prices do not show properly, this is because (again)
the ram problems that this game has without a variable width font.



------------------------------------------------------------------------------------
CREDITS

Romhacking:
saito

Translation:
saito

Testers:
saito

------------------------------------------------------------
DISCLAIMER


We are not linked to Spike or any other game company,we are just fan translators.

We're just releasing a stand-alone .pff file.

YOU WILL NEED THE ORIGINAL GAME DISC IN ORDER TO PLAY THIS 
FAN-TRANSLATION.

WE DON'TSUPPORT PIRACY BY ANY MEANS!

YOU CAN PURCHASE THE GAME FROM YOUR LOCAL STORE OR FROM ONLINE STORES.

WE DON'T CHARGE ANY FEE OUT OF THIS PATCH.

IF YOU BOUGHT THE GAME WITH OUR FAN TRANSLATION APPLIED,THEN YOU HAVE BEEN RIPPED-OFF.


Thanks an enjoy this translation.