Use with:

(Redump)
File: Zill O'll Infinite (Japan).iso
MD5:  0dff715c5ae54b1cff759c35ca977c4e
CRC:  91A2DCCE