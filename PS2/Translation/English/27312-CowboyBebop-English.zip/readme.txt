Use with:

(Redump)
File:               Cowboy Bebop - Tsuioku no Serenade (Japan) (Shokai Genteiban Box).iso
CRC32:              DA383EEE
MD5:                2c75db015e4f41e57e4f2cf19083c85a