Use with:

(Redump)
File:               Simple 2000 Series Vol. 113 - The Tairyou Jigoku (Japan).bin
BitSize:            2 Gbit
Size (Bytes):       279859776
CRC32:              62F40224
MD5:                478B472261F2FFCB5A0B85620B96212A
SHA1:               3970C7424D5A2F59EB179078BE815F828136002B
SHA256:             C37E18FCF0EF5CDDB46819D2C1FC85314A57E8E5803FC0000FFA9A7ECC0568F6