Use with:

(Redump)
File:  Hungry Ghosts (Japan).iso
CRC32: 9D898274
MD5:   251e818a9b8d8c3d9a32024446bf83dc
