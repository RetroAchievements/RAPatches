Use with:

(Unpatched Redump)
Final Fantasy XII International - Zodiac Job System (Japan).iso
md5: 59a8d0ce669d1afe25d512e7ed706043
crc: 46B57743