Use with:

(Redump)
File:               Sega Ages 2500 Series Vol. 1 - Phantasy Star Generation-1 (Japan).bin
BitSize:            533 Mbit
Size (Bytes):       69932016
CRC32:              3A9B5922
MD5:                BBA63DA6BD64489DA663A856B1D49C8F
SHA1:               3FAE75234774D8DB3D73228AAF8A33BEC9844D73
SHA256:             6CF26DC83353598A585E49D1DCCF1C0310E0156D645BB4B466740270EB158D25