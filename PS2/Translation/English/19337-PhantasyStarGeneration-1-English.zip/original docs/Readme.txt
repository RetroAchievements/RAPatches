Phantasy Star Generation:1

English Translation v3.01 (Jul 31 2025)


Table of Contents:

[A00] Disclaimer
[A01] Changelog
[A02] Fan Translation Credits
[A03] FAQ
[A04] Translation Notes
[A05] Closing

-----------------------------------------------------

[A00] Disclaimer


SEGA AGES 2500 Series Vol. 1 - Phantasy Star Generation:1 and the Phantasy Star franchise (c) Sega.
All rights reserved.

No ownership is claimed by Kyence or FlamePurge over Phantasy Star Generation:1 and/or the franchise
from which it originates. Commercial use of this patch, including but not limited to reproduction,
sale, etc. is strictly prohibited.

This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
FlamePurge and/or any of the project contributors are not liable for damage incurred to the
end-user, their OS, and/or their hardware while using this patch.

Apply this patch only to a Japanese BIN/CUE image with the following specifications.

   Sega Ages 2500 Series Vol. 1 - Phantasy Star Generation 1 (Limited Edition) [NTSC-J] [SLPM-62362].bin
   Sega Ages 2500 Series Vol. 1 - Phantasy Star Generation 1 (Limited Edition) [NTSC-J] [SLPM-62362].cue
    SHA1 - 3FAE75234774D8DB3D73228AAF8A33BEC9844D73
     MD5 - BBA63DA6BD64489DA663A856B1D49C8F
   CRC32 - 3A9B5922
   
Phantasy Star Generation:1 and Phantasy Star Generation:2 are blue-back PS2 CD's, NOT DVD's.
In other words, they are meant to be formatted as BIN/CUE files and not ISO.

Players are encouraged to keep a backup of their original game files in case an error occurs.


If you wish to apply the Double EXP addendum, first patch the BIN with the English translation,
then apply the Double EXP patch.

-----------------------------------------------------

[A01] Changelog

v3.02 (Sep 14 2025)
- Fixed a formatting error with one of Shion NPC Wiz's lines. (Thanks: Artemis-kun)

v3.01 (Jul 31 2025)
- Fixed a bug wherein the credits would not fade from sepia to color and allow the player to make a Clear Game Save.
  IF YOU INTEND TO ATTEMPT PSGEN2'S CLEAR GAME QUEST, PLEASE UPDATE PSGEN1 TO v3.01, SPEAK TO THE GOVERNOR-GENERAL,
  AND WATCH THE CREDITS AGAIN!
- Corrected a few line breaks.
- Corrected directions to Sopia in NPC Cuatro's dialogue.
- Fixed several sentences with missing words.
- Changed Motavian Criminal to Motavian Outlaw to minimize enemy name label overlaps.

v3.00 (May 25 2025)
- Adjustments to variable width fonts by mziab.
- Added non-elemental ability icon.
- Full MTL- and friend-assisted retranslation by FlamePurge.
- Includes optional Double Experience addendum by mziab.

v2.10 (Nov 26 2015)
- New variable width font by tryphon.
- New variable width enemy name font by tryphon.
- Newly translated menu graphics by tryphon.
- Added item and ability icons from PSGEN2.
- Rewritten dialogue that expands upon Kyence's script by FlamePurge.

v1.01 (Aug 21 2012)
- Original translation by Kyence.
- Lutz is renamed Noah.

v1.00 (Aug 21 2012)
- Original translation by Kyence.
- Lutz is named Lutz.

-----------------------------------------------------

[A02] Fan Translation Credits


tryphon
- General reprogramming
- Added missing letters to v1.00
- Created Algoring, the translation software for PSGEN1 and 2
- Created various menu graphics
- Supreme patience with 22-year-old FlamePurge being insistent and demanding

Blaw-
- Translation support
- Providing a build of Algoring

mziab
- Completing Algoring for general use
- Double EXP addendum
- Translation assistance

Kyence
- Original project author
- Translation

FlamePurge
- Translation organization
- Machine retranslation coordinator
- Localization and series lore consistency assurance

Nobunaga
- Translated the ending credits
- Translation assistance

Kini
- Translation assistance

Orakio_Rob (orakio@gazetadealgol.com.br)
- Inspiration for the English translation came from his Portuguese translation effort
- Creating decompression software

Ignitz
Rodolfo RG
CUE
- Demystifying the compression and creating decompression software

Missagh Alami (http://www.pscave.com)
BenoitRen (http://www.pscave.com)
- PR and hosting the fan translation
- Website management

Wolfgang Landgraf (http://www.wolfgangarchive.com/psg1-web/index.html)
bokokun
- Gathering and releasing data on PSGEN1 and 2 via FAQs

Ace_Aileron
- All documentation proofreading

KahnerC
- Reporting multiple typos and bugs, thereby aiding the development of v3.01

Google Translate

DeepL

Kanji to Romaji Converter by J-TALK (http://nihongo.j-talk.com/)

Jim Breen's WWWJDIC (https://www.edrdg.org/cgi-bin/wwwjdic/wwwjdic?1C)

Sega of America

Sega of Japan

-----------------------------------------------------

[A03] FAQ


Q:  Why are Google Translate and DeepL credited? Is this a raw machine translation? Is this full of
    more errors? What happened to Kyence and vivify93?

A:  To be blunt, Kyence once wrote on the PS Cave Forum that her knowledge of Japanese is limited.
    When it or the WWWJDIC failed her, she would use Google Translate circa 2012. As bad as machine
	translation software can be now, it was infinitely worse then, and it sort of... led to her
	inventing plot points based on a few kanji she could recognize. (To say nothing of her intentional
    changes: Nekise to Nick was a small one, adding a romance subplot between him and Alisa was much
	larger.)
	
	I am vivify93. I now go by FlamePurge. In 2015, I didn't exactly know how creative Kyence had
	to get at times, and so I expanded her dialogue and fixed some logical errors I noticed; I figured
	it was inherent to the game's writing. It was not. I had no way of knowing how many of the odd-
	feeling story and NPC interactions were introduced by Kyence.

	I had been trying since 2015 to find a Japanese translator willing to help me provide an
	accurate localization of the game. It was 2025 when mziab fixed the translation tool, Algoring.
	I still had no translator. So, I remembered what Kyence did and I decided to do that myself.

	My own knowledge of Japanese is poorer than hers, but PSGEN1's dialogue is, for the most part,
	simple enough that the MTL softwares I used can more or less parse what's being said. The rest of
	it was up to comparing the machine translations against each other, asking friends to help with
	dialogue in bits and pieces, as well as heavy yet judicious use of WWWJDIC and J-TALK's Kanji to
	Romaji Converter.
	
	For further elaboration, please read the points below, "How literal is the translation?" and
	"Did you or Kyence make any changes to the script?"

	I feel that the translation is accurate despite the barriers that were placed before me, and the
	shortcomings it still and always may have. However, it is the culmination of a decade of passion
	and love, and I hope you enjoy playing as much as I did in its creation. 
	
	
Q:  Why is there a version where enemies give double experience? Why not double meseta, too?

A:  PSGEN1 has 2 grinding spots not present in the original PSI: getting to LV45 to survive Dezoris,
	and getting to LV75 to survive Baya Malay Tower. The 2x EXP patch provides a smoother adventure
	by keeping your team's levels up to speed as you play.

	On the other hand, the game practically bathes you in meseta. Combine that with how Spell
	Crystals could be exploited more easily if the player had 2x the money, it just made sense to
	leave meseta alone.

	Thanks to mziab for being kind enough to make the 2x EXP patch.


Q:  Will there ever be a version with character, spell, and item names used in the English
    localization of the Master System original? (Lassic, Noah, Wall, Cola, etc.)

A:  Probably not.


Q:  Are the enemy names the original Japanese names?

A:  Yes, aside from Robotcops, Mechaguards, and the colored/elemental Wyverns. There are more
    details in LINER.txt.


Q:  How literal is the translation?

A:  I tried to walk the tightrope of not changing too much while making the game an entertaining
    read. My biggest struggle lay in how I don't know very much Japanese, and I had to get
	creative.

	My process:

	1. Run the Japanese dialogue through GTranslate/DeepL.
	2. Judge if the translations are consistent, and determine the intended meaning.
	   This was done by...
	    A) Inference based on various translations I've seen of Japanese phrases over the years;
		B) Ensuring I fully understand the context of the dialogue;
		C) Paying attention to the romaji;
		D) Researching Japanese idioms; and
		E) As a Hail Mary, seeking help from friends in their limited spare time who do actually
		   know Japanese.
	3. Write the English dialogue based on what I believe to be an accurate translation.
	4. View the line formatted in-game and adjust as necessary.

    You will not find raw machine translations or vague rewrites based on concepts presented by the
    MTL software. I do not condone the method I used, nor do I want anyone to follow my example.


Q:  Did you or Kyence make any changes to the script?

A:  Kyence more or less used PSGEN1 as a canvas from which to improve her skills, resulting in the
    high quality PSGEN2 translation. Her GEN1 dialogue has a large amount of mistranslations and
	intentional changes, which produced a translation I cannot in good faith call accurate.
	
	So, yes, in v1.00, Kyence made many, many changes to the script, enemy names, item names, magic
	names... and my expanding upon her dialogue in v2.10 made things worse. What about v3.00+, you
	ask? As detailed previously, though my knowledge of Japanese is slim, I was able to use my
	personal skills to challenge myself and ultimately provide an accurate localization and a true
	telling of the story.

    What "localization" means for me:
     1. Japanese idioms are replaced with English equivalents
	 2. Dialogue is written as if spoken by a native English speaker
	    (Myau saying, "Dr. Luveno is really a genius after all, right?" would become
		 "Man, Dr. Luveno really is as smart as they say, isn't he?")
	 3. Ensuring character personalities shine through the same way they did in Japanese

	You can read a detailed breakdown of everything and anything I changed from the original
	Japanese text in LINER.txt.


Q:  What about the NPC names, which seem to be references to American celebrities?

A:  NPC names are unchanged from the Japanese text. Yes, there really are NPC's in the Japanese
	original PSGEN1 named Aaliyah, Lil' Mo, LeVert, and Baha Men.
	

Q:  What's going on with the spell names?

A:  The spell names are transliterations of their original kanji. Many reappear in Phantasy Star IV,
    so where possible, I took the spellings from that game's localization.


Q:  How long did the translation take to make?

A:  v1.00 started in 2010 and took 2 years.
    v2.10 started in 2015 and took 2 months.
	v3.00 started in 2015 and took 10 years.
	v3.01 started in 2025 and took 2 months.

	No one could figure out how to operate Algoring for about 9 years. While porting the tool to
	Python3, mziab discovered the build of Algoring tryphon gave to Blaw- (and Blaw- gave to me) was
	unfinished, explaining why it wouldn't work. As soon as mziab completed that build, everything
	fell into place.
	
	Algoring has been in a usable state since October 2024. I finished the patch in May 2025.
	So, in reality, v3.00 was only in production for about 7 months.


Q:  Will Kyence or you be translating PS Generation:2 to English?

A:  Kyence has done so already. http://www.romhacking.net/translations/2505/
    The patch remains in an unfinished beta state. I plan to complete it as well, though it will not
    require translation work.

-----------------------------------------------------

[A04] Translation Notes


Please read "LINER.txt" for detailed information.

- Near the end of the intro, Alisa stands over a cliff, forlorn and speaking in fragments.
  Kyence thought the tone would best be set by having Alisa swear vengeance against La Shiec
  instead.
  
  My interpretation is that Alisa is presented to us as an everyday girl who just had something
  horrific happen to her. She can't yet bring herself to admit the reality of murdering another human
  being in retaliation, so on the cliff she's steeling her resolve to actually seek vengeance.
  I felt the scene as-is was powerful, so I retained it rather than reuse Kyence's take.


- Kyence didn't understand the joke surrounding Phil, an NPC from Parolit. He first swears Medusa
  is real, and Alisa is skeptical. When you save Tyrone, Phil laughs at the very idea of Medusa's
  existence, and after slaying her, he loses his marbles and gives Alisa a book. He was changed into
  a stoner in earlier versions due to no one getting the humor.

  My interpretation is that he's trying to save face as a "big, strong man" that was only trying to
  look out for a "weak little girl," who proceeded to humiliate him by demanding how Medusa can be
  real if he's never seen her for himself. Essentially, he's trying to "put Alisa in her place" and
  acts more and more like a total jerk as you complete related events.


- After obtaining the Pale Divinity Key on Dezoris, there's a Consult where Myau and Tyrone discuss
  the key, then Alisa interrupts. Myau asks Alisa something, then she screams and PS2 button symbols
  appear.
  
  Players thought this was some kind of input code, but I asked at least 3 different Japanese
  translators, and it's supposed to be a comedy skit. Because this was tricky to translate, Kyence
  rewrote it into Alisa breaking the fourth wall.
  
  v3.00+ retains the original joke:
  
  Myau wonders if the Pale Divinity Key will lead them to the Frost Dragon, the Pale Divinity.
  Tyrone agrees.
  Alisa politely says, "That much was obvious."
  Myau is astounded by his own "insight."
  Alisa shouts in frustration. She starts ranting, which is represented by the PS2 buttons.
  
  A similar event is present in PSGEN2, where Nei reacts to a young boy's confounding decision by
  shouting and ranting in PS2 buttons.


- PelorieMate and Roginine are parodies of Japanese energy foods, CalorieMate from Otsuka
  Pharmaceutical Co. and Arginine V from Kirin. Trimate was added to PSGEN1 from later entries in
  the series.


- The four accessories on Dezoris that recover HP as you walk are all named after mythological or
  religious figures.
  
  Europa's Earrings - Europa, mother of King Minos from Greek myth.
  Vulcan's Ring     - Vulcan, god of fire and the forge from Roman myth.
  Helen's Necklace  - Helen of Troy, a beautiful Greek princess that nations warred over.
  Lucia's Mirror    - This one made me stumble. I thought perhaps it was referencing Lucia of
                      Syracuse, a Roman Christian martyr. Then I thought it was a reference to
					  Lucia from Lunar 2: Eternal Blue, given Japan Art Media worked on both games.
					  However, as there are no mirrors associated with the latter, I went with the
					  former.


- Please read "LINER.txt" for information on spell names.

-----------------------------------------------------

[A05] Closing


Has it really been an entire decade? I don't even go by "vivify93" anymore. I honestly never
thought I'd release an update to this patch, let alone meet the scope I had set.

I would like to specially thank mziab for making Algoring usable, and making the retranslation
possible.

If any of the original translation team are still out there, I hope v3.00+ is up to your personal
standards; it's finally up to mine.

Thank you so much for all your support,

FlamePurge (https://imminent-aardwolf-9aa.notion.site/The-Grit-07ce0587530940b0b16324339fe82a23)