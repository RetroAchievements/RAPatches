FILE "Phantasy Star Generation-1 (Japan) (En) (v2.1) (Kyence).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
