Use with:

(Redump)
File:  Saint Seiya - Sanctuary Juunikyuu-hen (Japan).iso
CRC32: 7E05AA80
MD5:   3be9cdf5f83e34dc48fad5972683228a