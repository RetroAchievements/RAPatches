FILE "Simple 2000 Series Vol. 113 - The Tairyou Jigoku (Japan) (Es) (v1.0) (Mr. Nobody).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
