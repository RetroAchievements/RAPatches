Use with:

(Redump)
Tales of the Abyss (USA).iso
md5: 7629b262da685bc46fcb1e6d5fc831e0
crc: 17988AFA