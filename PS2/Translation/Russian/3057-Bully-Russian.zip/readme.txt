Use with:

(Redump)
File: Bully (USA).iso
md5:  0477a28df3c4b625eecc2eb1da24501e
crc:  C991D508