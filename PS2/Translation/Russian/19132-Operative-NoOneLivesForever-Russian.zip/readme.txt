Use with:

(Redump)
File:  Operative, The - No One Lives Forever (USA).iso
CRC32: 9C471C48
MD5:   5367d2652e3038b0f15459f8d74d770a