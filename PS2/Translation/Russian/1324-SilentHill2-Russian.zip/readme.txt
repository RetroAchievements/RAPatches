Use with:

File:               Silent Hill 2 (USA) (En,Ja,Fr,De,Es,It) (v2.01).iso (redump)
BitSize:            28 Gbit
Size (Bytes):       3879108608
CRC32:              56FD79CC
MD5:                37A90D79DEA1D60B90B54B371C34C53A