Use with:

(Redump)
Grand Theft Auto - Liberty City Stories (USA).iso
MD5: 2d0cd1f12841de894a9a668f7c8fd5d3
CRC: 30784522

Grand Theft Auto - Liberty City Stories (Europe, Australia) (En,Fr,De,Es,It).iso
MD5: b604facde073fdc70a5a2d1220d77948
CRC: F8A6C4DC
