Use with:

(Redump)
File:               Grand Theft Auto - Vice City Stories (USA).iso
Size (Bytes):       4149182464
CRC32:              69C1139C
MD5:                3BF85783142BD4EBF8535B29D4251A67
SHA1:               08FEBF554E53D6AFF4C9F7144EC715909994B2D9