Use with:

(Redump)
File:               Silent Hill - Shattered Memories (USA) (En,Fr,Es).iso
BitSize:            10 Gbit
Size (Bytes):       1450704896
CRC32:              AFE2B5DB
MD5:                467483944D09D645A4953607249962EF
SHA1:               30F9D93BEAB84B9284569DF87AF6F34191406B8B
SHA256:             9B99E4694FEF9BFFA786961863BEA30EBA7156E1E071E4FA65C1C4EBA24B6251