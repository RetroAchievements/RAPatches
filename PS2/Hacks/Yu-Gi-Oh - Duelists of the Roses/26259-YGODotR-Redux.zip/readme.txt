Use with:

(Redump)
File: Yu-Gi-Oh! The Duelists of the Roses (USA).iso
md5:  ca838dae26ff750936c0814d1c2d33f1
crc:  C79D9A51