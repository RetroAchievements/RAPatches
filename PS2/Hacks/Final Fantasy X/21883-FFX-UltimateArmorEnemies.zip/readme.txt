Use with:

(Redump)
File:  Final Fantasy X International (Japan) (En,Ja).iso
CRC32: CF132E2C
MD5:   50161b879a829583b69c0e93b6d987e9