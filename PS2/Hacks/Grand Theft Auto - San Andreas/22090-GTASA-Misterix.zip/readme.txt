Use with:

(Redump)
Grand Theft Auto - San Andreas (USA) (v1.03).iso
MD5: c383c015065f8060343032480928d08d
CRC: 1C5E0EEE