Use with:

(Redump)
Life Line (USA).iso
md5: 6032135d49804d9db3200152a339b440
crc: 45F022D9