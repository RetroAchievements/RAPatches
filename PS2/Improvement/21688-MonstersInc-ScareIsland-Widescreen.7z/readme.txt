Use with:

(Redump)
Disney-Pixar Monsters, Inc. - Scare Island (Europe, Australia).iso
md5: e1297a77a336ba5dbb67ca7f770b5ccd
crc: 203A376E