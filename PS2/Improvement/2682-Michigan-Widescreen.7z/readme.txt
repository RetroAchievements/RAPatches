Use with:

(Redump)
Michigan - Report from Hell (Europe) (En,Fr,Es,It).iso
md5: 2118f7c405758da0c5a8ffb304dc703a
crc: D12E9D2E

Michigan (Japan).iso
md5: ddb843cd1b3a5075d46fc576fb7680bb
crc: 71475458