Use with:

(Redump)
Psychonauts (USA).iso
md5: 599a1889474d6d7e92095ab7b5265a32
crc: 6CE5D0CD