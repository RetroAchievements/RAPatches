Use with:

(Redump)
Harry Potter and the Chamber of Secrets (USA).bin
f20ac8dfd9df9500cf18cdf594a5a987
2E446506