Use with:

(Redump)
Dirge of Cerberus - Final Fantasy VII (USA)
md5: d6c91ef6da2c0faa9e4d2da3e077d050
crc: 5AB0E4AB