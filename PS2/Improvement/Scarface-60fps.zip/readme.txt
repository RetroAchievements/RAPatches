Use with:

(Redump)
Scarface - The World Is Yours (USA).iso
md5: aad9ed361e5697bf6960b9ac895e0565
crc: EFB00924