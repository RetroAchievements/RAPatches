Use with:

Redump
Radiata Stories (USA)
MD5: 1e497abb0c59cac8627d98b82e4148f0
CRC-32: 76870ee5