Use with:

(Redump)
Punisher, The (USA).iso
md5: 4bb4c2604a2c517e8ceefa803c54dc6d
crc: 778C9170