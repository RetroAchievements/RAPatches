Use with:

(Redump)
File:               Air Ranger 2 Plus - Rescue Helicopter (Japan).iso
BitSize:            35 Gbit
Size (Bytes):       4698767360
CRC32:              07F04C5D
MD5:                099BEB11A7D4280A0093CF32415AAB92
SHA1:               3E3E3860EFE54743BF8311CA608F7C3C961664C7
SHA256:             E26A317B74E16CF6DE46DD3B865203A9B565A17F72376287A94D4A269ADA9A37