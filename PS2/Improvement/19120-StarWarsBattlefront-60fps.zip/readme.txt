Use with:

(Redump)
File:               Star Wars - Battlefront (USA).iso
Size (Bytes):       4697260032
CRC32:              12a56268
MD5:                3d8e481e3e78b9e2af6b493857db6e47
SHA1:               99d1cfed9237eee823d6595afefb7fafa2ee9cb1