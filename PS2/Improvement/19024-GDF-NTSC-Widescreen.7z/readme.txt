Use with:

(Redump)
Global Defence Force (Europe).bin
md5: 03ca862748d4c6b8fbe6ad41d5831124
crc: A1AE52FD