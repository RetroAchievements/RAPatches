Use with:

(Redump)
Need for Speed - Underground (USA).iso
MD5: 5a27191623e2248e14bd6f0aca2eb476
CRC: 8D1F7A13