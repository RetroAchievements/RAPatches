Use with:

(Redump)
File:               Nickelodeon Rugrats - Royal Ransom (USA).iso
BitSize:            28 Gbit
Size (Bytes):       3822813184
CRC32:              E3D3A8C0
MD5:                D71298C7C26EC0C898A59D6BE2A5A7F4
SHA1:               0FB591001D3E4B9508E03D4F4710F834C27A2148
SHA256:             CFB6013F293EDEBADC5B38083B9481B22EEB3121E7DFA94A0C1E2FCFD57A0BE8