Use with:

(Redump)
File:               Nickelodeon Tak - The Great Juju Challenge (USA).iso
BitSize:            15 Gbit
Size (Bytes):       2097512448
CRC32:              D5DBCEF0
MD5:                F554B4DB3EDE9EFFBFA0B127B2CF62E8
SHA1:               99289A56E84BB0922E94B3DF5B242A1709F34EF9
SHA256:             70CFB795B0014B9BC61D23D692797FAE049DF5585E9A16D06AF9B767B22B7BF4