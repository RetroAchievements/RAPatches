Use with:

(Redump)
Disney's Chicken Little (USA).iso
md5: 5b7bcf946c89678c47bc68a714f54ea6
crc: EF0EE7B7