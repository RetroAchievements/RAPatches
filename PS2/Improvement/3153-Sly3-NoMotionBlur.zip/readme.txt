Use with:

(Redump)
File: Sly 3 - Honor Among Thieves (USA).iso
MD5:  1dfe7f0aac25320678244b4c43f12b4f
CRC:  0A9386CF