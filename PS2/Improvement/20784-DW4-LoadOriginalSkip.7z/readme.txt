Dynasty Warriors 4 - Xtreme Legends (USA) (Load Original Skip) (Raichi).xdelta - Use with:

Redump
Dynasty Warriors 4 - Xtreme Legends (USA).iso
MD5: 4F9EAD5D1183E3BBBC9A6006B02C113B
CRC32: E4FCF429


Dynasty Warriors 4 - Xtreme Legends (USA) (Undub + Load Original Skip) (v1.0) (General Plastro, swosho, Raichi).xdelta - Use with:

Redump / Lost Level Archive
Dynasty Warriors 4 - Xtreme Legends (USA) (Undub) (v1.0) (General Plastro, swosho).iso
MD5: 1E0CB9FD9B058ABA335125F3E2A877D8
CRC32: 7FAB6683