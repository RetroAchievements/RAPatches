Use with:

(Redump)
File: Armored Core 3 (USA).iso
CRC:  6370240D
MD5:  1258c8e17f58a80f1e01b0391ae97abe

