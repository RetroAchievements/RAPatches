Use with:

(Redump)
Red Faction (USA) (v2.00).iso
md5: 336900f0e68e30394d281e70118308e9
crc: 5D7057B4