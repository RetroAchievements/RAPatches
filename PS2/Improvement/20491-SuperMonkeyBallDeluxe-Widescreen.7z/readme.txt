Use with:

(Redump)
Super Monkey Ball Deluxe (USA).iso
md5: 498c5c30364f74fb7fc2671fd7a3dec1
crc: AFEF21E5