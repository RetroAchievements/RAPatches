Use with:

(Redump)
Gadget Racers (Europe) (En,Fr,De,Es,It).bin
md5: 9ce6383cb5260e300cacde569ea5916d
crc: 052EBF65