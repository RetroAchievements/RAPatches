Use with:

(Redump)
File:               Grand Theft Auto - Liberty City Stories (USA).iso
BitSize:            29 Gbit
Size (Bytes):       4010016768
CRC32:              30784522
MD5:                2D0CD1F12841DE894A9A668F7C8FD5D3
SHA1:               F690B24E4F6F7CFCB642F9FAAA1E05D2BA6A3A3A
SHA256:             9E45271F8835F6B77213C8A7FF3BD1E4307FFFA9C3F4434CF8498A5A7B59C4FE