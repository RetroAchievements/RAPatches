Use with:

(Redump)
File:               Disney's Chicken Little - Ace in Action (USA).iso
BitSize:            12 Gbit
Size (Bytes):       1740668928
CRC32:              7087E0E0
MD5:                C060B1B823B046708B1460582AD3B8AB
SHA1:               888CB82D6462BE2990D78610DD9A1722ACF8313A
SHA256:             4C17AE374299287041D215B7E5130074A423B59D3F5082C4546D973B3F7C17B3