Applies on the Japan dump from Redump.
Original File: Metal Slug (Japan).iso
Original CRC32: 69ffd26c
Patched CRC32:  ee883f7b

OBS: There's also a widescreen patch. To use it, place the "SLPS-25650_7D8D8B8A.pnach" file into the "PCSX2 -> Resources -> Patches.zip".