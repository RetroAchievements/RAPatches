Use with:

(Redump)
File:               Michigan - Report from Hell (Europe) (En,Fr,Es,It).iso
BitSize:            30 Gbit
Size (Bytes):       4105764864
CRC32:              D12E9D2E
MD5:                2118F7C405758DA0C5A8FFB304DC703A
SHA1:               28229AADCD6029BB89AE2BA6E7E3C462846FFF47
SHA256:             EC8D0461403A774DD4130D16B330981E6493A386733F1797A6258D7FD8D6142A