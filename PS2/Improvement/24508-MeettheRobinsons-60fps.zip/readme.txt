Use with:

(Redump)
File:               Walt Disney Pictures Presents Meet the Robinsons (USA).iso
BitSize:            11 Gbit
Size (Bytes):       1590099968
CRC32:              360EB11F
MD5:                7C79EDBCEA78C7331976D691628C81E1
SHA1:               BAF2821AE5756803AAEA293882827DE32C223511
SHA256:             B25DB7262C334D3B4A58647A707460EE91338BCE9D1EC390F3AE9FAF44134B4C