Use with:

(Redump)
Lara Croft Tomb Raider - Anniversary (USA).iso
md5: fd53e7606373ddb30c5420fcb0faa320
crc: 80955C2C