Use with:

(Redump)
Grand Theft Auto - Vice City (USA) (v3.00).iso
md5: a7e51117609b98673851ef9abc2fd6f3
crc: 7D2BFCF4