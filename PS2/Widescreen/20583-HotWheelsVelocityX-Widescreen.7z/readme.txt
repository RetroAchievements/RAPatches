Use with:

(Redump)
File:               Hot Wheels - Velocity X - Maximum Justice (USA).iso
BitSize:            12 Gbit
Size (Bytes):       1674903552
CRC32:              6B14E621
MD5:                13F775A1CC027C5E79D0F3A4127BD581
SHA1:               E51EE91522EBC45889A6232796C7AE1C6B924703
SHA256:             15068D3D4FC85E69867DFB58DAD60A2F45BAA32FCF99F4A4B6A1036ACEABD13F