Use with:

(Redump)
File:               Air Ranger - Rescue Helicopter (Europe).bin
BitSize:            5 Gbit
Size (Bytes):       718604208
CRC32:              01F47272
MD5:                71E5FC458754F1BF2422EAC009C0E416
SHA1:               77D8C078C16E76EFD6A60823E6C75041402D198A
SHA256:             0FD33345F5E8CC3F015DE1438612A81A272BB73AFDC884BD48D3305AB27758B5

Or

(Redump)
File:               Air Ranger - Rescue Helicopter (Japan).bin
BitSize:            5 Gbit
Size (Bytes):       751113552
CRC32:              9365BE67
MD5:                FC28BAC49F26913B353F5ECBE51C1BAA
SHA1:               9624E2D99F6636538E298980130033754AA1D2B5
SHA256:             75F28879EC36C0F93EBD8D90EFFE7D3994B6DD93777B3EA9528CEFD9A6BC968B