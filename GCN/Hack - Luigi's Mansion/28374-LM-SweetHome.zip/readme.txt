Use with:

(Redump)
File:               Luigi's Mansion (Europe) (En,Fr,De,Es,It) (Rev 1).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              9A75E03A
MD5:                109274D9078B5AECF3BFA9AF1D10688C
SHA1:               3F742BF1DB42BD3B24EC50BC66320F762B043752
SHA256:             8AAD63BF047CBA66210717C1FBB9E506A8FE7CEF8D38DF6981E0D57917761F24

or

File:               Luigi's Mansion (Europe) (En,Fr,De,Es,It) (Rev 1).rvz
BitSize:            1 Gbit
Size (Bytes):       240045924
CRC32:              F90F5939
MD5:                DC14DC547943EE019E27FDA8F42C642C
SHA1:               114DAF37A21B7BC2B85EE734AAC4F8E7B0930233
SHA256:             D6485D846D2283C857F069CC0D45D8FA1407A579450096BAC5183312A949D5DB


If using the .rvz, you will need to use Dolphin to convert it to ISO, which will result in the .iso above.