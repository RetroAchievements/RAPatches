Use with:
Mortal Kombat (Europe).sfc (No-Intro)
bcf52b016559d371eefcd216781f40cd
A81657D3