Use with:

(No Intro)
File:               Donkey Kong Country - Competition Cartridge (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              0E204FBD
MD5:                45E938A3ADDE7DC91968793D115C8057