Use with:

(No Intro)
File:               Zombies Ate My Neighbors (USA).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7CFC0C7C
MD5:                23C2AF7897D9384C4791189B68C142EB
