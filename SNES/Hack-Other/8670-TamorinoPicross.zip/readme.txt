/----------------------------------------\
|  Tamori no Picross (7-14) (Japan).bps  |
------------------------------------------
Use with:

(No Intro)
File:               Tamori no Picross (7-14) + SatellaQ + Machi Magazine (7-21) (Japan) [b].bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              26A6D609
MD5:                B8EDF62CB0F97B73658AFE9492BA9242
SHA1:               18A582AF6603EE0D60FEBF3A07B7796FB3151958
SHA256:             DBC6161119A2A8BA86DDFA0083A9C3D5C966D5909875FD83DC5C223C4EBB1FF4

/----------------------------------------\
|  Tamori no Picross (6-13) (Japan).bps  |
------------------------------------------
Use with:

(No Intro)
File:               Tamori no Picross (Japan) (6-13).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              762287C8
MD5:                62B340F9783472A2734C5BC4DDCFD724
SHA1:               E54B775390792EC42BA7CAA7BDF6E20A2BB065A0
SHA256:             511C7B25303339DF87DD86211F3529591ADC77A54B222D236525743F5DD539AC
