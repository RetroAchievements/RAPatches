Use with:
Firemen, The (Europe) (En,Fr,De).sfc [No-Intro]
ac995ab6f5667be14eb6471458e491d3
DEF665AF