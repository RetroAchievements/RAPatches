Use with:

Super Mario All-Stars (USA).sfc	(No-Intro)
53c038150ba00d5f8d8574b4d36283f2
925637C7