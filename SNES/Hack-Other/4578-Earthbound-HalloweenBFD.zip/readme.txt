Use with:
EarthBound (USA).sfc (No-Intro)
a864b2e5c141d2dec1c4cbed75a42a85
DC9BB451