Use with:

(No Intro)
SatellaQ + Tamori no Picross + Machi Magazine (Japan).bs
b8edf62cb0f97b73658afe9492ba9242
26A6D609