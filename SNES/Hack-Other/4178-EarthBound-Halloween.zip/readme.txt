Apply to:

EarthBound (USA).sfc (No Intro)
a864b2e5c141d2dec1c4cbed75a42a85
DC9BB451

Result:
~Hack~ EarthBound - Halloween.sfc
3c9a6079146414790ad6712d48ab31a3
D6076162