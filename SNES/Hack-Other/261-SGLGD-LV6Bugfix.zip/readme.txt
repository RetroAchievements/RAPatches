~Speedy Gonzales - Los Gatos Bandidos LV6-1 Bugfix (USA) (sluffy)~
Speedy Gonzales - Los Gatos Bandidos (USA).sfc (No-Intro)
b96f969d7a5be96151331f04d7cb36d2
E2DBAD76


~Speedy Gonzales - Los Gatos Bandidos LV6-1 Bugfix (USA) (Rev1) (sluffy)~
Speedy Gonzales - Los Gatos Bandidos (USA) (Rev 1).sfc (No-Intro)
a8c26fa9951d764d958fcb1beebe5089
CB0653D0