Use with:
Speedy Gonzales - Los Gatos Bandidos (USA).sfc (No-Intro)
b96f969d7a5be96151331f04d7cb36d2
E2DBAD76