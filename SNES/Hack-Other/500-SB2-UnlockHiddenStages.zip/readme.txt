Use with:

(No Intro)
Super Bomberman 2 (USA).sfc
0990cda295bd51587c6e3f173bdadba8
9C1F11E4