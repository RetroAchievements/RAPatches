Use with:

Super Castlevania IV (USA).sfc	(No-Intro)
094f035993e9724647b61ddcba1e9a7a
B64FFB12