Use with:

Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr).sfc	(No-Intro)
98458530599b9dff8a7414a7f20b777a
006364DB