Use with:

Super Mario Kart (USA).sfc	(No-Intro)
7f25ce5a283d902694c52fb1152fa61a
CD80DB86