Use with:

(No Intro)
Kaizou Choujin Shubibinman Zero (Japan).bs
db4dd0305051f7d3ca7bd2e114f4f1dd
26A4F6C3