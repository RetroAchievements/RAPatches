Use with:
Secret of Evermore (USA).sfc (No-Intro)
6e9c94511d04fac6e0a1e582c170be3a
A5C0045E