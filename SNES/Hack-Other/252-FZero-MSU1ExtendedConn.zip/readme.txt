Use with:
F-Zero (USA).sfc [No-Intro]
6f334790120e1fe1a972ff184d2cfc50
AA0E31DE