~Terranigma NTSC (Europe)~

Terranigma (Europe).sfc	(No-Intro)
d202156549f981f6dafc759575dd6e67
974523FF


~Terranigma NTSC (France)~

Terranigma (France).sfc	(No-Intro)
8995ffe9fa821aa54a7c17bff7647f66
614A7090


~Terranigma NTSC (Germany)~

Terranigma (Germany).sfc	(No-Intro)
2ff43498fbb957facf11c598dd8a6299
FFC21CB9


~Terranigma NTSC (Germany) (Rev1)~

Terranigma (Germany) (Rev 1).sfc	(No-Intro)
4f3f3c5504a524a0716b965808709118
6FB8A4DF


~Terranigma NTSC (Spain)~

Terranigma (Spain).sfc	(No-Intro)
5223853d5edc9856f2bf8a9f04d01d3a
00E61534