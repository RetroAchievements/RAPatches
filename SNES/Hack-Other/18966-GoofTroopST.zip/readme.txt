Use with:

(No Intro)
File:               Goof Troop (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              4AAFA462
MD5:                BB6A1198E291C8AE58E9581A4296ED4D