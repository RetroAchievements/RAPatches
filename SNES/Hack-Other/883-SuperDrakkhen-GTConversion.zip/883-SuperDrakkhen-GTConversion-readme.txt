Use with:

Drakkhen (Japan).sfc (No-Intro)
38d2f009f6352f044dbaf6405cc2ef4a
B0A016A2
