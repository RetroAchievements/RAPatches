Use with:

Donkey Kong Country (USA).sfc	(No-Intro)
30c5f292ff4cbbfcc00fd8fa96c2de3b
C946DCA0