Use with:

(No Intro)
File:               Arkanoid - Doh It Again (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              B50503A0
MD5:                03D30CA9AAA89738640CF14532DDFE6C
