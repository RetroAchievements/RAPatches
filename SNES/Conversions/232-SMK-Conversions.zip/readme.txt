Use with:

Super Mario Kart (USA).sfc (No-Intro)
7f25ce5a283d902694c52fb1152fa61a
CD80DB86


Use with:

Super Mario Kart (Japan).sfc (No-Intro)
f7afa112d7ec1d532636703e4b02700a
C8002453
