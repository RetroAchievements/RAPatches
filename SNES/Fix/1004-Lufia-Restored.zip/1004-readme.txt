Use with:

(No Intro)
Lufia & the Fortress of Doom (USA).sfc
4bbaad6abdfc9f05d2d8dde47df8b15d
5E1AA1A6