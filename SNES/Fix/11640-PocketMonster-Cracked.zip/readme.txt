Use with:

(No Intro)
File:               Picachu - Pocket Monsters (USA) (Pirate).sfc
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              AE6B73F0
MD5:                21A22272F3D2961D5004E224FD1B969F
SHA1:               FC83981D26A189BBC1E2E552AE91FC202CDD5261
SHA256:             E364AB10890FF8F21111D542C5649F72F36BD2C2CDF3904FB5924307C50A78FA