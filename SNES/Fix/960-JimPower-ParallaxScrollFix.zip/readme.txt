Use with:

(No Intro)
File:               Jim Power - The Lost Dimension in 3D (USA).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C469F8F0
MD5:                15CFCC91489C344D82AFE791A3F17261
SHA1:               45FBF4429B8B4A806AF31503A0CF968CFFBA3AF1
SHA256:             6F0BEC87ECE503B0FBE108CD159ED6F5FA7711B1C4FE31E982AF41AD5C638093