Use with:

File:               Emerald Dragon (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              9D0F5F98
MD5:                79FD387B6210C4F4796E01C412083596