Use with:

(No Intro)
File:               Mario to Wario (Japan) (En).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C6695E34
MD5:                B1774F03700DFC311BFD86411DB629C3