Use with:

Super Metroid (Japan, USA) (En,Ja).sfc (No Intro)
21f3e98df4780ee1c667b84e57d88675
D63ED5F8