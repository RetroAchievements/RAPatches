Super Metroid Redesign: Axeil Edition FINAL
by Drewseph

Index:
i.    How to play
ii.   Design Changes
iii.  Controller Input
iv.   Physics Changes
v.    Optional challenges
vi.   special thanks
vii.  version changes

			ENCOUNTER ANY BUGS?	
	PM me on the Metroid Construction forums under "Drewseph"
				or							
		    on Discord

------------------------------------------------------------------
i.			HOW TO PLAY
------------------------------------------------------------------
    REQUIRED SKILLS: In a normal play through you will need to perform these skills to complete the game.
			- Walljump (Automatic)			
			- Double Bombjump
			- Grapple Walljump
			- horizontal shine spark (run until samus glows and press down to crouch and charge. Press jump, then D-pad left/right)
			
    Helpful skills to keep in mind:	
            - X-Ray (not really required, but will be useful)
            - Crystal Flashing, see iii. CONTROLLER INPUT (again not required but it helps)		  
	
	
	What you need: 		"Super Metroid (JU) [!].smc"   ( DO NOT USE Super Metroid (E) [!].smc )
				An Emulator of your choice
				An IPS patcher.  What is included is NOT the full game.  
				It is a patch of only the changes made to the game!


	Download an Emulator:	https://www.google.com/search?q=snes+emulator&oq=snes+emulator  
							DO NOT USE ZSNES
	
	Download the Patcher:	https://www.google.com/search?q=Lunar+IPS
	Download the Rom:	What you thought I'd link to it here?  Thats on you my friend.
		
	What you need to do:	Run Lunar IPS and apply the patch in this folder to a clean un-headered rom.
				you can tell if a rom is headered by selecting it in the window and clicking on "properties"
				Size must be "3.00 MB (3,145,728 bytes)"  Any more and its a headered rom.
							
	Rom is headered?:	https://www.google.com/search?q=how+to+remove+the+header+of+an+snes+rom
		
WHATS NEW:
------------------------------------------------------------------
ii.			DESIGN CHANGES
------------------------------------------------------------------
	Room Changes:	Tourian was originally a really sloppy rush job as I had just graduated college
			and I was trying to finish the game before I would have less free time.
			I have finally implemented a design I had originally hoped for.
	
	Room Layout:	While watching the many different playthroughs over the years I got to 
			see where players had the most difficulties . I did my best to optimize 
			the level design in many areas which gave player unintentional difficulties.
						
	Enemy Health:	Many people complained about enemies taking too many shots to kill.  I originally
			intended this to have an impact on getting more powerful beams and being able to 
			kill easier. In other cases I meant for the player to use missiles as a weapon
			instead of just on doors.  I lowered the health of certain enemies to take fewer 
			shots. Certain enemies still have specific weaknesses.  Be sure to use missiles!
	
	Enemies:	I have added several new enemies which serve a few functions throughout the game.
			Title cards for new areas. 
			
			Metroids:	- Are just as fast as they were in redesign, but they are easier to detach.
					  When a Metroid latches onto you, use bombs to shake them off.
					  After a metroid is hit with enough bombs they will detatch and become stunned for a few seconds.

					- Cannot dodge when stunned.

					- Are pack hunters and will attack when another is in danger.
					
					- Prefer to capture aerial prey.

					- Have a telling sign when they are about to attack.

					- Packs of 3 must be killed together before a single metroid has a chance to respawn.
			
			Ridley:	 Will have less health in Norfair based on how many times you shot him at Ceres! (loses 70hp per shot)
			
						
	Express Elevators:	I have installed a series of shortcuts throughout Zebes.
				You'll have to unlock doors or blockades covering the elevator to make use of them.
				This should add some relief when it comes to back tracking.
						
	Auto Map Changes:	I changed the gfx for the map tiles to make doors more obvious where they
				Connect to surrounding rooms.  This makes navigation easier and less confusing.
				in denser areas such as Norfair.
						
	Hint System:		I replaced the moonwalking feature. When this is toggled in the game settings
				the map screen will highlight certain areas of interest just in case you forget
				to return after certain upgrades.  
						
				You can also toggle on/off by holding the Y button while on the map screen.
						
	Faster Loading:		Thanks to the decompression patch made available loading time for larger
				rooms moves much faster than before. I got help to speed up the fade and door
				transition speeds slightly.
						
	Sounds:			There are a few new sound FX.  Specifically morphing, placing a bomb
				new bomb explosion sounds.
					
	Statistics:		The end game now has a stat count, which is displayed along with the item %
				Distance Travelled in kilometres (X.xxkm)
				Energy Lost
				Enemies Killed
				Shots fired (only counts shots from arm cannon)
				Doors Traversed
						
	
------------------------------------------------------------------
iii.			CONTROLLER INPUT
------------------------------------------------------------------
	
	Manual Scrolling: 	Just press and hold the item cancel button
				followed by an aim up/down button (L/R by default)
				and the screen will move up or down to show you what 
				dangers are just out of sight.
												
	Auto Walljumping:	Simply spin jump against a walljump surface while 
				holding down the jump button.  Press away from
				the wall and Samus will walljump.
                Not all surfaces are grip-able. Surfaces must be Rocky or Rough.
                Smooth stone or loose soil won't allow samus to grab hold.
						
	Auto Morphing:		Many complaints were made about the difficulty of mid-air morphing
				into a morphball passage.  I took the liberty to allow most of the
				required passages automatically morph Samus under the condition that
				she is moving UP and pressing the d-pad in the direction of the hole.
	
	Auto Space Jump:	The original Super Metorid calculated whether you could or couldn't space jump 
				by checking your fall speed and comparing it to a minimum and maximum velocity.
				Redesign removed the maximum velocity so you can never miss the window and always
				jump again when in the air.  However due to the fall speed, if you were to press
				jump slightly too early you'd find yourself falling way to far while you reacted
				by letting go of the jump button and pressing jump a second time.  This meant you 
				fell so far that you found yourself at the bottom of where you wanted to go.
						
				Hold Jump: Samus will automatically space jump after falling half the distance of
                her jump height based on the peak of her last jump. 
	
	Shine Sparking:		All you need to do now is tap the jump button to initiate the 
				wind-up animation.  During this animation press ONE of the following buttons
						
					Up on D-pad: Vertical shinespark (Super Jump)
					Left on D-pad: Horizontal shinespark left (only when facing left)
					Right on D-pad: Horizontal shinespark right (only when facing right)
					Aim up (R default):  Diagonal shinespark in the direction player is facing.
		
				Smashing into a wall or ceiling has also has less of a cooldown before falling. 
				Vertical shinesparks also have "assist" windows which will now align samus
				so that she lines up with certain narrow openings.
						
	Spark Charging:		Boosting into a slope only requires pressing the direction Samus is 
				moving on the d-pad.  When she hits the slope 2 things can happen:
						
					D-pad LEFT/RIGHT ONLY: Samus will run and crouch automatically
					filling her charge for a new shinespark.
						
					D-pad LEFT/RIGHT + Run Button:	Samus will continue running at speedboost speeds.
						
	
	Crystal Flash:		When low on energy you can recharge your energy by dropping a powerbomb.
				Press AND HOLD the Shoot Button while it explodes until after the flash:
												
					Requirements:
						5 Missiles
						5 Super Missiles
						6 Powerbombs (one needed to start the process)
                    NOTE:  You cannot perform this while in a room with active metroids due to a 
					graphical glitch to samus' glowing palette. If you kill them, then you can CF
	
	X-Ray Scope:		Instead of holding the run button you now have to hold the Shoot button.
				The scope will not work if holding the Run Button, or when moving.
				Simply stand still and shoot while X-ray is selected.
						
------------------------------------------------------------------
iv.						PHYSICS CHANGES
------------------------------------------------------------------

	Grapple Swinging:	Samus gets a horizontal boost on releasing the grapple based based on how
				fast she is swinging. She also gets a vertical boost upward.
				In the original Redesign Samus fell like a rock when releasing grapple.

	Speeds:			Samus now moves faster horizontally in air, covering more distance 
				at lower speeds. I also increased run speed in water w/o gravity suit.
						
	Jump Height:		In the Super Metorid when you ran with the speed booster equipped
				the game had a different way of calculating samus' jump speed.
				This could result in the player actually having a lower maximum
				jump height if tha player jumped too soon.  I rewrote the routine
				to add vertical speeds with a fraction of her horizontal speed
				to give a more accurate boost to her jump height. 
				In short the player now always has a fixed minimum jump height
	
	Floaty Fall:		Samus has a gradual increase in falling speed instead of hitting
				terminal velocity immediately like in the original Redesign.
				Morphball still falls like a rock.
							
	D-Pad Release:		Releasing the d-pad while moving through the air
				will cause Samus to slowly decelerate instead of stopping
				instantly.
						
	Morphing Ball:		Morphball now animates only when moving, and has momentum to its roll.
				Be careful when you start gaining real speed that you stop in time.
				Bouncing from a fall no longer removes your speed. Hold Item Cancel to brake.
	
	Morph/Demorph:		Morphing and demorphing now have a sexy glow and sound effect!
				I also made the morphball use a totally different palette which uses more colors
				rather than the original 4.
	
	Bomb Jumping:		Bombs are now easier to time for bomb-jumping multiple times.
				Horizontal bomb-jumps are also easier.  I modified the movement 
				so Samus is no longer unable to move side to side 
				while moving upward from a bomb jump.

	Quicksand:		This was especially bad in Redesign because of the increased gravity.
				The only real way to escape it was to spam the jump button and L/R.
				I fixed the quicksand so it can be escaped with and without gravitysuit
				with a few jumps.
						
	Sandfalls:		If you are in water, than you are unaffected, save for the slight push downward
				If you are out of the water and in a sandfall, you can only spacejump one time.
				You have to land before you can space jump again.

	Spark Charge:		Shine sparking horizontal into a slope no longer requires holding down the run button.
				Samus will begin walking at a slower speed for a few steps before losing booster
				use this time to press down to initiate the charge again.
	
Liquid Behavior:
	
	Liquid Enter:		Added liquid resistance. Samus loses most of her speed on hitting
				a liquid without gravity suit.  She also has a much lower terminal velocity
				depending on the liquid she is in, and will fall slower.
	
	Liquid Exit:		Jumping out of water in Redesign was impossible due to the gravity 
				difference in water and air.  Samus now gets a boost based on her 
				vertical speed on reaching the surface.
						
	Lava Damage:		Damage from being in lava is now based on your depth in the liquid.
				When near the surface you take a much slower drain than if you were
				30 tiles under the surface.
						
	Acid Damage:		Acid is super corrosive and will weaken suit integrity very fast!
				STAY OUT OF ACID. Samus needs to stay out of acid for a few seconds before re-entry.
						
						
------------------------------------------------------------------
v.		NEW (OPTIONAL) CHALLENGES
------------------------------------------------------------------	

	Hell's Run:		This was once required to beat Redesign, but thanks to my wife (her major
				was in game design), we worked out a design which utilizes Hell's run as a
				benefit to speedrunners.  Now players have a choice:  
						
					Option 1)	Go kill Kraid and get varia in an unlocked room.
							But they have to trek through underwater puzzles and a maze.
									
					Option 2)	Survive Hell's run and get ice beam, and enter through the 
							back door of the varia chamber and unlock a short-cut 
							bypassing the water rooms.
	
		The challenges listed below should only be done after
		you are familiar with the changes in Axeil Edition since
		they really change the difficulty of the game.
	
	
	Skip Walljump:		If Samus manages to avoid "detection" after claiming missiles and morphball
				then a passage in the landing site will	let your return to your ship. 
				You can then head over to get bombs.

	Early Powerbombs:	There is a powerbomb expansion directly behind the first missile pack.
				If you manage to pass through the proper security trigger then you can
				return and collect this expansion.  However, if you are "detected"
				you cannot ever get this powerbomb until you have powerbombs.	
				The gatekeeper will IMMEDIATLEY grant access to Tourian if you collect this expansion!
		The Challenge:
				Bombs and Walljump boots are inaccessible during this challenge.
				Use hard saves at designated stations, since there is a possibility you
				will get permanently stuck.  Use caution when entering morphball passages.
						
				This Challenge will require advanced techniques
				No Tool Assistance is required. Hint system is disabled.
						
						
------------------------------------------------------------------
vi.				SECIAL THANKS
------------------------------------------------------------------

A few of the big changes in redesign could not have been done without the feedback and guidance
of those more experienced with ASM. Axeil edition also uses a few patches which should be credited.

Axeil:	Without you and your suffering I would not have been motivated to complete this version. Thank you!

Black_Falcon:	Flash for morphing/demorphing. Patch for morphball animations.

Cardweaver:	Helping with HTML for the site.

DSO:		Sound optimization patch and helped redirect room for new sounds.
			ASM help. Bug fixes & testing.

GF_Kennon:	Provided a space for the website, as well as an incredible form of dedicated modders!		
			
Grime:		Adjusted enemy speeds for Pirates and Skree's.  Fixes for Luquid surface colors
			
JAM:		Adding Walljump Boots and game time/item collection % to the Inventory screen.

Kejardon:	Adjusted Gate PLM speeds, and making short gates for Morphball passages. ASM lessons.
			Decompression speeds patch.

MathOnNapkins:	Provided feedback for Ending Talley code. Fixed shine sparking in lava.
				Thanks for the disassembler, it saved me many times!

PJBoy:		Altered Minimap calculations, helped with learning ASM as well as taking
			advantage of existing SM routines.
				
Scyzer:		Provided the Zebetite patch, Ammo station Patch, Spark charge when not holding run.
			Acid damage timer, and damage boost changes.
			
Testers:	Ozzatron, TestRunner, Komaru, Passar, Grime, Qactis, TheAnonymousUser, Zeran, Elminster, Hitaka, RealRed, Technomagus, Boomerang, SMLite



Everyone who has played:  you've helped provide wonderful feedback both positive and horribly negative.
                          but I want to listen to that negativity and see what I can do to improve on it!

------------------------------------------------------------------
vii.                 VERSION CHANGES
------------------------------------------------------------------
1.6 FINAL (11/29/2022)
- Fixed accidental tile type allowing of early item.(still can get early, but method was bugged)
- Removed soft lock in Crateria Depths where shine sparking through a wrong tile failed to remove bridge, trapping player.
- Removed gfx offset bug in brinstar shaft when entering door before screen lines up.
- Removed possible softlock in Norfair
- Fixed scroll bg in norfair grapple room
- Adjusted platforms to escape lava
- Tile data fixes in norfair
- Moved a enemy inot a more visible position in norfair.
- Added code to align screen when taking a shortcut in a norfair room passage.
- Fixed a potential soft lock involving a Maw grabbing samus and getting stuck in Morph ball.
- Fixed an error with item drops that had apparently been in the game since 2006 and I never knew existed. (Thanks Azder for noting that during your FM2021 Run!) 
- Created a checkpoint system for the escape sequence. if you die during the escape, you can 
  choose to restart from the end of the Mother Brain fight when the timer begins.
- Space jumping while holding run would not activate screw attack when not moving horizontally, forcing 
  the player to have to move the opposite direction to activate it.
- Sometimes quakes would not trigger, preventing progress. this has been fixed.
- With some trickey spin jumping and demorphing samus could get wedged into the ground and perminently stuck in a morphing tunnel in the beginning of the game.
- If getting grabbed by draygon at just the right moment during a morph, samus would be locked in Morphball colors and be unable to move.
- Grappling a wall while jumping and at 0 vert speed resulted in the player standing in mid air. I changed
  the pose and code in the grapple routine to make samus swing and get pulled toward the wall.
- Fixed a rare bug with Ridley grabbing the player while moprhing. this would cause the morphing ball to glitch out.
- Whoops, removed debug code for quake PLM
- Changed lava SFX to only play when a certain distance for the surface of liquid.
- Translated hint system for Japanese language
- Fixed Japanese language not saving on selection.
- Bombs now appear correctly when loading a save file, instead of only appearing once moving.
- Samus would die on certain elevator platforms if aiming up too far.
- Fixed an issue with above checkpoint system, if exiting tourian, the checkpoint spawned the player in crateria on a save station, breaking the save file.
- Fixed a potential hard lock if entering north east elevator in maridia to crateria without missiles
  Making a save would require the player to start a new game due to being permastuck.
- Added a continuity tile to fix scrolling bug caused my mockballing off screen.
- Fixed an issue with custom input not being saved properly due to MB checkpoint code.
- Repaired door leading to lower norfair. oops
- Fixed tile colors in Maridia.
- Appearance change for some structures in rooms. No change to actual gameplay affected.
- Moved an annoying little zeela in the brinstar fisrt elevator room.
- Shot reflections from missile/locked doors when aiming UP no longer get stuck inside door.
- Hopefully fixed an error where walljumping did work while screw attacking.
- Repointed a Door FX to prevent acid appearing in a norfair room when it should be Lava.
- Fixed an issue with the appearance of glass shards from glass tubes. Shards now appear on both sides when exploding.
- Elevators will auto-center the screen in bigger rooms when activating them.
- Removed death by being out of bounds.
- Fixed error in ceres where samus might get softlocked when ridley pushes player asside.  
- Fixed a glitch where placing a powerbomb destroys Mother Brains pillar preventing the fight from soft locking.
- Fixed several soft lock scenatios during the EPBC
- Fixed a potential hardlock during EBPC when running out of powerbombs during a certain part.
- Fixed a solid wall preventing 100%
- Surprise bug introduces with lava animations speeds fixed. haha
- Fixed issue with zebes explosions occuring in the air while in some rooms.
- Added event states to two rooms once thought inacessable during the escape sequence.
- Fixed a bug with scrolling in the room before Kraid. Spring balling would result in samus off screen death.
- Adjusted platform to prevent getting stuck in water during escape if not knowing about crouch jump.
- Fixed a problem in Metroid behavior with screw attacking.
- Addressed an issue with demorhing sometimes slowing samus down for a few frames.
- Addressed a bug where sometimes demorphing in the middle of a bounce 
  meant a full height jump even when tapping the jump button.
- Fixed maridia express elevator unlocking trigger from explored map, to door shell.
- Slope fixes that were causing the player to stop when hitting the ceiling.
- Fixed a crumble exit which might cause softlock.
- Patched movment glitch with walljumping off left wall and releasing jump.
- fixed a shortcut in tourian which was not checking correct events.
- fixed zebes timer during escape.
- Added a break system for morphball I meant to implement but never did.
- Scroll fix in a maridia shortcut.
- New title screen that does not block half of the screen off.
- New Ending sprite to match consistency of Redesign story.
- Fixed a bug with bouncing while facing right which would move the player a pixel over time.
- Removed a bug with Rinkas where getting latched by a metroid while standing in a rinka meant MAJOR energy drain.
- Fixed a bug where samus would double bounce in one frame
- Fixed a bug with HBJ locking you into a direction upon 
  colliding with a wall until you land or alternate left/right rapidly on dpad.
- Blue suit is no longer stripped when you mid air morph or land
  without d-pad input, while speed boosting.
- Running and morphing quickly will keep running speed 
  (easier in real time once speed boost is aquired since it is based on acceleration speed)
- Fixed a bug while morphing/landing which could teleport samus 
  a full screen or more to the side sometimes causing death.
- Doors now reflect shots that do not match, for example, blue doors open to everything, but a missile door reflects beams.
- Removed the penalty of booster loss and running slowdown when Arm Pumping.
- Level Design tile fixes for continuity/permastucks
- Fixed a missed check for samus falling while space jumping in sand falls.
- Fixed errors in code for death beams
- Minor Level design changes in various rooms.
- Fixed permastuck scenarios when getting early bombs.
- Reduced duration for auto crouching spark charging animation.
  (horizontal super jump into slope holding ONLY D-pad)
- Fixed crash on touching a door transition tile while reaching 00 Energy.
- Added a smoothing acceleration to door transition speeds.
- Fixed a bug when exiting a door where the player skips scroll triggers causing oob deaths.
- Fixed bad Ice beam damage value
- Samus moves to center of screen on dying much more smoothly.
- Inserted a check to initiate shinespark. Samus will no longer super jump when
  the RUN button is pressed. This should lead to fewer accidental sparks during long chains.
  for the same reason as above super jumps cannot occur when samus has been hit by an enemy.
- Added transitions for poses (croucing and aiming down while moving)
- Re-wrote momentum routine to adjust rules based on movment type
- Re-wrote Acid damage routine. 5 second limit inside acid. Fixed bug where flash stayed perminent on getting out.
- Re-wrote grapple swing speed calculations.
- Re-Wrote Bombjumping.
- Reduced Screw Attack speeds slightly. (due to overshooting many platforms by accident)
- Fixed an issue with scrolling in one of the last Tourian Rooms.
- Fixed an error with Screw Attacking in acid.
- Space jump sprite changes to normal spin on touching water without gravity suit.
- Fixed samus placment when moving upward through vertical door.
- Fixed an issue with bad frame animation and Walljumping
- Fixed bad demorph tiles in Tourian & Solid door bug in main power room.
- Fixed permastuck in bird cage.
- Fixed and moved HINT for lower crateria.
- Set check so damage bit was not cleared on mid air morphing.
- Fixed an issue with morphing in water gaining a 'Gravity roll' boost
- Express elevators moving upward would glitch out the top row of tiles.
- Corrected an error in crouching and turning around on the same frame and holding direction.
- Fixed an issue caused when grapple releasing too fast.
- Fixed an issue with bombs affecting samus during a grapple swing.
- Fixed an isse with grapple walljumps causing samus to float into the wall or across the screen.
- Fixed bug where walljumps pulled torard the wall.
- Fixed Scroll Snapping when changing direction and falling.
- Fixed Screw attack flash getting stuck on turning without holding run.
- Adjusted decel speed for spin jumping.
- Repaired an oppsie which broke the Intro scene 2.
- Adjusted Escape time parameters.
- Slightly reduced WJ horizontal speed due to slower fall rate.
- Fixed a bug with demorphing breaking suit colors.
- Fixed issue with changing directions during a door transition. and the side effect of elevators being borky.
- Save stations can be re-used after moving off of them.
- Removed acid penalty while grapple swinging.
- Made vertical death beams a bit more forgiving.
- Silly mistake in leaving a tourian room set as Brinstar causing purple feeding pit colors.
- Fixed a scroll bug in the big room before Kraid
- Fixed issue with save station asking to save on load game
- Fixed a bug that can cause screen glitches when getting hit by an enemy at fast speeds.
- Screw Attack lock was impossible if switches were on opposite sides, fixed how switches add to timers.
- Fixed scroll bug in pre bomb room where players could die off screen.

1.52
- Unblocked a game breaker for Early Powerbomb Challenge.
  Hit head on ceiling on final obstacle. Raised ceiling
- misc tile changes for art continuity

1.51
- Unblocked a game breaker for Early Powerbomb Challenge
- Tried to fix issue where samus "bounces" when rolling on a flat slope
- a few level design fixes that accidently got lost and were meant to be in 1.5
- Fixed mockballing, samus keeps momentum on landing in the air when d pad pressing in MB mode.  
  somehow this got undone a while ago and I never noticed.

1.5
- Moved and changed behaviour of Express Elevators.  They can now
  connect to any other unlocked express elevator instead of two fixed ends.
- Adjusted enemy weaknesses and beam damage.
- Reduced charge beam shot cooldown
- Reduced Super missile cooldown
- Rebalanced Ridley Ceres damage: Each shot reduces HP by 70hp and will reduce HP
  during the second encounter in Lower Norfair. (Max deduction: 70.3% HP)
- Metroid stun is always maxed when stunned by bombs.  It no longer stacks.
- Increased countdown until Metroid's re-spawn
- Guardian hints now show once you've visited the Gatekeeper.
- Changed room layouts to make some guardians more accessible
- Adjusted room layouts to make some hidden passages a bit more visual.
- Added alternate progression routes.  Hint system still uses a fixed path.
- Removed Draygon door blocking West Maridia Guardian.
- Reduced activation time for platforms in lava.
- Automap fixes.
- Screw Attack doesn't give speed boost in sand falls when in air.
- minor expansion relocations.
- Added energy refill before first save in Tourian after completing Phase 1
- Made crumble block permanent at end of the final security death beam in Tourian.
- Tweaked grapple beam swing behaviour
- increased morphball speed in air & water
- increased running speed in water
- misc. tile changes in level data
- Fixed bug in which decelerating on a slope would result in
  very fast vertical screen and samus jittering.


1.4
- Metorid AI fixes all around
- Metroids outside feeding pit no longer dodge
- Fixed an issue where rolling into a bomb didn't register.  now it does resulting in easier detach of Metroids.
- Metroids detatch when you fall into acid.
- Increased the time delay for a re-spawning metorid when outside the feeding pit
  This gives you extra time to kill 3 metroids in the room
- Fixed a bug where the screen shakes when landing.


1.3
- Updated read me to explain Metroid Strategies
- Fixed a room in maridia which was air, when it should have had water
- Increased speed of Guardians
- Made a Guardians or path to guardians more visible
- Acid now kills samus within 5 seconds. (before was 3 seconds, with 14 full tanks)
  now it takes 5 seconds to die when submerged in acid regardless of number of tanks.
  Got 2 tanks? 5 tanks? 14 tanks?  5 seconds to get out.
- Fixed Death beam Sound.
- Changed many Uber doors in Tourian to 5 missile doors. Doors leading to an important room will remain Uber.
- Increased morphball roll speed without Hi Jump slightly. (1/4) any faster and the animation doesn't match roll speed well.
- Adjusted acceleration of fall speed when not morphed
- Removed bomb spread due to a glitch as a result from bomb timer and limiter code.
- Made Metroids detach with a minimum of one second stun.
- Fixed Crystal flash refill bug.
- Lowered required fall speed for space jump while in air.  Speeds remain the same in sand falls while out of water.
- Fixed a tile bug causing the player to get stuck in a wall.

1.21
- Fix a bug in Tourian where a room was, in error, setting enemies to clear to 30 instead of 4
  resulting in an almost endless wave of metroids.

1.2
- Removed time penalty for wrong Screw attack puzzle input. Instead if you enter the wrong combo a Buzzing occurs
  and deactivates the switches.
- Fixed glitch with lights not appearing when switch is triggered in the SA puzzle.
- Added hints for guardians once you beat Ridley
- Adjusted Morphball maze in norfair near crocomire, above the two dynamo's.
- Removed need to spark charge for the east norfair guardian.
- Removed platforms in guardians room because of an exploit which was confusing players for being the solution.
- Removed metroids response to powerbombs when playing a normal game and NOT the EPB challenge. Powerbombs reset stun time and were confusing
  players making them think they were supposed to powerbomb metroids to get them off.  bombs were always the weakness and stun the metroids
  for a few frames for each bomb hitting a latched metroid. This stun time stacks until the metroid is dead or powerbombed, when it is reset.
  EPB changes it so PB's stun the metroid for max stun time.
- Fixed jumping in sand falls without gravity, was over wrtiting codes with codes.
- Fixed vertical door detection in Tourian.
- misc. tile fixes
  
1.1
- Changed camera scroll to hopefully prevent or minimize OOB deaths by accident. might have cause other camera related wonky-ness, let me know if you notice any
- Swapped position of 4 energy tanks with the place of certain super missile packs in order for more access to energy tanks
  (Included item index values so 100% unaffected, however you might find items spawned in places you already collected from)
- Added save stations before Botwoon and Tourian
- Ridley HP and damage adjusted,  before Ceres shots adjusted vulnerabilities, now it reduces his HP by $32 for every hit you landed.
- Removed the lock in before Ridley and GT in case the player is under equipped and can no longer get trapped. Added ammo station before GT.
- Metroids outside the feeding pit freeze for longer and have a higher stun cap.
- Changed several diapers.
- Fixed Speedbooster blue suit glitch from crouching and holding R.  or so I think.  let me know if this continues
- Adjusted air spike invincibility timer to last longer underwater without gravity. and reduced the damage dealt.  result is easier getting out of spike pits under water.
- Removed spike pits in west crateria.
- Fixed dying off screen to not cause death on reloading.
- Fed baby
- Narrowed hold in Maridia sandfalls leading to draygon to prevent frequent falls to the water below
  resulting in backtracking.
- Adjusted Lost Caverns clue
- Tweaked Auto Space jump.
- Adjusted Morphball maze in east Crateria
- Fixed permastuck for EPBC in west norfair
- Adjusted Powerbomb maze near crocomire
- Fixed phantoons defeated location on map
- Lowered grapple swing speed boost when letting go.
- Fixed some hint system icons that never went away.  
  might be more, PM me screens when encountered.
- Misc Tile changes.
- Crystal flash now restores 799 energy.  changed input requirement to only holding shoot
- Adjusted Hi Jump hint location
- slightly lowered time to charge a beam.
			