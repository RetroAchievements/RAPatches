Use with:

(No Intro)
File:               Super Metroid (Japan, USA) (En,Ja).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              D63ED5F8
MD5:                21F3E98DF4780EE1C667B84E57D88675
