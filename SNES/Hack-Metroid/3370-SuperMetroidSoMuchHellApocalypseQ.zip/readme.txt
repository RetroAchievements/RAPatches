~Hack~ Super Metroid So Much Hell Apocalypse Q.bps


Use with:

Super Metroid (Japan, USA) (En,Ja).sfc	(No-Intro)
21f3e98df4780ee1c667b84e57d88675
D63ED5F8


~Hack~ Super Metroid So Much Hell Apocalypse Q (Pl).bps


Use with:

Super Metroid So Much Hell Apocalypse Q.sfc
b7d78ef6c96d8c4596f1c61fd07e466f
DC9B7EC8