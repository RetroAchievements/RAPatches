Use with:

(No Intro)
File:               Final Fantasy III (USA).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              A27F1C7A
MD5:                E986575B98300F721CE27C180264D890