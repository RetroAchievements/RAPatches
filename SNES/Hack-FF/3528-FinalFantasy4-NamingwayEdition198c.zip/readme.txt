Use with:
Final Fantasy II (USA).sfc [No-Intro]
4fa9e542b954dcb954d5ce38188d9d41
65D0A825