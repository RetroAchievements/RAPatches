There are three .bps patches for use with any of the current USA No Intro ROMS. 

Use with:

(No Intro)
Final Fantasy II (USA).sfc
MD5: 4fa9e542b954dcb954d5ce38188d9d41
CRC: 65D0A825

(No Intro)
Final Fantasy II (USA) (Rev 1).sfc
MD5: 27d02a4f03e172e029c9b82ac3db79f7
CRC: 23084FCD

(No Intro)
Final Fantasy II (USA, Europe) (Rev 1) (Virtual Console).sfc
MD5: 6ee1bfa6ac945590197c3925ee94b8dd
CRC: 96CFA5C9

