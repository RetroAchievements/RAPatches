Use with:

(No Intro)
Final Fantasy VI (Japan).sfc
97bf78e916b80f47cf35edf502be34dc
45EF5AC8