Rockman X New Years 2016
Rockman X New Years 2017
Use with:

No Intro
Rockman X (Japan).sfc
9963dd54175bbe2d02999f4ced43f829
6A1B6926



Rockman X New Years 2021
Rockman X New Years 2022
Use with:

No Intro
Rockman X3 (Japan).sfc
b1023717d7beae8ca83a390198fbcbff
E476912B