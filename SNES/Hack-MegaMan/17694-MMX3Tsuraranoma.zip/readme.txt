Use with:

No Intro
Rockman X3 (Japan).sfc
b1023717d7beae8ca83a390198fbcbff
E476912B