Use with:
Mega Man X (USA) (Rev 1).sfc (No-Intro)
df1cc0c8c8c4b61e3b834cc03366611c
DED53C64