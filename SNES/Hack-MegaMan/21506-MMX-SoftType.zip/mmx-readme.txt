Use with:

(No Intro)
File:               Mega Man X (USA) (Rev 1).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              DED53C64
MD5:                DF1CC0C8C8C4B61E3B834CC03366611C