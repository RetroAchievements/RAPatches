Use with:

Mega Man X (USA)(Rev 1).sfc (No Intro)
md5 - df1cc0c8c8c4b61e3b834cc03366611c
crc - DED53C64