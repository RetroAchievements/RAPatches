Use with:

Mega Man X3 (USA).sfc (No Intro)
cfe8c11f0dce19e4fa5f3fd75775e47c
FA0FE671