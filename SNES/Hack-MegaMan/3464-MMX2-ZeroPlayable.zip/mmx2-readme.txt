Use with:

(No Intro)
Mega Man X2 (USA).sfc
67905b989b00046db06df3434ed79f04
947B0355