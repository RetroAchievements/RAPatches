~Hack~ Mega Man X - Hard Type (USA) (2.2.2) (Hart-Hunt).bps
Use with:

Mega Man X (USA).sfc (No Intro)
a10071fa78554b57538d0b459e00d224
1033EBA4



~Hack~ Mega Man X - Hard Type (USA) (Rev1) (2.2.2) (Hart-Hunt).bps
Use with:

Mega Man X (USA) (Rev 1).sfc
df1cc0c8c8c4b61e3b834cc03366611c
DED53C64