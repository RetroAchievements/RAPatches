Use with:

Mega Man X3 (USA).sfc	(No-Intro)
094f035993e9724647b61ddcba1e9a7a
B64FFB12