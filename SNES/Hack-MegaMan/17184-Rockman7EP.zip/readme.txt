Use with:

Rockman 7 - Shukumei no Taiketsu! (Japan).sfc
e9c126cbd7c68c9e985dc501f625b030
31F18DDA
