Use with:

Kaizou Chounin Shubibinman Zero (Japan) (BS).sfc (No-Intro)
db4dd0305051f7d3ca7bd2e114f4f1dd
26A4F6C3
