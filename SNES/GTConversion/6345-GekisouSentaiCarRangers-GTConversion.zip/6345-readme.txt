Use with:

Gekisou Sentai Carranger - Zenkai! Racer Senshi (Japan).sfc (No-Intro)
27eb2c85bb733416762fa1bcd91a4ab7
14C66FCA

SD Gundam Generation - Axis Senki (Japan).st (No-Intro)
16375432c8ffc540b459cfd31723572b
72B4235F
