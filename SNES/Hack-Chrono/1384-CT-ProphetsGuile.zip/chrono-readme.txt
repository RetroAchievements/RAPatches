Use with:

(No Intro)
File:               Chrono Trigger (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              2D206BF7
MD5:                A2BC447961E52FD2227BAED164F729DC
