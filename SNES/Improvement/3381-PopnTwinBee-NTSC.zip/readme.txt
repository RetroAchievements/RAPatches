Use with:

Pop'n TwinBee (Europe).sfc	(No-Intro)
ed9c32231cd480448f355c4ed54b1bae
588A9707