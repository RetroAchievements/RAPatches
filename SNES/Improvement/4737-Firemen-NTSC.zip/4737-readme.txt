Use with:

(No Intro)
File:               Firemen, The (Europe) (En,Fr,De).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              DEF665AF
MD5:                AC995AB6F5667BE14EB6471458E491D3
SHA1:               4B82C70824922380A3193E282D7674A442BD6DD4
SHA256:             A0106F9CFF7ABBF25E081E2531F6D4B4AEDF6F0DC8D155A66506817BFF267D12