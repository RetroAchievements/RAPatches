Shadowrun SNES Mouse Patch
by rainwarrior (Brad Smith)
https://rainwarrior.ca
2022-03-07


This patch adds support for the SNES Mouse to Shadowrun.

It is inspired by, and partly based on the emulator lua script by Gamachara:
https://github.com/Gamachara/SNES-Shadowrun-Mouse-Script


Choose the IPS patch appropriate for the version of the ROM you have. CRC and likely filenames below:

3F34DFF0 - Shadowrun (USA).sfc
2AF15F10 - Shadowrun (Europe).sfc
E420E96F - Shadowrun (Germany).sfc
30829D8E - Shadowrun (Sweden).sfc
EFD4D741 - Shadowrun (Japan).sfc

(ROM files should not have headers.)

Here's an easy to use IPS patching tool:
https://bbbradsmith.github.io/ipstool/


Directions
==========

Connect a SNES mouse to the second controller port.
Use a controller with your left hand.

The controller works as normal except for L/R which now affect the mouse.
Left/right mouse clicks map to B and A normally.
Hold L on the controller for alternate button use.
  On the MAIN GAME SCREEN or in THE MATRIX:
    L+Left = START (Status)
    L+Right = X (Spell)
  With the ACTION GLOVE active:
    L+Left = L (Examine)
    L+Right = R (Open)
  In a menu:
    L+Left = L (Page Up)
    L+Right = R (Page Up)

Press R on the controller to cycle mouse sensitivity. (Mid/High/Low)

The Y button (quick Inventory) can't be activated with the mouse, but you can still reach Items through the START menu.
The game can be played without ever needing to use buttons on the right half of the controller.


Directions (Japanese)
=====================

The Japanese version has a slightly different mapping because of its altered control scheme.

Connect a Super Famicom mouse to the second controller port.
Use a controller with your left hand.

The controller works as normal except for L/R which now affect the mouse,
and also some unused gamepad buttons have been used for duplicate functions that assist the mouse:
  On the MAIN GAME SCREEN:
   A now brings up the ACTION GLOVE (not just X)
   B now brings up the CROSS-HAIR (not just R)
  On the TITLE SCREEN:
   A now opens the title menu

Left/right mouse clicks map to A and B normally.
Hold L on the controller for alternate button use.
  On the MAIN GAME SCREEN or in THE MATRIX:
    Left = A (Action Glove)
    Right = B (Weapon)
    L+Left = START (Status)
    L+Right = Y (Spell)
  With the ACTION GLOVE active:
    Left = A (Action)
    Right = B (Cancel)
    L+Left = L (Examine)
    L+Right = R (Open)
  In a menu:
    Left = A (Confirm)
    Right = B (Cancel)
    L+Left = L (Page Up)
    L+Right = R (Page Up)

Press R on the controller to cycle mouse sensitivity. (Mid/High/Low)

The game can be played without ever needing to use buttons on the right half of the controller.


Source
======

Source code for these patches is provided in the src/ folder.

To build the patches, cc65 is required. Download the snapshot here and put in a folder at: src/cc65/
https://cc65.github.io/

Optionally, the build batch file also applies the patches using Floating IPS (flips) which can be downloaded here:
https://www.romhacking.net/utilities/1040/



Author
======

rainwarrior (Brad Smith)
https://rainwarrior.ca
2022-03-06

Support:
https://www.patreon.com/rainwarrior
