Use with:
Final Fantasy II (USA) (Rev 1).sfc (No-Intro)
27d02a4f03e172e029c9b82ac3db79f7
23084FCD