Use with:

(No Intro)
File:               Super Bomberman 3 (Europe).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              A096A6E5
MD5:                681343F71B5FCE4F7E960F3091E56026