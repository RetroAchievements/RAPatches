Use with:

(No Intro + RAPatch)
File:               Final Fantasy IV - Namingway Edition (v1.98b) (Rodimus Primal).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              26B5F1C6
MD5:                936CE8C534346E61D8E21EFBA9177184
SHA1:               CD7E06522257FDCF4D60E36B4EC84023D70EE8B2
SHA256:             63BFAF7A97BF4A69650312BC7A4BC748501B99915953A23BD122FD9E3E2C98D3

File:               Final Fantasy IV - Namingway Edition (v1.98c) (Rodimus Primal).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              41237AE7
MD5:                7F2C8D00101BD3EE2F4EF739E499A302
SHA1:               756372EF5B7554FC104A1728977822A2F0FCDD13
SHA256:             7C05C496682CD490D393EC750804A8116D89489A6A512F6AFDF7B349D03CA3A9

File:               Final Fantasy IV - Namingway Edition (v1.98d) (Rodimus Primal).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              8F367F39
MD5:                E2DC34549DB609189D8ED989C58C77F9
SHA1:               EFCABC37F6328138C8D5C2928EEC95DE928791D5
SHA256:             1D98CD9F824CB91380DD7453C8D9C7A165D57106141AFC24451DD17CD46A79EA

File:               Final Fantasy IV - Namingway Edition (v1.99a) (Rodimus Primal).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              996A2DF3
MD5:                CAAE66DEC5B2D9767EA25A464A694EDB
SHA1:               778842C53700CF0AC7F2A549069D2C5256A74B02
SHA256:             AF0129EB73E941674D217D31DAB58E7EA4E0926F4E99EC9A8E7A868260B1B2AD