Use with:

(No Intro)
Lufia II - Rise of the Sinistrals (USA).sfc
6efc477d6203ed2b3b9133c1cd9e9c5d
20f2ac29