Use with:

(No Intro)
Mickey Mania - The Timeless Adventures of Mickey Mouse (USA).sfc
RA Checksum: e3f9cc6d8321fa661a30cabe5dce141a
CRC32 Checksum: 08806B5B