Use with:

(No Intro)
Seiken Densetsu 3 (Japan).sfc
58ebd7cbf28ceadc03aec4f448956a0b
863ed0b8

Trials of Mana (World) (Collection of Mana).sfc
c9829d76e25f8c4bf459cf77a8306825
9743dc0e

Trials of Mana (World) (Rev 1) (Collection of Mana).sfc
d40bd9267fb21ad8f8987cb8da473dbc
173e6097