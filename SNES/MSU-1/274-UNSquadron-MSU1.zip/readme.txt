Use with:

(No Intro)
U.N. Squadron (USA).sfc
RA Checksum: affecaf49a6bd32188f62d9ad1f833ea
CRC32 Checksum: 231F0F67