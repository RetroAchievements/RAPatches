Use with:

(No Intro)
Soul Blazer (USA).sfc
83cf41d53a1b94aeea1a645037a24004
31b965db