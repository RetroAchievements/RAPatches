Use with:

(No Intro)
SimCity (USA).sfc
23715fc7ef700b3999384d5be20f4db5
8aedd3a1