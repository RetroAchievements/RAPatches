Use with:

(No Intro)
Ys V - Ushinawareta Suna no Miyako Kefin (Japan).sfc
f630c6e0f11fd53d112f3dd004ea7184
5e08c48c