Use with:

(No Intro)
Maui Mallard in Cold Shadow (USA).sfc
RA Checksum: 5ece56f9a92f4c243ae9311b9e1965f0
CRC32 Checksum: 2D3B9662