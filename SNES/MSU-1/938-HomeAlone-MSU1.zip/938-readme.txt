Use with:

(No Intro)
Home Alone (USA).sfc
87447e71a602b02797054a4d80349c20
07c494b1