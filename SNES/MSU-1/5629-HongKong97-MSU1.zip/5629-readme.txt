Use with:

(No Intro)
Hong Kong '97 (Japan) (En,Ja,Zh-Hant) (Unl).sfc
8cb1cfe8f847fe073c3609415adc2a19
11a6e64b