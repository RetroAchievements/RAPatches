Use with:

(No Intro)
File:               Hong Kong '97 (Japan) (En,Ja,Zh-Hant) (Unl).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              11A6E64B
MD5:                8CB1CFE8F847FE073C3609415ADC2A19
SHA1:               544BBF6F34A8E9CFA73A0D1785E1017F3CAA5833
SHA256:             051962A5AA5C8AF2B4EE4FA08DF9CB0CF253DD0F84C369F1869824E3D3B72042

https://www.zeldix.net/t1636-hong-kong-97