Use with:

(No Intro)
Jurassic Park (USA).sfc
bb9c2f667ced16a2e605b385c041c744
77540cb9

Jurassic Park (USA) (Rev 1).sfc
ff42b93f32c7921a88ef46fdf79a8445
8bfde0b7