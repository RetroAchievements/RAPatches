Use with:

(No Intro)
Super Star Wars (USA) (Rev 1).sfc
RA Checksum: 744b9d1a382adfabf0515d6d0e5dfed7
CRC32 Checksum: BE47F6C6