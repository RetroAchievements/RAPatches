Use with:

(No Intro)
Toy Story (USA).sfc
RA Checksum: df1d99115ce4a386054b511b62cd5cc6
CRC32 Checksum: 8328822B