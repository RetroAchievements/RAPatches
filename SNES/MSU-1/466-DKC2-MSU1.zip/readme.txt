Use with:

(No Intro)
Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr) (Rev 1).sfc
RA Checksum: d323e6bb4ccc85fd7b416f58350bc1a2
CRC32 Checksum: 4E2D90F4