Use with:

(No Intro)
File:               Final Fantasy - Mystic Quest (USA) (Rev 1).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              2C52C792
MD5:                F7FAEAE5A847C098D677070920769CA2
SHA1:               6BE74B73B736BC6027C0E92619874DA7C498BED0
SHA256:             F71817F55FEBD32FD1DCE617A326A77B6B062DD0D4058ECD289F64AF1B7A1D05