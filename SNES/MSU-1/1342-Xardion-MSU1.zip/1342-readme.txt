Use with:

(No Intro)
Xardion (USA).sfc
4369249d5f53fb9d70b1915cf533af03
c7c12a57