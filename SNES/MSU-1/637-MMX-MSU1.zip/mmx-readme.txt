Use with:

(No Intro)
Mega Man X (USA).sfc
RA Checksum: a10071fa78554b57538d0b459e00d224
CRC32 Checksum: 1033EBA4

Mega Man X (USA) (Rev 1).sfc
RA Checksum: df1cc0c8c8c4b61e3b834cc03366611c
CRC32 Checksum: DED53C64