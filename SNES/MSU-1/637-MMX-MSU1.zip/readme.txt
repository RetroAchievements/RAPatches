Use with:

(No Intro)
Mega Man X (USA) (Rev 1).sfc
RA Checksum: df1cc0c8c8c4b61e3b834cc03366611c
CRC32 Checksum: DED53C64