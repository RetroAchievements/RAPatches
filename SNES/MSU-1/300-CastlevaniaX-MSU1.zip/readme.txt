Use with:

(No Intro)
Castlevania - Dracula X (USA).sfc
dc629be2ee515461315cde57210e36c0
7C4887E1