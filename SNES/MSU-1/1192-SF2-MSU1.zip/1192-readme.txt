Use with:

(No Intro)
Street Fighter II (USA).sfc
be7fc84ac1151b99ad48329327e2aaa7
bc3dcd9d