Use with:

(No Intro)
Ys III - Wanderers from Ys (USA).sfc
c8236962fd9f85f6d1961934166d6bd5
64a91e64