Use with:

(No Intro)
Street Fighter II Turbo (USA).sfc
ac63bd5085b0f8f35e2cff59e9c34456
A45CADD6

Street Fighter II Turbo (USA) (Rev 1).sfc
014863e139f5a9e9fc8ecf59a133223b
D43BC5A3