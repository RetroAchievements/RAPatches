Use with:

(No Intro)
Choujikuu Yousai Macross - Scrambled Valkyrie (Japan) (En).sfc
e11c1d923ea1b2f6a00e5886aa6b6202
a5db02e9