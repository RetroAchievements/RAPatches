Use with:

(No Intro)
Battletoads-Double Dragon (USA).sfc
RA Checksum: 3c433a8aa73986e1361423303e92785b
CRC32 Checksum: 8B18AC01