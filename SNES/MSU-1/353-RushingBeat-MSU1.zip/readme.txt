Use with:

(No Intro)
Rushing Beat (Japan).sfc
RA Checksum: ee392bdcd28d073585f198ce9187456f
CRC32 Checksum: A6F0693D