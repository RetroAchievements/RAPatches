Use with:

https://saralene.tv/ctso/

(No Intro + RAPatches)
File:               Radical Dreamers - Nusume Nai Houseki (Japan) (2-24) (En) (v1.4) (Demiforce).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              A2664B10
MD5:                55C5BAAEDFFCF4FD022361C531C72178
SHA1:               D06A13524A907E5834A755E3A710FB30ADB33C49
SHA256:             83BB5839ED560C05CB98DF5BDBCF0FF9F613C5083FA0A097B8536498F47AE48A

(No Intro)
File:               Radical Dreamers - Nusume Nai Houseki (Japan) (2-24).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              660B8CC4
MD5:                5D1C642C23D0BB113ACE249A586F0689
SHA1:               A4FF257E0CA71A60A7D76EA49B0DBAB770268A5F
SHA256:             3B3B8EA66EBA1B3C29EE420835C6F6776421E7E5C724AC93ECEBC7B109DD08AA