Use with:

(No Intro)
R-Type III (USA).sfc
cb4a282e8a7bde5e16103c4136f9491e
642b656b