Use with:

(No Intro)
Battletoads in Battlemaniacs (USA).sfc
RA Checksum: e44b9987e33ef7237b24457a6c997723
CRC32 Checksum: 617AC925