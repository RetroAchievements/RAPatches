Use with:

(No Intro)
Pitfall - The Mayan Adventure (USA).sfc
02cae4c360567cd228e4dc951be6cb85
03e67d38