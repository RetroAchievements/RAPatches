Use with:

(No Intro)
Earthworm Jim (USA).sfc
25fdebdec0e83132d8f24e9ac5bfc45f
3a4a47eb