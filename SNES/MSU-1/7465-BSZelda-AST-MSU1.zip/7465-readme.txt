Use with:

(No Intro)
File:               BS Zelda no Densetsu - Inishie no Sekiban - Dai-1-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              0D2B95A8
MD5:                A90F92A606E342B35AA4BC070CFE3F78

File:               BS Zelda no Densetsu - Inishie no Sekiban - Dai-2-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              1B71A609
MD5:                F203AB9D9720C2BA8AC8453B0C10553C

File:               BS Zelda no Densetsu - Inishie no Sekiban - Dai-3-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C251D4FA
MD5:                59CEE44354ED6FD664236BA9F6B18A63

File:               BS Zelda no Densetsu - Inishie no Sekiban - Dai-4-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              8385BBF4
MD5:                DA4D548E54A593E635E023BBF7DB72B1
