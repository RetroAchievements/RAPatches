Use with:

(No Intro)
Super Off Road (USA).sfc
0c1cc5369a31c988858a087598bab9c3
fe263383