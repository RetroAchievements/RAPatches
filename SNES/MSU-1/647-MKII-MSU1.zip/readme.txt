Use with:

(No Intro)
Mortal Kombat II (USA).sfc
RA Checksum: 9873c45bf77eb06262e9b8d8c4b841b4
CRC32 Checksum: 1C3D3B72

Mortal Kombat II (USA) (Rev 1).sfc
RA Checksum: a0b9bebbc80958e36292abd9b8fb758e
CRC32 Checksum: 70BB5513