Use with:

(No Intro)
Mortal Kombat II (USA) (Rev 1).sfc
RA Checksum: a0b9bebbc80958e36292abd9b8fb758e
CRC32 Checksum: 70BB5513