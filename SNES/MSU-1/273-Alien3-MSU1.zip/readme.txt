Use with:

(No Intro)
Alien 3 (USA).sfc
RA Checksum: 09120ba8c0052997481117683b4e70db
CRC32 Checksum: 98E2AC15

Alien 3 (USA) (Rev 1).sfc
RA Checksum: 730bef426e194a06a2f61e703e0719ca
CRC32 Checksum: 9cce2eb7