Use with:

(No Intro)
Contra III - The Alien Wars (USA).sfc
RA Checksum: ede82658dafdd6febbfbe6a9c9082500
CRC32 Checksum: 84DA7CFE