Use with:

(No Intro)
Saturday Night Slam Masters (USA).sfc
c8dd52b075e1681f590d2f97ab5b4d7e
54161830