Use with:

(No Intro)
Demon's Crest (USA).sfc
RA Checksum: e990ae600a8326eda25489bdddffca55
CRC32 Checksum: E8236AD2