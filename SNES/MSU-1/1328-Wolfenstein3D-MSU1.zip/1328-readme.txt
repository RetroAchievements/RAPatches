Use with:

(No Intro)
Wolfenstein 3-D (USA).sfc
418034d574ebdaea7659b3a90eebef58
6582a8f5