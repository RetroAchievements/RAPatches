Use with:

(No Intro)
Donkey Kong Country (USA) (Rev 2).sfc
RA Checksum: 2e604bc12fb8f9467765c807c24877fa
CRC32 Checksum: 762AF827