Use with:

(No Intro)
Star Ocean (Japan).sfc
d686ba6df942084216393ada009126dc
3dbdfdbf