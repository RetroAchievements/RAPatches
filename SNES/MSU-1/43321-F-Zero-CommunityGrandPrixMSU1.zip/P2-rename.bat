@echo off
setlocal
set "RENAME_DIRECTORY=%~dp0"
powershell.exe -NoProfile -Command "$ErrorActionPreference = 'Stop'; $old = 'F-Zero CGP P2'; $new = 'F-Zero - Community Grand Prix (v1.0) (P2) (Worthy MF, Fennor Virastar)'; $count = 0; Get-ChildItem -LiteralPath $env:RENAME_DIRECTORY -File | Where-Object { $_.Name.Contains($old) } | ForEach-Object { $name = $_.Name.Replace($old, $new); $target = Join-Path $_.DirectoryName $name; if (Test-Path -LiteralPath $target) { Write-Warning ('Skipped (name already exists): ' + $_.Name) } else { try { Rename-Item -LiteralPath $_.FullName -NewName $name -ErrorAction Stop; Write-Host ($_.Name + ' -> ' + $name); $count++ } catch { Write-Warning $_.Exception.Message } } }; Write-Host ('Renamed ' + $count + ' file(s).')"
pause
endlocal
