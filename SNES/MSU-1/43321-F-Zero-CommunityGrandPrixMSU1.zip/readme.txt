Use with:

(No Intro)
File:               F-Zero (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              AA0E31DE
MD5:                6F334790120E1FE1A972FF184D2CFC50
SHA1:               D3EFD32B68F1FE37A82DB9D9929B7CA7CC1A3AF4
SHA256:             BF16C3C867C58E2AB061C70DE9295B6930D63F29F81CC986F5ECAE03E0AD18D2

Original patch, msu file, and pcm files can be found at https://romhackplaza.org/romhacks/f-zero-community-grand-prix-cgp-super-nintendo-romhack

The batch files included will rename the default filenames to match the RAPatches BPS files.