Use with:

(No Intro)
Legend of the Mystical Ninja, The (USA).sfc
bf6da6f13729c8925d8725d7dd25b420
82479d6a