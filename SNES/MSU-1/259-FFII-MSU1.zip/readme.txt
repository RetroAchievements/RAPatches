Use with:

(No Intro)
Final Fantasy II (USA) (Rev 1).sfc
RA Checksum: 27d02a4f03e172e029c9b82ac3db79f7
CRC32 Checksum: 23084FCD