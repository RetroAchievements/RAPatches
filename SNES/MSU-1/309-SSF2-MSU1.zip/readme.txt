Use with:

(No Intro)
Super Street Fighter II (USA).sfc
RA Checksum: 02c9c7e7914f9808487704e122554d4c
CRC32 Checksum: F16D5CE9