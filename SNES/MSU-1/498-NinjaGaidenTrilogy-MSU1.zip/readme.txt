Use with:

(No Intro)
Ninja Gaiden Trilogy (USA).sfc
RA Checksum: a641a33a829154f656ca00ab1ef35500
CRC32 Checksum: 066FE797