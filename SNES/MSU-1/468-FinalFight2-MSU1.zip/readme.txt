Use with:

(No Intro)
Final Fight 2 (USA).sfc
RA Checksum: 262616f80a6c194527d41e2c72b61aca
CRC32 Checksum: 8C37FF55