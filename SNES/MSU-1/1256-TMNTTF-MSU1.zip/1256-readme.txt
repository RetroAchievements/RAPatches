Use with:

(No Intro)
Teenage Mutant Ninja Turtles - Tournament Fighters (USA).sfc
878e95bca6b94b3fa0e72fef1867434c
e2fe5dbf