Use with:

(No Intro)
Super Punch-Out!! (USA).sfc
RA Checksum: 97fe7d7d2a1017f8480e60a365a373f0
CRC32 Checksum: E2F92F84