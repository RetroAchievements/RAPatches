Use with:

(No Intro)
Rock n' Roll Racing (USA).sfc 
RA Checksum: 1978359063c02ad2badd3c0e993aca14
CRC32 Checksum: 7D06F473