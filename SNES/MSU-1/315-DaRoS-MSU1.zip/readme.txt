Use with:

(No Intro)
Death and Return of Superman, The (USA).sfc
RA Checksum: dbf576310985b10fa48c6a1c8915b19d
CRC32 Checksum: A567957C

Death and Return of Superman, The (USA) (Rev 1).sfc
RA Checksum: 256611711f506c2bb9cd2bc197d50071
CRC32 Checksum: 012EF33D