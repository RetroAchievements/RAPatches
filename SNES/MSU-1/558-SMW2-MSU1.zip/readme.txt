Use with:

(No Intro)
Super Mario World 2 - Yoshi's Island (USA).sfc
RA Checksum: cb472164c5a71ccd3739963390ec6a50
CRC32 Checksum: D138F224

Super Mario World 2 - Yoshi's Island (USA) (Rev 1).sfc
RA Checksum: ce1e3e33b6e39d37b43d7de599f9e785
CRC32 Checksum: CF98DDAA
