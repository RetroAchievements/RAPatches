Use with:

(No Intro)
Earth Defense Force (USA).sfc
c0e5d653d0bec492117fa4f53cfcb619
ca8ff946