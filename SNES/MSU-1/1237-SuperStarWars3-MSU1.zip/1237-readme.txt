Use with:

(No Intro)
Super Star Wars - Return of the Jedi (USA).sfc
06aa5b85ed1d3bc61d94ece1f96a050e
c709ec69

Super Star Wars - Return of the Jedi (USA) (Rev 1).sfc
dc147fcbf64265d2940f359cfde7e74f
4a5f30d8