Use with:

(No Intro)
Kirby's Dream Land 3 (USA).sfc
201e7658f6194458a3869dde36bf8ec2
ec8a48f6