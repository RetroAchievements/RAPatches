Use with:

(No Intro)
Shaq-Fu (USA).sfc
9ad77707da7c7e4913a1644b3b6cdfd8
52916c9d