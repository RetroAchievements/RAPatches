Use with:

(No Intro)
Simpsons, The - Bart's Nightmare (USA).sfc
5f8c3fd37130d9b80f1d98d1b7034161
ed1c03c2