Use with:

(No Intro)
Captain Commando (USA).sfc
RA Checksum: fa1aca992a1bbe309651fff64541866f
CRC32 Checksum: 81DB73C7