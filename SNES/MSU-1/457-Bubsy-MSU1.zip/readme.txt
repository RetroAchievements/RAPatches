Use with:

(No Intro)
Bubsy in - Claws Encounters of the Furred Kind (USA).sfc
RA Checksum: 6ac508bddbabc699f181d7858ccfcf0f
CRC32 Checksum: 444A52C1