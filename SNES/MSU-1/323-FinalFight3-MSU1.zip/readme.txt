Use with:

(No Intro)
Final Fight 3 (USA).sfc
RA Checksum: 1288de058352d6f9c3ba146a61581555
CRC32 Checksum: A916E708