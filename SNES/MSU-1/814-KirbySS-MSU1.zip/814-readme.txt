Use with:

(No Intro)
Kirby Super Star (USA).sfc
cb76ea8ac989e71210c89102d91c6c57
89d0f7dc