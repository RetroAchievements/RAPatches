Use with:

(No Intro)
Mega Man 7 (USA).sfc
RA Checksum: 301d8c4f1b5de2cd10b68686b17b281a
CRC32 Checksum: 2D947536