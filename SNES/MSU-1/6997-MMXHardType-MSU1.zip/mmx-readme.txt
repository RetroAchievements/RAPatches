Use with:

(No Intro)
File:               Mega Man X (USA).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              1033EBA4
MD5:                A10071FA78554B57538D0B459E00D224