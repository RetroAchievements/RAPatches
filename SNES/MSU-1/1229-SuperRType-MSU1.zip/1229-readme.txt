Use with:

(No Intro)
Super R-Type (USA).sfc
cfcd1ff3da5309e5021efaa58012058d
8b22c830