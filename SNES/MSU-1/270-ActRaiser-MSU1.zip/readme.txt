Use with:

(No Intro)
File:               ActRaiser (USA).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              EAC3358D
MD5:                635D5D7DD2AAD4768412FBAE4A32FD6E
SHA1:               E8365852CC20178D42C93CD188A7AE9AF45369D7
SHA256:             B8055844825653210D252D29A2229F9A3E7E512004E83940620173C57D8723F0


Music packs: https://www.zeldix.net/t1536p25-actraiser