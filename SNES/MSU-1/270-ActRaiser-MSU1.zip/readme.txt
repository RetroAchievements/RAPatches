Use with:

(No Intro)
ActRaiser (USA).sfc
RA Checksum: 635d5d7dd2aad4768412fbae4a32fd6e
CRC32 Checksum: EAC3358D