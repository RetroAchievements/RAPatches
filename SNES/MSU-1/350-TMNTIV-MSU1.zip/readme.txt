Use with:

(No Intro)
Teenage Mutant Ninja Turtles IV - Turtles in Time (USA).sfc
RA Checksum: 807009d25eb31559974daa3e39eeccd7
CRC32 Checksum: 5940BD99