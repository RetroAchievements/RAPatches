Use with:

(No Intro)
Super Adventure Island (USA).sfc
206e6c5c05ac1a83dde21400325a4a7d
dcd46848