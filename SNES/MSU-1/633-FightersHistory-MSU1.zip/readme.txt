Use with:

(No Intro)
Fighter's History (USA) (Rev 1).sfc
RA Checksum: 4181e243ae146d471dc5c292dce772ac
CRC32 Checksum: 3D17F6EA