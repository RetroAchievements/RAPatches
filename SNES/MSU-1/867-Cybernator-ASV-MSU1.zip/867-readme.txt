Use with: 

(No Intro)
Cybernator (USA).sfc
8376c1bfac08f6fbbf99f26abaee6da0
4DFA05B3

Juusou Kihei Valken (Japan).sfc
9f4f827317f507b0ac4702245f161687
A5F63557