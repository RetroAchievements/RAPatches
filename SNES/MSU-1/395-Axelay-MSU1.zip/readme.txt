Use with:

(No Intro)
Axelay (USA).sfc
RA Checksum: 699bbdffab13c41fa8d4a9b3c25d60e7
CRC32 Checksum: F812B533