Use with:

(No Intro)
Secret of Mana (USA).sfc
RA Checksum: 10a894199a9adc50ff88815fd9853e19
CRC32 Checksum: D0176B24