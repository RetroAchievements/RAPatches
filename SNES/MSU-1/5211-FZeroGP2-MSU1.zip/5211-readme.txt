Use with:

(No Intro)
BS F-Zero Grand Prix 2 - Practice (Japan) (10-23).bs
95338a78fb51efc0ae04edfde8034a26
14756b56

BS F-Zero Grand Prix 2 - Practice (Japan) (12-6).bs
c1008db81315057be63c2901a39eb1fb
57b1c3ed