Use with:

(No Intro)
Wolfchild (USA).sfc
a7541f6554a7fa1aab250039ce24bcd8
13bfb3a0