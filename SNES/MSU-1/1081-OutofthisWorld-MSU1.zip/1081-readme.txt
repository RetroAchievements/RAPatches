Use with:

(No Intro)
Out of This World (USA).sfc
8b8acdec1c2345477ddec5516413c2a1
5f40a869