Use with:

(No Intro)
Illusion of Gaia (USA).sfc
a7c7a76b4d6f6df389bd631757b91b76
1c3848c0