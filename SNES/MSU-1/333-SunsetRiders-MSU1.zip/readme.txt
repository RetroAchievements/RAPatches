Use with:

(No Intro)
Sunset Riders (USA).sfc
RA Checksum: 1e1b47d5e5b0d9faa5447273a52fc6ea
CRC32 Checksum: 52ADA404