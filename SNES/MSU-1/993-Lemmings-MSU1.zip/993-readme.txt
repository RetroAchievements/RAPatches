Use with:

(No Intro)
Lemmings (USA).sfc
283c2e794c1eae82a31dfac608e76222
7f8b51a1