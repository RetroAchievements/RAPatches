Use with:

(No Intro)
Gradius III (USA).sfc
RA Checksum: ea30c4f341f6b7a6e290699460ba6c51
CRC32 Checksum: CD973979