Use with:

(No Intro)
Super Ghouls 'N Ghosts (USA).sfc
19b2d7a555ecef4c453a819e67e61574
6aaba901