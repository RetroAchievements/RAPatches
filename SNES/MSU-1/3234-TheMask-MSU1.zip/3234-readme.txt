Use with:

(No Intro)
Mask, The (USA).sfc
c918a40bb2b3f44f3468d6a1ba0a5f88
e17626e2