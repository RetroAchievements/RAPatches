Use with:

(No Intro)
Super Scope 6 (USA).sfc
a17d52680cc29e46ce41da360e8febe3
b141ea99