Use with:

(No Intro)
Darius Twin (USA).sfc
0e7c6781a6ae15d36a5885a03c132898
c5341764