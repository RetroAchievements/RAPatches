Use with:

(No Intro)
Ys IV - Mask of the Sun (Japan).sfc
a4e5ed2dbd1e3612917b91ab58e6feea
ca7b4db9