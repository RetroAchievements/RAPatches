Use with:

(No Intro)
Terranigma (Europe).sfc 
RA Checksum: d202156549f981f6dafc759575dd6e67
CRC32 Checksum: 974523FF