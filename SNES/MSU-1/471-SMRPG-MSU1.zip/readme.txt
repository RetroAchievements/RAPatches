Use with:

(No Intro)
Super Mario RPG - Legend of the Seven Stars (USA).sfc
RA Checksum: d0b68d68d9efc0558242f5476d1c5b81
CRC32 Checksum: 1B8A0625