Use with:

(No Intro)
E.V.O. - Search for Eden (USA).sfc
2ffd5027d32f0ec5326981ee1be1ca32
dd49911e