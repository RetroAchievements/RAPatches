Use with:

(No Intro)
Ultimate Mortal Kombat 3 (USA).sfc
RA Checksum: 0644da71f79d405a22934daa1474cefc
CRC32 Checksum: F5BFE41E