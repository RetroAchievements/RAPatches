Use with:

(No Intro)
Ninjawarriors (USA).sfc
RA Checksum: a8711c9185c7a6c52b863567b188ce1e
CRC32 Checksum: 7537D8D7