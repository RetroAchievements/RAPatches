Use with:

(No Intro)
File:               Super Mario Kart (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              CD80DB86
MD5:                7F25CE5A283D902694C52FB1152FA61A