Use with:

(No Intro)
Super Double Dragon (USA).sfc
RA Checksum: 38129cf359c7bc93a82358fa305b07ae
CRC32 Checksum: 09ED12A5