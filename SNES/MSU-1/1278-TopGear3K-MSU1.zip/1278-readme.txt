Use with:

(No Intro)
Top Gear 3000 (USA).sfc
23eaa07e3f3315fa43f4b4d94ec97a7b
a20be998