Use with:

(No Intro)
Earthworm Jim 2 (USA).sfc
c3ff5fd4e3f46653fec94ba60d70281d
393de197