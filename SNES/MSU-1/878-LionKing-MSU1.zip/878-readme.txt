Use with:

(No Intro)
Lion King, The (USA).sfc
6a5b2f9bde72f7d72db7dfe9afd0f47a
c8fbfaa8