Use with:

(No Intro)
EarthBound (USA).sfc
RA Checksum: a864b2e5c141d2dec1c4cbed75a42a85
CRC32 Checksum: DC9BB451