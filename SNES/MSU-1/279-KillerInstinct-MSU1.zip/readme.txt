Use with:

(No Intro)
Killer Instinct (USA) (Rev 1).sfc
RA Checksum: c9b698cf98f1aede7a87c1e449384632
CRC32 Checksum: 09E9A04E