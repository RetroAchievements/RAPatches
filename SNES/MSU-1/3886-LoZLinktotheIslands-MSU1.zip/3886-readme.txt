Use with:

Legend of Zelda, The - A Link to the Past (USA).sfc
608c22b8ff930c62dc2de54bcd6eba72
777AAC2F