Use with:

(No Intro)
Mortal Kombat 3 (USA).sfc
ec6fa27bfc201dd0ef0000f4c65fb57a
4E6AF725