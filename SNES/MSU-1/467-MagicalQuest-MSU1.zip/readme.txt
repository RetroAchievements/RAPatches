Use with:

(No Intro)
Magical Quest Starring Mickey Mouse, The (USA).sfc
RA Checksum: 649c377a7479c898b1933962c4badaad
CRC32 Checksum: 10874C70

Magical Quest Starring Mickey Mouse, The (USA) (Rev 1).sfc
RA Checksum: 56f6c071c5b83b60333ddc830273b274
CRC32 Checksum: bb24ece5