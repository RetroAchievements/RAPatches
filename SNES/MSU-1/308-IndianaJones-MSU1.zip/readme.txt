Use with:

(No Intro)
Indiana Jones' Greatest Adventures (USA).sfc
RA Checksum: 77c5cb84c9768756c13fa8f956bfb11e
CRC32 Checksum: 70DA6BB8