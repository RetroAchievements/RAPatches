Use with:

(No Intro)
Top Gear 2 (USA).sfc
c9fc87528511770db888b28a4c506f46
2b88bee8