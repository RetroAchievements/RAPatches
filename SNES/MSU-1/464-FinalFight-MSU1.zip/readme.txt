Use with:

(No Intro)
Final Fight (USA).sfc
RA Checksum: f638224ce95e2101c2948edf7569ac73
CRC32 Checksum: 4CAB21DB