Use with:

(No Intro)
Street Fighter Alpha 2 (USA).sfc
RA Checksum: aa3c90fa7d89eb3dc3389a9436bd0cf8
CRC32 Checksum: 9C59DDFF