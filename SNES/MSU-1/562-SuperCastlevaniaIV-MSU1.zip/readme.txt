Use with:

(No Intro)
Super Castlevania IV (USA).sfc
RA Checksum: 094f035993e9724647b61ddcba1e9a7a
CRC32 Checksum: B64FFB12