Use with:

(No Intro)
Super Star Wars - The Empire Strikes Back (USA).sfc
9e9286f8971abe77f34b0fcda8391e8f
f45b15be

Super Star Wars - The Empire Strikes Back (USA) (Rev 1).sfc
61003f39100168a2ace6ff952c72689d
1e7ea62c