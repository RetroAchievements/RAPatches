Use with:

(No Intro)
Top Gear (USA).sfc
RA Checksum: e5040a079ff03eb93747424af9be75f4
CRC32 Checksum: D34C49B7