Use with:

(No Intro)
Spider-Man (USA).sfc
RA Checksum: 73199b27fe52caa56b12e42122df1fc8
CRC32 Checksum: C99E174E