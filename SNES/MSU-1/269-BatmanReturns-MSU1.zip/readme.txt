Use with:

(No Intro)
Batman Returns (USA).sfc
RA Checksum: 5ef8e1f3e88c86f149838c569a0c0328
CRC32 Checksum: E87DFDF6