Use with:

(No Intro)
Pilotwings (USA).sfc
RA Checksum: 8dcb216beed58c798b25df55f62218d0
CRC32 Checksum: 266C44ED