Use with:

(No Intro)
Justice League Task Force (USA).sfc
2078b064bdf300eb656971946c26430f
31cf46d1