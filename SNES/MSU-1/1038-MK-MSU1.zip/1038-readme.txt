Use with:

(No Intro)
Mortal Kombat (USA).sfc
0934878bb5ef33f25c1fcaba18a1105b
def42945

Mortal Kombat (USA) (Rev 1).sfc
3ca4ba9c14827abfa0d047151bc86634
7ca113c9