Use with:

(No Intro)
Hook (USA).sfc
1a0a3a079db7a848ee019161cbdb1788
0c572ef0