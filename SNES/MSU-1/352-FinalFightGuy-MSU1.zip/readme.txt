Use with:

(No Intro)
Final Fight Guy (USA).sfc
RA Checksum: 067ad2453b32cb6fe595fc822b780700
CRC32 Checksum: BC1AE3C2