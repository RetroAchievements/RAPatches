Use with:

(No Intro)
Wing Commander (USA).sfc
19c9a9f9e6835bd2879d8c9bad3830ad
65ad4f8d