Use with:

(No Intro)
Prince of Persia (USA).sfc
8ffc8d34bc75bc049122894b4292eb85
891bb2bb