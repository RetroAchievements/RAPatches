Use with:

(No Intro)
File:               New Super Mario Land (World) (v1.5) (Aftermarket) (Homebrew).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              2B50F2AF
MD5:                37AC79B4BF8148BF1B80C36CC8C5F853