Use with:

(No Intro)
Rendering Ranger R2 (Japan) (En).sfc
057f03c63b9cdb4b1e7dd340982f2640
8fb5ac86