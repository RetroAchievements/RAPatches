Use with:

(No Intro)
Chrono Trigger (USA).sfc
RA Checksum: a2bc447961e52fd2227baed164f729dc
CRC32 Checksum: 2D206BF7