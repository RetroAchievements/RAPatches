Use with:

(No Intro)
Final Fantasy V (Japan).sfc
d69b2115e17d1cf2cb3590d3f75febb9
c1bc267d