Use with:

(No Intro)
Wild Guns (USA).sfc
RA Checksum: 94d30063d9b17567d32079e766251569
CRC32 Checksum: 085D8D14