Use with:

(No Intro)
Fatal Fury (USA).sfc
44a0e420744a8c77a0832d079dd25476
c67257d0