Use with:

(No Intro)
ActRaiser 2 (USA).sfc
32cfe65f6dd6e4b58839729a3b1dbd60
4901f718