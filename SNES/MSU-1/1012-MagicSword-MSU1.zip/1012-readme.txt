Use with:

(No Intro)
Magic Sword (USA).sfc
ad7349eb7afd3d809161ee70bd2c361d
27325e4d