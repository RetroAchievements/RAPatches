Use with:

(No Intro)
Tetris & Dr. Mario (USA).sfc
73cf4163c3c2b3f8a38775a5d132c448
6c852ef3