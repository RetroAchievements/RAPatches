Use with:

(No Intro)
Super Mario Kart (USA).sfc 
RA Checksum: 7f25ce5a283d902694c52fb1152fa61a
CRC32 Checksum: CD80DB86