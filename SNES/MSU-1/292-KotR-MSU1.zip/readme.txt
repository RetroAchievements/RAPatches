Use with:

(No Intro)
Knights of the Round (USA).sfc
RA Checksum: e2c47c0754f874b2b16d5f06be3dbe34
CRC32 Checksum: AAA82126