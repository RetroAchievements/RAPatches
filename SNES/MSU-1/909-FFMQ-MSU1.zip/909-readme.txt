Use with:

(No Intro)
Final Fantasy - Mystic Quest (USA).sfc
da08f0559fade06f37d5fdf1b6a6d92e
6B19A2C6

Final Fantasy - Mystic Quest (USA) (Rev 1).sfc
f7faeae5a847c098d677070920769ca2
2C52C792