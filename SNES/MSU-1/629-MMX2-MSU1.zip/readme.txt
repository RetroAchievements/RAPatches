Use with:

(No Intro)
Mega Man X2 (USA).sfc
RA Checksum: 67905b989b00046db06df3434ed79f04
CRC32 Checksum: 947B0355