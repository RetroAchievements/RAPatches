Use with:

(No Intro)
Final Fantasy III (USA) (Rev 1).sfc
RA Checksum: 544311e104805e926083acf29ec664da
CRC32 Checksum: C0FA0464

Final Fantasy III (USA).sfc
RA Checksum: e986575b98300f721ce27c180264d890
CRC32 Checksum: A27F1C7A