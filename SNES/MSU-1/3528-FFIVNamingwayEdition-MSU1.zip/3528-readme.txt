Use with:

(No Intro)
Final Fantasy IV (Japan).sfc
5cdc56ba9f5f23e412af09f11ed47f83
21027C5D

Final Fantasy IV (Japan) (Rev 1).sfc
a2959ad8c1ff5f2719264ab4c7e40464
CAA15E97