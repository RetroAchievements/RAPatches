Use with:

(No Intro)
Joe & Mac (USA).sfc
cc902de2efa54df4d2c27acd7f4a6bf4
3a2b6167