Use with:

(No Intro)
Hagane - The Final Conflict (USA).sfc
RA Checksum: 44cb6bbbb233bc5d602d54fd418232f1
CRC32 Checksum: 8E0A7034