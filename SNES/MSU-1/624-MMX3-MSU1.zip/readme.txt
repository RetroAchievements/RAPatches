Use with:

(No Intro)
Mega Man X3 (USA).sfc
RA Checksum: cfe8c11f0dce19e4fa5f3fd75775e47c
CRC32 Checksum: FA0FE671