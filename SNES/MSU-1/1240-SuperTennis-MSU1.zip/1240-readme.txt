Use with:

(No Intro)
Super Tennis (USA).sfc
17accf8a0b3d514561cadbdb03715a71
8d383776