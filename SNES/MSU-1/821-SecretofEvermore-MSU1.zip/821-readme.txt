Use with:

(No Intro)
Secret of Evermore (USA).sfc
6e9c94511d04fac6e0a1e582c170be3a
a5c0045e