Use with:

(No Intro)
Aladdin (USA).sfc
RA Checksum: 8e00910312b30663768d907114d301c2
CRC32 Checksum: 124D8E4D