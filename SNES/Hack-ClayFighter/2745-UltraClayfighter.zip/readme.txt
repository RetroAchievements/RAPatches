Use with:

(No Intro)
File:               Clay Fighter - Tournament Edition (USA).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              B360F7AF
MD5:                A6637CCB145E42BBCE94FBCE3A1BB5E7
SHA1:               A7D9A90F792C90D3D51F62DB6279E9533DAB5CA8
SHA256:             EA52B39A8E1EA15BFAD6B92883C9A5FE744CECD7C0E175AA3BD40280CF7A966E