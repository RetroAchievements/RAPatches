Use with:

Kirby Bowl (Japan).sfc	(No-Intro)
b14696cdc0569a05647f2a3f2756ac07
2A24FC9B