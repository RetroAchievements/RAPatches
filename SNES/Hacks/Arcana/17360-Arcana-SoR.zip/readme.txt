Use with:

(No Intro)
Arcana (USA).sfc
MD5: cefe028852135a1695ed9f6e692bc0ca
CRC: C891B297