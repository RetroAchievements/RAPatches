Note regarding the final level:
	There were some vram issues that I wasn't able to fix using code, but instead I cleared out FG2. This means that instead of 
the screen being covered in visible layer 2 garbage, it gets covered by clear garbage. This garbage still can cover up actual layer 2
tiles, though. Sorry.

Worthless Paragraph:
	This started as a project where I was supposed to feel free to make "Anything" - such was the title 
of the folder that housed it - free from pressures of being original or particularly impressive. Naturally, I didn't do that, 
and now we have a hack that steals a lot of ideas from a lot of people, and tries to be novel and polished but fails.
While I hate how much work I had to put into it, I'm still somewhat proud of it. I hope you get a bit of joy out of playing.

Some thanks:
	Thanks to RBPimlico and MiracleWater (and Sixcorby a bit) for the testing and feedback.
	Thanks to medic for helping me "fix" the final level. 
	Thanks to Wyatt, Sixcorby, gbreeze, and Koopster for overworld advice.
	Thanks to my friends on JUMP Team and Team JANK for being cool and supportive and for making the past couple years suck a bit less.
	Thanks to idol for the suggestion to make the title be emojis.

	Dedicated to lazy. I hope you enjoy this little "jump team fanfiction".

If this marks my retirement from solo hacking, as it might, I'd like to extend my thanks to the community for being such a cool space to 
play and create.

Thanks for playing (and reading).
