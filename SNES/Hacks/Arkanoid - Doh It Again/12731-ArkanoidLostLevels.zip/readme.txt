Use with:

Arkanoid - Doh It Again (USA).sfc	(No-Intro)
03d30ca9aaa89738640cf14532ddfe6c
B50503A0