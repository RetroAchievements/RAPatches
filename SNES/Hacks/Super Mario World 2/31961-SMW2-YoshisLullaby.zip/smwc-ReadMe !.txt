THANK YOU FOR DOWNLOADING YOSHI'S LULLABY !!
Current version is 1.2
Current language is english

=========================
|	SUMMARY		|
=========================

1. Introduction

2. How to play it ?

3. Credits

4. Programs and patches used

5. Legal notice

=================================
|	1. INTRODUCTION		|
=================================

Started in end 2018, Yoshi's Lullaby is YoshiVert99's hack of 
Super Mario World 2, released on SNES. Discover 54 new levels
through sublime landscapes and cool challenges to collect all 
the red coins and flowers!

=========================================
|	2. HOW TO PLAY IT ?		|
=========================================

1) Find, in a legal way, a US 1.0 ROM of SMW2. Other versions are
not tested, so don't use them.

2) Download Floating IPS (FLIPS).

3) Open FLIPS and select APPLY PATCH.

4) Select YOSHI'S LULLABY.bps, then select your original ROM.

5) Save your new patched ROM.

6) Launch you ROM with ZSNES, or other SNES emulator (the game was fully tested with ZSNES)

7) Enjoy !

=================================
|	3. CREDITS		|
=================================

YoshiVert99			Level editing, GFX editing, testing
Tonberry2K			Sprites ripping (used for custom icons)
Unknown Pinterest user		2-5 custom icon
Baklavagossip5			6-7 custom icon
Yoshis Fan			Sprites database
ShinyNinetalesTM		Golden Egg's BG3 Wiki
SMWCentral community		Useful help and programs
Racknae				Its precious help
My Yoshi friends		Testing

=================================================
|	4. Programs and patches used		|
=================================================

Golden Egg 		Romi
Ycompress 		FuSoYa
YI Entrance Editor	Romi
Asar			Alcaro
Floating IPS 		Alcaro
YY-CHR			YY
YIPES			Kipernal
HxD			Maël Hörz
HeAdder			Yoshis Fan
Better Middle Rings	Raidenthequick
Yoshi Colors Choice	Raidenthequick
LevelTool 	 	Jimmy

=================================
|	5. Legal notice		|
=================================

Super Mario World 2 : Yoshi's Island is owned by Nintendo.
This game is just a hack made by a fan, so please do not
share ROMs of this hack and don't say it was made by you.
Only the PATCH file can be shared legally.