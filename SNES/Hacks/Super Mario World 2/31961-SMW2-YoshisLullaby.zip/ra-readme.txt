Use with:

(No Intro)
File:               Super Mario World 2 - Yoshi_s Island (USA).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D138F224
MD5:                CB472164C5A71CCD3739963390EC6A50
SHA1:               C807F2856F44FB84326FAC5B462340DCDD0471F8
SHA256:             9B4957466798BBDB5B43A450BBB60B2591AE81D95B891430F62D53CA62E8BC7B