Use with:

(No Intro)
File:               Super Mario RPG - Legend of the Seven Stars (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              1B8A0625
MD5:                D0B68D68D9EFC0558242F5476D1C5B81
SHA1:               A4F7539054C359FE3F360B0E6B72E394439FE9DF
SHA256:             740646F3535BFB365CA44E70D46AB433467B142BD84010393070BD0B141AF853