Use with:

(No Intro)
File:               Fire Emblem - Seisen no Keifu (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              DC0D8CF9
MD5:                D044F97BE5FC00BD5E02C935F7E88058
SHA1:               90F0BDEAF0151899F96281258FCB30899FBD0D44
SHA256:             9D8D0AAB728B90DDEEE6DA8DBAFADD89FCEB7C00B0EB432255B427A679F41AAB