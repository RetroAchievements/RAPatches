Use with:

(No Intro)
File:               Fire Emblem - Thracia 776 (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194816 (Headered)
CRC32:              95E289DD