﻿◆ FF5_nostalgia ver.1.04
-------------------------

Use the power of the crystal to temporarily transform into the likeness of a legendary warrior associated with each job.

Change jobs to use nostalgic characters from previous games.

Each job is assigned characters from the feature phone (garakei) versions of FF Legends and FF4TA,
FF3 jobs, FF4 main characters, FF6 main and supporting characters, FFRK and Romancing SaGa 1 main and supporting characters, and scrapped characters.

*Commercial use is prohibited. Please use in accordance with other conventions in the modding community.

◆ Patch Target
-------------

SNES version of unmodified FF5 ROM file without header

◆ Disclaimer
-------

We are not responsible for any damages caused by the use of this patch.

◆ Patch Contents
-------------

A parallel-world FF5 with homages to other games, similar to FFLegends.
This is a somewhat forced what-if story set 30 years in the future.

Changes have been made to the story, job characters, jobs, BGM, weapons, shop items, bosses,
and balance.
A new class, the Ancient Martial Artist, has been added that specializes in attack and can use a variety of weapons, and the Monk has been abolished.
The Beastmaster has been abolished, and some of its abilities have been integrated into the Blue Mage.

*The Wind Crystal display message remains the same as for Monk.

In version 1.04, the world will enter a twilight state after Exdeath obtains the power of nothingness in the Third World.
The palette is based on the feature phone version of FFLegends, with some parts conforming to the smartphone version. There are discrepancies in the surface colors of fields and towns,
but we intentionally avoided unifying the colors out of respect for the FFL language.
Some maps (castles, mountains, forests, etc.) do not support twilight. Thank you for your understanding.

*Due to changes to the events in World 1, the story flag management differs from the original.

You cannot directly use save data from the original. m(_ _)m

Inu's "Strong New Game" patch has been incorporated.

If you want to use data from the original, please load the srm file via "Strong New Game" (press L or R once on the loading screen to display the + symbol, then load).

This will allow you to carry over your items, magic, jobs, abilities, and gil.

◆ Game Features
---------------

- ​​Transform into nostalgic characters from previous games, primarily FFL, by changing jobs.

While most characters have some connection to jobs, there are some characters that have been forced into the game.

- Other changes are summarized in Q_and_A.htm and diff.htm (contains spoilers), so please check them regularly.

◆ Built-in patch (FF5_nostalgia.ips)
------------------------------------

・The following patch by Inu

ff5_core-1.7.ips (FF5 system-wide optimization and bug fixes)
ff5_auto_jump.ips
ff5_berserk_command.ips (Berserker automatically uses abilities)
ff5_berserk_jump.ips
ff5_check.ips
ff5_chemist_ending.ips
ff5_field_dash.ips (B-dash in the field)
ff5_item_delay.ips
ff5_lr_men u.ips (Use L/R to switch between members in the menu and move between item pages)
ff5_lv5_death.ips
ff5_ngplus.ips (Press L or R to display + and load data → New Game+)
ff5_optimize.ips (Excludes certain weapons when at maximum strength)
ff5_sortplus.ips (Sort Improvements)
ff5_specialty.ips
ff5_swdslap.ips (When equipped with a sword, the additional paralysis caused by Mineuchi correctly activates)
ff5_two_handed.ips (Allows two-handed use of dagger-type weapons)

*ff5_atb_switch.ips (Switching action order with the X button) is intentionally left out.

Please use it yourself.

・The following patches by Min

FF5 Internal Damage Change Patch ver. 1.0.ips
FF5 Music Expansion ver. 1.6.ips

・The following patches by Leet Sketcher

FF5-GalufGaffe-N.ips

・The following patches I made myself

ff5+offering.ips
ff5+3stars.ips
ff5+ultima.ips
ff5+omit_rename.ips
ff5+add_music_r.ips
ff5+set_bgm.ips
ff5+FL_all.ips
ff5+Galuf_mimic.ips
ff5+gate_keeper.ips
ff5+sage_staff_magic_ex.ips
ff5+stand.ips
ff5+kanji.ips
ff5+int_abilities.ips
ff5+scan_always_success.ips
ff5+21jobs.ips

◆ Reference Patch
------------

Anonymous's patch below

FF5: Soredemo Tatakau Patch

I deciphered part of the Soredemo Tatakau patch and used it as a reference for introducing "Kaiden no Kakashi." Since I have no knowledge of assembler, I deciphered it by trial and error, relying on Shingo Endo's analysis and the 65816 mnemonic table.

Due to the command setting process, the Soredemo Tatakau patch cannot be used in conjunction with this.

Apologies to the author m(_ _)m. I learned a lot!

◆ Bugs/Issues
-------------------

・Emulator Compatibility
I tested the game from start to finish multiple times on SNESGT.

I only played parts of the game on other emulators, so unknown bugs may occur.

Therefore, I recommend SNESGT.

・Wyvern Grass
During testing, there was an instance where the Wyvern Grass would revive immediately after being defeated and enter into a conversation between Gilgamesh and Enkido. I suspect an overflow probably occurred when an ally's attack interrupted the Hiryuu Grass's action a split second too early. Therefore, I was forced to remove all the Hiryuu Flower revival routines.
To avoid bugs, Hiryuu Flower is now finished once defeated.

- Three Stars
All abilities consume 1 MP, but Phoenix consumes 2. Based on my current knowledge, I don't know the cause and it's beyond my control, so I've compromised and left it as is.
Please understand that this is a feature of the game.
Goblin Punch normally consumes 0, but it consumes 1. This is due to the convenience of Three Stars, so I intentionally omitted the process to set it to 0.
I tried it out using a binary editor and was satisfied if the results were close to what I intended. Sorry for the bugs.

- Faris's Samurai (Jinnai) job graphics
The graphics are drawn with a one-armed character, which makes the animation look distorted, but I'm leaving it as is. Thank you for your understanding.

- Sky color during the ending scene where the power of nothingness is used

The sky color palette acquisition is not branched, so it remains a sunset.

This is easily fixable, but we are leaving it as is.

Please understand that this is a feature issue.

◆ Remaining Issues
-----------

- ​​Regarding additional events and dungeons ← Progress!

Min's FF5 Map & Event Expansion ver1.24.ips is currently unavailable, effectively preventing us from expanding the maps and events.

This patch is extremely attractive, allowing us to add kanji, maps, map chips, events, and dialogue. It has also been discovered that it includes a random treasure chest function.

I do not have the advanced knowledge or skills to create a similar patch.

This patch is currently unavailable, so it has become a lost technology.

We have only successfully restored the kanji and map palette expansions, but crucial aspects such as maps, events, random treasure chests, and SRAM expansions have been stalled due to a lack of analysis, and have been stalled for a long time.

・Introducing effects from other works ← Slight progress!

Although we managed to understand the specifications for FF5's effects program, the design is completely different from FF6's. The original game was already full of data, and the structure proved difficult to expand.

There is a way to do this, but since it would require a considerable amount of work,

we are currently putting research and development on hold. Previous materials have been republished in a separate ZIP file, so please refer to that if you're interested.

◆ Various Files
---------------

・FF5_nostalgia.ips

This is a patch containing all the modifications.

Includes various patches from Inu.

・diff.htm, Q_and_A.htm

Information on changes, etc. Many spoilers, so please review voluntarily.

◆ Acknowledgments
-------

Thanks to the various patch creators, those who shared analysis information, and
those who created various tools, my long-awaited FF5 modding has become a reality.

Thank you very much.

◆ Character List
-------------------

・Romancing SaGa 1

Jamil: City thief... Bartz the Thief
Galahad: Mercenary... Galuf the Blue Mage
Miriam: Fire mage... Rena the Black Mage
Red Mage: Monster of the Frozen Lake... Rena the Red Mage
Death: Lord of the Underworld. Saluin's brother... Faris the Pharmacist
Saluin: Final boss evil god... Bartz the Impersonator (Obsidian's Impersonator Monkey)
Shelah: Saluin's sister... Rena the Pharmacist
Female Warrior: Female warrior who never appeared (unplayed character)... Rena the Knight
Male Priest: Male priest found in various temples (unplayed character)... Bartz the Blue Mage, Faris the Red Mage
Priestess: Female priest (unplayed character)... Faris the White Mage
Mysterious Man: Mysterious unplayed character. There's a theory that he's Mirza... Bartz the Bard

*ROM extracted image is almost exactly as is. For the color palette of scrapped characters, see Toranosu.

- FF3

Onion Knight: Bartz, Galuf, Faris, Kururu Knight
Lena: Samurai
Kururu: Magic Swordsman
Hunter: Bartz, Kururu: Hunter
Illusionist: Bartz, Kururu: Summoner
Ninja (Modified): Lena, Kururu: Ninja
Sage: Bartz: Time Mage, Lena: Geomancer, Faris: Summoner, Kururu: White Mage

※Modified to look like an SFC game by hand while looking at the original NES pixel art.

- FF4

Rydia (Childhood) Kurul Black Mage
Terra: Galuf Time Mage
Cid: Galuf Apothecary
Gilbert: Galuf Bard
Porom: Kurul Red Mage

*ROM extracted image is almost the same

・FF6

Tina: Lena Summoner
Shadow: Galuf, Kurul Samurai
Mog: Faris Dancer
Banaan: Galuf White Mage
Ghost: Faris Time Mage
Gastra: Galuf Summoner
General Leo: Bartz Old Martial Artist (Monk)
Imperial Soldier: Galuf, Faris Thief

*Tina only has been modified from FF TRIBUTE ~THANKS~. Other minor modifications include making the ROM extracted images single-legged.

・FF4TA
Cain: Faris, Kurul, Dragoon

・FF Legends

Dusk: Warrior of Light...Bartz, Feng Shui Master
Sera: Warrior of Light...Lena, Time Mage
Nacht: Warrior of Darkness...Galuf, Magic Swordsman
Diana: Warrior of Darkness...Lena, Faris, Bard
Alba: Warrior of Darkness...Lena, Faris, Blue Mage
Frey: Ranger Chapter Helper...Galuf, Hunter
Barbara: Dragoon Chapter Helper...Lena, Dragon Knight
Send feedback
Use the arrows to see the full translation.
Translation results available 
