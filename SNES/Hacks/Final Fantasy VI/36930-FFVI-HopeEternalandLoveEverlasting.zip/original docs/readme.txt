FINAL FANTASY VI: HOPE ETERNAL AND LOVE EVERLASTING		version 1.0		30 Sept 2025
---------------------------------------------------------------------------------------------------------------------------------------------------------------
A PERSONAL INTRODUCTION
Final Fantasy VI: Hope Eternal and Love Everlasting is a labor of love, that began nearly fifteen years ago with the
ROM hack known as Final Fantasy VI: Once Again, an early effort at a Final Fantasy VI rom hack. It was my very
first project, and for many years my only completed one. It didn't take long after completion of that, that I realized I
was deeply unsatisfied with the work I put out, so I tweaked it, and tweaked it, and tweaked it until I realized that this
was no mere "version 1.1" of Once Again I was working on – it was something else; something much, much bigger.
It kept getting more and more ambitious, as I considered what I could do, and what I should do, until very recently,
when I realized that whatever I had been making all these years,I had completed it. And though I could tweak it and
tweak it and tweak it, forever, it was time to let it go.

And so, I give you Final Fantasy VI: Hope Eternal and Love Everlasting, or HeaLE. 

---------------------------------------------------------------------------------------------------------------------------------------------------------------
Please apply the included .ips file to the following ROM: 

Final Fantasy III (U) (V1.0) [!].smc
---------------------------------------------------------------------------------------------------------------------------------------------------------------

If you've downloaded this via ROMhacking.net, you've probably already read my spiel about what this project is about.
Nevertheless, here's what to expect:

 - Challenge! This hack is nowhere near as easy as the original. It starts off leisurely enough, but gently nudges you
further and further until the end, where you'll be expected to stay on your toes even in lesser battles, and in more
difficult battles to adapt and utilize new strategies. 

 - Refurbished enemies! Every enemy is changed in some way - some are even transformed
entirely - and don't take it easy on you. Most have even been relocated, and thus new battle formations abound. You
never quite know who you're going to run into.

 - Character re-balance! Characters stats and abilities have been rebalanced in such a way to greater 
emphasize their existent skillsets. Every character in the game can be expected to be never less useful than before,
and in fact most are now far more useful. Even Gau and Umaro might bring enough to the table to tempt you and invest
in them!

 - Revamped items, weapons, armor and relics! Every item in the game has been tweaked or changed, sometimes
radically, even replaced entirely, with lots of new abilities to be found. Every item has some use to it, and some are
simply weird, and fun to play around with. 

 - Revamped magic system! The 54 magic spells learned from Espers have been drastically changed, and are now
re-ordered as Black, White and Time magic, with 18 spells each, inspired by its immediate predecessor. 

 - A feast for the eyes! Drawing inspiration from Final Fantasy V in particular, Final Fantasy VI: HEaLE has been
completely recolored, with a vivid but atmospheric color palette. A few character sprites have been changed to better
suit the nature of the project.

 - A brand new script! Inspired by Clyde Mandelin/Tomato's epic notes on the translation of the game, and by Ted
Woolsey's original SNES script, the game was re-written in order to give longtime players yet another new experience.
Humor and warmth are stressed, but also the richness of the character drama.  Both large and small fonts have also been
changed, reminiscent of the fonts used in Final Fantasy VI Advance.

Special thanks to the good folks on FF6Hacking.com, without whose help and effort this project would have never
made it this far. Also to Tomato/Clyde Mandelin, whose notes for the translation of the original game I am indebted
to. Also a special thanks to DeviantArt user P0C0L0C0, whose "caped Cyan" sprite was a major inspiration on the
sprite work I did for the character. Thanks to Casual Tom for pointing out various script errors (Oct 2025)

And, of course, a super special thanks to my pal Val, co-author of the new script, and without whose advice,
support and overall encouragement this project would likely never have been completed.

A few patches were used in the creation of this project, which merit mention and credit. Due to the chaotic production
of the project (many of my original notes were lost between disasters, and the project today survives only due to sharing it
with close friends while work was in progress), I may have missed a few items. If you notice anything that has not been
credited, please let me know.

Patches used in the creation of this project:

Evade / M.Evade bugfix
B Button dash, variant B
True Duel
Restored Ability Names
Overkill 32,000
Sword Tech Ready Stance B variant
Final Fantasy VI Titlescreen Mod

Included in this ZIP file is a mini-guide, meant to fill in any gaps of information (item functions, for instance) and generally
offer tips and tricks so that fans of a 30 year old game don't have to spend another 30 years searching for that one Lore or
rare monster, or wondering why certain things work differently than before.
---------------------------------------------------------------------------------------------------------------------------------------------------------------
VERSION HISTORY
30 Sept, 2025 - Version 1.0 Released
27 Oct, 2025 - Version 1.1 Released (minor but crucial fixes to Vargas and Sophia battle scripts, Sketch Bug fix NOT applied, spelling
and grammatical errors fixed - thanks to Casual Tom!)