Use with:

Final Fantasy III (USA).sfc (no intro)

CRC32:	A27F1C7A
MD5:	E986575B98300F721CE27C180264D890
SHA1:	4F37E4274AC3B2EA1BEDB08AA149D8FC5BB676E7
SHA256:	0F51B4FCA41B7FD509E4B8F9D543151F68EfA5E97B08493E4B2A0C06F5D8D5E2

1)  Acquire game with above hashes
2)  Use tush to add a header to the game file
3)  Patch game file with this patch
4)  Play