Final Fantasy �Y - SPX ver.14.1.ips
This patch requires the free software WinIPS SMB Laboratory http://47.tok2.com/smblabo/

.

Please apply this patch to a ROM of 3,145,728 bytes (= no header).
If applied to a ROM with a header, it will not work properly.

When this patch is applied, the ROM will change from HiROM to ExHiROM.
It will not work with SNEShout.
It cannot be used in conjunction with other patches.

*This patch is a hack patch for the great God patch,
"Final Fantasy 6 Omega Additional Patch Ver18.2".
Since we did not receive direct permission from the creator of the Omega patch, HZ9Cy.3WvI,
if we receive a complaint from him, we will promptly remove it from the uploader.

Main changes
- Dialogue changes
It's a subtle change, so some people may not notice it. However, after the collapse, some parts have been significantly changed.

- Event changes

In line with the dialogue changes mentioned above, some changes have been made to the character's actions.

Mainly, I have tweaked the events after the collapse.

The additional events are not that impressive, but some have been prepared for after the collapse.

- Various parameters of weapons, armor, etc.

Basically, the attacks of allies have been significantly weakened. However, summoning magic and gag-type learned skills (blue magic), which had few opportunities to be active in FF6, have been strengthened.

- Enemy behavior patterns

Enemies, especially bosses, have been strengthened. Since allies have been weakened, it is unlikely that you can defeat them by simply pushing through, but it is probably not so unreasonable that you will get stuck. If you make full use of support magic that you do not normally use, you may be able to clear it quite easily.

- Battle program

For details, please refer to the modification information exchange thread at http://jbbs.livedoor.jp/game/45891/.

Update History

2008/12/30 Uploaded Final Fantasy �Y - SPX ver.1.0 to http://www4.uploader.jp/dl/SPARX/.

2009/01/31 Minor changes to Final Fantasy �Y - SPX ver.1.1. Corrected minor typos.

2009/07/04 Updated to Final Fantasy �Y - SPX ver.2.0. Made major changes to the items listed under "Major Changes". Also, Jeff will not appear unless you recruit Mash. Changed the flag so that you cannot enter the Tower of Rubble unless you recruit anyone other than Shadow and Gogo.

2009/07/30 Minor changes to Final Fantasy �Y - SPX ver.2.1. Gogo's four selectable abilities have been returned to the original three, and the special command, "Imitation," has been reinstated.
However, "Magic," "Blue Magic," and "Summoning" have been changed so that they now consume MP.
Also, "Items" cannot be imitated.
Note: If you have already recruited Gogo,
the above changes will not be reflected in your save data, even if you reapply the patch. We apologize for the inconvenience, but
please use cheat codes to make the changes.

09/22/2009 Updated to Final Fantasy �Y - SPX ver.3.0.
The overall difficulty has been lowered so that even those at a relatively low level can easily complete the game.
�E Parameter changes
�� "Flame Shield" and "Ice Shield" can now be equipped by all characters other than Gau and Gogo, rather than being equipment exclusive to Edgar and Kaien.
��It has been made possible to learn "Reraise" from magic stones, which is a magic spell exclusive to Tina, Gau, and Gogo. 
��Tina has been changed so that she will learn several powerful spells between levels 40-60. 
��The power of Kaien's deadly sword "Fierce" has been slightly weakened. 
��Relm's "Sketch" and "Manipulate" and Gau's "Abareru" have been significantly revised. 
In particular, with regard to Gau's "Abareru", moves that were too powerful have been changed to a different move. etc.
�E Changes to battle program
��The guaranteed hit and unconditional pierce Reflect specifications for magic activated by various rods and the "Wind-Cutting Blade" have been removed. 
��The damage inflicted by "Ultimate Weapon" has been changed to approximately current HP x 0.75.
�� Changed the damage dealt by "Valiant Knife" to approximately (Max HP - Current HP) x 0.75.
�� Changed the specifications of "Stardust Rod" from physical damage followed by single-target meteor shower to 50% physical damage and 50% all-target meteor shower.
�� "Throw" can no longer be "Mimetic".
- Fixed an issue where the line breaks would go awry and the text would be displayed strangely when the character's name was changed to a longer name.

12/28/2009 Updated to Final Fantasy �Y - SPX ver.4.0.

The highlight of this release is the addition of a boss. When adding the boss, we tinkered around with flag manipulation, event offsets, and other things, so unexpected bugs may occur.
If you find any bugs, please report them to the SPARX patch question thread at http://jbbs.livedoor.jp/game/45891/.
<Major changes>
�E Boss monsters added
�� "Leviathan" added
Information can be obtained from an old woman in the port town of Nicea.
�� "Jabotender" added
Information can be obtained from bandits in the town of Maranda.
�� Serious battle with "Gilgamesh"
He's in the Coliseum.
* Due to flag manipulation, "Gilgamesh" will not appear in save data if you have completed the post-collapse Zen event
before applying this patch.
In the above situation, "Gilgamesh" will appear if you change RAM address 7E1F2B, 0x23 to 0x27. �� "Siegfried" returns.

Can now be fought in the Coliseum.

- Various parameter changes

�� Fixed a bug that caused additional items to be treated as "machines".

�� Some changes have been made to the items available in the Coliseum, with a focus on additional items.

�� Fixed a bug that caused the boss monster "Flame Eater"

to appear in Beast Plains.

�� Improved the accuracy of "Soul Saber".

�� Some changes to character stats.

�� Banan may be a little stronger...

�� The special skill effects for the additional monsters were not set, so they have been changed to those in the GBA version.

�� Quick has been abolished �� has been replaced with a different magic spell.

As a result, Enhanced Holy Dragon has been significantly weakened. etc...

- Event changes

�� Si�� will definitely die.
�� Fixed a bug that caused death by petrification during the battle with Omega to be considered a victory. etc...

�E Changed the battle program

�� Excalipur is the strongest sword with an attack power of 255.

�� Changed the magic activated by the "Stardust Rod" from Meteor (magic) to Meteor (special).

2010/03/22 Updated to Final Fantasy �Y - SPX ver.5.0.

<Major changes>

�E Changed the battle program

�� Snow (his blog address: http://elsnow.blog12.fc2.com/) made some changes to the ATB system modification program and installed it.

Thank you, snow, for your help.

Specifically, the ATB system is now FF5 compliant.

In other words, the ATB bar does not move at all when someone is taking action. This makes speed a much more important parameter.
�� Enhanced haste (ATB bar growth speed: 1.3x �� 1.5x)
Haste has become an important magic in this patch, to the point that having it or not can completely change the game balance.
�� Changes to Weakmaker specifications
Previous specifications (Target is determined randomly, like a Death Roulette.
���@ Instead, it works on everyone.)
Current specifications (You can now select the target, making it more useful.
However, it never works on resistant enemies.)
�� Removed the feature that instantly kills undead with Ex-Potion and Elixir (to be precise,
maximum HP damage, or 9999 damage if it exceeds 9999).
Undead will still heal normally even if you use these items.
�� Interceptor bug (When Shadow is equipped with "Angel Wings",

2010/08/10 Final Fantasy �Y - Updated to SPX ver.6.0.

<Major changes (in no particular order)>

�� Major changes.
�� Fixed a bug where the name of the technique displayed in the upper center during battle was different from the name of the technique displayed in the lower window when used (see SPARX patch creation thread >>150).
�� Fixed a bug where characters other than Shadow would become interceptors.
�� Ported FF5 music (with help from fellow thread member Passerby-san)

0 x 5F Deadly Battle on Big Bridge

0 x 60 Final Battle

0 x 61 Battle 2

0 x 62 Battle 1

�� Changed so that Libra works on most monsters

(See SPARX patch creation thread >>159)

�� Fixed Coliseum bug (when betting additional items, they do not disappear, but unrelated items disappear)

�� A bug occurs when throwing additional weapons, so all additional weapons cannot be thrown

�� Changed specifications so that magic acquisition points are entered even if additional monster parties are defeated (in which case, the magic acquisition point parameter storage address was moved to 33F600)

�� Added weapons equivalent to chicken knives and brave blades

Note) Attack power after change is not displayed on the status screen like in FF5.
Therefore, please judge the current attack power only by the damage value. 
�� Fixed a bug where if Dejonator was used in the battle against Omega, after all players were wiped out, they would return to the field in a combat-incapacitated state.
(See SPARX patch creation dedicated question thread >>168)
�� When attacking with a weak attribute, damage is doubled.
If it is a physical attack, it is physical defense/4, and if it is a magic attack, it is magic defense/2.
�� Slightly shortened the time that the sleep and stop states are maintained. 
�� Regarding the countdown for Death Sentence, if an enemy casts it on an ally, it is fixed to 15. If an ally casts it on an enemy, it is the same as before.
�� Damage when gauntlets are equipped changed from 1.3x to 1.5x.

�� Weakened Hawkeye and Sniper, exclusive to Locke.

See Thread for Sharing Mod Information >>305)

�� Tina's maximum trance time was shortened a little.

�� Weakened Umaro's charge and character throw.

�� When Tina's trance time reaches MAX, she gains magic mastery points after the battle.

No longer displays messages (if there are spells to learn, they will of course be displayed as before.)

�� Fixed save bug (see Thread for SPARX patch questions >>119).

(Thank you to the anonymous users who cooperated.)

�� Siegfried slightly weakened. Is this still too tough?
�� Glow Egg is back
�� Flying attribute added to Omega, Omega Weapon, and Exdeath Soul
(To prevent Quake from self-destructing due to the force field)
�� If you don't mind spoilers, ask a scholar somewhere
for an easy way to defeat Omega

2010/12/25 Updated to Final Fantasy �Y - SPX ver.7.0.

<Major changes (in no particular order)>

�� "Magic Wind (originally called "Magic Wind Blade")" can now be used with any weapon (including existing weapons).

�� Regarding weapons with additional magic such as "Holy Rod",
�@ Even in the back row, the power of the additional magic is not halved (weapon damage is halved)

�A Additional magic is not activated by "jump".

�� Regarding weapons with 1/2 special skills such as "Wind Blade",
�@ Even in the back row, the power of the special skill is not halved (weapon damage is halved)

�� The magic activated by "Stardust Rod" has been changed back from "Meteor (special)" to "Meteor (magic)".
�� Weakened the damage of human power attacks by "Critical" and "Maneater" from 2x to 1.5x.
�� Weakened the damage of flying enemy power attacks by "Hawkeye" and others from 2x to 1.5x.
�� When in "Invisible" state, using "Shadow Sneak" would result in "Invisible" + "Sneak" state.
When using "Shadow Sneak", the "Invisible" state will automatically be cancelled.
�� The attack power displayed in the status is the weapon's attack power + the individual character's unique attack power, but all individual character's unique attack power has been changed to 0.
�� The old woman in Kolingen said, "I hear there's a really strong guy in the Coliseum.
He's apparently aiming for a "Single Strike Blade." " I felt uncomfortable with the factually incorrect line, so I changed it to reflect the line. It's possible to lose even at late level 30. (Even if you lose, the event will proceed as normal, so don't worry.) �� Adjustments to the stats and behavior patterns of some bosses. Generally, they've been strengthened, but bosses that were felt to be too strong have been weakened.

2011/04/03 Updated to Final Fantasy �Y - SPX ver.8.0.

<Major changes (in no particular order)>

�� Tina weakened
MAX trance time: 4/5 of the original �� 2/3 of the original
�� Kaien's special sword, Sky, specification change
Instead of a counter large damage attack, it is now a one-hit kill technique with an attack power of 255 and a hit rate of 44.

Logic: At least two bugs have been confirmed with the special sword, Sky, and in particular, Kappa Rampage is a serious bug. To eliminate that.
�� Relum strengthened
Spec change to "Sketch"
For damage techniques, refer to monster attack power and magic power �� refer to Relum attack power and magic power
I won't go into the detailed formula, but by changing the specification as above, the damage value based on the basic sketch will be greatly improved.
�� Fixed a bug (specific to ver. 7.0) that prevented Stragos from learning "Grand Trine."

Also, the specifications of "Grand Trine" have been changed.

Play the game to see how it has been changed.

�� Leo strengthened

Changes to the specifications of "Shock."

Leo is only a supporting character, but considering that Gau can also be used, he is not entirely useless.

�� Fixed a bug (specific to the modified version) that caused Gogo to be unable to use magic despite having enough MP in the Tower of Fanatics (specific to the modified version).

�� Fixed a bug (specific to ver. 7.0) that caused the enemy to repeatedly use only Fire when fighting the strengthened Holy Dragon.
�� Fixed a display bug (specific to the modified version) that caused the Kaiser Dragon's graphics to be distorted.

�� Fixed a display bug (specific to the modified version) that caused parts of Omega's body to be reflected in the enemy's kappa graphics.

�� Fixed a bug that caused enemies with slip and slow resistance to not enter regeneration or haste states.


2011/06/22 Minor changes to Final Fantasy �Y - SPX ver.8.1.

<Major changes (in no particular order)>

�� Changed the specifications so that an interceptor is attached to Relm if Shadow dies.

�� Changed so that a hint for the explosive fist appears immediately in the fight against Vargas.

�� Items can now be purchased in the latter half of the Demon Train. (So you won't get stuck on the Demon Train?)

�� Hastened the appearance of Rhizopus at Barren Falls.

�� Fixed typos in "fearful gaze" and "paralyzing".

2011/09/24 Minor changes to Final Fantasy �Y - SPX ver.8.2.

<Major changes (in no particular order)>

�� The magic that consumes rods was previously immune to Reflect, but has been changed to Reflect.
�� The guards that appear in the imperial capital of Vector have been changed to Weiss.
(From a point made by >>331 in the SPARX patch creation thread for questions)
�� Weakened Armor Kappa (to prevent Kappa from becoming invincible)
�� Changed MP consumption for Stinky Breath from 37 to 32
�� Changed behavior patterns for Skull Dragon, Skull Dragon (strengthened), and Plague.
(Improved descriptions to make patterns easier to read. However, this does not mean they are easier to defeat.)
�� Made it impossible to put them to sleep with the Sleeping Mask.
�� Changed behavior pattern for Holy Dragon (strengthened).
Even if your party has 3 or fewer people, if all members are near death, the Holy Dragon's behavior will change. (As pointed out by >>354 in the SPARX patch question thread)

2012/02/04 Minor changes to Final Fantasy �Y - SPX ver.8.3.

<Major changes (in no particular order)>

Fixed a bug that caused the power of Dice (Normal) to be extremely weak.

Changed the Interceptor that wanders around Samatha Village alone as an NPC when Shadow dies to a different NPC.

(In this patch, when Shadow dies, Relm is set to carry the Interceptor around with her.)

Resurrected Garkimasera from Omega Patch.

(It likes dark, damp basements.)

Fixed a bug that allowed players to escape during the battle with Ifrit and Shiva.

Fixed a bug in the battle with Flame Eater.

Fixed a bug that caused the game to freeze if a certain action was taken when defeating the three people who appear in the dream.
�� Fixed a bug in the additional dungeon "Shrine of Souls" where the final boss was displayed incorrectly.
�� Changed Exdeath Soul to Exdeath.
�� Fixed a bug in Relm's sketch where some enemy skill names were only displayed as frames and not on the screen.
�� Changed the specifications that caused some bosses to die easily from level 5 death.
�� Added Berserk resistance to Magic Master (to prevent it from becoming a boring vanish game)
�� Fixed a bug where Omega would attack another ally character even though he used targeting.
�� Added a message to make the fight easier, as the specifications for the fight against Deathgaze are significantly different from the original, and there is a possibility that players were confused by the lack of explanation.
�� Strengthened Tonberries (they approach faster.)
�� Changed so that Gogo can also remove the curse from the Hero's Shield.
etc...

2012/05/29 Updated to Final Fantasy �Y - SPX ver.9.0.

<Major changes (in no particular order)>
�� Changed so that, like FF5, effects are not displayed when magic or monster skills are missed. (Some skills will display effects even if they miss, and magic reflected with Reflect will always display effects whether it's a miss or not.)
�� Changed so that the feature that removes abnormal conditions when equipped with a certain abnormal condition resistance accessory (e.g. equipping a star pendant will cure poison) is not removed.
�� Fixed a bug where abnormal conditions would not be removed even if you used a magic spell or item to cure abnormal conditions when equipped with a certain abnormal condition resistance accessory (e.g. holy water cannot cure zombies in Cloudy Heaven if they are equipped with ribbons).
�� Fixed a bug where if a character becomes ineligible while equipped with a certain accessory that inflicts a status abnormality, and then enters the next battle as is, they will become resistant to that status abnormality (e.g. if they die while equipped with Hermes Shoes, enter the next battle while still dead, and are revived, Haste will no longer work on that character).
�� Fixed a bug where if a Magic Seal is activated on a character equipped with certain attribute-absorbing armor,
it will result in MP being stolen instead of MP being absorbed for the attribute magic that is absorbed
(e.g. if the character who used Magic Seal is equipped with Flame Shield and someone casts Fire,
that character's MP will be reduced by the amount of MP consumed by Fire.)
Fixed so that it can be properly absorbed.
�� Changed the effect of the Magic Seal, which stabs the sword towards the ceiling, to something different. (In this patch, it is not called the Magic Sealing Sword, and it can be activated even if the weapon is not equipped.) �� Changed to properly release the permanent trance bug (e.g. when Trans Tina is in a stopped state and the trance gauge reaches 0, the trance will not be released even if the stop is released). However, a new bug occurs where the back command does not disappear only when the trance gauge reaches 0 and the trance is forcibly released. However, this is a bug that does not benefit or hinder the player, so it is left alone. etc...

2013/03/02 Updated to Final Fantasy �Y - SPX ver.10.0.

<Major changes (in no particular order)>
�� Fixed typos.
�� Changed monster behavior patterns.
�E Fixed a bug that caused enemies to become invincible in the Flame Eater battle.
�E Fixed a bug that caused the strongest monster to die before changing form when a certain spell was cast. etc...
�� Bug fixes for additional BGM.
�� Graphic change for Impersonator Gogo (enemy).
�� Bug fix for Tina's permanent trance bug fix program.
�� Various parameter changes
- Two types of blasters (one with and one without instant death resistance).
- Equipped with Circle (ignores instant death resistance & disappears) on Omega. etc...
�� Berserk correction for Dice and Cheating Dice is disabled.
�� Guaranteed hit correction for Cheating Dice is disabled.
�� Changes to Last Resort specifications. (Subtly different, but a super ball that does not disappear even when used.)
etc...

2013/12/07 Updated to Final Fantasy �Y - SPX ver.11.0.

<Major changes (in no particular order)>
�� Fixed typos.
�� Changed monster behavior patterns.
�EFixed the bug that caused enemies to become invincible in the Flame Eater battle mentioned above.etc...
�� Resurrected the feature that "jump" deals double damage when equipped with a spear.
�� Changed the feature that "jump" deals double damage even when equipped with the additional weapon, Gungnir.
�� Moved almost all of the proof items obtained when defeating most of the hidden bosses to the "Important Items" column.
�� Changed the feature that when encountering "Hidden" at character level 70 or above, "Hidden" changes to "Zeromus" during battle.
Once "Hidden" has been defeated, you can encounter "Zeromus" immediately regardless of character level. (Once you defeat "Hidden," you can't encounter him again outside of the Shrine of Souls.)
�� Fixed a bug that caused the state to revert to before the collapse if all players were wiped out by the rats before the battle with "Orthrus" after the collapse. 
�� Weapons equivalent to "Brave Blades" have been renamed to "Blade Blades," and can now be wielded with two hands. 
�� Armor abilities have been tweaked. (Basically all have been strengthened.)
�� "Fake Dice" has been returned to a guaranteed hit. 
�� "Throwing" has been weakened. (As it was too powerful at high levels.)
�E When taking the enemy from behind with a "Side Attack," the double damage has been reduced to 1x damage.
�E The "Bo Shuriken" original to this patch has been removed, and the attack power of "Fuma Shuriken" and "Windmill" has been weakened.
�E Weapons with a higher attack power than "Windmill" generally cannot be thrown. (However, with some exceptions, non-purchasable items can be thrown.)
�� Fixed a bug where if you were hit by "Dejonator" or "Circle" while under the effect of "Reraise", you would become invisible and invincible (uncontrollable),
and keep hitting the enemy until it was defeated. 
�� Added "Wonder Wand". (When attacking an enemy, a random effect from "Fire" to "Blizzard" will be activated.)
�� Weakened "Trance". (Because it was too powerful towards the end of the game)
Weakened the damage from 1.5x to 1.25x. 
�� Changed the attack power description of "Valiant Knife", "Chicken Knife", "Brave Blade", "Last Resort", and "Wonder Wand"
to ??? to be the same as "Ultimate Weapon".
etc...

2014/03/15 Updated to Final Fantasy �Y - SPX ver.12.0.

<Major changes (in no particular order)>
�� Equipment description expansion. Added "MP Critical", "HP Recuperation", "Attack OK", "Attack OK", "Flying Attack",

and "Human Attack", and removed "Magic Fist OK" (Reason: In this patch, Magic Fist = Magic Fist,

and can be activated regardless of whether a weapon is present or not.)
�� The techniques that occur in Gau's "Abareru" are displayed on the "Abareru" status screen. 
�� Ported the FF4 BGM "Battle with Golbez the Four Heavenly Kings". 
We received information about the above modifications from Tsusshi, the creator of FF6T. 
We would like to take this opportunity to thank him. 
�� Rearranged the monster names in Gau's "Abareru" in alphabetical order in Assassin's "Alphabetical Rage patch".
�� Fixed a bug in the previous version where "Abareru" was displayed as "Stray Catoshi". 
�� Fixed a bug where the Variant Knife would cause critical hits. 
�� The attack graphic for the Ultima Weapon was previously only a dagger; it has been reverted to the previous 3-stage change. 
Changed so that when it is �� HP/2 it becomes a long sword, when it is �� HP/4 it becomes a sword, and when it is < HP/4 it becomes a dagger. 
�� On the weapon status screen, the attack power display for "Chicken Knife" and "Brave Blade" was ???,
but has been changed so that the attack power display changes depending on the number of times you have escaped. 
�� Changed so that if you use "Important Items" such as "Grandpa's Salmon" or "Old Clock Screw",
that item will disappear. 
�� The free beds that you can stay in in "Moblis" are no longer available for use. 
�� Added a casting motion to "Blue Magic".
�� The airborne waiting time for "Jump" has been shortened from E0 to A0.
�� "Wild Fang" was previously designed to be ineffective against flying enemies, but this has been reverted to the original version.
(However, its power remains weakened.)
�� "Regenerate" can now be cast on enemies.
etc...

2014/07/28 Updated to Final Fantasy �Y - SPX ver.13.0.

<Major changes (in no particular order)>
�� Added fanfare music from FF4 and FF5.
�� Added background music for "The Final Battle (FF4)".
�� Changed Omega's field graphics to look like FF5. 
The information on the above modifications was provided by Tsusshi, the creator of FF6T.
We would like to take this opportunity to thank him.
�� Fixed a bug that caused the game to freeze when the status menu for "Abareru" was opened and then closed.
�� Fixed a bug that caused the display effect of some weapons to change to "Ultima Weapon."
�� Fixed a bug that caused the game to freeze when winning a battle after opening a certain treasure chest in the Demon Sealing Wall.
�� Manipulated flags so that there were no inconsistencies in some of Gilgamesh's events.
�� Fixed a behavior bug in a certain Relm event.
�� Phoenix Enhancement (All-party Raise)
etc...

2021/11/19 Updated to Final Fantasy �Y - SPX ver.14.0.

<Major changes (in no particular order)>
�� Increased the speed at which the ATB gauge fills by 1.5 times. Realizes speedier battles.

Of course, enemies also attack at high speed, so if you're not used to it, turn down the battle speed.

�� In the original, changes to the battle speed in the configuration only affected enemy characters, but it has been changed so that it also affects allies.

�� Strengthened special swords. Doubled the speed at which the gauge fills. In exchange, the power of some special swords has been weakened.

�� Accessories that increase strength by 50% are back. However, unlike the original, it is now weakened to a 50% increase in bare strength (if a strength-increasing item is equipped, the strength status will increase by that amount), rather than a 50% increase that includes the increase in strength status.

�Z In the original, when attacking a resistant enemy with "Blast Voice" or "Sunbeam,"

nothing was displayed; now a mistake is displayed. 
�Z In the original Omega Patch, when the blue magic spell "Self-Destruct" was used,

the character who used it would disappear; this has been changed so that it now becomes incapacitated. 
�Z The blue magic spell "Fusion" has been changed to the following.
�E The character who used it is incapacitated rather than disappeared.
�E The MP of the character targeted by "Fusion" is numerically restored, but the amount of MP consumed is

more than the MP they had at the time,

fixed a bug where spells still could not be cast.
�E Changed specifications so that a miss occurs if the character who used it and the target match.
�E Reduced the issue where the character who used it was ineligible for Reraise. 
�Z Weaknesses are now given top priority. In the original, absorption took priority over weakness, so

1) When the same attribute has both a weakness and absorption at the same time (occurs when using attribute absorption armor + Abareru or Weakmaker)

2) When there is even one absorption attribute against a multi-attribute attack

Both of these two patterns were absorbed, but with this modification, both of the above patterns

are treated as weaknesses and Gogo will take heavy damage.

�Z In the original, there are two patterns that Gogo cannot select on the status screen:

1) Abilities of characters that he has never recruited (when Gogo joins, the only one that may apply is Mog's "Dance")

2) "Throw" when he has abandoned Shadow

Both patterns have been disabled. In other words, "Dance" and "Throw" can now be used under any conditions.
�Z Fixed a flag bug with "Iron Block" in Kaien's Nightmare "The Magic Train." 
�Z When "Invisible" and "Double Body" were in the original Omega Patch, if a physical attack was performed while equipped with a Sniper Eye, the above statuses

were ignored and the attack was guaranteed to hit (the status change was not removed either), but the specifications have been changed so that if the attack misses, the status change will also be removed. 
�Z In the original, if the person protecting was "Invisible," the attack would no longer protect, but it has been changed so that the attack will now protect. 
�Z In the original, if the person being protected was "Double Body," the attack would protect, but it has been changed so that the attack will no longer protect. 
�Z The special move "Spiral Soul" has been changed to the following specifications.
�E The character who used it is incapacitated rather than destroyed.
�E MP does not reach 0.
�E As with "Chakra," it only removes status abnormalities such as "Darkness," "Poison," "Silence," and "Slip."
�E The level at which it can be learned has been changed to 30.
�Z The special sword "Dragon" has been changed to the following specifications.
�E Now depends on magic defense.
�E The effect value of HP absorption has been changed to 64.
�E The effect value of MP absorption has been changed to 8.
�Z When in "Darkness", physical evasion rate is 0%.
�Z When in "Sleep", "Petrification", "Stop", and "Freeze", physical and magical evasion rates are 0%.
�Z Various parameter changes.
etc...

2023/10/13 Minor changes to Final Fantasy �Y - SPX ver.14.1.

<Major changes (in no particular order)>
�Z Weakened "Panace"; changed to ineffective against petrification.
�Z Changed "Wave Motion Gun" to FF5 specifications.
�Z Fixed bugs in some event flags.
�Z Fixed a bug where, when absorbing a non-elemental magic with the Magic Sealing Sword, a subsequent elemental magic would cause damage to be taken even if the character in the back row was in an attribute absorption state.
�Z If an evasive action using a sword or shield or "Breeze Cloak" was set at the same time as the activation flag for Interceptor Defense was raised,
which one would be activated was decided randomly; this has now been changed to prioritize Interceptor Defense.
�Z When Interceptor Defense is activated while invisible, a zombie, or riding Magic Armor, only a "miss" message was displayed;
this has been fixed so that the Interceptor is now displayed and there is a set chance of an Interceptor counterattack being activated.
�Z Weakened "Jump"; guaranteed hit removed. However, it is guaranteed hit when equipped with "Sniper Eye."
�Z Weakened "Throw"; guaranteed hit removed. Weapon hit rate (basically 100%, with some exceptions) = hit rate of "Throw" (hard to hit enemies with high evasion rates). Guaranteed hit with "Sniper Eye". However, if you are "Invisible" or "Double-body", it will miss.
�Z "Invisible" and "Double-body" states strengthened. Changed so that if you are "Invisible" or "Double-body" physically attacked from behind, you will not be hit.
�Z Part of monster behavior pattern changed.
�Z After obtaining an item added by ROM expansion at the Soul Shrine, if you obtain an item other than the additional item in consecutive battles, there is a bug where the additional item acquisition flag has not been cleared and a normal item becomes an additional item. (Naturally, if you obtain an unregistered additional item, a bug will be displayed.) Since the additional item acquisition flag could not be found, the monster appearance pattern was changed and the possibility of the above bug occurring was reduced to 0.
etc...