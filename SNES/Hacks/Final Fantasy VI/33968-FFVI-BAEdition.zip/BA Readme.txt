
*This is a hack ROM for Final Fantasy 6. The main content is balance adjustments.
FF6 has a lot of magic and items that are too powerful, so we've been adjusting their performance.

We have also strengthened some bosses.

*I also refer to overseas websites and FF6-G websites for my research.

*Please apply the patch to ROMs whose headers have been deleted. Otherwise, bugs will occur.

--------------------------------------------------------------

Update content
*This patch is intended for people who want to play FF6 normally, develop their characters, and complete the game in a normal way.
　Please be aware that this patch was not originally designed for low-level players.
　I haven't even played at a low level yet.

*Please note that unexpected bugs may occur depending on the emulator environment and type.

"★" indicates major changes in this update.

★Magic and item related


* Minor monsters
- Overall adjustments


*Boss Relationship
- Adjusted most of the boss monsters before the collapse
- Adjusted most of the boss monsters after the collapse
-Created additional monsters. See separate file.
- Added a setting to allow enemy image data to be shared between normal and additional expansion addresses
+
Fixed some combat messages
+
*Fixed a bug in the Lost Number battle where arms would respawn after the core was destroyed
+
★Adjusted the final battle with Kefka

--------------------------------------------------------------

◎Other
: The evasion rate bug has also been fixed.

: ★Removes the recovery and damage cap for drain attacks (can still deal damage even when HP is full).

:★Added a maximum HP dependent type to percentage damage techniques.

: ★The halving of reflected damage caused by Reflect has been removed. The effect duration is now roughly doubled.

: ★Defense-ignoring damage can now also be reduced with Protect and Shell.

: ★A new "Boss Flag" has been added to the monster's flags. When this flag is set on a monster, it will have the following characteristics:
　- Undead monsters will not die even if you use Raise or Holy Water on them.
　● Nullify percentage damage techniques
　● Nullifies some special effects (Seduction, Mealstorm, Love's Country, Dijon, Mysterious Sound Wave, Nullifies status prevention)
　●Does not slip or freeze

*Fixed a bug where enemies would drop items like variant knives when changing parties.

: All bonuses from magic stone equipment have been removed. The magic spells learned by some phantom beasts have been changed.

: Accordingly, the initial ability scores of each character have been adjusted.

: ★Some changes were made to the monster techniques that can be used in Abareru.

: Slightly reduces the overall EXP gained by monsters after the collapse, and reduces the MP increase when leveling up.

: Throw damage is increased from 2x to 1.5x

: ★When Kaien learns all the special sword techniques, the charge time for the special sword will be reduced.

: ★Tina's magic damage multiplier in Trance has been changed to 1.5x.

:★Shadow Interceptor's defense chance changed to 25%.

: Mogu's dance is now modeled after the terrain in FF5.

：★You can jump consecutively up to 3 times. The third jump has a 1/8 chance of occurring.

Zenithage's damage doesn't get distributed (it's still a bit weak though)

: The story continues even if Leo loses against Kefka.

: In Cid's rescue event, Cid is never saved.

: Added hints about some of the additional bosses in the townspeople's conversations.

: ★ Added forced encounters to each area outside the Tower of Fanatics

: The enemies' physical defense is too high, making it difficult to use "Attack," so we set the average value to around 100.

: Fixed graphical glitches in the conversation window