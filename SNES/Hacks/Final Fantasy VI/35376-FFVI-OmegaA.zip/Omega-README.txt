﻿Final Fantasy 6 Omega Additional Patch Ver. 18.2
This patch requires the free software WinIPS
SMB Laboratory
http://47.tok2.com/smblabo/


This patch should be applied to 3,145,728-byte (i.e., headerless) ROMs.
It will not function properly if applied to ROMs with headers.
Note that applying this patch will convert the ROM from HiROM to ExHiROM.
Ver. 10.0 and later will not work with SNEShout.
Cannot be used in conjunction with other patches.

Contents
Adds enemies from FF5: Omega, Divine Dragon, Gilgamesh, Gogo the Impersonator, and Exdeath Soul
In addition, adds the FF4 boss Zeromus.
Also changes the names and effects of some moves.
Replaces Siegfried with Gilgamesh.
Adds the scrapped monster Kaiser Dragon.
The Three Dream Brothers have been replaced with the "Magus Sisters," enemies from FFIV.

Appearance Locations
Omega: Battle begins when you talk to the symbol wandering the cave leading to the Ancient Castle.
Divine Dragon: Battle begins when you examine the treasure chest (armor?) that contained the Soul Saber in the basement of Figaro Castle.
Gilgamesh: Battle begins when you open the treasure chest that contained the Ultima Weapon in the Demon-Sealing Wall Cave before the world's collapse.
Gilgamesh: Appears in the Demon Train (events are slightly changed), and can also be encountered in the Coliseum.
Gogo the Impersonator: Battle begins during the event where Gogo is recruited.
Zeromus: ? All party members must be level 70 or above when fighting Hidden.
? Erebos is killed.
? Hidden's remaining HP is 12,800 or less.

Meeting all three of these conditions will transform Hidden into Zeromus.
Exdeath's Soul: Open the treasure chest containing Tiger Fang in the Beast Plains Cave to enter battle.

Death Penalty, who you would normally fight here, appears as a normal monster in the cave leading to the Ancient Castle.

Kaiser Dragon: Located in the same location as in the GBA version.

*The battle with the Divine Dragon has been replaced with obtaining the Soul Saber, so you cannot fight it if you have already obtained the Soul Saber. If you wish to fight it,

Go to Silgonhagen's homepage
http://www.a1.hey-say.net/~silgon/
to obtain the save data modification tool and make treasure chest No. 155 unobtained.

Similarly, the treasure chest containing Gilgamesh is No. 132.

The Soul Saber can be found in the treasure chest in Phoenix Cave (originally an empty treasure chest).

*Due to the expanded enemy data in Ver. 6.0, the previous structures are no longer usable. A structure definition file for the modified version is included, so please use that for modifications after applying the patch.
*Since the save data has been expanded from version 17.0, previous save data will no longer be usable.
If you wish to retain your previous data, please convert it using the included save data expansion tool.
This is not necessary for new games.

-About the expanded monster data (from version 6.0)
Up to 95 monsters can be added. Enemy numbers 1A0-1FE are available.
Enemy numbers 180-19F cannot be used as their graphics are used for summons, etc.

-About the expanded monster party data (from version 7.0)
Up to 151 types of monster party formations can be added. Party numbers 240-2D6 are available. Party numbers 2D7 and 2D8 cannot be used as they are used in Coliseum battles.

-About music changes (from version 10.0)
FF6 music specifications are the same as those in Romancing SaGa 3.
Some data has been moved to allow for the addition of new songs. Please refer to "Major Changes.txt" for details.
Up to 40 songs can be added. Instruments can also be added.
The songs that have been changed are as follows:
Imperial Castle: "Gastler Empire" → "Kingdom of Baron" from FF4
Samasa Village: "Stragos's Theme" → "Mysidia" from Final Fantasy IV
Phoenix Cave: "World of Mythical Beasts" → "Dungeon" from Final Fantasy IV
Ancient Castle: "Serpent's Path" → "Mountain People" from Final Fantasy IV
Mount Zozo: "Sacred Mountain Coltz" → "Mountain of Trials" from Final Fantasy IV
When the Magus Sisters appear: "Hmm?" → "Dancing Doll Calcobrina" from Final Fantasy IV
Dream Dungeon: "Lost Woods" → "Incubus" from Romancing SaGa III
World of Mythical Beasts: "World of Mythical Beasts" → "City of Mythical Beasts" from Final Fantasy IV
Fight against the Magus Sisters: "Final Battle" → "Battle 2" from Final Fantasy IV
Narshe Mine (before collapse): "Coal Mining City of Narshe" → "Dungeon 2" from Romancing SaGa I

Starting with version 15.0, you can specify battle music for each enemy party by following the steps below.
Select the target monster party from the "Monster Party 2" structure
and set bit 3 (0x08) of the fourth byte (specifying battle music).
Bits 4-7 should not be set at this time.
Select the target monster party from the "Monster Party-Specific Battle Music" structure
and specify the music number you want to use.

- Regarding conversation data capacity expansion
51E600 to 51FFFF is the conversation data offset table, and 520000 to 53FFFF is the conversation data.
The original area is now used for event codes.

- Regarding character addition
As of version 15.0, characters can be added. Additional characters can be used with the code 1B XX.
To add new characters, write the character graphics starting from 596E00.

- Regarding "Strong New Game"
"Strong New Game" is available as of version 15.0. After the world collapses, you can select "New Game +" by talking to the person on the other side of the counter in the beginner's house.
The following values ​​are inherited in "New Game +."
Strength, Stamina, Speed, Magic Power, Items, Magic Stones, Gil, Play Time, and Steps.
Other values ​​(such as key items, level, experience points, max HP, and max MP) are not inherited.

- About Encounter Table Expansion
Starting with version 17, it's now possible to add encounter patterns.
How to Use the Additional Area
Select the number you want to use from the "Additional Encounter Table" in the ? structure and set the monsters and party types you want to appear.
In the "Map-Specific Encounter Table Number" in the ? structure, set the value corresponding to the map number you want to call the additional table for.
For example, if you want to use the additional table on map number 40, set the value of [40] to FF.
In the "Map-Specific Additional Encounter Table Pointer" in the ? structure, set the value corresponding to the map number you want to call the additional table for to the encounter pattern number you want to call.

- About Additional Items
Additional items were added in version 17.
Additional items cannot be sold in stores or stolen from monsters.
To set them as dropped items, enter the last two digits of the additional item number in the "Additional Item Drop Table"
for the corresponding monster party.
(For example, 00 for 100 Apocalypse, 01 for 101 Zorin Shape, etc.)

- About Additional Dungeons
The extra dungeon "Dragon's Lair" was added in version 17.
The conditions for entry are the same as in the GBA version. However, magic stones cannot be obtained.
The "Shrine of Souls" was added in version 18. You can find information about its location in the Coliseum.
Send feedback
Translation results available
