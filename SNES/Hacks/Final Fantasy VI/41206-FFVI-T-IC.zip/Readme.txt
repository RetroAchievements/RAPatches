Use with:

Final Fantasy VI (Japan).sfc (no intro)

BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              45EF5AC8
MD5:                97BF78E916B80F47CF35EDF502BE34DC
SHA1:               1C6A6DD90D3463F4532202199885A2C0E9A485F6
SHA256:             7187333502021ADDC80CE27D5B0B4316DCAC9318871E1C3ED5ED474B10177B65


1)  Get the unmodified Japanese game

2)  Remove the header (use Tush to determine if you have a header. Tush will remove the header for you).  Tush can be found at https://www.romhacking.net/utilities/608/

3)  Confirm the above CRC32/MD5/SHA1/SHA256