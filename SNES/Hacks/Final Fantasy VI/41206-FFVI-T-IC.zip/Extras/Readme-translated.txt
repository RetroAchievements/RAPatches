● ● Introduction ● ●

Thank you for downloading FF6T-IC.

This patch is based on "FF6 T-Edition 2.9.4" and "FF6 T-Edition EX 1.6.3" (created by Tsushi), which are modified versions of the Super Famicom version of "FINAL FANTASY VI," and has been further modified.

FF6T-IC has only been tested on the uosnesw emulator.

While it will likely work on other emulators as well,
uosnes is recommended unless you have a specific reason not to.

● ● What is FF6T-IC? ● ●

- This is an alternate story of FF6, featuring Rachel, who had very little screen time in the original game, as the protagonist.

- As the protagonist is female, there are some yuri-esque conversations.


* This patch features numerous spells and items from other numbered FF titles,

and many original spells, resulting in a rich variety of magic.

* Damage inflation intensifies significantly towards the end of the story,
allowing you to enjoy battles with massive numbers flying around.

* Each spell has relatively low MP cost, making them easy to use.

(This doesn't mean the game is too easy, though.)

* This patch utilizes the "Disc Change System" described below,
allowing the use of multiple ROMs to increase the variety of spells, items, and enemies.

* Unusually for Final Fantasy, the protagonist is a typical back-row character,
weak in physical attacks and with low HP,
but excels in battles with a magic-based combat style.

* Many original spells exist in this patch,
and Rachel's specialty, water-elemental attack magic,
provides particularly valuable opportunities for use.


For other detailed specifications,

please see the included "Specifications.txt" file.

The Twitter hashtag is


#FF6T_IC


(Since "-" cannot be used in hashtags, "_" is used instead.)

https://x.com/search?q=%23FF6T_IC&src=hashtag_click&f=live

While there are many spoilers, you should be able to get a feel for the atmosphere of the work from the tweets about the production process.

Author's Twitter

https://twitter.com/FF_IC_waterga

● ● What is the Disc Change System? ● ●

FF6T-IC uses a disc change system,

where you switch the ROM used for gameplay as the story progresses.


Disc1 → Disc2 → Disc3

The game progresses in numerical order.

(You cannot return to the previous disc.)

After Disc 3, you can go to Disc EX, but
you can also return to Disc 3.

Think of it like the PlayStation-era Dragon Quest and Final Fantasy games;

This might make the disc change system easier to understand.

For information on disc change timing and methods,

please refer to the included "Disc Change Guide.txt".

● ● How to Create an FF6T-IC ROM ● ●

FF6T-IC uses more than one ROM for gameplay.

This patch uses four ROMs due to the disc change system,

so you need to create four ROMs.

◆STEP 1

First, remove the header from an unmodified FF6 ROM.

If you don't know how to remove the header, this is helpful.

https://emu.web-g-p.com/info/system/header_smc.html

WEB GAME PLATFORM - Emulator Information Bureau (Top Page)

https://emu.web-g-p.com/info/center/

◆STEP 2

Next, visit Tsushi's website

http://jbbs.shitaraba.net/game/55803/

At the very top

Current Latest Patch → Click on the "here" section

This will take you to the uploader (Tsushi's Patch Repository uploader.jp).


Download the file labeled "FF6 T-Edition 3.0.7+EX 2.0.6.zip" (Date/Time: 26/04/27 12:00)

Then, apply the "FF6 T-Edition 3.0.7.ips" and "FF6 T-Edition EX 2.0.6.ips" patches to the FF6 ROM whose header you just removed.

This will create two ROMs: 【FF6 T-Edition 3.0.7.smc】 and 【FF6 T-Edition EX 2.0.6.smc】

*Caution*

Do not apply the other patch to a ROM that already has one patch applied.

This is how to apply the following:


FF6 T-Edition 3.0.7.ips to an unmodified FF6 ROM


FF6 T-Edition EX 2.0.6.ips to an unmodified FF6 ROM




Reference: CRC32 values ​​for each ROM

FF6 (Original, no header) CRC32: 45EF5AC8

FF6 T-Edition 3.0.7.smc CRC32: 89CFA065

FF6 T-Edition EX 2.0.6.smc CRC32: 3C73F2F2

"CRC32" is a string of alphanumeric characters used to verify whether multiple files are identical.
It is also used to check if the ROM held by the game patch creator and the ROM with the downloaded patch applied by the player are identical.

If they are not identical, the "CRC32" values ​​will not match.

When launched on an emulator, the "CRC32" will be displayed in the lower right corner, etc.
Please check if it matches the values ​​above.

(The verification method varies depending on the emulator.)

If they don't match, the patch application has failed. Even if it works normally,
there's a possibility of problems occurring somewhere, so this investigation is important.

Also, when applying patches with winips, if you don't have the latest version,
problems may occur. Even if you've already downloaded it,
please use the latest version of winips just to be safe.

If the "CRC32" doesn't match after applying the patch with winips, or if it matches but the game doesn't work properly,
applying the patch using the site below often works, so if you're having trouble,
please try it.

https://web.save-editor.com/tool/

Search for "ROM patch application tool" on this site,

and click "IPS" which is located just below it.

You can apply the patch from IPS PATCHER (IPS patch application tool).

◆STEP 3

Create the FF6T-IC Disc 1 to Disc 3 ROMs.

Apply the following three patches to FF6 T-Edition 3.0.7.smc

FF6T-IC Disc1.ips

FF6T-IC Disc2.ips

FF6T-IC Disc3.ips

Then

Apply the following patch to FF6 T-Edition EX 2.0.6.smc


FF6T-IC DiscEX.ips

In short:

Discs 1-3

FF6 T-Edition 3.0.7.smc + FF6T-IC Disc1.ips → FF6T-IC Disc1.smc

FF6 T-Edition 3.0.7.smc + FF6T-IC Disc2.ips → FF6T-IC Disc2.smc

FF6 T-Edition 3.0.7.smc + FF6T-IC Disc3.ips → FF6T-IC Disc3.smc

Disc EX

FF6 T-Edition EX 2.0.6.smc + FF6T-IC DiscEX.ips → FF6T-IC DiscEX.smc

That's the general idea.

This should result in the following four ROM files.

◇ FF6T-IC Disc1.smc (Disc1) CRC32: 1D6F0BF4

◇ FF6T-IC Disc2.smc (Disc2) CRC32: 8F693CBB

◇ FF6T-IC Disc3.smc (Disc3) CRC32: 82AA2540

◇ FF6T-IC DiscEX.smc (DiscEX) CRC32: C70A644E

*Note*

If the CRC32 value of the ROM you created does not match the values ​​listed here,

the patching was not successful, so please try again from the beginning.

Starting a game with a ROM whose CRC32 value does not match may cause problems

and may prevent the game from functioning correctly.

Once these ROMs are successfully created,

you can finally start the game.

Launch FF6T-IC Disc1.smc in your emulator and

start a new game.

Using save data or state saves from FF6 or FF6T will cause problems, so please be sure to start a new game.

For information on disc changes (when the ROM used for gameplay changes) and what to do at that time, please refer to the included
"Disc Change Guide.txt".

● ● Important Notes ● ●

The creator of FF6T is Tsushi, and this patch (FF6T-IC) is based on that,
and further modified by Waterga (twitter@FF_IC_waterga).

Please do not send any questions, bug reports, or other complaints about FF6T-IC to the FF6T creator, Tsushi.


● ● Your Opinions and Feedback ● ●

For opinions, feedback, inquiries, bug reports, etc., please use:

Author Waterga's Twitter

https://twitter.com/FF_IC_waterga

Or
"Marshmallow," where you can send opinions anonymously

https://marshmallow-qa.com/ff_ic_waterga?utm_medium=twitter&utm_source=promotion

Please use these options.

● ● Finally ● ●

I played around with it while modifying it, and I think FF6T itself is very fun, and the variety of additional elements are abundant.
I think it's a high-quality patch.

I would like to express my deepest gratitude to Tsushi, the author of FF6T.

Also, to those who have published modification information and tools, those who have created videos,
the creators of other patches, and former Square staff.


Waterga