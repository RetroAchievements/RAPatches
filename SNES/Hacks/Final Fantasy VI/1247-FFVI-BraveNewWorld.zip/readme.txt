Use with:

(No Intro)
Final Fantasy III (USA).sfc
e986575b98300f721ce27c180264d890
A27F1C7A