Use with:

(No Intro)
File:               Final Fantasy III (USA) (Rev 1).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              C0FA0464
MD5:                544311E104805E926083ACF29EC664DA
SHA1:               057ADA1C641E3E0B3CA34E6E4F4EB1B05A87143A
SHA256:             10ECCC5D2FAB81346DD759F6BE478DCB682EEF981E8D3D662DA176E1F9A996BC


(No Intro + RAPatches)
File:               Final Fantasy VI - Presentiment Era (v3.3) (Mr. Branford).sfc
BitSize:            48 Mbit
Size (Bytes):       6291456
CRC32:              51AC88D8
MD5:                80222CB895048625A8D18AD74589ADFC
SHA1:               0C6EB3110A48FF303AF0CCDBFFCB52205F8F3591
SHA256:             2056C3B1CC47C4F4BDCF210872309EA485C81B0518D9A01EF8B40FA812D34FA6