Final Fantasy 6 - A Complete Hack
Version 2.0

Created By: MC50
E-Mail: matthewcarter50@hotmail.com

Patch this rom to Final Fantasy 3 Version 1.0.

---------------------
WHAT IS THIS PROJECT?
---------------------

This is a complete hack of Final Fantasy 3 for the Super Nintendo. Me, as well as a friend of mine, had made Final Fantasy 1 hacks before (Not of the greatest quality, but we had fun doing them), and decided to make a hack of this game. It took a while, but it should be complete now.

---------------------
WHAT HAS CHANGED?
---------------------

Nearly everything. Character sprites have been changed drastically, some are based off the original sprite, others are almost entirely from scratch. The characters are now "Classes", which you should name to whatever you want.

The characters stats have been changed, some of the special commands have been shuffled around as well. Not only that, but espers no longer teach magic or give stat boosts - The summons have been made far more powerful in exchange.

Magic, instead, is learned from equipment. For example, the "Avenger" weapon teaches Sleep at an 8X Rate, but can only be equipped by Red Mage and Blue Mage. No one else will be able to learn Sleep through that method, and many characters may not be able to learn it at all.

Various random enemies have been altered. Some of them are the same, some of them have new attacks, some of them have stats that have changed.

All of the bosses have been changed. Some of them have had just minor alterations (Such as Vargas, or the Tentacles), whereas others are complete overhauls (Such as Blue Dragon). The difficulty is higher then the original FF6, but not by a whole lot, in my opinion. I was never aiming for a super difficult game, because a few friends of mine who have never played FF6 before are going to play this.

Equipment has been changed. Almost every piece of equipment has been renamed and had stats altered. I know how FF6 works, so I tried to give most of the equipment a use for the time you will get it, unlike pointless things in the original game. Don't expect to find equipment such as the offering around, either.

Dialogue has been almost completely changed. Now, the NPC text is split into two categories - Helpful, such as people who give you tips about the game that you amy or may not have known, or telling you where to go next or about an area, or completely random, which is almost certainly an injoke, or at least a reference to something. Still, at the very least it's something different to read then the plain old FF6 plot, right?

The main plot is silly, but it is a bit more serious, and some parts of it were shamelessly stolen from other things. Again, it's something different to read, and should make for an interesting experience. It really feels quite different with the different dialogue and sprites combined.

There are other changes, as well. For example, some spells have had their effects changed, such as W Wind becoming a directly damaging spell. In addition, every single Rage has been changed. They all have two attacks now, instead of just one, and oftentimes the original attack that they gave you in the game has been changed to something else. (EX: Stray Cat now casts Haste and Slow). There are Lore changes as well, some of them have been changed.


---------------------
WHAT'S UPDATED?
---------------------

Some noticable changes from the last version. Several spelling mistakes were fixed. Some weapons and armor were changed around a bit, as well as who can equip what. There were some significant changes to several bosses, mostly lategame ones. Added a couple more lategame fights, as well. I've attached a Rage document that should be mostly accurate. Also fixed a couple sprite errors.

Also, the Morph sprite has been redrawn, and is vastly improved.

As of the new version, I have added a hard mode. This has a lot of changes to the gameplay - and it's significantly harder than the original game, though not obscenely hard by any means. Try it if you like a challenge - I think some of the bosses, especially some World of Balance ones, are much more interesting, if less forgiving.

Updated this again in 2019. Nothing too major - biggest change was in improving the characters face pics. There were some other changes, mostly to the hard version. Some minor balance changes, and a big difference is that the Back Row's effectiveness was reduced, along with Rages being learned automatically (Both these changes are only in the hard version.)

I left the two old versions in there, if someone still wants to see the old face pics or doesn't like the couple of gameplay changes. I'd suggest the newer ones, but I thought I'd keep them for nostalgia.

---------------------
OTHER NOTES
---------------------

Patches applied include the Vanish/Doom Patch, Psycho Cyan Patch and the Evade Bug fix patch. The biggest draw to this game is that it's complete - the World of Balance is more focused on the dialogue changes, whereas the World of Ruin is more focused on the battle changes, much like the original game.

I'd like to thank my friends for playing and helping me with the hack, Lord J for FF3USME, as well as the new version which came out at the perfect time to edit dialogue. Also, the creators of patches such as Assassin, for their work on FF3 Hacking.

AND YOU




This is a complete hack This is a complete hack of Final Fantasy 3 for the Super Nintendo. Myself and a friend decided to work together to make a hack for our friends to play. In the end, we thought it turned out really well, and we decided to release it to the public.

WHAT'S CHANGED?

A lot. Character sprites have been changed drastically. The characters stats have been changed, special commands have been rearranged. Bosses have been changed, some only slightly, though the majority have undergone more significant changes. Some randoms have been changed, some have been given  buffs, though many remain similar.

Dialogue has been almost completely changed. NPC text is split into two categories - Helpful, such as people who give you tips about the game that you amy or may not have known, or telling you where to go next or about an area, or completely random, which is probably an injoke, or at least a reference to something. Still, at the very least it's something different to read then the plain old FF6 plot, right?

The main plot is silly, but it does get serious at times, and some parts of it were shamelessly stolen from other things. The characters personalities are pretty much unchanging and very exaggerated, but again, it's something different to read, and should make for an interesting experience. It really feels quite different with the different dialogue and sprites combined.

Mechanic wise, the biggest change is that all spells are learned from equipment. Some of them are relics, armor, weapons, among other things. There are quite a few spells that most of your party can learn, so make sure to check it out.

The difficulty of the game isn't the highest, though it does get tougher as the game goes on. It's certainly tougher then the original. Bug fixes that were applied include Vanish/Doom, Psycho Cyan, and the Evade Bug. If you're looking for a hack that doesn't take itself too seriously, but manages to change enough about the game to make it feel different, then give this one a shot.

THE CAST

As a note, Character Names are meant as Placeholders. I expect you to rename them to whatever you want.

White Mage (Original - Terra) - Command - Health

The White Mage is the main character, replacing Terra. He equips staffs, and learns all White Magic naturally.  His special command, Health, sets Regen on the party. Just about what you would expect, huh?

Dragoon (Original - Locke) - Command - Jump

Fairly serious. As a Dragoon, she equips spears. Jumping becomes a big damage source late in the game, and she can equip heavy armor. She also learns lightning magic and a few support spells.

Red Mage (Original - Edgar) - Command - Steal

The first goofy character to join the team. He's self-confident, but an idiot. He learns up to the level 2 spells in most magic, as well as a variety of status inflicting spells. Two swords that you can equip give him X-Magic, being the only character to have the command.

Monk (Original - Sabin) - Command - Blitz

Violent. Her Weapon selection is poor, but unarmed attack is high. Learns some healing magic as well as a few support spells. Each Blitz attack is of a different element.

Samurai (Original - Cyan) - Command - SwdTech

Makes terrible puns. Equips all weapons with two hands, making his fight command powerful. SwdTechs are altered - The first directly damaging one isn't until level 6, so you'll have to put up with gimmicks before that. Learns some debilitating magic.

Black Mage (Original - Celes) - Command - Morph

Mean. A little crazy. She learns most Black Magic naturally, but has to learn some through equipment. Very strong Black Magic, along with Morph to power it up even more.

Blue Mage (Original - Shadow) - Command - Lore

She Reads books a lot, but is maybe not all that smart? Equips Swords and daggers, and can learn some offensive magic. The main focus is, of course, on Lores. Many of which have changed, and some of which are the same.

Beastmaster (Original - Gau) - Command - Rage, Control

Doesn't exactly speak very often.  He equips Claws, some spears and knives. All Rages have been changed in the attacks they use - they all have two different attacks they can choose from now. Control is also very effective in disabling a tough random.

Pirate (Original - Setzer) - Command - Capture, Slots, Tools

He's a Pirate. Some tools have changed. Slots have been buffed, especially Lagomorph. He has a lot of options, and eventually gets the best physical defense in the game. Can't use magic or summon espers, though.

Ninja (Original - Strago) - Command - Throw

Speaks in an... Odd way. He equips two weapons, and can Throw, which works exactly as you would expect it to. Defenses are terrible, but offense is high. Learns Fire Magic, along with a reasonably high magic stat.

Knight (Original - Relm) - Command - Runic

Quiet. She equips Knight Swords, as well as heavy armor. All of the class specific equipment makes her Auto-Cover allies. She takes a while to get started, but ends up strong, with good healing spells, and a strong physical attack.

Dancer (Original - Mog) - Command - Dance

Kinda normal, actually. She equips Boomerangs, along with a couple swords and daggers. Learns Ice Magic, as well as some stronger Black Magic spells like Flare. Really fast and evasive, and most of her unique equipment gives Auto-Image. Good as a secondary spellcaster.

Mimic (Original - Gogo) - Command - Mimic

Very similar to Gogo, but with a different equipment draw. She's good at what she does, and her ultimate weapon is a ValiantKnife knockoff.

Berserker (Original - Umaro)

A very buffed Umaro. he hits hard, and has a lot of life. Of course, all the same problems that come with not being able to control him still exist...
