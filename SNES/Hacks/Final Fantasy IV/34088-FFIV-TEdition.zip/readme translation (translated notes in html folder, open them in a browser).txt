html files and this guide translated by Kain Stryder of InsaneDifficulty.com / NGPlus.net
Translations done by Lazarus_DS and Kain Stryder.
English ips patches done by Serity.
Want to reach me? https://discord.gg/RgCCBAv - PM me here or just ask in the FF6 T-Edition channel.


Note on Pink Tail farming: The bug from vanilla was not fixed, so if you farm several tails at once then go to trade them in, the game 
will take ALL the tails at once for ONE armor.


Current Mod Version: 1.3


9/13/20 - Version 0.1

- First release of the files. Compared to FF6 T-Edition, this is very bare bones. As it stands now, the mod is completed and hasn't been 
touched in over a year as of this writing. Within you'll find all the files translated and ready to assist you in playing. As of now, there's 
no English translation or lua for this, and if one will be made is still in the air. I just felt like tackling the html files and getting 
this out there asap since it wasn't a huge task compared to FF6 T-Edition's information. Any additional work or updates will be posted here 
or in the Discord listed at the top of this document.

9/16/20 - Version 0.2

- Added a monster/item drop list to the html files. Also thanks to Serity, there's now some basic English patches for the mod. ONLY the 
items/equipment/monster names are in English, with some truncation (8 character limit). For now it helps tremendously, but if we can do 
more remains to be seen. Please note these are in a beta phase and not super finalized; it's just to get stuff into English and playable.

9/18/20 - Version 0.3

- Finished translating all the BNE2 folder's files for modders/coders etc to have that info.

10/18/20 - Version 0.4

- Added descriptions to the items/equipment via a patch. Due to space limitations and wording, some stuff is very mangled, such as 
Instruments for Edward. Sorry for this.

12/13/22 - Version 0.5

- A new update by Tsushiy is up. Please check the history.html for a full rundown on what's new. He also has plans for a EX patch or disc 
2 just like FF6 now, but if/when this'll happen is unknown (only discussion for now). He has plans and ideas for what he still wants to do 
for this mod (despite saying he was done, he seems interested again), so we'll see what happens. No further progress at this time on the 
English translation side, but I'll update as we do anything new.

9/19/23 - Version 0.9

- A decent update has been done to the translation effort. I managed to translate and fix up most of what Laz did/missed in his initial sweep 
about a year ago. Most if not everything except the dialogue in the game is now in English. I did translate the party swap dialogue at the 
end game to make it a little easier for players to understand what was up, as well as inform you how to do it as it's a little wonky. All 
battle dialogue, as well as any yes/no prompts and important text is translated, but beyond that, the only thing not is dialogue as mentioned. 
Currently, I technically can translate the dialogue, but it'd be truncated. Bad. And most of the translations for menus and the like are 
already truncated, for which I'm sorry, there's just very limited space to work with due to Japanese characters vs. English ones. Regardless, 
you should have a much easier time playing the mod and ultimately, dialogue wise, you're just missing the vanilla story. Translating the 
dialogue, currently for me, would be a screen-by-screen process and very slow, and I'm just not up to doing it. If we devise a method to 
inject the SNES or GBA script in, we will do that and push this to 1.0, but until then this will sit as-is. I may ninja update or edit it if 
I find errors (I more than likely missed some stuff while translating). I'll update if any more progress is made. Enjoy!


Please use this translated material for whatever purpose. If you publish it somewhere or use it to translate the game data itself, please 
give credit where credit is due.

Most importantly, have fun and enjoy the game! And thank you to Tsushiy for making this mod!