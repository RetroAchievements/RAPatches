Use with:

(no intro)

File:               Final Fantasy IV (Japan) (Rev 1).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              CAA15E97
MD5:                A2959AD8C1FF5F2719264AB4C7E40464
SHA1:               EAC14578B3465FFCE874119005F9B244E8565A79
SHA256:             9AB77350F2090AB310E1AD4398F9AA15C63B1AA5AF0F59131094715AEC3FF207