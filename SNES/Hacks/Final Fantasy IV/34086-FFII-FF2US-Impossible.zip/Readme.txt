Use with:

(no intro)

File:               Final Fantasy II (U) (V1.0) [!].smc
BitSize:            8 Mbit
Size (Bytes):       1049088
CRC32:              E73564DB
MD5:                C4CDA05CCE28DFD2D13F698BCC29EDB2
SHA1:               610F7D819617A4F9252FA01093F182B2203FF56E
SHA256:             ABCBACFBCAC08C2CB3142741472D78F1385D3BE067430CF43FBB192AD0FAB581

1)  Add header to above file (use TUSH or similar)
2)  Check above hashes; headerless file will not match