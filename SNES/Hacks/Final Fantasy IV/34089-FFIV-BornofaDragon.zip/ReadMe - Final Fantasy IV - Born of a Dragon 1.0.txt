----------------------
FF4 - Born of a Dragon 1.0
----------------------

By MGE (MikesGamingExperiments), 2017-2021

Welcome!  Thank you for taking the time to read the readme.  Long hours were put into this hack, so I appreciate anyone taking the time to play it and I hope you enjoy it thoroughly.  Changes will inevitably be made to the readme, the manual and the game itself, so when downloading a new version, please re-check the readme.  Thank you!

INTRODUCTION

FF:BoaD was imagined from the beginning to be a difficulty only hack, and a semi-extreme one.  It is not intended to be digestible for new jRPG fans, people new to Final Fantasy or even FF4.  This hack expects that you will have a deep understanding of all typical jRPG inner workings, including ones in FF4 such as ATB, talking with townsfolk, exploration, class slection/customization, etc.  This game does not deviate from the primary story of FF4, so there is essentially no new storyline content - all changes are subplots, balances or gameplay changes.

This hack is not a...
-  Retranslation
-  Reinterpretation of the original story
-  A Beginner-friendly game

Though the game maintains a high level of difficulty, it hopefully does not do so in an annoying way.  The primary focus was to make the game as difficult as possible while still being enjoyable (details below), by avoiding some of the more typical, "hacky" hack pitfalls.  The game is not overly grindy (boring), it does not assume omniscient knowledge of impossible to find secrets (unfair), and it does not require a large amount of luck (inconsistency).  However, please be advised that doing absolutely no grinding will make the game much harder, there are some new secrets and being a little lucky or unlucky is still possible.

FF:BoaD is not cheat-proof.  No attempts have been made to disable existing glitches that one may have used in the original, vanilla game.  I am looking into fixing a lot of the stat bugs present in the vanilla ROM, so stay tuned for that.  It is upon the player to decide whether they want to use glitches, but I would assume that if you're playing a game designed to be difficult, you'd be ruining your own entertainment by cheating.  Regardless, it's up to you.

LEVELING

FF:BoaD is designed to be bottle-necked at boss checkpoints.  You have a window of a few levels to beat each boss.  New areas will seem difficult until you've gained a few levels, then manageable.  Once you're at the appropriate level for that area, leveling will become sluggish.  If you're having issues beating a boss, it's best to re-examine your equipment and strategy first.  It is possible to brainlessly grind your way through the game, but I highly recommend you do not.  It will take you a very, very long time.

Regular monsters are more difficult, but not intended to be annoyingly difficult.  That said, some can and will kill your party if you aren't cautious, especially towards the latter half of the game.

SECRETS

There are many hidden treasure boxes with no visual signal, but they are hinted at by townsfolk and do not provide you with equipment or weapons that will make make a very difficult fight into a cakewalk.  There ARE weapons and armor that are obvious and meant to be found on the primary path.  Of particular use are elemental resistance, immunity and absorption armor.  They are extremely useful.  I advise you to open every chest you do see and explore every area that is plainly visible.  For the most part, treasure boxes are in exactly the same places they were before (with different contents).

STRATEGY

Scan is available to all white magic users almost immediately and WORKS ON MOST BOSSES.  If there is a boss or a new monster you're having difficulty with, I encourage you to scan it as soon as possible.  Unfortunately Scan does not provide details regarding magic defense vs. physical defense, but generally, if one isn't working, try the other.  Some monsters are very resistant to one or the other, but (almost) no monsters are resistant to both.  Also, because the game has a 16 bit limit for boss HP, 65535 is the max PAPER HP of some bosses and may not be indicative of their real health.  Some monsters "regenerate" their health, moving on to a new phase, to give the illusion of having higher health.  This was already implemented in the original, vanilla game for Zeromus.  Also, if a boss has HP that seems unbeatable, don't give up-  some of those bosses "die" early, once reaching a specific HP.

STATUS EFFECTS 

Thankfully, most monsters will not have a slew of annoying status effects to inflict upon you.  However, there are status effects in game, and while used sparingly, they are key elements in many fights. "Heal" potions that cast Esuna are still in game, but are very expensive, rare and valuable, now known as Remedy.  You'll want to use "Eyedrops" for darkness, "Antidote" for poison, etc., if you possibly can.


NEW FEATURES

There are very few actual new features to the game, but most of the originally intended features which were dummied out have been restored.  For example, Cecil, while in Dark Knight form, can use his Dark sword ability.  A few minor issues with the original game have been tweaked, such as descriptions for items whose use hasn't changed.  Additionally, several original version bugs have been patched out-  Long Range bug, Immunity/4x bug, etc. Credit to Dragoon ZERO and Grimoire LD respectively for those patches, which can be found on Romhacking.net.  User Options 2.0 has also been applied to the ROM for your convenience.  This is a special feature utility hack provided by chillyfeez.  This allows the player to run at faster speeds on the overworld by turning on the feature with the 'L' button.  This utility also implements an always-on Cache option on the menu that gives you access to the Big Chocobo anywhere you are in the world.  As such, Whistles and Carrots are no longer used in game.  Make use of this Cache!  You'll find yourself hanging on to a lot more equipment in this hack than in the original game.  It's easy to run out of space.

NEW GEAR

There is a wealth of new armor, weapons and spells.  Almost every weapon, armor, item and spell in the game has been altered in some way.  In some cases, in very small ways, like MP cost and Hit% changed to bring the lesser spells into value (or as close as possible...).  In other ways, certain spells are radically different or missing altogether.

Enemies are obviously different in stats and behavior, however there are very few completely new monsters in the game and nothing has been taken out.  All monsters appear in exactly the same areas they always have, sometimes in larger or lesser quantities, but still there.  Drops for all monsters are completely different.

RUNNING

This is a very controversial change, I know.  While inside dungeons in FF4:BoaD, you are not able to run whatsoever...  yes, you read that correctly.  Why?  For a few reasons.  First, it makes little sense that in a closed, confined, dark space chock full of monsters, you could just run the other way and not either run into more monsters or fall off a cliff or something.  Secondly, it resolves a ton of issues with balancing and pacing that the original game suffered from, due to it's lenient run mechanic.  Eblan, Cave Magnes, Sealed Cave, Feymarch (Land of Summoned Monsters) and Sylph Cave can all be tuned to a specific level window, whereas previously, one could simply chain-run through, grabbing treasures.  You'll find yourself having to ration items more, look for save points and plan your battles and steps accordingly.  Finally, it ensures that all the new AI and scripting done to dungeon monsters gets seen and not simply run through and skipped.

NEW BATTLE MECHANICS

Though much of what has been implemented had already been in the game, now it is rebalanced and utilized fully.  The following are all behaviors you can expect to see from monsters throughout FF4:BoaD:

- Enemies targetting specific characters
- Enemies targetting your weakest character
- Endurance races
- Strategy puzzles
- DPS races
- Tough monsters with one, big weakness
- Monsters that use character Commands (Jump, Dark, Regen, etc.)
- Monsters with multiple phases

STARTING OUT

-  The Training Room has been re-worked. The NPCs have lots of information to share; some is redundant with this ReadMe's information.
-  Townsfolk throughout the game are the PRIMARY source of information for new content.  Any NPC with anything relevant to say to the original story has been left intact, but boring stories about dealing Imps hard blows have been removed (Oh, my sweet Margarita...!).  Those townsfolk will have important hints to share regarding boss strategies, hidden treasure and weapon lore.
-  Exploring the town of Baron should give you an idea as to how the game has been changed.  Most secrets are in the same location they previously were, but may contain new items.  Frequently, the items will be in the "spirit" of the original secret.
-  Talk to everyone, especially before and after big events in the story line.  They will have different things to say!

CLASSES

True to the original game, characters have intended "classes".  FF4:BoaD does not allow you to tank with Rosa and cast black magic with Cecil, however, specialization within their original roles is now possible, using different equipment.  Much in the same way the original game worked, but hopefully more well thought out, there are sets of equipment that can be mixed and matched to make a hardy caster or a more dangerous tank.  You'll need to min/max according to each boss's strategy if you want to be successful.  If a boss is throwing magic at you constantly, but does relatively little physical attacking, don your Magic Defense gear and blast him.

BUGS/CRASHES

Some new spells use slots of old spells. These spells, in turn, have the effects of the old spells that were taken out when OUT of battle (aka field). Sight, etc. This is referenced in a few dialogues in game to maintain continuity, but I'm not sure how to change this without messing up a bunch of other stuff.

Some items are in the same slot as old items. If you accidentally use something like a crystal shard (rock symbol + "Light") and lose the item, it is not gone forever, but you won't find a replacement until the end of the game. If it doesn't have an obvious use by the name (X-Potion, etc.) then it probably won't work out of battle.

Bugged tiles (aka Wormholes) may still be in game, that is to say, squares that will randomly lead you to somewhere in the game, potentially cutting you off from airships/quest hubs, etc. I've tried to find and eradicate all these, but if I missed some, I apologize.  I believe this is a byproduct of such heavy editing.  Also, the stair hierarchy glitch seems to happen more often on accident, which can mess up gameplay.  I've playtested extensively, and they are very rare, but it's just not feasible for me to take every action and check every possibility.  Just to give you an idea, there was a monster on the moon which was dropping a single, normal item that is dropped by other monsters and works fine, but when dropped, following the battle, the game would crash, but only about 50% of the time.  I have no doubt that there are other such bugs still present.  Please report them if you find them so they can be fixed or worked around.  Thank you.

THANKS

A huge thank you goes out to numerous people who probably didn't know they were helping me with this hack, directly or indirectly.

PinkPuff, the writer of FF4kster, the primary program used to create this hack.  110% of my thanks.
Grimoire LD for beta testing!!!
Slickproductions.org (which is gone now, I believe)
InsaneDifficulty
NGPlus
FF6 Brave New World creators
Romhacking.net
chillyfeez
JCE3000GT
Sam, my personal friend, who has played through dozens of games with me over beers for years and years
GameFaqs.com
Deathlike2

A SHORT GUIDE TO THE BEGINNING OF THE GAME

**SPOILERS**

As was tradition in older Final Fantasy games, including Final Fantasy 4, in the original manual there was a brief walkthrough to get you going on the game.  Follow this guide to get a feel for the mod.

-  In Baron, grab treasures out of pots and houses.  Namely, to the right of the Inn, near Rosa's house, find Goggles in the moat by entering near the dancer, and walk through the trees near the old woman on the outskirts of town to find a Megalixer hidden in the bushes behind the stone wall to the South.  Enter the Inn, open the door and collect the three treasures.  Grab the tonic in the jar near the counter.  Visit Rosa's house and collect the two items there.
-  Outside, begin grinding to Level 3 or 4.  Initial equipment is fine for this.  If you encounter SwordRats, run.  You are not strong enough to fight them yet.  Try to finish off Imps with Dark-  they frequently drop Tonics, which will heal your characters without having to use the Inn.  Use the Inn for deaths, not Life potions, if you've found any.  Using the money gained from Baron Castle and Baron Town, you should be able to buy a few Tonics, too.
-  Once your characters are level 3 or 4, you can stock up on Tonics and Life potions (if you can afford any).  Grab at least a couple of EyeDrops, as well.
-  Set out towards the Chocobo forest, grab a Yellow Chocobo and ride it up to the Mist Cave.  Save the game.
-  There are three treasures in the Mist Cave, all worth getting.  If you can grind to level 4 or 5 while using Tonics to maintain your health, so much the better.
-  There is a single, very dangerous encounter in the Mist Cave-  6x SwordRats.  Use Cecil's Dark ability.  They will only counterattack once per use.  If you can manage to stay alive and slay all 6, you'll almost certainly get a Life potion.
-  Before fighting the Mist Dragon, unequip Cecil with the Strength Ring and equip it to Kain, putting Kain's Agility Ring on Cecil.  Kain will be the primary damage dealer for this fight.  Cecil is essentially worthless-  this fight can be completed at Level 1 potentially, as Mist Dragon's physical attack is very weak and a single Tonic can heal multiple rounds worth of hits.
-  Begin the battle.  Kain should Jump immediately.  Cecil should attack.  Mist Dragon will attack, cast Ice-1, then attack again.  Ice-1 will hit very hard, possibly killing Cecil.  If it does, leave him dead and continue the fight with Kain.  Kain must time his jumps so that he is not present on the battlefield for Ice-1.  This will depend greatly on your agility and current level.  Typically, the time to input the command is immediately after being hit by the first physical hit of the turn.  It is possible to get a critical hit and end the battle in only a few turns, but this usually doesn't happen.
-  Once victorious, exit North to the Misty Valley.  Heal up, move towards Mist, then unequip all items from Kain, as he'll be leaving the party and will take all his equipment with him.
-  Enter Mist Village.  Before walking into the clearing ahead, walk South and into the trees.  There will be a path towards the building to the South.  Grab an Elixir from the pool, then exit the pool and check even further South to find a path to a grassy clearing in the woods that contains a Megalixer.
-  Retrace your steps, then continue on.  Kain will leave.
-  Save the game.  Start out towards the NE, to a town called Kaipo.  If you want to grind a couple levels with Cecil, you have the ability to do so, as there is an NPC outside the town gate who sells Tonics.  Before entering the town, make sure you have at least 7-10 Tonics.  When ready, enter the town.  Some events will happen, and you'll begin combat against Baron soldiers.  Immediately use your Shadow Sword as an item to set up Blink.  Make sure you're in the back row, as this will bring any damage that gets through to 1.  Fight the non-officer guards until they're dead, re-setting Blink and using Tonic as needed.  Move to the front row, set up Blink using the Shadow sword, then ensure you are at full HP.  Attack the officer.  He'll counter attack with Fire1.  He also intermittently physically attacks.  Make sure you heal up with Tonic before attacking again.  Maintain Blink at all times.  He will die, and they will drop some consumables, and if you're lucky, accessories.
-  Visit Rosa in the NE house.
-  You are now ready to outfit Rydia-  she can equip Kain's old Iron helmet and his Agility Ring.  This will save you the GP of having to buy them expensively at the Kaipo weapon store.  The store also has a wand called Sting which does ranged physical damage.
-  Rydia is pretty defenseless at first.  Cast Blink using the Shadow Sword on her.  Kill a few enemies with Dark, if you can.  Once she learns Sleep, begin casting on all monsters each combat.  Level her up until she has enough HP to survive a few good hits.
-  Move on to the cave to the NE, the Watery Pass.  In this cave, make sure to look for a Waterfall on the first screen-  inside is a Wisdom Ring, which can either turn Rydia's black magic from poor to viable, or Tellah's black magic from viable to very powerful.  Your choice.
-  Keep consumables at hand, be careful about your steps and always make sure to save!

GOOD LUCK!  YOU'LL NEED IT!