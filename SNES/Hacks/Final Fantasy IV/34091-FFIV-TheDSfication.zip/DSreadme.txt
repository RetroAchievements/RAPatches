=================================
Final Fantasy IV - The DSfication
=================================

=====
About
=====
After playing the DS version of Final Fantasy IV you can tell a lot of differences between these games, the extra commands are much more relevant and fun to use in the DS version, most bosses are much more challenging and the game is balanced much better. So When I see the SNES version of this game I think how fun it could have been to have had some of the implementations and changes from the DS version. I knew nothing about ASM so I couldn't really do much on my own, thankfully there are tools out there to help me out. And well, after some time I started learning ASM on my own, and here I am trying to come up with this frankenstein of project.

Fog bugs, feedback, comments, and suggestions feel free to comment it in the forum or directly with me:
https://www.romhacking.net/forum/index.php?topic=34950.0
https://www.romhacking.net/community/7090/

================
Special commands
================
Parry
Universal command, the user enters in parry state which doubles the defense and increases magic defense by 25, the effect lasts until your next turn.

Dark
Attack one target with a wave of darkness that deals about twice the damage of Fight, consumes ⅛ of the user’s maximum health.

Jump
Leaps in the air, making the user untargetable for a while, lands on an enemy to deal about twice the damage of Fight, the attack ignores rows.

White
A list of support magic that heals, protects, or removes negative statuses on the allies in exchange of MP.

Black
A list of offensive magic that deals damage or inflict negative statuses on the enemies in exchange of MP.

Call
A list of creatures that can be called in battle to deal damage or activate some effect in exchange of MP.

Recall
Attempts to cast a random black magic against all enemies in exchange of MP, the list of possible spells is Fire1, Fire2, Fire3, Ice-1, Ice-2, Ice-3, Lit-1, Lit-2, Lit-3, Toad. All spells have the same odds to be casted.

Hide
It makes the user untargetable for a while.

Salve
Heal all allies with a cure1 item at full power.

Sing
A list of support magic that grant positive effects to the allies or inflict negative statuses on the enemies.

Aim
Unmissable attack to one enemy, the damage is about the same as Fight.

Pray
Attempts to heal all allies by around ~20% of their maximum health and restore some of their MP, there’s a small chance of failure.

Focus
The user stores energy, it can be released with Fight or Kick, dealing about twice their damage.

Kick
Deals some damage to all targets, the attack ignores rows, the damage is higher if the user stored power with Focus.

Brace
Increases the user’s defense and enters in parry state.

Twincast
Chant a powerful random spell in exchange of MP of two members, it needs two compatible members in the party. There’s a minimal chance of failure.

Bluff
Doubles the power of the next spell. It also affects the power some items.

Cry
Decreases the Defense and Magic Defense of all enemies.

Cover
The user receive physical damage instead of the selected ally or an ally wth low HP.

Peep
Checks a target’s remaining HP, and elemental weaknesses.

Imbue
Sets fire, ice, and lightning on the user’s weapon, dealing elemental damage with physical attacks like Fight.

Steal
Attempts to steal the most common drop of an enemy, odds increase with a higher Level.

Throw
Consumes a weapon to attack an enemy, ignores rows and the target’s defense, damage depends on the user’s level and the attack of the weapon.

Ninja
Offensive magic, similar to Black magic, that deals damage or inflict negative statuses on the enemies in exchange of MP.

Bless
Restores MP to all allies, the amount restored increases with the user’s Level.

=========================
Alternative retranslation
=========================
Many thanks to Northener who has provided me with a patch that offers an alternative translation for this hack. 
I have to clarify that due to the amount of invasive patches this game has there might be a small amount of empty textboxes in the final game.
~ Thanks for your understanding ~

================
Changed formulas
================
Some formulas have been modified, find the details below

Example:
(Old) first line = previous formula used in Final Fantasy II
(New) second line = new formula in Final Fantasy IV - The DSfication

(Old) Accuracy = Weapon's accuracy + (Level / 4)
(New) Accuracy = Weapon's accuracy + (Agility / 4)

(Old) Attack = Weapon's attack + (Strength / 4) + (Level / 4)
(New) Attack = Weapon's attack + (Strength / 4) + (Agility / 4)

(Old) Attack multiplier = 1 + (Strength / 8) + (Agility / 16)
(New) Attack multiplier = 1 + (Strength / 8) + (Level / 8)

(Old) Magic evasion = Equipment's magic evasion + ((Wisdom + Will) / 8)
(New) Magic evasion = Equipment's magic evasion + ((Will + Will) / 4)

(Old) Magic defense multiplier = (Wisdom + Will) / 32 + (Agility / 32)
(New) Magic defense multiplier = (Will + Will) / 32 + (Level / 32)

(Old) Spell power = (Magic's spell power x 4)
(New) Spell power = (Magic's spell power x 4) + (Level / 2)

(Old) Summon Spell power = (Magic's spell power x 8)
(New) Summon Spell power = (Magic's spell power x 4) + (Will / 2)

(Old) Relative agility formula = (Cecil's Agility x 50) / (My Agility x 10)
(New) Relative agility formula = 750 / (My Agility + 32)

(Old) Spells casted by a weapon use a fixed magic multiplier assigned to the respective Weapon
(New) Spells casted by a weapon use the owner's stats

(Old) Critical rate odds = (base critical rate / 98)
(Old) Base critical rate is a fixed value depending on the character. That value is doubled with a weapon equipped, and tripled with bow and arrows.
(New) Critical rate odds = (Agility / 255)

(Old) Critical bonus with 1 weapon = base critical bonus + (Weapon's attack / 2)
(Old) Critical bonus with bow and arrows = critical bonus + Arrow's attack
(Old) Critical bonus with 2 weapons or no weapons = critical bonus
(Old) Base critical bonus is a value between 0 and 60 depending on the character
(New) Critical bonus = 48

(Old) Split damage = Damage or Healing / Number of targets
(New) Split damage with 1 target = Damage or Healing / 1 (unchanged)
(New) Split damage with 2 target = Damage or Healing / 2 (unchanged)
(New) Split damage with 3 target = Damage or Healing / 2
(New) Split damage with 4 target = Damage or Healing / 3
(New) Split damage with 5 target = Damage or Healing / 3
(New) Split damage with 6 target = Damage or Healing / 4
(New) Split damage with 7 target = Damage or Healing / 4
(New) Split damage with 8 target = Damage or Healing / 5

==============
Other changes
==============
*   The delay of most commands have changed to resemble the DS version
*   Character's stats have changed to the DS stats as much as possible
*   Sing and Aim command now works with any weapon as long as a weapon is equipped
*   Some algorithms were changed (accuracy, attack multiplier, magic defense multiplier, magic evasion, spell power, poison damage and frequency, gradual petrification's frequency, armor/protect's defense bonus, shell's magic defense bonus ...)
*   Equipment's stats, bonuses, elements, properties, etc... Have changed to resemble the weapons from the DS version
*   Initial spells and spells learned by level have changed to match the ones from the DS version
*   Magic's spell power, accuracy, delay, MP cost changed
*   Some spells were added and/or reworked according to the DS version
*   Enemy stats, AI, experience, gil, counters, etc... Have changed to resemble the enemies from the DS version
*   Damage/Healing output variations has been changed from the default bonus (from 0% to 50%) to be from 0% to 25%
*   The speed of dialogue in battle has been increased 
*   Unlimited arrows
*   Relative agility formula has been changed
*   Small changes on maps
*   Small changes on chest's content
*   Small changes on palettes
*   The superboss Geryon has been added

===============
Tools and hacks
===============
FF4kster 0.8 (https://www.romhacking.net/utilities/914/)
FF4tweak 1.15 (https://www.romhacking.net/utilities/1654/)
YY_CHR.NET 20210606 (https://www.romhacking.net/utilities/958/)
Final Fantasy IV User Options 3.1 (https://www.romhacking.net/hacks/2232/)
SNES Final Fantasy IV: Add 15 New Spell Slots 1.0 (https://www.romhacking.net/hacks/5043/)
FF2 with FE QoL Hacks 0.2 (https://www.romhacking.net/hacks/4372/)
FF4 Long Range Fix (https://www.romhacking.net/hacks/892/)
Remove poison message (https://www.romhacking.net/hacks/7985/)
Final Fantasy II - Battle dialogue speed up (https://www.romhacking.net/hacks/8196/)


==============
Wall of Thanks
==============
Pinkpuff
Chillyfeez
Grimoire LD
Aexoden
ScytheMarshall
Northener

=========
Changelog
=========
version 1.53
* 2024/04/07
* Fix wrong HP values of some enemies.
* Fix a minor bug in the boss fight vs Milon Z.
* The list of weapons that can be used with Throw command has been increased.
* The algorithm used for ATB has been changed (again) there's no anchor anymore, find the new one in the changed formulas.

version 1.52
* 2024/03/06
* Fix a bug in the boss fight vs Valvalis that could freeze.

version 1.51
* 2024/02/18
The hack now has 2 versions, the original version (1.51) and the one with retranslation (1.51 - retranslated)
The "1.51" does NOT contain the new retranslation and the "1.51 - retranslated" does NOT contain the patch "FF2 with FE QoL Hacks 0.2" (https://www.romhacking.net/hacks/4372/), this has to be done due to the number of incompatibilities the "FF2 with FE QoL Hacks 0.2" has with other patches. So pick the version 1.51 if you care a bit more about those quality of life changes, pick 1.51 - retranslated if you prefer alternative dialogues.
* The error with a door not asking for the Lugae key is only present in the 1.51 which is caused by the patch FF2 with FE QoL Hacks 0.2. The game should be fully playable with it though.

version 1.5
* 2024/02/17
* New section in readme "Special commands"
* New section in readme "Alternative retranslation"
* "Summary of changes" was renamed to "Other changes"
* Formula for critical rate and critical hit have been modified.
* Formula to speed up the first turn of all party members and monsters.
* Formula for spells with split damage/healing has been modified.
* Avenger sword has been buffed.
* Dark command was dealing more damage than shown on screen, it has been fixed.
* Aim command doesn't lose accuracy in the middle slot anymore.
* Cry command was reworked, now it decreases Defense and Magic Defense.
* Bluff command was reworked, now it doubles the damage for the next spell, similar to the DS version.
* Brace command was reworked, now it casts Armor on the user and enters in parry state (defend).
* Fixed an error with Zeromus' AI.
* Fixed an error with a door not asking for the Lugae key.
* Geryon's stats and AI have been changed to be more challenging.

version 1.4
* 2023/11/04
* Small nerf to Slow effect. Originally you could increase a target's wait time up to ~100%, now it is by ~50%.
* Small buff to Fast effect. Originally you could decrease a target's wait time up to ~25%, now it is by ~37.5%.
* Previous to version 1.4 ALL spells had a small spell power bonus at higher Level (exclusive behavior of this hack). Now Summons have a small spell power bonus at higher Will stat and Non-summon spells have a small spell power bonus at higher Level.
* A couple monsters had a change in their defense stats.
* Level up post level 70 will increase 2 point of a random stat, In previous versions it was only 1 point.
* Nerf to Cecil's HP growth, the difference is minimal though.
* The speed of dialogue in battle has been increased.
* Bugfix: there was a bug where magic sometimes dealt a wrong amount of damage on multiple targets, it is working properly now.

Version 1.3.1
* 2023/10/26
* Bugfix: The event in the Ribbon room wasn't working properly.

Version 1.3
* 2023/10/25
* Changed the title screen.
* Added the optional boss Geryon.
* Decreased the encounter rate in Mt. Ordeals summit and the Giant's lung.
* A treasure chest has been added in Toroia.
* Fixed an error where an item was listed twice on a shop.

Version 1.2.1
* 2023/08/13
* FF2 with FE QoL Hacks' press select to show information has been disabled, data does not match the changes of my hack.
* Bugfix: Edward's list of spells was bugged.

Version 1.2
* 2023/08/11
* many J-Items were added (mostly items that can cast spells, Apple, Soma Drop, Siren)...
* Update to many shops to include J-Items and other stuff.
* ATB formula (a.k.a Relative Agility) will be changed (again) The new formula will make slow party members and slow enemies faster as they were too slow, Tellah can't wait for it.
* The speed was readjusted for some enemies to balance with the new ATB formula.
* Including Chillyfeez's Cache patch (access Fat Chocobo's storage from the Menu).
* Including some quality of life changes from B0ardface's FE's QoL patch.
* Including Dragoon ZERO's Long range fix patch.
* Most enemies that had Air resistance do not have it anymore.
* Count's countdown has been slow down with the new ATB formula.
* Poison damage doesn't show the "damaged by poison" message anymore.
* bugfix?: Cat Claws doesn't sleep anymore and Poison Axe doesn't cast poison anymore.
* Include most of the updated formulas in the readme.
* Known bug: Peep shows wrong HP on enemies with high HP.
* Known bug: Custom menu has a few graphical misalignments.
* Known bug(?): b0ardface's FF2 with FE QoL Hacks has a lot of hardcoded vanilla information that doesn't match my changes, be wary of that.

Version 1.1
* 2023/01/06
* This new version has plenty of balance changes and a few bugfixes.
* On 1.0 Relative agility of the anchor was 6, with 1.1 Relative agility of anchor is 10.
* Many spells had their delay modified to adjust them with the new Relative agility.
* Some random enemies found early in the game had their attack increased.
* Mombomb battle was modified, Mombomb now has 500 more HP, now Yang gives a hint of what to do during this battle and a countdown is added like in DS version.
* Speed of some enemies and bosses were modified due to the Relative agility changes.
* AI, stats, and counters of some enemies and bosses were modified to be more in line with the DS version.
* Spell power of Heat ray has been increased.
* Spell power of Chocobo summon has been slightly increased.
* Magic evasion is increased further the more will the character has.
* A bug in the AI of the final battle glitched the game upon winning, it should be solved now.

Version 1.0
* 2022/10/16
* First release


=====
?????
=====
