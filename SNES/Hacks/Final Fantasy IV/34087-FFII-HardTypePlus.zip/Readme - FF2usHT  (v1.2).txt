	                     Final Fantasy 2 US Hard Type+
	                             Version 1.2 [revision 2004]

	           Note: Please maximize window and set word wrap.


Main Concept/Main Hacker: JCE3000GT
E-mail:         	Von_Kaiser@yahoo.com
New Web Site:		Nothing at the moment...email me.


Note: Patch this on the GoodSNES renamed Final Fantasy II (U) (V1.0) [!].


                              -------------------
                              |  P R O J E C T  |
                              -------------------

Project started July 2000

After a successful FF3us Hard Type Edit I decided FF2us needed one.  With the 
help of a select few I knew this was possible.  I've also discovered and 
documented new data in the ROM itself.  


Known problems:

Q - "How come I see some Japanese text?"

A - I intended it that way.


Q - "Why did you change so much from the original game?"

A - I just change a few things to add flavor.  That is why I am calling it: FF2usHT+


Q - "Did you edit any dialogue?"

A - Just a little.  Nothing related to the cohesiveness of the story.


Q - "Why is -monster name here- so hard?  It's impossible to beat him!"

A - I played the game all the way through 10x with minimal level ups and items to
    insure a balance of difficulty and fun.  Leveling up somemore should help.

Q - Follow up: "I leveled up and - monster name here - still beats me!"

A - Go to the bottom to learn how to fill out a "Progress Report", and I'll look into it.


Q - "What did you do to your hair?"

A - I assure you I did nothing to my hair...


Supported:
FF2us Version 1.0

Not supported:
FF2us Version 1.1 (not tested--and not recommended for patching)
FFIV Non-Translated and Translated Versions
FFIV WSC ROM also no supported
FFIV from FFOrigins not supported

New features added in Version 1.2:
-Did some minor clean up...and edited a character stat.

What's next on the list:
-Nothing for this version.

Bugs:
-None with the re-worked ROM so far...

Bugs fixed:
-When Yang fights 3 Red Golbins he dies.  I Replaced Red Goblins with normal Goblins.
-When the Thief is near death he hides and battle freezes.
-Character weapons starting on the wrong hand when you get the the 1st time.
-When Cain fights with James the game blacks out.
-When James "becomes a paladin" did give party the Legend Sword.
-The Ninja starts with and learns the right spells.
-Landing the Big Whale will not send you back inside it..instead you're outside with
 the same music playing (Well it's actually a GOOD bug, but still).
-The "invisible" paths in the Lunar Subterrain and Cave of Bahamut have the GFX glitched.
-Exiting the Sylvan and Summon Monster Caves by the "Exit all the way out tile" trigger
 sends you in the middle of the Lava "Ocean".
-When getting the Ninja the 1st time he has all FuSuYa's Black Magic Spells, conversely 
 FuSuYa doesn't have any!
-Exchanged some treasure data...

================================================================================

               --------------------------------------
               |   P R O G R A M M E R ' S   L O G  |
               --------------------------------------

Version .10
   July 2000:
	Item and Monster Names Edited
	Menu Names Edited
	Character and Class Names Edited

Version .19
   August 2000:
   	Character Startup Stats and Equipment Edited

Version .20 - .76 
   August 2000 - March 2001:
	Project halted-no report.

Version .76
   March 2001:
	Limited Monster Stats Edited
	Limited Monster Graphic Data Edited
	Edited Item Icons
	Edited and finalized Shop Data

Version .77 - .79
   April 2001 - July 2001:
	Project halted-no report.

Version .80
   August 2001:
   	Finalized Character Stats and Equip
	Edited Character Learned @ Level Magic
	Edited Character Starting Spells
	Edited and finalized Item Cost Data
	Edited and finalized Enemy Item Won Data
	Edited and finalized Character Battle Menus
	Limited Script editing

Version .81
   September 2001:
	Edited some Magic Spells
	Edited some Monster Formations
	Edited and finalized Font
	More Script editing

Version .82 - .95-RC1
   September 12, 2001
	Scrapped the ROM and started re-working a new ROM to fix the bugs.
	Left the Under/Overworlds and Moon maps alone.  =(

Version .96-RC1.5 - .97-RC2
   September 13, 2001
	Edited a few spells, including 2 of 3 Asura effects.
	Edited the Title Screen slightly.
	Cleaned up and re-worked Font and Icons.
	Edited the Title Screen a little.
	Edited some magic's MP Cost.
	Finished the monster stats.
	Completed character startup stats/equipment.
	Edited a few monster formations.
	Grotto Adamant Event has been expanded...
	Added limited Japanese text for some things.
	Started distributing Beta copy for very limited Beta testing.
	Underworld\Overworld\Moon Maps\Triggers edited some.
	Edited a few Magic Spells...try using a spell you never tried before, you
	 might get a suprise!
	Edited Asura, instead of the Cure Max effect (2 of 3) your party will have
 	 Blur casted on it.

Version .98-RC2.5 - .99-RC3
   September 13, 2001
	Created a new monster formation specifically for an enemy.
	Added more Japanese Font.
	Edited a few monster stats.
	Edited some of the Lunar Monster's Attack Sequences.
	Altered the Title Screen.

Version 1.0:
   January-August, 2002
	Found Item stats!!
	Tweaked Valvalis, she had 45 speed and 50 magic power...having said that she also casted  Lit-3 and did 4000-7000 	 damage.
	Finalized the monster items.
	Edited and semi-finalized most\all monster HP, Strength, and Attack sequences.
	Added Hack Version # in the Status screen. 
	Edited a few weapons to equal out the Strength  of the Dragoon/Knight/Ninja. 
	Created 4 new items from scratch.� You gotta fight me to get 'em.� =)
	Created several monster formations specifically for some areas, and treasure chests.
	Edited the Title Screen.
	Changed the "Paladin" text in the dialogue to something else.
	Edited a few Magic Spells to be more useful.
	Edited some monster's speed so they attack more.

Version 1.1
   August-October, 2002
	Tweaked a few Weapons and Armor.
	Edited a few monsters--a few of them harder, a couple easier.
	Edited the casting time on all "power" spells (IE Nuke, Holy, Bahamut, etc)
	Edited a few Magic Spell's MP cost.
	Tweaked a monster formation or 2. 
	Edited Porom/Rosa's "Learn Magic spell at level up" data.
	Edtied the cost of a few items.
	Edited an item shop.
	Changed a few Treasure Chest's contents.
	Fixed up some referrences to the 'Dark Knight" and "Paladin"

================================================================================
================================================================================

Disclaimer:

"Final Fantasy 2"(R), "Final Fantasy 4"(R) and all occurences of related
context to their sotfwares are registered trademarks of Square Co., Ltd.
The programmer of this patch is not affiliated with Square Co. and
is not responsible for any loss or damage of material/sofware of the user.
A "Patch" is not illegal.  If you do not agree with this 
disclaimer, do not use this patch.

================================================================================
================================================================================

                        ------------------------------
                        |   I N S T R U C T I O N S  |
                        ------------------------------


Requirement:
* IPS patcher.
* FF2us Version 1.0 only...Version 1.1 is untested.
* A emulatorand brain to play.
* No cheating or item duplication is recommended to recieve 
  the full enjoyment of this patch.


"How do I install FF2usHT?"

1. Download an IPS patcher of choice.  I recommend: IPSWin by ZeroSoft.  You
   can find this program at www.zophar.net.


2. To ensure the patch is 100% installed correctly please use a NON patched ROM.


   ** W A R N I N G **

Do not email me for requests for the ROM or IPS patcher.  You can find an IPS patcher on
the www.zophar.net if you look hard enuff.


================================================================================

               --------------------------------------
               |    P R O G R E S S  R E P O R T    |
               --------------------------------------

Please email me with a progress report in this format (Copy Paste).

Begin:
--------------------------------------------------------------------------------
Name:
eMail:
Problem\Bug:
Solutions you've tried:



General comments:




--------------------------------------------------------------------------------
End

Also please send a copy of either the .srm or .zst file unzipped so I can examine
it myself to better understand the problem.  Also please feel free to send any
Image.bmp files unzipped of the problem as well.  Of if you are just gonna use
this Progress Report for "close calls" "whoa look at that!" or my favorite "what
the hell?!" please feel free to do so!  I'm going to dedicate a section for these pics.  =)
That is as soon as someone sends me some screens...

================================================================================

                     -----------------------------------
                     |   S P E C I A L   T H A N K S   |
                     -----------------------------------

iLLuSioNiX:	For teaching me basics in hex. (And long nites on ICQ)
		Thanks buddy!

Xlom3000:	For beta testing, and being a friend in need.  Keep up the good work.  =P

Yousei:		For the FF4ed with the FF4.txt that contains all the
		data I needed to get started.

Kryten:		And for his killer FF3 Windows project, you got my full support!

Lord J:		For his FF4h.exe srm editor...without it I'd would've gone
		insane.  Also for FF3usME the absolutely perfect FF3 editor...
		And of course the support.  Thanks buddy!

cipher:		For being there is my FF3usHT days.  And beyond...  =)

Dark Knight Kain	For some beta testing work in 2003-2004.

Square:		Well...Square of Japan for FFIV NOT Square US for FF2
		a.k.a. FFIV Easy Type.  What the hell were you thinking.
		Well...actually, because of that I'm here and you're reading this.  =)


================================================================================

                     -----------------------------------
                     |            L I N K S            |
                     -----------------------------------



-My eMail: Von_BlitzKrieg@yahoo.com
-http://www.angelfire.com/pq/jumparound/index.html, FF3usME's home! - Yes this is a plug so deal with it.
-www.zophar.net - Home of anything about Emulation.
-www.zsnes.com - My favorite Emulator.
-www.snes9x.com - Another great Emulator.

================================================================================

				2001-2004 JCE3000GT-Soft a division of BlitzKrieg Innovations