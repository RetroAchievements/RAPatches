Use with:

(No-Intro)
File:               Seiken Densetsu 3 (Japan).sfc
Size (Bytes):       4194304
CRC32:              863ed0b8
MD5:                58ebd7cbf28ceadc03aec4f448956a0b
SHA1:               209c55fd2a8d7963905e3048b7d40094d6bea965