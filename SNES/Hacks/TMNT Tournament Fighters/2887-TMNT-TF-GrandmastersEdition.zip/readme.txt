Use with:

(No Intro)
File:               Teenage Mutant Ninja Turtles - Tournament Fighters (USA).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              E2FE5DBF
MD5:                878E95BCA6B94B3FA0E72FEF1867434C
SHA1:               C2460CE4AEDA68F6170BDF9CFA52467B56E15EBF
SHA256:             849141370F164D6DB3E5709DA670726F958CE13FFEF69319564DB3FB0B12C69D