Use with:

(No Intro)
File:               Donkey Kong Country (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              C946DCA0
MD5:                30C5F292FF4CBBFCC00FD8FA96C2DE3B

File:               Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              006364DB
MD5:                98458530599B9DFF8A7414A7F20B777A