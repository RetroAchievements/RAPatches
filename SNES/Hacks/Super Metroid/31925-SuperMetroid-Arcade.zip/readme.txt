Use with:

(No-Intro)
File:               Super Metroid (Japan, USA) (En,Ja).sfc
Size (Bytes):       3145728
CRC32:              d63ed5f8
MD5:                21f3e98df4780ee1c667b84e57d88675
SHA1:               da957f0d63d14cb441d215462904c4fa8519c613