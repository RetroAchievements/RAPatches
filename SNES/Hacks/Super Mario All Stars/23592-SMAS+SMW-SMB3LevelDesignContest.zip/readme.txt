Use with:

(No Intro)
File:               Super Mario All-Stars + Super Mario World (USA).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              F84305B1
MD5:                7ECAF3E2E021C8A836041C85886F4594
SHA1:               D245E41A2B590F7D63666B0772CBDDFB26F254A2
SHA256:             A8806BFE07CD3C9945D9FD3FCEA932AE1CD671CAB5CAE12BB7A2AE726CBF9175