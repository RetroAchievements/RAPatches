Use with:

(No Intro)
File:               Legend of Zelda, The - A Link to the Past (USA).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              777AAC2F
MD5:                608C22B8FF930C62DC2DE54BCD6EBA72
SHA1:               6D4F10A8B10E10DBE624CB23CF03B88BB8252973
SHA256:             66871D66BE19AD2C34C927D6B14CD8EB6FC3181965B6E517CB361F7316009CFB