/========================\
Rockman X New Years 2016 |
Rockman X New Years 2017 |
Rockman X New Years 2023 |
--------------------------
Use with:

(No Intro)
File:               Rockman X (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              6A1B6926
MD5:                9963DD54175BBE2D02999F4CED43F829
SHA1:               86C18BA1FC762B6D0BCDEE7314A29B5C97CAC082
SHA256:             2626625F29E451746C8762F9E313D1140457FE68B27D36CE0CBEE9B5C5BE9743


/========================\
Rockman X New Years 2021 |
Rockman X New Years 2022 |
--------------------------
Use with:

(No Intro)
File:               Rockman X3 (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              E476912B
MD5:                B1023717D7BEAE8CA83A390198FBCBFF
SHA1:               8E0156FC7D6AF6F36B08A5E399C0284C6C5D81B8
SHA256:             C477282947B4DE4E23AFAA99FBF3CA7613EC6B31C1755E616D6DCE7AEEEB66D6