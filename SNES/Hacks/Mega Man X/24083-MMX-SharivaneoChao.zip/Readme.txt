Cadê o Chão Sharivan by AlexHylian

(PORTUGUESE)
Para jogar a hack você vai precisar usar a versão USA do jogo
Segue abaixo informações para usar o patch corretamente

Versão original do jogo
Database match: Mega Man X (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 449A00631208FBCC8D58209E66D0D488674B7FB1
File/ROM CRC32: 1033EBA4

Ao usar o arquivo 1.0 da hack ficará assim
File/ROM SHA-1: D9DDB212BF64B6AE58BA141812D1D1D3C1C64521
File/ROM CRC32: A49DE32E

Ao usar o arquivo 1.1 da hack ficará assim
File/ROM SHA-1: EC389F058AA95406742CDDC1BE7BCC631B6620CF
File/ROM CRC32: 4075AC7E


(ENGLISH)
To play the hack you will need to use the USA version of the game
Below is information to use the patch correctly

Original Unmodfied Mega Man X
Database match: Mega Man X (USA)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 449A00631208FBCC8D58209E66D0D488674B7FB1
File/ROM CRC32: 1033EBA4

When using the 1.0 hack file it will look like this
File/ROM SHA-1: D9DDB212BF64B6AE58BA141812D1D1D3C1C64521
File/ROM CRC32: A49DE32E

When using the 1.1 hack file it will look like this
File/ROM SHA-1: EC389F058AA95406742CDDC1BE7BCC631B6620CF
File/ROM CRC32: 4075AC7E

in English I think the name of the hack is: Where is the floor Sharivan