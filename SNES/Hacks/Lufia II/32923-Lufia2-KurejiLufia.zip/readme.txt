Use with:

(No-Intro)
File:               Lufia II - Rise of the Sinistrals (USA).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              20F2AC29
MD5:                6EFC477D6203ED2B3B9133C1CD9E9C5D
SHA1:               A89931C1F29B161B8BE717DFAB4A4ADB54B42B84
SHA256:             7C34ECB16C10F551120ED7B86CFBC947042F479B52EE74BB3C40E92FDD192B3A