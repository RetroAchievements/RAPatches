Lufia 2 - Age of the Sinistrals, v9
Praetarius


===Patching===

The patch is for an (U) ROM, both headered and unheadered version available.
 
To apply the main patch you may need LunarIPS.




===Emulator===

Will not work with ZSNES, SNES9x 2005 or earlier.




===Game Modes===

Start:	exp, gold, damage, AGL are all at their base values

Hard:	exp and gold gain are x2
	player character take 25% more damage before defense, e.g. what would be 125 damage can now be 190
	enemies take 7/8 damage before defense, e.g. what was 1k damage might now only be 800
	enemies have 25% more AGL

Gift:	same as start but you can only play the Ancient Cave and choose whatever party composition you want




===Spells/Skills===

The original list of 40 spells was expanded to over 100, some of which even Guy and Dekar can learn.
These "spells" include regular spells, physical techs and a few passive abilities.
Each character can only have at most 36 spells at the same time.
Learning a spell from a spell shop (or finding one in the Ancient Cave) provides small stat bonuses.



===Skill Reset===

If you really, really want to change your known spells, visit the old man in Merix, bottom left house.
You might only offer this service after the events with the bridge are finished.
This costs you 50% of your current gold.
He removes ALL spells and skills except Reset and Light from EVERYONE whether they are in your party, currently not in your party or have yet to join!!
You'll also lose all stat bonuses from so far learned skills.

If you're able to stomach the costs, you can repeat this as often as you want.



===Capsule Monster===

Their exp and levels are now tied to Maxim's. They are updated on changing a CM or when winning a battle with the CM alive.
AI was changed slightly compared to vanilla. In general class 4 and 5 are less likely to use a regular attack and prefer more specials.
Even when class 5 is unlocked, you can freely switch back to classes 1-4 without needing the respective fruit.
When levelling, CM still get "halved" stat growth once they pass a level threshold of 16 times their class rank, like in the original.
That means a class 2 Jelze will get full stat growth for levels 1-32 but from level 33 on gets penalized.



===Damage Mechanics===

1) Calculate basic attack power:
-ATP for regular attacks
-various for spells, e.g. Thunder has 1.75*(INT+55)
-Capsule Monster specials usually have ATP or INT with a factor of x1.5-3; only 3 moves go above that with at most x5.
(and even then they fall short of stronger CM's raw power with their x3 moves)
-fixed values for most enemy specials, means they are not affected from ATP/INT buffs or debuffs


2) Multi-target penalty:
most enemy specials and physical attacks ignore this step

1 target  = 100%
2 targets =  80%
3 targets =  65%
4 targets =  55%
5 targets =  50%


3) Weaknesses, Resistances:
usually of the x2 or x0.5 type, multiple elements can apply at the same time, except for Anti-X type elements, those cancel all other elements.


4) Critical damage:
usually only regular attacks, tech-like spells and weapon based IP moves can crit at all. Certain CM moves auto-crit.
A handful spells have the auto-crit property to bypass defense values.
If the RNG decides a move became critical, apply another multiplier to the current damage.
Most weapons only have 100% damage multipliers to allow for defense-piercing on crits (i.e. skip step 7).


5) Hard Mode multiplier:
if the target is a hero: 125%
else: 87.5%


6) Damage randomization:
Exact factor/damage range depends on the attack used.


7) Defense:
On a critical hit of a physical attack, defense is halved.
Whether DFP or MGR is used, depends on the attack.
In either case subtract the defense value from the damage unless it exceeds 50% of the damage value.
Then, it gets more complicated.
For each "50%" mark defense passes, the effectiveness is halved.
Lets say we have 500 damage and 1000 defense.
a) damage is reduced to 250 (50%) and defense is reduced by 250 as well, then cut in half, so we have now 250 damage vs 375 defense.
b) damage gets reduced to 125 and defense is brought down to 125 as well.
c) damage gets reduced to 63 (always round up here), defense gets brought down to 32.
d) damage gets reduced to 32, defense is down to 1, finally less then the next 50% mark .
e) subtract remaining defense, so we end up at 31 damage.


8) divide damage by 2, just because


9) Row:
Only on most physical attacks, this includes percantage attacks, strangely enough.
Each "distance" reduces damage by 25% (additive), so player backrow vs enemy backrow is 50%.
CM are considered to be in the front.
For some reason, some "huge" enemies like certain bosses consider the top left character to be one step closer than they would normally be.
A fixed 250 damage attack would give the following damage spread in their case:
250 188 CM:188
125 125


10) Guarding:
Regular guarding ONLY takes effect if you have your turn before the attacker and ONLY against physical attacks.
If the Guard Up skill is known, damage is further cut in half; this sub-step also applies against magic attacks.
Guarding basically increases row distance by "1.5 rows".
Back row vs "huge" boss, defending = 3.5 rows distance = 87.5% damage reduction.



===(De)Buff Mechanics===

Buffs and Debuffs can stack to a limit of 200% of base stats on the buff side or 50% base stats on the debuff side.

Buff applies buff rate to the distance between current and 200%,
e.g. 40% buff on a current 120% state increases by [200% - 120%]*40% = 32%

Debuff applies debuff rate to the distance between current and 0%,
e.g. 20% debuff on a current 120% state decreases by 120%*20% = 24%
However, it is not allowed for a value to drop below 50% of its base.
So a 10% debuff, going from a neutral state, would inflict (baring rounding):
10%, 9%, 8.1%, 7.29%, 6.56%, 5.9%, 3.15%, 0%, 0%
so the maximum debuff effect requires 7 applications of a 10% debuff.



===Item Drops===

You can only get one item per battle.
The first enemy to (invisbly) drop an item has priority.
Drop rate for bosses is either 0% (no item) or 100%.