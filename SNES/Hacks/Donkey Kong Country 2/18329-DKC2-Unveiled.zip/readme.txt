Use with:

(No Intro)
File:               Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              006364DB
MD5:                98458530599B9DFF8A7414A7F20B777A
SHA1:               3EC2035962918B5523D8B4745406F46F2A739B8D
SHA256:             35421A9AF9DD011B40B91F792192AF9F99C93201D8D394026BDFB42CBF2D8633