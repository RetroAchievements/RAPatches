Use with:

(No Intro)
File:               Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr) (Rev 1).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              4E2D90F4
MD5:                D323E6BB4CCC85FD7B416F58350BC1A2
SHA1:               69D0F91BFD05837B44023E33A6699AA28FCA19CB
SHA256:             B79C2BB86F6FC76E1FC61C62FC16D51C664C381E58BC2933BE643BBC4D8B610C