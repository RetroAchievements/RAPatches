Nemesis
By: Dennsen86
Kaizo Intermediate

This hack was built in the last 15 months. 
Most of the hack was built live during my streams. 
Without the community that helped me with so many things, 
this hack would never have been finished.
don't take this hack too seriously. fun should be the priority!
there are 2 Secret Exits that are not required to complete the game
in the zip folder you will also find a split file if you want to do speedruns.
there is also a picture of plebsen in the folder that you can print out 
and hang over the bed!

Have Fun and Good Luck!


Infos:
- Choclate Hack
- 14 Exits + 2 secret Exits
- custom character (You play as Plebsen)
- Fast Retry system 
- A custom overworld
- No HUD
- Custom palettes, graphics, mechanics and music 
- Start + Select on OW to Save 
- No water or cape levels
- Shoutout portrait rooms

Hope you´ll enjoy!

PATCHNOTES v1.1
- options for cheese and jank have been removed
- removed some Message blocks that could cause crashes
- added the missing split to the split file
- individual adjustments in jumps for better game flow
- Fixed animation bugs on the overworld
- Corrected credits