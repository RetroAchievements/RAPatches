Use with:

(No-Intro)
File:               Super Mario World (USA).sfc
Size (Bytes):       524288
CRC32:              b19ed489
MD5:                cdd3c8c37322978ca8669b34bc89c804
SHA1:               6b47bb75d16514b6a476aa0c73a683a2a4c18765
SHA256:             0838e531fe22c077528febe14cb3ff7c492f1f5fa8de354192bdff7137c27f5b