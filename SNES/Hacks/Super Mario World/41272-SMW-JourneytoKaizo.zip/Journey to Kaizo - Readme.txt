In Journey to Kaizo, you accompany Reimu on her adventure through the Shroompire. In search of her father, she explores six diverse regions to collect the Golden Coins. Only with all six coins will she be able to open the Golden Gate at the entrance to the Stronghold and uncover the secret of her quest.

This hack is designed for Kaizo beginners who already have some experience. We’ve included a tutorial level (Practice Playground) that teaches everything you need to know to complete the hack. We recommend visiting the playground before starting your quest to familiarize yourself with the basics. If you ever get stuck, you can always return to practice and improve your skills. Since this hack contains many levels in each zone with increasing difficulty, it will be your companion on your Journey to Kaizo.

This hack features:
 - 38 creative and sometimes a bit more challenging levels
 - linear regions without secret exits
 - a touching story with a surprising ending
 - free choice between instant powerup and vanilla powerup
 - fully featured tutorial level (Practice Playground)
 - hidden creator portrait rooms in each creator level
 - sometimes tricky, but optional, moon challenges at the end of each creator level
 - clearable checkpoints by pressing L+R on a level
 - a lot of individual asm coding
 - autosave
 - a LOT of goon faces
 - several easter eggs
 - cutscenes, drawn by Anna Lavellan
 - a lot of music ported exclusively by Ahrion
 - Super Mario Land 2 inspired semi-open overworld created by Devazure
 - Retro Achievements:
   https://retroachievements.org/game/41272

Official Journey to Kaizo Trailer (from Summer 2025):
https://www.youtube.com/watch?v=V05rynulXDU


====


CroNo's Comment:

Thanks to
 - my community
 - our playtesters
 - SMWCentral
 - Team J2K
 - and everyone who encouraged and motivated me to realize this collaboration
 
Without you, the project would not have been possible.

I love you all ❤️