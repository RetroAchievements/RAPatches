Use with:

(No Intro)
File:               Block Kuzushi GB (Japan) (SGB Enhanced).gb
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              54B67501
MD5:                55EF8421492242C2726E355C41AEF000
SHA1:               7540FE9AF69D8C7D48F50C2D5FE6D3CE07421F74
SHA256:             A676A5EF60D03B30CF451FC24F52F732E8B9EB86A8226A24A2CA060D12E5FAB9