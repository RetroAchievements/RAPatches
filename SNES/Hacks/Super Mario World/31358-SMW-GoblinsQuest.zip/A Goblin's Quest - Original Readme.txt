One day Lumi the Goblin woke up and realized she was STARVING, so she decided to walk down to the local supermarket to see if they had any gyros. This is her story.

This is a semi-difficult Kaizo light hack. If you had to ask I'd say maybe a 6/10 or so? Its hard to define difficulty for kaizo hacks, its all in the eye of the beholder. Well I am bad at Kaizo Mario, and this is about a 6. So hopefully that'll inform your download choice.

The levels in this hack are usually built around a gimmick or concept. The hack itself is rather chocolatey, though the gimmicks are USUALLY less in ASM and more in sprites and interesting level design. My goal in this hack (and most hacks) is to get people to go "WHAT THE HECK" as soon as they see a level (though usually use a word different than heck), then find out they really like the level anyway

Just as last time, I am not a Kaizo player. I'm not even really a Mario player. So all my stuff is a little weird for your typical Kaizo sensibilities. I've been told it feels like "Kaizo from an alternate universe where all the sensibilities are slightly different".

Things this hack has:

Goblins
Trashcans
96 fugumannen (Yes, 96 different fugu. Its my favorite sprite.)
Chocolatey design
Gyros (hopefully!)
Some humor, depending on how much of a fuddy duddy you are.
No trolls or deadly kaizo blocks. Mischief is fun, trolls are not.
A secret room in every single level, the "Murr Room" of that level

SPECIAL THANKS:

Thanks to Arcadia(@neonarcadia) for the custom sprite and art for Lumi. Thanks to Glitchcat7 and Marcy August for playtesting. Thanks for Amethyst_Rocks for playtesting and looking at my levels as I made them and telling me to just stop already, which tempered a few levels. You should thank her too. Trust me.

As the rare reader of the readme, you will get a special reward. MURR! Thats your reward.

VERSION DIFFERENCES:

1.1: Bug fixes

Please enjoy!