Use with:

[No Intro]
Super Mario World (USA).sfc
hash: cdd3c8c37322978ca8669b34bc89c804
CRC: b19ed489