SMW Friends and Rivalry

SMW Friends and Rivalry is a Super Mario World hack with traditional level design akin to the Mario games made by Nintendo.
It features 90+ new levels and 118 exits across 9 worlds
Also a lots of new stuff like new moves for Mario, custom sprites, custom music, graphics and much more.

It also features optional collectibles such as 5 dragon coins per level and 3ups moons on much of the levels, the game keeps track of which ones you collected on the map,despite not counting towards 100% those are still a fun way to challenge yourself collecting them all.

I hope you have fun playing it, and if you like this SMW hack check out my other smw hacks at smwcentral.net too.
-Bandicoot

-------------------------------------

How to patch the .bps file and play it:

- Get the bps patch for the hack ready(comes available in 2 diferent languages and 2 diferent dificulty levels, choose your prefered one), it should be available at smwcentral.net SMW Hacks section.
- Get a american rom of the original Super Mario World
- Download Floating IPS(Flips) at smwcentral.net tools section
- Open FLIPS and click "apply patch", select the BPS patch and then the american SMW rom
- Play it using an SNES emulator(SNES9x is my recomendation)
--------------------------------------------------------------

Story:
Mario and his friends were preparing for a party on Jamboree island, a resort paradise by the sea.
However Kamek comes out of nowhere and hipnotize everyone while Mario was out on the market buying some drinks for the party, now Mario must go on an adventure where he will have to face his turned-evil hipnotized friends to rescue them from the spell and defeat Kamek 
--------------------------------------------------------------

-Credits-

Below is the list of names of everyone who helped my in this project, a huge thanks for all them.

Game Design & Level Design:
Bandicoot

Beta Testing:
Bandicoot
Erpster2
marioisradical
lo fang 123
Railson
Lordkronos100
Deankind & Flickering Pixelz
Rghotic
Pepsilover22
EntySky 
Green Jerry

Graphics:
Bandicoot
Gamma V
Pink Gold Peach
BakonMaker 
Green Jerry
Natsuz2
Truxton
ShadowDragon121
Dan 
TheOrangeToad
cheeyev
Ralshi02
tmauri
SuperLuigiBros
clockworkweeble
Crafink
ModernKiwi
LinkstormZ
Kusamochi
Deeke
pokerface
SafeDesire
NopeContest
System
Blizzard Buffalo 
edgar
Rykon-V73

Custom Music:
Gamma V
Pink Gold Peach
Goomba-24
DMB
HaruMKT
KevinM
Anas
bebn legg
Captain 3
Notto
Moose
Aguiar Salsicha
El Diablo
MarioFanGamer
Papangu
MoxieClaus
FPI
Xulon
hazel
Marcozzo Daro
S1Z2
Aspecat
sinseiga
Dippy
Fullcannon
drmr
MercuryPenny
ggamer77
Milon Luxy
Dzing
Slash Man
icrawfish
its_4life
Dispace
CK Crash
Archbishop Weeble-Wobble
Dispace Troblex
Mayonnai
Fyord
Samantha
Sariel
CrimsonZN
Hooded Edge
Wakana
Enderdavid_HD
LadiesMan217
Infinity
SviSvi
smw2midi
Harumi
FYRE150
Ultima
brickblock369
ggamer77
Zavok
RednGreen
EDIT3333
Jimmy
Coolmario
Pinci
Ahrion
4life

Custom Sprites:
RussianMan
yoshicookiezeus
Mandew
lion
JackTheSpades
Sonikku
NerDose
HammerBrother
MarioE
TheBiob 
Friday_D0nat
andy_k_250
Darolac
Erik557
Koyuki
Akaginite
TheBiob
SMWEdit
Super Stiviboy
Von Fahrenheit
mykeyk
Blinddevil
Koopster
HuFlungDu
imamelia
Masashi27
Isikoro
Nesquik Bunny
WhiteYoshiEgg
leod
Romi
Erik
MarioFanGamer
KevinM
TheXander
Mirumo
EternityLarva
AmperSam
Dispari Scuro
Tattletale

Patches & ASM:
Noobish Noobsicle
MarioFanGamer
Lui37
Alcaro
WhiteYoshiEgg
Roy
Chdata/Fakescaper
Blind Devil
Romi
BMF
HammerBrother
JackTheSpades
smkdan
Discothebat
MathOnNapkins
Edit1754
MarkAlarm
Arujus
VitorVilela
KevinM
Minimay
ASMagician Maks
kaizoman666
Thomas
Kaizoman
Telinc1
Maxx
Major Flare
Mattrizzle 
Kevin
immamelia
aCrowned
MarioE
mikeyk
Roy

custom blocks:
HammerBrother
Telinc1
TheXander
Darolac
ShadowMistressYuko
JackTheSpades
Iceguy
Infrared
quietmason
Alcaro 
Bio
lx5
Roy
Sonikku
MarioE
Sind
Ersanio
Sind
RussianMan
K3fka
wye
Davros
mikeyk
MarioFanGamer
HuFlungDu
wiiqwertyuiop

Tools:
Fusoya
Kipernal
Alcaro
Atari2.0
JackTheSpades 
Tattletale
TheBiob
p4plus2
Fernap
Vitor Vilela
mikeyk
uyuyuy99
dtothefourth

