
  ██████╗ ██████╗  █████╗ ██╗   ██╗███████╗
  ██╔══██╗██╔══██╗██╔══██╗██║   ██║██╔════╝
  ██████╔╝██████╔╝███████║██║   ██║█████╗  
  ██╔══██╗██╔══██╗██╔══██║╚██╗ ██╔╝██╔══╝  
  ██████╔╝██║  ██║██║  ██║ ╚████╔╝ ███████╗
  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝

  ███╗   ██╗███████╗██╗    ██╗
  ████╗  ██║██╔════╝██║    ██║
  ██╔██╗ ██║█████╗  ██║ █╗ ██║
  ██║╚██╗██║██╔══╝  ██║███╗██║
  ██║ ╚████║███████╗╚███╔███╔╝
  ╚═╝  ╚═══╝╚══════╝ ╚══╝╚══╝ 

  ██╗    ██╗ ██████╗ ██████╗ ██╗     ██████╗     ██████╗ 
  ██║    ██║██╔═══██╗██╔══██╗██║     ██╔══██╗    ╚════██╗
  ██║ █╗ ██║██║   ██║██████╔╝██║     ██║  ██║     █████╔╝
  ██║███╗██║██║   ██║██╔══██╗██║     ██║  ██║    ██╔═══╝ 
  ╚███╔███╔╝╚██████╔╝██║  ██║███████╗██████╔╝    ███████╗
   ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝     ╚══════╝



  ┌─┐┌┐ ┌─┐┬ ┬┌┬┐
  ├─┤├┴┐│ ││ │ │ 
  ┴ ┴└─┘└─┘└─┘ ┴ 
───────────────────
"Brave New World 2" (BNW2) is the sequel to Brave New World (https://smwc.me/s/30248) and is dedicated to BraveToazter.

BNW2 contains a total of 100 rooms across 26 exits, with 13 exits for Any% (no secrets/palaces). Most levels are 5-7 rooms in length.

Just like its predecessor, BNW2 is a showcase of glitches that exist within Super Mario World engine.
Some of these glitches (commonly found in "Kuso" hacks) can be extremely precise and require frame-perfect inputs.
My intent was to make the execution of glitches as simple as possible while still being challenging and fun.
Though the custom ASM & graphics prevent BNW2 from being a completely "vanilla" hack, the glitch tech involved *is* vanilla and can be reproduced in the base game.

The FIO™ hint system has returned to help players understand obscure glitch tech: Press SELECT in any room (even at the "Retry" prompt) for a detailed explanation of how to complete the room.

You get automatic midways at every screen transition (door/pipe), except when the room contains an actual midway bar. All checkpoints are saved to SRAM automatically.
Secrets can be found in the first room of marked levels (red dots on overworld).

Have fun and good luck!


  ┌─┐┌─┐┌─┐┌┬┐┬ ┬┌─┐┬─┐┌─┐
  └─┐│ │├┤  │ │││├─┤├┬┘├┤ 
  └─┘└─┘└   ┴ └┴┘┴ ┴┴└─└─┘
────────────────────────────
Lunar Magic v3.31 - FuSoYa                       https://smwc.me/s/32211
UberASM v1.4      - Vitor Vilela                 https://smwc.me/s/32657
Asar v1.81        - Alcaro et al.                https://smwc.me/s/25953
AddmusicK v1.0.8  - Kipernal                     https://smwc.me/s/24994
Effect Tool 3.0   - JackTheSpades, dtothefourth  https://smwc.me/s/23331
GPS v1.4.3        - TheBiob, p4plus2             https://smwc.me/s/31515


  ┌─┐┌─┐┌─┐┌─┐┌┬┐┌┐ ┬ ┬ ┬
  ├─┤└─┐└─┐├┤ │││├┴┐│ └┬┘
  ┴ ┴└─┘└─┘└─┘┴ ┴└─┘┴─┘┴ 
───────────────────────────
Retry System v0.3.4              - Kevin https://smwc.me/t/118748
Disable Scorecard on Level End   - Kevin https://smwc.me/w/32
Disable Intro Level              - Kevin https://smwc.me/w/43
Turnblock Bridge Tile Fix        - Kevin https://smwc.me/w/35
Disable powerup animations       - Kevin https://smwc.me/s/28997
VRAM Optimization                - Kevin https://smwc.me/s/28028
Fix Halo on Overworld            - Kevin https://smwc.me/1599775
Player X Speed Fix v3.0          - HammerBrother, tjb0607 https://smwc.me/s/24862
No More Sprite Tile Limits v1.21 - Arujus, MathOnNapkins, NoelYoshi, Tattletale, Vitor Vilela, edit1754 https://smwc.me/s/24816
Overworld Saving                 - Alcaro, Erik, westlasher2 https://smwc.me/s/24706
Overworld Speed Changer          - wye, carol    https://smwc.me/s/20813
Remove Statusbar                 - Lui           https://smwc.me/s/18862
Victory Pose Fix v1.1            - TheBiob       https://smwc.me/s/22372
Remove "Mario Start"             - Stivi         https://smwc.me/w/54
Single Player Only               - p4plus2       https://smwc.me/s/12380
Automatic Walking v1.1           - mathie        https://smwc.me/s/21731
Custom Cursor                    - MarioFanGamer https://smwc.me/s/29549


  ┌┬┐┬ ┬┌─┐┬┌─┐
  ││││ │└─┐││  
  ┴ ┴└─┘└─┘┴└─┘
─────────────────
Nintendo Presents: Game Boy - Startup                   (Masked Man) https://smwc.me/s/25274
Title: Malmen - Shadowrunner                            (Ahrion)     https://smwc.me/s/32583
Victory: Jikkyou Oshaberi Parodius - Hip Hop Dance Club (Kevin)      https://smwc.me/s/26443

1-OW: Groundseed - Hometown              (Dippy)         https://smwc.me/s/29473
1-YH: Yoshi's Story - Love Is In The Air (Fyre150)       https://smwc.me/s/32585
1-YH-S: Kabuki - YOOO                    (brickblock369) https://smwc.me/s/30425
1-1:  Bomberman 2 DS - Multiplayer Lobby (Teows)         https://smwc.me/s/25277
1-2:  Metropolis Street Racer - Menu     (HaruMKT)       https://smwc.me/s/30901
1-S:  Steven Universe - Amalgam          (RednGreen)     https://smwc.me/s/29125

2-OW: TMNT - Overworld 1                 (Segment1Zone2) https://smwc.me/s/31768
2-1:  Paper Mario - Shooting Star Summit (Fyre150)       https://smwc.me/s/28055
2-2a: Coral Labyrinth                    (Redngreen)     https://smwc.me/s/29127
2-2b: Celeste - Golden Ridge             (Wyatt)         https://smwc.me/s/31881
2-2S: Nintendo Power Menu Program - Menu (Ahrion)        https://smwc.me/s/32103

3-OW: SAR - Crustacean Oscillation (Giftshaven) https://smwc.me/s/31733
3-1:  MFDOOM - Coffin Nails        (BoneFish)   https://smwc.me/s/25612
3-2a: ko0x - Galaxy Guppy          (Beruga1990) https://smwc.me/s/30118
3-2b: Megaman & Bass - Database    (Samantha)   https://smwc.me/s/22643

4-OW: (Same as #1: Groundseed - Hometown)
4-1:  Eek! The Cat - Final Rescue (Kevin)  https://smwc.me/s/29369
4-2:  SchoolboyQ - Collard Greens (mueuen) https://smwc.me/s/30307
4-S:  Smirk - Heidi #7            (Ahrion) https://smwc.me/s/30113

5-OW: Metropolis Street Racer - Menu (HaruMKT)     https://smwc.me/s/30901 (Also used in 1-2)
5-1:  Ducktales - The Moon           (Hooded Edge) https://smwc.me/s/31049
5-S:  Azazel - Polta Taivas          (Ahrion)      https://smwc.me/s/30339

6-OW: Em 022000 - Modern Talking    (Ahrion) https://smwc.me/s/29503
6-1:  Danko - Complications         (Ahrion) https://smwc.me/s/31625
6-2:  EWJ2 - Lorenzen’s Soil        (Kevin)  https://smwc.me/s/25809
6-3a: The Vagrant - Secret Workshop (Wakana) https://smwc.me/s/20964

7-OW: SMH - On The Moon                (worldpeace) https://smwc.me/s/23208
7-1:  ko0x & Blz - Masters of Disguise (Ahrion)     https://smwc.me/s/32635
7-2:  Last Bible 3 - Shark Ship        (Kevin)      https://smwc.me/s/29267

S-OW: HiScore Theme                    (Ahrion)     https://smwc.me/s/32119
S-1:  Unreal ‘99 - Forgone Destruction (Dippy)      https://smwc.me/s/21332
S-2:  DKC:TF - Scorch ‘n Torch         (musicalman) https://smwc.me/s/19821
S-C:  Dubmood - Mario Airlines         (Ahrion)     https://smwc.me/s/33751
S-X:  (Same as Title Screen: Malmen - Shadowrunner)


  ┌─┐┬─┐┌─┐┌─┐┬ ┬┬┌─┐┌─┐
  │ ┬├┬┘├─┤├─┘├─┤││  └─┐
  └─┘┴└─┴ ┴┴  ┴ ┴┴└─┘└─┘
──────────────────────────
Fyre150 - Frogatory              https://smwc.me/s/32733
imamelia, allowiscious - Clouds  https://smwc.me/s/2544
Hayashi Neru - Mountains         https://smwc.me/s/17068
JowTH - Title Font               https://smwc.me/s/6363



  ┬ ┌┐┌┌─┐┌─┐┬ ┬─┐┌─┐┌┬┐  ┌┐ ┬ ┬
  │ │││└─┐├─┘│ ├┬┘├┤  ││  ├┴┐└┬┘
  ┴ ┘└┘└─┘┴  ┴ ┴└─└─┘─┴┘  └─┘ ┴ 
──────────────────────────────────
         ABC_ore: Takumi & Tatsujin series
      mmBeefStew: El Dorado
MicrowaveBrother: O'Ghim
    NewPointless: Mad with Kaizo Power, Learning to Fly
       MegaScott: Akogare
         Fyre150: 10 Yumps
     SimplyAwful: Colors


  ┌─┐┬ ┬┌─┐┬ ┬┌┬┐┌─┐┬ ┬┌┬┐┌─┐
  └─┐├─┤│ ││ │ │ │ ││ │ │ └─┐
  └─┘┴ ┴└─┘└─┘ ┴ └─┘└─┘ ┴ └─┘
───────────────────────────────
Goon Nation
Juzcook
Jikurein
YouFailMe
ThirdWall
Caioskii
Morpha
Caspur
Simplyawful
Fryinb
Spacepig
Brakkie
Wolfguy
spratt


  ┌┬┐┌─┐┌─┐┌┬┐┌─┐┬─┐┌─┐
   │ ├┤ └─┐ │ ├┤ ├┬┘└─┐
   ┴ └─┘└─┘ ┴ └─┘┴└─└─┘
─────────────────────────
BraveToazter
Kurtistrydiz
My wife's patience
Zapplex
CardboardCell
Megascott
LouisDoucet
RBPimlico
BabaYegha


  ┌┬┐┬ ┬┌─┐ ┌┐┌ ┬┌─┌─┐
   │ ├─┤├─┤ │││ ├┴┐└─┐
   ┴ ┴ ┴┴ ┴ ┘└┘ ┴ ┴└─┘
────────────────────────
My Wife & Family
Sandman
Ahrion
Voipah
SMWCentral
