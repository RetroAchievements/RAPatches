==============================================================================
=                                  WELCOME                                   =
==============================================================================
Welcome to the readme that 90% of you probably won't read, and that's okay!
None of the information here is required to know before playing the hack.
However, you'll find more in-depth explanations regarding the pause menu as
well as any relevant technical details about this hack.

Note that these levels are longer than what you are probably used to (on
average, each section ranges between 40-60 seconds, with most levels having
2 sections). And if you have played Super Dram World 1 or 2, the difficulty
of the levels in this hack are much greater. It will not be an easy journey.
Don't worry though, I'm sure there's still jank to be found.

100% completion is achieved by beating all 28 exits. Any yumps achieved and
portraits found are merely bonuses.

This hack relies heavily on camera manipulation. If you find that the screen
does not scroll when it needs to, you are either doing the obstacle in an
unintended way, or something actually broke. Hopefully it's the former.

Lastly, here is a link to a list of music I used in the hack:
https://docs.google.com/spreadsheets/d/1hXbiDbkVZl1qHxdSqwvU3DqFyOUnZ4-C60OEsZV-XHA/edit?usp=sharing

Thank you so much for downloading Super Dram World 3. I sincerely hope you
enjoy playing this hack as much as I enjoyed making it.

Disclaimer: if you play with savestates, I recommend either turning them off
or rebinding the hotkey since this hack uses select+L+R to reset some stuff.

Currently known bugs:
- Dying with the menu retry on while an ON/OFF block is hit will send it to
  the moon (I am calling this a feature)

==============================================================================
=                                 PAUSE MENU                                 =
==============================================================================
This hack features a custom pause menu that lets you perform various
actions. Use the D-Pad to move and A or B to select. Use L or R to hide
the menu. Note that there is still a pause timer (just like in vanilla SMW),
which prevents pausing and unpausing the game immediately.

---------------------
- Main Menu Options -
---------------------
RESUME:           Unpauses the game. Note that if you are on the ground, you
                  will jump as a result (unless you unpause by pressing start)
                  If you want to toggle a jump input by pausing, this can
                  be achieved by either:
                      - holding the jump button on RESUME while the pause
                        timer is active and unpausing by pressing start, or
                      - hiding the menu, then holding the jump button and
                        unpausing by pressing start
SETTINGS:         See settings options below
RESET CHECKPOINT: Allows you to go back to the beginning of the level (don't
                  worry, there is a confirmation prompt)
QUIT LEVEL:       This can also be achieved by pressing select (anywhere)
	
---------------------
- Settings Options  -
---------------------
Note that you cannot unpause the game while in this menu (unless you hide
the menu using L/R).

MUTE:  Mutes the music ON or OFF. Note that restoring the volume when
       unmuting is slightly jank, so it might be quieter or louder than
	     normal. Exiting and re-entering the level will fix this
RETRY: Toggles the retry behavior of the level you are currently in
           - FAST instantly restarts the level upon death
           - MENU shows a prompt on the bottom-left corner of the screen upon
             death. Useful if you want to see the screen after dying to figure
		         out what to do in the level
ICON:  Toggles an offscreen indicator ON or OFF when above or below the level
           - SCALE will draw the indicator towards the center of the screen,
             depending on how high above the screen you are. This does not
             apply to the bottom of the screen
PAUSE: Instantly pauses the beginning of the level until you press ANY
       button. This includes the run buttons. Useful for seeing the very
       first jump/obstacle
METER: Displays a graphical meter for certain values. This value varies
       depending on the level (i.e. blue P-Switch timer, P-Meter, etc.).
       Only 1 value is displayed per level
BACK:  Return to the main menu

==============================================================================
=                             TECHNICAL DETAILS                              =
==============================================================================
There have been a plethora of patches and fixes inserted into this hack to
(ideally) make your experience more pleasant and less janky! Here is a list
of the ones that you would probably care about:

-------------------
- Physics Changes -
-------------------
- No oscillation at max speeds (walking, running, flying, swimming, sliding)
- Interaction with sprites every frame (bomb explosions included)
- No cape float delay (letting go or jump begins descent immediately)
- Consistent cape turnaround (sorry vanilla-capers)
- Cape-spin hitbox activates on both sides every frame
- Throw in the direction you're pressing, always, no exceptions (while
  spin-jumping, cape-spinning, etc.)
- Spit out sprites in the direction you're pressing while riding Yoshi
  (even while in mid-turning animation)
- Disable player interaction timer is now actually set for sprites when
  spitting them out with Yoshi
- No shooting fireballs while spin-jumping
- Grabbing/throwing springboards does not stop your momentum
- Proximity wraparound fix (i.e. no triggering proximity-based sprites while
  on the edge of the screen)
- P-Balloon speeds are doubled (only relevant for one section of a level)

----------------------------
- Quality of Life Features -
----------------------------
- Pause menu features
- Start + select to exit any level
- Re-enter castles and switch palaces (you can use A or B instead of L + R)
- Each level unlocks immmediate access to its respective checkpoint AFTER
  beating it for the first time
- Football RNG is consistent (low-medium-high bounce pattern repeating)
- ON/OFF state cooldown (in case you activate two or more ON/OFF blocks
  within a small period of time)
- Throwblock jump-grabs are now a 2-frame window (pressing grab and then jump
  a frame later works, and vice versa). This also applies to keys and
  the propeller block sprite
- Kicked sprites will trigger offscreen blocks
- Fireballs shot while slightly offscreen will not despawn immediately
- Dismount off of Yoshi with L or R (using A still works. Note that L/R only
  dismounts and doesn't act as a jump input while held)
- Sprites will be knocked in a consistent direction when hitting the block
  below them

--------------------------------------
- "Accidentally Frame-Perfect" Fixes -
--------------------------------------
- Wall-jumping is disabled (sorry TAS'ers)
- X-speed is always set to 0 while grabbing throwblocks
- No spin-jumping on noteblocks, ever (the SFX will still play, though)
- No stomping on a sprite and eating it on the same frame
- Throwblocks will not break when thrown upwards at certain ceilings and
  blocks (rather than "clipping" the side and breaking)
- Carryable items will always activate certain blocks when thrown upwards
  (rather than "clipping" the side and not activating whatever block it's
  hitting)

==============================================================================
=                              VERSION HISTORY                               =
==============================================================================
Version 1.3
- Fixed an issue where the game would freeze in certain levels while playing
  with some emulators
- Fixed an issue where a grey winged platform would despawn in one of the
  rooms in "CLASSIC TROPE CASTLE"
- Fixed being able to go through some of the pillars in "THE CETACEAN'S DARK
  TRANSFORMATION"
- Slightly modified the tutorial room in "RESURRECTIONS"
- Removed an unintended extra block in "RED SWITCH PALACE"
- Removed cheese that skipped a significant portion of "N.A. AIM"
- Slightly modified a name in the ending credits

Version 1.23
- Fixed the mute option not working in levels "PABLO'S PARADISE" and "SKYZO
  CITY"

Version 1.22
- Fixed a softlock in "EXIT THIS EARTH'S ATOMOSPHERE"
- Fixed a checkpoint in "FOR ULTRA PLAYERS"

Version 1.21
- Modified the colors in "WELCOME TO SHELL" to be more color blind-friendly
- Slightly modified the graphics in "CHIPOTLE GOUDA BRIDGE"
- Slightly modified the name of the portrait in "NOSTALGIA STAR"
- Fixed a typo in the ending credits
- Fixed a typo in "POST GAME"

Version 1.2
- Fixed a misaligned hitbox with bullet bills
- Fixed an ON/OFF block that would sometimes not trigger when hit with an
  upthrown item
- Fixed a typo in the ending credits
- Fixed an issue where the camera would not scroll in "GROWN MAN'S WILD RIDE"
- Fixed a potential softlock in "RESURRECTIONS"
- Fixed a bug that allowed a mid-air jump in "EXIT THIS EARTH'S ATOMOSPHERE"
- Fixed a screen barrier issue in "JUMPING OVER IT"
- Fixed misplaced blocks and sprites in some of the rooms of "FOR ULTRA
  PLAYERS"
- Slightly modified and added additional indicators to a few setups

Version 1.13
- Minor fix in the retry system

Version 1.12
- Minor fix in the boss room of "CLASSIC TROPE CASTLE"

Version 1.11
- Minor graphical fix

Version 1.1
- Fix a bug in the Mechakoopa room of "CLASSIC TROPE CASTLE"
- Fixed cutoff in "CHIPOTLE GOUDA BRIDGE"
- Slightly modified and added additional indicators to a few setups

Version 1.0
- First public release
- The code is 69420