STORY


Eleven years ago, Mario left his garage door up. This has made a lot of people very angry, and has been widely regarded to be a bad move. How, eleven years later, his sins repeat, and he finds he must once again travel home to right his wrongs.


WHAT TO EXPECT IN THIS HACK


Mario left the Garage Door Open Again is a chocolate-lite Kaizo Light hack, with easy to medium difficulty, starting easier and curving upwards to medium towards the end. As I am not a Kaizo player, or even really a big SMW fan, the hack's design has been described as rather odd by the play testers, so expect to go "what" a lot. There are also no trolls and traps. Trolling is boring. Mischief is the new meta.


WHY IS THIS EVEN A THING, PLEASE TELL ME YOUR LIFE'S STORY


Okay, you don't have to shout.

In the early 2000s I was a member of the Acmlm's Board community, going by Samus Aran or Marzen. I never made anything important, certainly nothing you'd care about (most of what I did was make two levels and give up in SMB3 or something), but it was a place for me to hang out and share in a fun hobby with friends. In the late 2000s I grew out of it, but that was right when SMW hacking started picking up. So I really hunkered down and tried my hand at making a romhack.

In 2009, I did that. Mario Left The Garage Door Up, a "one and a half world" long romhack. It's honestly god awful, lots of cookie cutter design, and it literally only runs in ZSNES, cause that's what we had back then. I show it off sometimes to friends, but that's it. I never really tried to make anything else, because I'm not even a big fan of SMW. I'm a Sonic kid (as you can tell by my musical choices in this hack).

So, fast forward eleven years. I become good friends with some members of the Kaizo community. At the time I wasn't a fan of Kaizo, I thought the whole point was to be rude and make bad level design, and it made no sense to me. But my friends help me see the creativity and fun that can be had through it, so I start crafting the dumb idea of reviving my "series". Three months and a lot of work and help from those friends later, I have the sequel to my hack you've never played or heard of (It wouldn't be accepted to this site even if I submitted it).

As I had never played a Kaizo game before this (I've since played Quickie World 2, it's good), the design is apparently very very odd, like if we were in a bizarro world and the meta of modern Kaizo hacks were just slightly different.

Thanks for reading this unnecessary backstory, hopefully you found it mildly entertaining. Enjoy the hack!


SPECIAL THANKS


Special thanks to Amethyst_Rocks, shovda, UndeadBlackBird, and iIIustrious for helping playtest this hack and make it not god awful bad. Credits are in the actual game for everyone who did everything. Shout outs to shout outs.