﻿達人マリオ PART 1/2 (Tatsujin Mario part 1/2)

Mario is small-only in part 1/2.
Power-ups, Yoshi and so on are in part 2/2.

This hack requires a lot of glitches and techniques.
Some stages require TAS-like techniques.
I cleared this using gamepad and keyboard without emulator functions.
I recommend using emulator functions as this hack is very difficult.

When Mario is on the overworld, the item box and power-up are reset.
The midway point bar doesn't make Mario big.
Wrong warp bug (entering a door/pipe 256 times) has been patched.

Documents
The SMW Glitch List - SMW Central
 http://www.smwcentral.net/?p=viewthread&t=72499
マリオワールドテクニック一覧　-　ゆとりTAS日記
 http://ism140.blog.shinobi.jp/%E3%83%9E%E3%83%AA%E3%82%AA%E3%83%AF%E3%83%BC%E3%83%AB%E3%83%89%E3%83%86%E3%82%AF%E3%83%8B%E3%83%83%E3%82%AF/%E3%83%9E%E3%83%AA%E3%82%AA%E3%83%AF%E3%83%BC%E3%83%AB%E3%83%89%E3%83%86%E3%82%AF%E3%83%8B%E3%83%83%E3%82%AF%E4%B8%80%E8%A6%A7

Special Thanks
test play and check - MIYABI,うずめ,災難,幕の内 
patch - ステンス,ゴブリン退却部隊,Noobish Noobsicle

The solution of the opening level
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
↓
First: Collect five Yoshi coins.
Second: Enter the last door using key.
Third: Scroll left in front of goal.
Finally: Touch goal tape.