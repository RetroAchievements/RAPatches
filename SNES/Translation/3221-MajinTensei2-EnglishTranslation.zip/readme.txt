Use with:

Majin Tensei II - Spiral Nemesis (Japan).sfc	(No-Intro)
8e21174afb7fdcc060b71bfb7f1feb1e
31B2B1B4