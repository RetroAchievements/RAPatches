Use with:

Emerald Dragon (Japan).sfc	(No-Intro)
50de817422dec36b9266cc6aacf9e44e
9D0F5F98