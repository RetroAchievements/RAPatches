Use with:
Rudra no Hihou (Japan).sfc (No-Intro)
e5ffb8ca8331076037a32db94627518c
5D8CB7AC