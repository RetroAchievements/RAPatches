Use with:
Magical Pop'n (Japan).sfc (No-Intro)
e47f184fd5d2285bcc4ee07d990f5375
C49D28A4