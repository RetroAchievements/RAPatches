Use with:
Final Fantasy III (USA) (Rev 1).sfc (No-Intro)
544311e104805e926083acf29ec664da
C0FA0464