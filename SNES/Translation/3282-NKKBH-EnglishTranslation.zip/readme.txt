Use with:
Nekketsu Tairiku Burning Heroes (Japan).sfc (No-Intro)
900ecfb892e63d89e3a46eb2c4a8dc8e
DA105A27