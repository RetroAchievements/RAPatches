Use with:
Magical Quest Starring Mickey Mouse, The (USA) (Rev 1).sfc (No-Intro)
56f6c071c5b83b60333ddc830273b274
BB24ECE5