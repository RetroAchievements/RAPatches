Use with:

(No Intro)
Mega Man X (USA).sfc
a10071fa78554b57538d0b459e00d224
1033EBA4