Use with:
Dragon Ball Z - Super Saiya Densetsu (Japan) (Rev 1).sfc (No-Intro)
0fa7887f1bcde2dd207e20d782092607
ADE7B968