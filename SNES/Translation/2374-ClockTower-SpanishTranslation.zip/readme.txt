Use with:
Clock Tower (Japan).sfc (No-Intro)
51f8a9e95ec58fa5b9c3ec2da530d598
CBCD0DAD