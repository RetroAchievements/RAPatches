Use with:
Sparkster (Europe).sfc (No-Intro)
03b64e37d5b5f8b92e8681940f2e0f75
F43C155C