Use with:
Live A Live (Japan).sfc (No-Intro)
c223de99d22665b62c91e02727963bd4
6291EE08