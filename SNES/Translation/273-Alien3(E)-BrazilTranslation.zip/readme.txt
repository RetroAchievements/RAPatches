Use with:
Alien 3 (Europe).sfc [No-Intro]
0f10ec520fbdbb009f97333b59ff8d49
378613B0