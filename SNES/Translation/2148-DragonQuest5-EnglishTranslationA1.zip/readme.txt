Use with:
Dragon Quest V - Tenkuu no Hanayome (Japan).sfc [No-Intro]
d8e95e744e66e7ec30d9591f71dafd0a
BC955F3B