Use with:

Crystal Beans from Dungeon Explorer (Japan).sfc	(No-Intro)
18c356623ae0407119ceae8c06edfa7a
79663A93