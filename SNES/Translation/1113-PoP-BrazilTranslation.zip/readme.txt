Use with:
Prince of Persia (USA).sfc (No-Intro)
8ffc8d34bc75bc049122894b4292eb85
891BB2BB