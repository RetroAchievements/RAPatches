Use with:

Slayers (Japan).sfc	(No-Intro)
1b7b9b3eabe1008bad9dc19dcad9142f
0B610445