Use with:

Fire Emblem - Monshou no Nazo (Japan) (Rev 1).sfc	(No-Intro)
0cb432dd9d5c1afa5048334b110fddc0
A427B7E6