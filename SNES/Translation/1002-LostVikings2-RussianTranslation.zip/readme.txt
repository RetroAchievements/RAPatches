Use with:
Lost Vikings 2 (USA).sfc (No-Intro)
6808b453828d6a6f228e3225055df4c4
3AA01DBD