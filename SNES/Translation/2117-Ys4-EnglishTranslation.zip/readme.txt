Use with:

Ys IV - Mask of the Sun (Japan).sfc	(No-Intro)
a4e5ed2dbd1e3612917b91ab58e6feea
CA7B4DB9