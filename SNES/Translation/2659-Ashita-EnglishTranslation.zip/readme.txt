Use with:

Ashita no Joe (Japan).sfc	(No-Intro)
c7f80eb13ad9ee5fb5598b24002b6113
6B54BE97