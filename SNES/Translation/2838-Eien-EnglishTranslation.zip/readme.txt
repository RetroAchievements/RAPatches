Use with:

Eien no Filerna (Japan).sfc	(No-Intro)
50de817422dec36b9266cc6aacf9e44e
41E9CD70