Use with:

Dual Orb II (Japan).sfc	(No-Intro)
eb42510c01054711bcf04346aba7ed2f
E8798F65