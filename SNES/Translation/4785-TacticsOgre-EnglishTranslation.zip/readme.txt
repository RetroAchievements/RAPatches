Use with:

Tactics Ogre - Let Us Cling Together (Japan) (Rev 2) (NP).sfc	(No-Intro)
e60fef5d311e06ab16a127f1c7718958
12F0A699