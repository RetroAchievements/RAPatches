Use with:

Dark Law - Meaning of Death (Japan).sfc		(No-Intro)
d58849487d0ab3038f5f9cc38efc8602
125A0C22