Use with:

File:               Tales of Phantasia (Japan).sfc (No-Intro)
BitSize:            48 Mbit
Size (Bytes):       6291456
CRC32:              E9946B84
MD5:                207CD1C0AAACA29FAA389218B800F8FC