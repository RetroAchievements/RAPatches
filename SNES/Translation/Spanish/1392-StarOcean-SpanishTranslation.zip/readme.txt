Use with:

(No Intro)
File:               Star Ocean (Japan).sfc
BitSize:            48 Mbit
Size (Bytes):       6291456
CRC32:              3DBDFDBF
MD5:                D686BA6DF942084216393ADA009126DC