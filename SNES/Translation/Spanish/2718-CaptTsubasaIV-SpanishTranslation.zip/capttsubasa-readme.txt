Use with:

(No Intro)
File:               Captain Tsubasa IV - Pro no Rival-tachi (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              3E04B246
MD5:                CB99EDFC9514036D6E5FD1E128937328
