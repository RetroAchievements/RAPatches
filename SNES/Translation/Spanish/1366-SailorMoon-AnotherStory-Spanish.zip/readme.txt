Use with:

(No Intro)
File:               Bishoujo Senshi Sailor Moon - Another Story (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              02A442B8
MD5:                5F776488E366B6D6B44F6E8A01D9953D
SHA1:               137F84BA5D0736B887213E0C0CABD0649BBBAFC7
SHA256:             B85F5970EA619B7A6671A4DE8CCE430E2654A2E5BBEF5E74EF35D4702DADB67B