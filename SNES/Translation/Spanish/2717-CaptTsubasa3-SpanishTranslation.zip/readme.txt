Use with:

(No Intro)
File:               Captain Tsubasa III - Koutei no Chousen (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              26B0CEE3
MD5:                3ECAD6D88BEFDE8B2BD96C94927B86B2