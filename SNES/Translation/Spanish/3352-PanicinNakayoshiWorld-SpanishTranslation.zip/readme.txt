Use with:

No Intro
Panic in Nakayoshi World (Japan).sfc
340ac051810666f085165f8913e0ba7
7AC3C0C6