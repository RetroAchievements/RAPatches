Use with:

Seiken Densetsu 3 (Japan).sfc (No-Intro)
58ebd7cbf28ceadc03aec4f448956a0b
863ED0B8
