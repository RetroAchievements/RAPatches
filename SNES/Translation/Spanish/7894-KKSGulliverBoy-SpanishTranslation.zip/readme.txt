Use with:

(No Intro)
File:               Kuusou Kagaku Sekai Gulliver Boy (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              F3F8A200
MD5:                26BE7C4B848871EA38FAFCF0BD4980E0