Use with:

(No Intro)
File:               Ihatovo Monogatari (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C588CD17
MD5:                B9AE4D372BEE326846B0778E3B34533B
SHA1:               43983938960D0547B4A5585D04E7336D931FB79E
SHA256:             B3BB23B92E91CA25DD071493451FFE937AE1D281C0995C60F44B04F49AD0DBEB