Use with:

(No Intro)
File:               Alcahest (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       1048576
CRC32:              870427D0
MD5:                092CAAE477250249943F2F026DAA0A5