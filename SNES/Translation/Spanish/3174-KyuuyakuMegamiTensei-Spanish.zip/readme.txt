Use with:

(No Intro)
File:               Kyuuyaku Megami Tensei (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              C8D286C9
MD5:                9918DBF3F0D349CAC24631BDF77939F3
SHA1:               827F6E0534E2317E3348CE76BD47BEC8691B3563
SHA256:             FFDC7F254C6D965D481918E7D53A451F94F6B1CB035383AE3DFC8F3B5895DE3B