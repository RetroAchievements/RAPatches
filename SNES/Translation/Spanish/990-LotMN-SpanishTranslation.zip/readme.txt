Use with:

(No Intro)
File:               Legend of the Mystical Ninja, The (USA).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              82479D6A
MD5:                BF6DA6F13729C8925D8725D7DD25B420
SHA1:               E7DB9B1220D66BC8665FE2761AC396DC28BFD88C
SHA256:             C865FB17E8C59A21D32B9A605319241FA74EC732E3F0EE58F5D7FCBD8EE57C6B