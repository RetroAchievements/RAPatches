Use with:

(No Intro)
File:               Tetris Battle Gaiden (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              B8F5F846
MD5:                F21E1FEFCB3187877060B3FAFB53ABD2
SHA1:               E455607B32B0ADF14BF4AF917CBF6561ECCD1D0D
SHA256:             7A96458B60507B60B581B7A1BA32F2855CFF18D6F13BFEB45AD161DD469C5C61