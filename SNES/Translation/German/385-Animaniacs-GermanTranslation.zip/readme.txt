Use with:
Animaniacs (Europe).sfc [No-Intro]
ce41fb926db8fcaad4665774f3731b7a
C28A80F6