Use with:

(No Intro)
File:               Ganbare Goemon Kirakira Douchuu - Boku ga Dancer ni Natta Wake (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              BB9D8E56
MD5:                A53BEE4978D7C8E13CDEC5151207DE54
SHA1:               EE71384E286F088508A736B7305AD5EFECFBCC1A
SHA256:             6F0C79C2BF342F33EA265A7343E3F1C163B49C32F6E4A717BF5F3C6FCBF576DE