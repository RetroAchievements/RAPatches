Use with:

(No Intro)
File:               Ganbare Goemon - Yuki Hime Kyuushutsu Emaki (Japan) (Rev 2).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              6CD62399
MD5:                8478D65A49CCD0FE68CEFC6757153730
SHA1:               0E0F23D415F4EAFF718CB062C5B6A187E1303B01
SHA256:             9FC2D2DA1D1153A7D54DB066F81EE43347228458792BD1F042CAB065A35C02D8