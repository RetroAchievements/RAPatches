Use with:

Nangoku Shounen Papuwa-kun (Japan).sfc	(No-Intro)
6a2d887f7aa9a1dd5187dc573b26156d
8BDA9255