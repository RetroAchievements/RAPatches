Use with:

Bike Daisuki! Hashiriya Tamashii (Japan).sfc	(No-Intro)
9bc21069d1c9eba86dad2ba0e994e5a1
B363FC99