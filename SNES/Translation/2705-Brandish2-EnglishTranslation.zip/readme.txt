Use with:

Brandish 2 - The Planet Buster (Japan).sfc	(No-Intro)
16647a6edc60975425d52c255c4c8523
BB89E67E