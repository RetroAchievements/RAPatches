Use with:
Tenchi Muyou! - Game Hen (Japan).sfc (No-Intro)
2402f5886f141c8c81ad863b1f603975
69D9CAA9