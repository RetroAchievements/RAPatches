Use with:

Treasure Hunter G (Japan).sfc	(No-Intro)
b1774fc2e0af8427fd3bcf116a4ec0e0
3CCEED49