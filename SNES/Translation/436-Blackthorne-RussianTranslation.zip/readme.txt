Use with:
Blackthorne (USA).sfc [No-Intro]
ee33097d436b4901a71f7e4c9a5cb409
856BEAB1