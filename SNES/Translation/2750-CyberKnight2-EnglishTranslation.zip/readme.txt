Use with:

Cyber Knight II - Chikyuu Teikoku no Yabou (Japan).sfc	(No-Intro)
4244bb90aa722836b746be0574351874
ED8BCBF4