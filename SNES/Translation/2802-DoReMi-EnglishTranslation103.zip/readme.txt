Use with:
DoReMi Fantasy - Milon no Dokidoki Daibouken (Japan).sfc [No-Intro]
19b64f594ffd4c312ffee6af1102ec7d
9F2C2633