Use with:

Dark Half (Japan).sfc		(No-Intro)
55108013f875db3b39da04b8f58489ab
7B9793B1