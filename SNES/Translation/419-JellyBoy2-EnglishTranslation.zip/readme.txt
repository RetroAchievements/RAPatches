Use with:

Jelly Boy 2 (Japan) (Proto).sfc	(No-Intro)
9da4e7cb3815962583ae5dea60593d04
F3A6C574