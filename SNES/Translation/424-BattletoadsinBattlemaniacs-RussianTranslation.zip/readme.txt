Use with:
Battletoads in Battlemaniacs (USA).sfc [No-Intro]
e44b9987e33ef7237b24457a6c997723
617AC925