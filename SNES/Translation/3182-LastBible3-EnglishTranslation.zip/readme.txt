Use with:

Last Bible III (Japan).sfc	(No-Intro)
4c836f4924544f8160dab3260f43a732
5F1D73D7