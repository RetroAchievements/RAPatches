Use with:
Kishin Douji Zenki - Battle Raiden (Japan).sfc (No-Intro)
2152cca035b8e3080d9eddb5bea8d94d
0BECFC92