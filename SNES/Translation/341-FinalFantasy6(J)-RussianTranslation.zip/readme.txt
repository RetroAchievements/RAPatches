Use with:
Final Fantasy VI (Japan).sfc (No-Intro)
97bf78e916b80f47cf35edf502be34dc
45EF5AC8