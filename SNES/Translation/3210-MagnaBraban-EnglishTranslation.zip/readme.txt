Use with:

Magna Braban - Henreki no Yuusha (Japan).sfc	(No-Intro)
dcec157fb9e6bf1bda288996b0ef75d9
5F86ADA5