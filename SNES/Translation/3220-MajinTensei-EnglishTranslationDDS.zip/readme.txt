Use with:

Majin Tensei (Japan).sfc	(No-Intro)
0fe71f9a99ec8dfcb14e0195c9ac3940
C1B5D46A