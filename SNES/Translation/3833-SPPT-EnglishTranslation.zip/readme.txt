Use with:

Super Puyo Puyo Tsuu (Japan).sfc	(No-Intro)
d19486b22c8a4f11aa969671ae1967b2
271E1F3F