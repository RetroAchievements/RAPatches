Use with:
Dragon Quest VI - Maboroshi no Daichi (Japan).sfc [No-Intro]
ac9955fa4c1aa8ebcc1d09511808c58b
33304519