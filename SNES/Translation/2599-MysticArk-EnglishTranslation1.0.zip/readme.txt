Use with:
Mystic Ark (Japan).sfc (No-Intro)
540e82f13ad57a2c6ffc0e14e3f61098
FEB80589