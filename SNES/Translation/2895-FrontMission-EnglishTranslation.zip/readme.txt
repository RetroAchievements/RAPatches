Use with:
Front Mission (Japan) (Rev 1).sfc (No-Intro)
7d557d4ee07b3ced3240d636a57b8bd0
50278B21