Use with:
Front Mission (Japan).sfc [No-Intro]
8098a3d165fff3e4d786e2902d21fd2c
FE27E061