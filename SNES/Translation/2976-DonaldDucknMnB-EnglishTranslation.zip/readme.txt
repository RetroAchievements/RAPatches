Use with:
Donald Duck no Mahou no Boushi (Japan).sfc [No-Intro]
c7cf4c193dc8600d8c2a02ee728023f4
1ED5D2FA