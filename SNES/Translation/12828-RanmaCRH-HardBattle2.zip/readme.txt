Use with:
Ranma 1-2 - Chougi Ranbu Hen (Japan).sfc (No-Intro)
8c7dfc3dc5d13b145fc116dbcb84521b
0C552B1F