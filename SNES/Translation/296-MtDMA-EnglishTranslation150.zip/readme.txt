Use with:
Mickey to Donald - Magical Adventure 3 (Japan).sfc (No-Intro)
4b87392aaf03517d3f45ebf06eb2d4bc
32EEA1E9