Use with:
Super Back to the Future Part II (Japan).sfc (No-Intro)
427fe52b3883ee077bf189476492c2f0
B367D0B9