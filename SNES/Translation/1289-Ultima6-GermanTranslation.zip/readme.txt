Use with:
Ultima - The False Prophet (USA).sfc (No-Intro)
b99e36b9e0e84bce7d3e399bab2aee3f
9277C9F7