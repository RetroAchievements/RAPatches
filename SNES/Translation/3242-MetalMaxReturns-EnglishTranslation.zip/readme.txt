Use with:

Metal Max Returns (Japan).sfc	(No-Intro)
5c6821cb81c5b8f2b25f27b4030b21d7
4396A35B