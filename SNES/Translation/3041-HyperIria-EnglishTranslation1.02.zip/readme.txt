Use with:
Hyper Iria (Japan).sfc (No-Intro)
32314ad978deecd5fef5ad5e55906d1e
AE7F2B0D