Use with:
Marvel Super Heroes in War of the Gems (USA).sfc (No-Intro)
d3c46f884c50f50236639c5f6303eef7
00AF56E8