Use with:

Chaos Seed - Fuusui Kairouki (Japan).sfc	(No-Intro)
ab6cbbe55068a36718e223ee98090946
76E01CCB