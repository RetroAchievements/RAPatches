Use with:

Fire Emblem - Thracia 776 (Japan).sfc	(No-Intro)
c3fd1cad754256d7a013864d917f47fa
FC519952