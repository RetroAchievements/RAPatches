~Fushigi no Dungeon 2 - Fuurai no Shiren (Japan) (En) (1.0) (Aeon Genesis)~

Fushigi no Dungeon 2 - Fuurai no Shiren (Japan).sfc	(No-Intro)
8c8fc738eae4eb714b43889767daf094
AF5703EE



~Fushigi no Dungeon 2 - Fuurai no Shiren (Japan) (Rev1) (En) (1.0) (Aeon Genesis)~

Fushigi no Dungeon 2 - Fuurai no Shiren (Japan) (Rev 1) (NP).sfc	(No-Intro)
6cdd5607e78d7f240ea7aa85565c97c2
824AA6B5