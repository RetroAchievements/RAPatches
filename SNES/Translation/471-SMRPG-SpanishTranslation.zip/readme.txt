Use with:
Super Mario RPG - Legend of the Seven Stars (USA).sfc (No-Intro)
d0b68d68d9efc0558242f5476d1c5b81
1B8A0625