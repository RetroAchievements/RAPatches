Use with:

Cyborg 009 (Japan).sfc	(No-Intro)
0be736bb76d0a5cce320886570382362
4A5263DB