Use with:

Neugier - Umi to Kaze no Kodou (Japan).sfc	(No-Intro)
d7289c3133e50cb6a3738d9fbc69769e
7F0DDCCF