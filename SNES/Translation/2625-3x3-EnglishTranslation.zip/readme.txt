Use with:

3x3 Eyes - Juuma Houkan (Japan).sfc		(No-Intro)
7e55ee60aa3f1e37f7a7a006201ec035
AD4AD163