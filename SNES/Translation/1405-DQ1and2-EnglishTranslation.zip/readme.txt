Use with:
Dragon Quest I & II (Japan).sfc [No-Intro]
1def71b5557cc6bb7402281d888cae80
98BB6853