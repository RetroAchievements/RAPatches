Use with:
Bishoujo Senshi Sailor Moon - Another Story (Japan).sfc [No-Intro]
5f776488e366b6d6b44f6e8a01d9953d
02A442B8