Use with:

Captain Tsubasa IV - Pro no Rival-tachi (Japan).sfc	(No-Intro)
cb99edfc9514036d6e5fd1e128937328
3E04B246