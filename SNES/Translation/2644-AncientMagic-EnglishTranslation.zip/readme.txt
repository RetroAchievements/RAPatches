Use with:

Ancient Magic - Bazoe! Mahou Sekai (Japan).sfc	(No-Intro)
decbc035448e68dc899a1db456e77afd
D5B09EEF