Use with:
Addams Family Values (Europe) (En,Fr,De).sfc [No-Intro]
a89681df8060e78bde0dd8340c209649
FE85E2F2