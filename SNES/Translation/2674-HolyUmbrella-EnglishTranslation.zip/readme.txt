Use with:
Holy Umbrella - Dondera no Mubou!! (Japan).sfc (No-Intro)
69d50aa193e7b3988c761f96c5dcdd5a
F0A9DEAD