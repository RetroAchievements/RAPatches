Use with:
Star Ocean (Japan).sfc (No-Intro)
d686ba6df942084216393ada009126dc
3DBDFDBF