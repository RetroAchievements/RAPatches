Use with:

Gourmet Sentai Barayarou (Japan).sfc	(No-Intro)
b29ea2c67d6ecabf99c22829058f710b
9F717D76