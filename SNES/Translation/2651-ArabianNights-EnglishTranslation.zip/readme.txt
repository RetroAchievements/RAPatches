Use with:

Arabian Nights - Sabaku no Seirei Ou (Japan).sfc	(No-Intro)
eb1ad755da3310f392cf8bc94962612e
B6DBF57B