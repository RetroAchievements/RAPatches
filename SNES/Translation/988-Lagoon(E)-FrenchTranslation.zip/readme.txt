Use with:

Lagoon (Europe).sfc	(No-Intro)
3aeb9114483f6646a10c1afaa0532aac
840D0C53