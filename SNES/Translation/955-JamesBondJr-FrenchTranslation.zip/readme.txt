Use with:

James Bond Jr (USA).sfc	(No-Intro)
40bc3a750d8adeaaf15abdaaa6db9ee0
69C2F850