Use with:

Marvelous - Mouhitotsu no Takara-jima (Japan).sfc	(No-Intro)
b9b77e5f378b871ece75caba82718a8e
CEDF3BA7