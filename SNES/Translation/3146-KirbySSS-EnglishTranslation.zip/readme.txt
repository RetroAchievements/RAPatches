Use with:
Kirby no Kirakira Kids (Japan).sfc (No-Intro)
7bab28c964f9306b161bbef8871e17a7
035265BF