Use with:
Majuu Ou (Japan).sfc (No-Intro)
c48199b6996211ac200b8b2daafc18ef
4737370B