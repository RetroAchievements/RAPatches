Use with:

Tengai Makyou Zero (Japan).sfc	(No-Intro)
29998124a67deda111d5aca8aaf5dca5
1E327BD9