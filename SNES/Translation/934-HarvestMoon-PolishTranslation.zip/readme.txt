Use with:
Harvest Moon (USA).sfc (No-Intro)
c9bf36a816b6d54aed79d43a6c45111a
F829129E