Use with:
Tenchi Souzou (Japan).sfc (No-Intro)
5bec2d7ecf3117b479c69cada8ebafa4
3CC7FDF4