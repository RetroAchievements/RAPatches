Use with:

(No Intro)
Metal Max Returns (Japan).sfc

CRC32:              4396A35B
MD5:                5C6821CB81C5B8F2B25F27B4030B21D7
