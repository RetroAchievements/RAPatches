Use with:
Great Battle IV, The (Japan).sfc (No-Intro)
771f518a8035740cc017287d2e5a7889
FB165A32