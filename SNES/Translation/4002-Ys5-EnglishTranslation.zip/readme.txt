Use with:
Ys V - Ushinawareta Suna no Miyako Kefin (Japan).sfc (No-Intro)
f630c6e0f11fd53d112f3dd004ea7184
5E08C48C