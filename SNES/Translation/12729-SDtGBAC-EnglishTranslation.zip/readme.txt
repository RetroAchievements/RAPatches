Use with:
SD The Great Battle - Aratanaru Chousen (Japan).sfc (No-Intro)
d952a16db6a4154f877a6713f9da9172
38726EC1