Use with:

Dragon Ball Z - Super Gokuu Den - Totsugeki Hen (Japan).sfc	(No-Intro)
8bd89634d1b2205b1e7ef016485c0076
D531289B