Use with:
Dragon Ball Z - La Legende Saien (France).sfc (No-Intro)
36e1391f0b1f29f16ef5d4eb83c3725b
8F24F886