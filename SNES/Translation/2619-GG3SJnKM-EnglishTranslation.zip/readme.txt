Use with:

Ganbare Goemon 3 - Shishi Juurokubee no Karakuri Manjigatame (Japan).sfc	(No-Intro)
7da54082f302c3f781539f371691ec2f
7E5929E8