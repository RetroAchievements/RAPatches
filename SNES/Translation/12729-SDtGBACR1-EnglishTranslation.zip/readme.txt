Use with:
SD The Great Battle - Aratanaru Chousen (Japan) (Rev 1).sfc (No-Intro)
827ab21778c4ec8dd8b6796ea12f5261
2A8D1AFF