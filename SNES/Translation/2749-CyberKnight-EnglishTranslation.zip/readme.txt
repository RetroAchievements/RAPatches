Use with:

Cyber Knight (Japan).sfc	(No-Intro)
db9465e77ac9b8a496d0039031c9d446
64034B07