Use with:
Hook (Europe).sfc (No-Intro)
7693f2ac4ba870378bbd26935f24afe2
6679A772