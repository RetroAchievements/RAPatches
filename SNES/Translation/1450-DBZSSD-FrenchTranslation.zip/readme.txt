Use with:
Dragon Ball Z - Super Saiya Densetsu (Japan).sfc [No-Intro]
f93601fe3bccac45c332b79e69e3ac83
32B17409