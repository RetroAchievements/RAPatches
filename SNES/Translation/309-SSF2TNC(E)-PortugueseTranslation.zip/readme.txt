Use with:
Super Street Fighter II (Europe).sfc (No-Intro)
68f9192f7d9553327a976662af9c331d
6D86BFB0