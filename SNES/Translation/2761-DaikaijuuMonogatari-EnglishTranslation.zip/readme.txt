~Daikaijuu Monogatari (Japan) (En) (1.0) (Dynamic-Designs)~

Daikaijuu Monogatari (Japan).sfc	(No-Intro)
0be736bb76d0a5cce320886570382362
4A5263DB


~Daikaijuu Monogatari (Japan) (Rev1) (En) (1.0) (Dynamic-Designs)~

Daikaijuu Monogatari (Japan) (Rev 1).sfc	(No-Intro)
f60d3ede1e4bf7f9df1fa8f375317f54
5B09F3AD