Use with:
Battletoads-Double Dragon (USA).sfc [No-Intro]
3c433a8aa73986e1361423303e92785b
8B18AC01