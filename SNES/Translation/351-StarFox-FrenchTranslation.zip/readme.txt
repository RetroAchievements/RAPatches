Use with:
Star Fox (USA).sfc (No-Intro)
9dce6a9dcbe4e304d67b9e8fd8999e7e
0BAE0941