~Star Fox (USA) (Fr) (1.0) (YodaJR)~

Star Fox (USA).sfc (No-Intro)
9dce6a9dcbe4e304d67b9e8fd8999e7e
0BAE0941



~Star Fox (USA) (Rev2) (Fr) (1.0) (YodaJR)~

Star Fox (USA) (Rev 2).sfc (No-Intro)
def66db12f5e644c0cf00c42cfa7ae7b
8FC4E6D0