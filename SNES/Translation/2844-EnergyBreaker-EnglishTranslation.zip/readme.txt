Use with:

Energy Breaker (Japan).sfc	(No-Intro)
b0010547a9c7812326da17b66e167004
74D89D96