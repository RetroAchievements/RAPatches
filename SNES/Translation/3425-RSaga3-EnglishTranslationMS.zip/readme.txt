Use with:

Romancing Sa-Ga 3 (Japan) (Rev 1).sfc	(No-Intro)
54c1454f8067ec39bd6d97f197e09816
6C50C2CF