Use with:
Bobby's World (USA) (Proto).sfc [No-Intro]
6452748e3042c9b7a4ff37dde5e9e69b
18BBEE33