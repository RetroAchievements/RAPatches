Use with:
Chrono Trigger (USA).sfc [No-Intro]
a2bc447961e52fd2227baed164f729dc
2D206BF7