Use with:
Goof Troop (USA).sfc (No-Intro)
bb6a1198e291c8ae58e9581a4296ed4d
4AAFA462