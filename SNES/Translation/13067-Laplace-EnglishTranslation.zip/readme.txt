Use with:

Laplace no Ma (Japan).sfc	(No-Intro)
3593df92fba7bedbb68f22f61f081d55
49C4CC15