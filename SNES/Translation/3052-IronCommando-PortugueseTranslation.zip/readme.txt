Use with:
Iron Commando - Koutetsu no Senshi (Japan).sfc (No-Intro)
c656e7408b5ef8a774ea8b354bf47779
828B5F07