Use with:

Alcahest (Japan).sfc	(No-Intro)
092caae4772502499b43f2f026daa0a5
870427D0