Use with:

Lennus II - Fuuin no Shito (Japan).sfc	(No-Intro)
52af259ac9347cd2b6ae450671e9dbd6
C68BE22A