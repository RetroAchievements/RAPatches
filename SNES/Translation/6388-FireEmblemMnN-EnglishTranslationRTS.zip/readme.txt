Use with:

~Fire Emblem - Monshou no Nazo (Japan) (En) (0.2) (RobertTheSable)~

Fire Emblem - Seisen no Keifu (Japan).sfc	(No-Intro)
d044f97be5fc00bd5e02c935f7e88058
DC0D8CF9


~Fire Emblem - Monshou no Nazo (Japan) (Rev1) (En) (0.2) (RobertTheSable)~

Fire Emblem - Monshou no Nazo (Japan) (Rev 1).sfc	(No-Intro)
0cb432dd9d5c1afa5048334b110fddc0
A427B7E6