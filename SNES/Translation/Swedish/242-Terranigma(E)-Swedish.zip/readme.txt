Use with:
Terranigma (Europe).sfc (No-Intro)
d202156549f981f6dafc759575dd6e67
974523FF