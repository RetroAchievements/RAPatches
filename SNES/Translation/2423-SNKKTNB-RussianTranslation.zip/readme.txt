Use with:

Shin Nekketsu Kouha - Kunio-tachi no Banka (Japan).sfc	(No-Intro)
73754658aae9024f23570b494ee86f01
31BE696C