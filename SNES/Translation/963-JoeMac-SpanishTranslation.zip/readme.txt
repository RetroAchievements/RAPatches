Use with:
Joe & Mac (USA).sfc (No-Intro)
cc902de2efa54df4d2c27acd7f4a6bf4
3A2B6167