Use with:
Aero Fighters (USA).sfc [No-Intro]
510b850d22a6f3d67ccbfdd979501943
F194D00A