Use with:

JoJo no Kimyou na Bouken (Japan).sfc	(No-Intro)
cd17d26a8c27b57e0a50043a686923b4
56BA694A