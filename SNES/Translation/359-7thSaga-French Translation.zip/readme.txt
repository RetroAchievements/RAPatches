Use with:
7th Saga, The (USA).sfc [No-Intro]
a42772a0beaf71f9256a8e1998bfe6e3
B3ABDDE6