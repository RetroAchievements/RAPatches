Use with:
Shin Megami Tensei (Japan) (Rev 1).sfc (No-Intro)
2da54797ddf350a71e170110553ed8a5
A3D40A74