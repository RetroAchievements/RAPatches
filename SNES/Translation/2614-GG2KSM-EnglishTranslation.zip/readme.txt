Use with:
Ganbare Goemon 2 - Kiteretsu Shougun Magginesu (Japan).sfc (No-Intro)
afd06ade29b5270a79199a531b0c7964
CA4C0219