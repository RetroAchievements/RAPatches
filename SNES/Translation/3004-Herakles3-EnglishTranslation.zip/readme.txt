Use with:

Heracles no Eikou III - Kamigami no Chinmoku (Japan).sfc	(No-Intro)
c610614b9528f338c169984b96fcbc0a
61939546