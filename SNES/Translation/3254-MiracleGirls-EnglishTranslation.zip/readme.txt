Use with:
Miracle Girls (Japan).sfc (No-Intro)
a1c9f6e6191d483f33f0369fad43ea22
AB82EBBE