Use with:
Umihara Kawase (Japan).sfc (No-Intro)
abddd496bab9c4fd12007f3125db85cc
393CCCA2