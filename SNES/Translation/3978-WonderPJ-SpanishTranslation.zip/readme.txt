Use with:

Wonder Project J - Kikai no Shounen Pino (Japan).sfc	(No-Intro)
42e9be5f98bb5ece06da79b3dbf26fa9
AF8F4DB9