Use with:
Hameln no Violin Hiki (Japan).sfc (No-Intro)
5b042f9443d8338e0eb7e2604f9a3363
FB500926