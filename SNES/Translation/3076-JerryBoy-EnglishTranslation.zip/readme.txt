Use with:
Jerry Boy (Japan).sfc (No-Intro)
f487330132177f2182b17bf6ef617a13
4EF452F6