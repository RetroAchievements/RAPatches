Use with:
Metal Warriors (USA).sfc (No-Intro)
1b1282421d39a473f634958c28dca0d4
F2AB92D4