Use with:
Panel de Pon (Japan).sfc (No-Intro)
ce9b7f3572867f3c1c6ff889b02a63a4
14D70786