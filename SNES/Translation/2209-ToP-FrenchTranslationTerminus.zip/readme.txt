Use with:
Tales of Phantasia (Japan).sfc (No-Intro)
207cd1c0aaaca29faa389218b800f8fc
E9946B84