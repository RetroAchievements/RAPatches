Use with:
G.O.D - Mezame yo to Yobu Koe ga Kikoe (Japan).sfc (No-Intro)
ed35a998c76d415c518cdee1959d2afa
4D2CE16F