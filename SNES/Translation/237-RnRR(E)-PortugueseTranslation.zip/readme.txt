Use with:
Rock 'N' Roll Racing (Europe).sfc (No-Intro)
ea99d9924329380fe4a0d523caf9d2e2
B02DAF39