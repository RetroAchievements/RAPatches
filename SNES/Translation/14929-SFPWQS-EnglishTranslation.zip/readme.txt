Use with:

Super Fire Pro Wrestling - Queen's Special (Japan).sfc	(No-Intro)
868c5612612444e545ee610245990fc0
3227F1B1