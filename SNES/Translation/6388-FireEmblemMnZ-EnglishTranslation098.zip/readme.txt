Use with:
Fire Emblem - Monshou no Nazo (Japan).sfc [No-Intro]
2d674a5b82f7691cdb27702031d0f960
25D214F4