Use with:
Great Battle III, The (Japan).sfc (No-Intro)
267a6ce87b972ae7800d1b118bcb538e
B311DF48