Use with:
Top Gear (Europe).sfc (No-Intro)
9d66f2463e8f85942b7967e23bbcd53b
B0150052