Use with:
Final Fight 3 (USA).sfc [No-Intro]
1288de058352d6f9c3ba146a61581555
A916E708