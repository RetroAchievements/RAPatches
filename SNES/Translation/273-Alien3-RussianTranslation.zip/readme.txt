Use with:
Alien 3 (USA) (Rev 1).sfc (No-Intro)
730bef426e194a06a2f61e703e0719ca
9CCE2EB7