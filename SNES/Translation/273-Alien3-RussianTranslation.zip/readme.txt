Use with:
Alien 3 (USA).sfc [No-Intro]
09120ba8c0052997481117683b4e70db
98E2AC15