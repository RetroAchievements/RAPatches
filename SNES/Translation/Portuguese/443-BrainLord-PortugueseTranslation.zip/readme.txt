Use with:
Brain Lord (USA).sfc [No-Intro]
290ffe44a6d10ac30cea203c026daf31
3990B432