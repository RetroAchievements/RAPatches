Use with:

Final Fantasy V (Japan).sfc (No-Intro)
d69b2115e17d1cf2cb3590d3f75febb9
C1BC267D
