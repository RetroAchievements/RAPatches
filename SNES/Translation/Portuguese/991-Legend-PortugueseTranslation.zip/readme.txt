Use with:
Legend (USA).sfc (No-Intro)
0c684458019a60b0e16acb408f1418ea
0A6DD870