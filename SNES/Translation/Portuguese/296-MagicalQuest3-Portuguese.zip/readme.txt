Use with:

(No Intro)
File:               Mickey to Donald - Magical Adventure 3 (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              32EEA1E9
MD5:                4B87392AAF03517D3F45EBF06EB2D4BC
SHA1:               8A153F92AD2498FBF66E4CB100F6E5B950098044
SHA256:             453359B20F78787FCFEA0DAFE715238F0FF3F1D6F4D729285DC72A8004131A3B