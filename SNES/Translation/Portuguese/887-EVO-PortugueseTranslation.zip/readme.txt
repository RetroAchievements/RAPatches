Use with:
E.V.O. - Search for Eden (USA).sfc [No-Intro]
2ffd5027d32f0ec5326981ee1be1ca32
DD49911E