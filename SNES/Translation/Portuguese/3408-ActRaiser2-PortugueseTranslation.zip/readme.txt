Use with:
ActRaiser 2 (USA).sfc [No-Intro]
32cfe65f6dd6e4b58839729a3b1dbd60
4901F718