Use with:

(No Intro)
Goof Troop (USA).sfc
bb6a1198e291c8ae58e9581a4296ed4d
4AAFA462