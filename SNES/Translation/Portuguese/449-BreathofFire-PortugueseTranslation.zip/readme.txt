Use with:
Breath of Fire (USA).sfc [No-Intro]
cdef890e99a0fb62c4d449d867c4244a
C788B696