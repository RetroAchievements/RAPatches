Use with:

(No Intro)
File:               NBA Live 95 (USA).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              1CD2393D
MD5:                86021F9150C5A03E00D7F9E688A5A981