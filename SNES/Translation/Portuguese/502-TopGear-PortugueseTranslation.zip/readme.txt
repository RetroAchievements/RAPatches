Use with:
Top Racer (Japan) (En).sfc (No-Intro)
bfebdb22fa71d87e81f41982e798530d
E5A57B12