use with:
Wonder Project J - Kikai no Shounen Pino (Japan) (No-Intro)
42E9BE5F98BB5ECE06DA79B3DBF26FA9
AF8F4DB9