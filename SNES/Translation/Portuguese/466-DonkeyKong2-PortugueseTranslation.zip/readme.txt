Use with:
Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr) (Rev1).sfc [No-Intro]
d323e6bb4ccc85fd7b416f58350bc1a2
4E2D90F4