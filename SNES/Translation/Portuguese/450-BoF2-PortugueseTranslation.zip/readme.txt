Use with:
Breath of Fire II (USA).sfc (No-Intro)
e1ff1ed4ad5dbdbe86774920dfb5e9d4
67CDACC5