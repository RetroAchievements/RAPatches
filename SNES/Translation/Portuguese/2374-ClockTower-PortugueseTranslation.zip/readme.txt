Use with:

(No Intro)
File:               Clock Tower (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              CBCD0DAD
MD5:                51F8A9E95EC58FA5B9C3EC2DA530D598