Use with:
Animaniacs (USA).sfc [No-Intro]
ff08ca993882bfe2ab860865897bfe77
CF0F14D2