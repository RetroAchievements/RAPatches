Use with:

Super Fire Pro Wrestling X Premium (Japan).sfc	(No-Intro)
88b3c5b6e79bf4859940090c4ca6eabe
82DE1380