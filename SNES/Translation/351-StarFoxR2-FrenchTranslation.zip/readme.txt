Use with:
Star Fox (USA) (Rev 2).sfc (No-Intro)
def66db12f5e644c0cf00c42cfa7ae7b
8FC4E6D0