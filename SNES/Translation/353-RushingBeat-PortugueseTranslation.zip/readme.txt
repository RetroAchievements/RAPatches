Use with:

Rushing Beat (Japan).sfc	(No-Intro)
ee392bdcd28d073585f198ce9187456f
A6F0693D