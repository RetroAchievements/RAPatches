Use with:
Shin Megami Tensei II (Japan) (Rev 2).sfc (No-Intro)
cca92f7cc9d7aba76b457883553ff497
E38228A7