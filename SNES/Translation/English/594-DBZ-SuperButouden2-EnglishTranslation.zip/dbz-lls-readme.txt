Use with:

(No Intro)
File:               Dragon Ball Z - La Legende Saien (France).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8F24F886
MD5:                36E1391F0B1F29F16EF5D4EB83C3725B