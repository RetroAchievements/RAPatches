Use with:

(No Intro)
File:               Heracles no Eikou III - Kamigami no Chinmoku (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              61939546
MD5:                C610614B9528F338C169984B96FCBC0A
