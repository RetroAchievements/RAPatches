Use with:

(No Intro)
File:               Romancing Sa-Ga 3 (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              5399BDDB
MD5:                42561559D91013C63B0FDBA31FC323BF

File:               Romancing Sa-Ga 3 (Japan) (Rev 1).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              6C50C2CF
MD5:                54C1454F8067EC39BD6D97F197E09816
SHA1:               ED50AC054F664175A2004D3B7423DAAD3021FB7B
SHA256:             3EFA91F18CC6CD012BC213FF421813C113DF51E62F68180CC54C782F21616897