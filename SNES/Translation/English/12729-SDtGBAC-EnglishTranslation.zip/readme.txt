~SD The Great Battle - Aratanaru Chousen (Japan) (En) (1.0) (Aeon Genesis)~

Use with: 

(No-Intro)
SD The Great Battle - Aratanaru Chousen (Japan).sfc
d952a16db6a4154f877a6713f9da9172
38726EC1

OR 

~SD The Great Battle - Aratanaru Chousen (Japan) (Rev1) (En) (1.0) (AeonGenesis)~

Use with:

SD Gundam Gaiden - Knight Gundam Monogatari - Ooinaru Isan (Japan) (Rev 1).sfc
827ab21778c4ec8dd8b6796ea12f5261
2A8D1AFF