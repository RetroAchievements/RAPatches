Use with:

(No Intro)
File:               Wizardry I-II-III - Story of Llylgamyn (Japan) (En,Ja) (NP).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              B8A72553
MD5:                5987975FB59733089149003C506810AF