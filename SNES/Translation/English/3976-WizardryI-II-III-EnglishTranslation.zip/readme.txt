Use with:

(No Intro)
Wizardry I-II-III - Story of Llylgamyn (Japan) (En,Ja) (NP).sfc
5987975fb59733089149003c506810af
B8A72553