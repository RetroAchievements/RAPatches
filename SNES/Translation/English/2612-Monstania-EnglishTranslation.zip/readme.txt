Use with:

(No Intro)
File:               Monstania (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              F3887022
MD5:                6DFDB138ABEB84899C4143342E1901EA