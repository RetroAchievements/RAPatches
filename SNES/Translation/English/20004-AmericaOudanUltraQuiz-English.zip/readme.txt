Use with:

(No Intro)
File:               America Oudan Ultra Quiz (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              9624E6ED
MD5:                B7EDE602782F8FF1CF182D1B7E95F2C6
SHA1:               7D53B77C51C7C7E964F40E12B641A405D2E68B2A
SHA256:             62975466FA1FDF985D8C0DF378F247D1148FC6A42CFD698DC4429A93BDC5A532