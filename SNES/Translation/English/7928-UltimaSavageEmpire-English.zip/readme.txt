Use with:

(No Intro)
File:               Ultima - Kyouryuu Teikoku - The Savage Empire (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              DDDB20AD
MD5:                AE8A5CB920BAC544872C22C4D6D5EC97
SHA1:               C1702689D6946983BD8FEC54231C514DD44C4CF7
SHA256:             CEA2D5912F4167F115788ABDD6BEC4B5306BB202A52A1C681496E11CC6278EED