Use with:

(No Intro)
File:               Xak - The Art of Visual Stage (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              557B8DB1
MD5:                1E6D224DD2A2BC8678B7AA5817C7DB96
SHA1:               FBEFE349D80654F55D976C7E8282EC3D958D142C
SHA256:             EF2E4D8A7769D4E8B0BACA81554FB934E3CDF69B1DB591B46B625EB932A7EF81