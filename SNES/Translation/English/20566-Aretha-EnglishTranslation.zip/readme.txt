Use with:

(No Intro)
Aretha (Japan).sfc
ddf4920ae09530da94eae230fdffd3c4
395BADE3