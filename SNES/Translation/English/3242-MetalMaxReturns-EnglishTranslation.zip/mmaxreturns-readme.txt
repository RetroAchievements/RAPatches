Use with:

(No Intro)
File:               Metal Max Returns (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              4396A35B
MD5:                5C6821CB81C5B8F2B25F27B4030B21D7
