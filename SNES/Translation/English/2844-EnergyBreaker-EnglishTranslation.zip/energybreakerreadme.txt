Use with:

(No Intro)
File:               Energy Breaker (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              74D89D96
MD5:                B0010547A9C7812326DA17B66E167004