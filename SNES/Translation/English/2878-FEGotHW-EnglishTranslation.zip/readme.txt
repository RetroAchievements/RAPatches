Use with:

Fire Emblem - Seisen no Keifu (Japan).sfc [No-Intro]
d044f97be5fc00bd5e02c935f7e88058
DC0D8CF9