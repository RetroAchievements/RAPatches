Use with:

(No Intro)
File:               Final Fantasy V (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              C1BC267D
MD5:                D69B2115E17D1CF2CB3590D3F75FEBB9