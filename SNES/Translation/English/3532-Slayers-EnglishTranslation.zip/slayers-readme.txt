Use with:

(No Intro)
File:               Slayers (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              0B610445
MD5:                1B7B9B3EABE1008BAD9DC19DCAD9142F
