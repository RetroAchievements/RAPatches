Use with:

(No Intro)
File:               Fushigi no Dungeon 2 - Fuurai no Shiren (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              AF5703EE
MD5:                8C8FC738EAE4EB714B43889767DAF094
