Use with:

(No Intro)
File:               Magna Braban - Henreki no Yuusha (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              5F86ADA5
MD5:                DCEC157FB9E6BF1BDA288996B0EF75D9
SHA1:               AFB45F14F4C5B31D419A1166044877B12A0A3707
SHA256:             5EEB159BF0576FF687BAC9F356F5E8564021DC0D5BC18BFA22D63DC25CFA062B