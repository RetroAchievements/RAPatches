Use with:

Torneko no Daibouken - Fushigi no Dungeon (Japan).sfc	(No-Intro)
6c519cb2d7a0c7b197bb4d4377c82456
654E1BE4