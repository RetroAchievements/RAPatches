FF5r English - Nov.19 to Nov.29, 2020
Version 1.0c

Installation:
(1) Obtain an unheadered FF5j ROM. Not headered, and not translated.
    The compatible and tested version has a CRC32 checksum of C1BC267D.
(2) Acquire FF5r from https://www.romhacking.net/hacks/1408/
(3) Install FF5r140.ips (not FF5r140h.ips) over your FF5j ROM.
(4) Install this patch over your new FF5r140 ROM.
(5) Play!

Important notes:
* Enemies have two rare and one common steal. You can steal from
  an enemy until they have no items left (you can get everything).
  The second rare steal is the same item as the rare drop.
* Some additional item icons were added not in the japanese FF5r, in
  order to hopefully better categorize items into light, heavy, etc.
  
Thanks to:
    s8fp98fd5k - Developed FF5r in the first place!
    RPGe - I borrowed heavily from their work. Their font, their
           English-supporting ASM hacks, and the main story dialogue
           were used directly, along with many combat messages,
           enemy names, spell names, etc. They've mostly been touched
           up or modernized where applicable.
    FlandreScarlet64 - Suggesting FF5r, playtesting, feedback.
    Kain Stryder - Translation of new content.
    Odym82 - Translation of new content.
    ScarabEnigma - Playtesting, provided an end-game save, feedback.
    Others at the FF6 Hacking Discord - 
       Feedback on translations, playtesting.
    Tsushiy/FF6 T-Edition - Used some icons for grouping equipment.

Tested and working on:
    Snes9x 1.60 (Windows), bsnes v115 (Windows), ZSNES v1.51 (Windows)
    Snes9x EX+ 1.5.49 (Android)

Known issues:
* In some emulators, the game may crash at the text in the intro.
  The only emulator this is known to occur on at the moment is a 3DS emulator.