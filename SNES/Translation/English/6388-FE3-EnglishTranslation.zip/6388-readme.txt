Use with:

(No Intro)
File:               Fire Emblem - Monshou no Nazo (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              25D214F4
MD5:                2D674A5B82F7691CDB27702031D0F960

(No Intro)
File:               Fire Emblem - Monshou no Nazo (Japan) (Rev 1).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              A427B7E6
MD5:                0CB432DD9D5C1AFA5048334B110FDDC0