Use with:

(No Intro)
File:               Fire Emblem - Monshou no Nazo (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              25D214F4
MD5:                2D674A5B82F7691CDB27702031D0F960
SHA1:               3EE8CBE6638DA64F1D91DF9B81B1478498A5999F
SHA256:             23E45B26DC5A73D88173C5CB7FA7FAE682EAB6E55D657A71B3B366DC95D603CA
