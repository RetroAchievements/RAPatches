Use with:

(No Intro)
File:               Chaos Seed - Fuusui Kairouki (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              76E01CCB
MD5:                AB6CBBE55068A36718E223EE98090946