Use with:

(No Intro)
File:               Hero Senki - Project Olympus (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              789DA99C
MD5:                4DB71054142A1DBE0D3DCCEEB4E5C7BB
SHA1:               1C846FF08FF25325FBBEF1F9ACF10F6E73349F7E
SHA256:             926B1DE265D177D6C48443F700EE85DE4A4F3CBB4E509CFFD86AC735E4B052A0