Use with:
Great Battle II, The - Last Fighter Twin (Japan).sfc (No-Intro)
25194c0f0e0e9b808e3da152dbdfcdd2
8254A32E