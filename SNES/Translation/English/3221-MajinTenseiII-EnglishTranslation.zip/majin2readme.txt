Use with:

(No Intro)
File:               Majin Tensei II - Spiral Nemesis (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              31B2B1B4
MD5:                8E21174AFB7FDCC060B71BFB7F1FEB1E