Use with:

(No Intro)
File:               Nekketsu Tairiku - Burning Heroes (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              DA105A27
MD5:                900ECFB892E63D89E3A46EB2C4A8DC8E