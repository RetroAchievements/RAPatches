Use with:

(No Intro)
File:               Popeye - Ijiwaru Majo Sea Hag no Maki (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              F5BFCD90
MD5:                E07FB3C8AF18DD87260C0569E8588C31
