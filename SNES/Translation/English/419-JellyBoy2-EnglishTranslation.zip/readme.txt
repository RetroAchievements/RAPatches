Use with:

(No Intro)
File:               Jelly Boy 2 (Japan) (Proto).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              F3A6C574
MD5:                9DA4E7CB3815962583AE5DEA60593D04