Use with:

(No Intro)
File:               Super Puyo Puyo Tsuu (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              271E1F3F
MD5:                D19486B22C8A4F11AA969671AE1967B2
