Use with:

(No Intro)
File:               Gourmet Sentai Barayarou (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              9F717D76
MD5:                B29EA2C67D6ECABF99C22829058F710B