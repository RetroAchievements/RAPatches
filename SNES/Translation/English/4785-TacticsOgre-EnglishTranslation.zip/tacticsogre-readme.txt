Use with:

(No Intro)
File:               Tactics Ogre - Let Us Cling Together (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              DAF285A5
MD5:                6E0D35F157C856E57C8639FE041D05F2
