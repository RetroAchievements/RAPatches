Use with:

(No Intro)
File:               Accele Brid (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              4A736C38
MD5:                70688D5943868455F6C515DAB44DBF57