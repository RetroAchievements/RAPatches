Use with:

(No Intro)
File:               Marvelous - Mouhitotsu no Takara-jima (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              CEDF3BA7
MD5:                B9B77E5F378B871ECE75CABA82718A8E