Use with:
Bahamut Lagoon (Japan).sfc [No-Intro]
5254a985edc33928bb8535151a668080
1B83C440