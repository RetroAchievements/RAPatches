Use with:

Rockman & Forte (Japan).sfc (No-Intro)
55d9cdb05f53a3f7a5e3eacb81b28f09
5047E0D4
