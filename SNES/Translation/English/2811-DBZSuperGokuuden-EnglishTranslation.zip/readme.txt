Use with:

(No Intro)
File:               Dragon Ball Z - Super Gokuu Den - Totsugeki Hen (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D531289B
MD5:                8BD89634D1B2205B1E7EF016485C0076
SHA1:               926B861734CDEEF9E70CD436BE62C73481E7392F
SHA256:             CCA171C69DE8FD0AC2BDDAA492018A58FACCA64EBC4E760BCDC89C17F5B4AB4D