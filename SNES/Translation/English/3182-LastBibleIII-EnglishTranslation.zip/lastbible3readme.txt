Use with:

(No Intro)
File:               Last Bible III (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              5F1D73D7
MD5:                4C836F4924544F8160DAB3260F43A732