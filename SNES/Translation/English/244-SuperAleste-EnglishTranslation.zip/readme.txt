Use with:

Super Aleste (Japan).sfc	(No-Intro)
9943b6b85583facb088869db8d6a5f78
94D28FF9