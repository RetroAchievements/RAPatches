Use with:

(No Intro)
File:               Funaki Masakatsu Hybrid Wrestler - Tougi Denshou (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097664
CRC32:              CCDCDF10
MD5:                E47AFED5B1FB17572033E87790F26A2A
SHA1:               C994E0555D2690938472A8AF39E796712EF99D7D
SHA256:             80DE2212FEA860A908546C7844FFB815177FCEB46393CE2E8470E1A4FE1C57AD