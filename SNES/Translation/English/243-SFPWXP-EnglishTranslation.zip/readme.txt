Use with:

(No Intro)
File:               Super Fire Pro Wrestling X Premium (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              82DE1380
MD5:                88B3C5B6E79BF4859940090C4CA6EABE