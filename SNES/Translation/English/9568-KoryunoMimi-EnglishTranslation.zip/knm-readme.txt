Use with:

(No Intro)
File:               Kouryuu no Mimi (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              89276C88
MD5:                198A029EB746756A79951004E96C4C86
