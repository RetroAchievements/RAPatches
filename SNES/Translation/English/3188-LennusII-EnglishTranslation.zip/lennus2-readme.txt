Use with:

(No Intro)
File:               Lennus II - Fuuin no Shito (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              C68BE22A
MD5:                52AF259AC9347CD2B6AE450671E9DBD6
