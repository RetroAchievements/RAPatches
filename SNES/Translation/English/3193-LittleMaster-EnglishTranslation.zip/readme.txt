Use with:

(No Intro)
File:               Little Master - Nijiiro no Maseki (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              B916334C
MD5:                74B01CB4EC81821EE254D2F2E9025D47
SHA1:               75B76715D4A20371E0340DBEEE3A51FF6A1DBAD3
SHA256:             4F1E5E1F85B4DA043C3C608641B1B38B33DF83A3EC5C0F2F0F300ECB1AD2E248