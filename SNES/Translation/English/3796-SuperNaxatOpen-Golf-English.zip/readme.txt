Use with:

(No Intro)
File:               Super Naxat Open - Golf de Shoubu da Dorabocchan (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              86AA8A10
MD5:                9A111E14CC660863EF994FC5D01A803A
SHA1:               B6CBED12C3CDEFF1E85023BF9CDEF47CD70D7195
SHA256:             2AB51A85A6A91493F0CAB8F54B196A8BE0FF23FD2F6B8F6EA6A6FD1B2A79DD7A