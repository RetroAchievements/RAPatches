Use with:

(No Intro)
File:               Bike Daisuki! Hashiriya Tamashii (Japan).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              B363FC99
MD5:                9BC21069D1C9EBA86DAD2BA0E994E5A1
SHA1:               D0457FC27ADFF1B0AD236535F60F91711B15F0DB
SHA256:             3FB25A3B30E897455DE88E9E1D5FF2DF81E56B89F3FE7B7D9E0248A19A146B4B