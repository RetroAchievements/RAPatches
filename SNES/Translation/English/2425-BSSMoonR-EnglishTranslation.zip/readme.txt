Use with:
Bishoujo Senshi Sailor Moon R (Japan).sfc [No-Intro]
39b1e06fae0d6176c6ec4bb98f842eb7
4AEE5ABB