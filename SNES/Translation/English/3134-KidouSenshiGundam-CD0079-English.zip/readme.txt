Use with:

(No Intro)
File:               Kidou Senshi Gundam - Cross Dimension 0079 (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1573376
CRC32:              A845CD41
MD5:                E94813119DF509A81A031B2E66ACF34C
SHA1:               A7BC1655BCBA3BD65DBAC8152530E90AB873F9E5
SHA256:             F7D80265B796EF16E2CA99C30660FF3F78C9F773F9AEF8F7B3A23E48D7A7E5C6