Use with:

[No Intro]
Super Nazo Puyo - Rulue no Roux (Japan).sfc
hash: bf4658e6ab66ec4f5388e17d63b33157
CRC: ba1dba22