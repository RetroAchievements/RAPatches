Use with:

(No Intro)
File:               Ancient Magic - Bazoe! Mahou Sekai (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              D5B09EEF
MD5:                DECBC035448E68DC899A1DB456E77AFD