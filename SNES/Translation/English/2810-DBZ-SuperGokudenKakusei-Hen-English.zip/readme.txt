Use with:

(No Intro)
File:               Dragon Ball Z - Super Gokuu Den - Kakusei Hen (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              3172CD4F
MD5:                8502A3E5C0FDC56B6495A644ACA54413
SHA1:               3B7278A54F8D470DCB1BD92060D744380325F30B
SHA256:             CC5AB583B5189C3F5B374335EDF4B857461278D41EF674F7DB31AA100DCB814A