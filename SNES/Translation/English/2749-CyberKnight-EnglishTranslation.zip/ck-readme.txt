Use with:

(No Intro)
File:               Cyber Knight (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              64034B07
MD5:                DB9465E77AC9B8A496D0039031C9D446