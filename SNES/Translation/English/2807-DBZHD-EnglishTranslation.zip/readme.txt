Use with:
Dragon Ball Z - Hyper Dimension (Japan).sfc [No-Intro]
ed18b3c3b148bcafdbe228e27e89bd2d
F4AB1557