Use with:

(No Intro)
File:               Shodai Nekketsu Kouha Kunio-kun (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              56C05339
MD5:                089A633C541CAF3FC7C48FAE9FBFC8FF
