Use with:

(No Intro)
File:               Metal Slader Glory - Director's Cut (Japan) (NP).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              2CAB2502
MD5:                1F353927E2990450E870BC3182DE84AD
SHA1:               045E084C81BD84371E16EF770D29C1D11DF98BE2
SHA256:             6BBB36AC6B0670729EF91DD3C19A1EA98FC10FEF09FF07925D71467CD771B729