Use with:

(No Intro)
File:               Langrisser, Der (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              7AEDD703
MD5:                E5BC92BCCD1F5DE77C41A9838B7D1F1B
