Use with:

(No Intro)
File:               Shin Nekketsu Kouha - Kunio-tachi no Banka (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              31BE696C
MD5:                73754658AAE9024F23570B494EE86F01