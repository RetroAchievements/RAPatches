Use with:

(No Intro)
Great Battle V, The (Japan).sfc
7dc0a87ec703ee7659aa04fb8f8d5058
BF3C9314