Use with:
Super Bomberman 4 (Japan).sfc (No-Intro)
df33e261104efee409de8f294d80ad6e
3BBAEB19