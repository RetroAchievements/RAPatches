Use with:

(No Intro)
Great Battle IV, The (Japan).sfc
771f518a8035740cc017287d2e5a7889
FB165A32