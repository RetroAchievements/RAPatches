Use with:

(No Intro)
File:               TwinBee - Rainbow Bell Adventure (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              91867AF4
MD5:                B965286DE67B7116B8EB587457F9B649