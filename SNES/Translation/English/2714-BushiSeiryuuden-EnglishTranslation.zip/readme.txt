Use with:

(No Intro)
File:               Bushi Seiryuuden - Futari no Yuusha (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              62D31295
MD5:                672D15E2200A5CA176233FCB10139E92