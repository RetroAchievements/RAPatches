File:               Feda - The Emblem of Justice (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              EDA70F8A
MD5:                1BFBB1C174B6E7362AF678DD584BA324