Use with:

(No Intro)
File:               Magical Drop (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              51177158
MD5:                92BAB89C7D16119B421314B7784F11E5
