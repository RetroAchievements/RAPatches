Use with:

(No Intro)
File:               Maerchen Adventure Cotton 100% (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              5FB7A31D
MD5:                1FE3A19E5B6C023637930BAEC6F47ECC