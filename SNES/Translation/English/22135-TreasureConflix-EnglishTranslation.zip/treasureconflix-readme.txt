Use with:

(No Intro)
File:               Treasure Conflix (Japan).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F50FB0B7
MD5:                534DE4685ED6A099A31717826AD8AD8B