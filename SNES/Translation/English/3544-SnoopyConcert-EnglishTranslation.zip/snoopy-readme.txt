Use with:

(No Intro)
File:               Snoopy Concert (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              3836A202
MD5:                64E20693431CBF71B52A872E6EE53430
