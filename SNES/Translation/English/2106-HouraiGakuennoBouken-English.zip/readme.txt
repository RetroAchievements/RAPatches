Use with:

(No Intro)
File:               Hourai Gakuen no Bouken! - Tenkousei Scramble (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6299FB1C
MD5:                586159E9055691AA8DE3757F408350FD
SHA1:               25E107E21D45B0C4095E623A723E2020A55C9253
SHA256:             65F1EEFE40D8C63B8390EFD6E57CEF4321F40B79EDEE2DA0B1575189F7135364