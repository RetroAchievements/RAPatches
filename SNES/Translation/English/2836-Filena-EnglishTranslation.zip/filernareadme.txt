Use with:

(No Intro)
File:               Eien no Filerna (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              41E9CD70
MD5:                50DE817422DEC36B9266CC6AACF9E44E