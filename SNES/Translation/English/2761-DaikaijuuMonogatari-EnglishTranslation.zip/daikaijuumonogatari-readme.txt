Use with:

(No Intro)
File:               Daikaijuu Monogatari (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              39CA5291
MD5:                A3D2F5CB1F2D47D6ED7B0DD822E3D13B