Use with:

(No Intro)
File:               BS Super Mario USA - Power Challenge - Dai-1-kai (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              88FA31CC
MD5:                BE58760840703A1F1F36B3BFA2E7B108
SHA1:               7DC4D3D2A11F2F4E05D7306053211131B7AA6D9F
SHA256:             39F948B19A6C526DC4B5A78D2A64F31C848AC0A7D58B3F545B5CEC18DEC64766

(No Intro)
File:               BS Super Mario USA - Power Challenge - Dai-2-kai (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              DEDB049D
MD5:                EFFD7E9360BE56DA5A9876B45A5989FC
SHA1:               3A64FEFC0A2A0C9A666917D0B685474C2073947C
SHA256:             2ACF62FEFEBBD8557794C5C779B4081A4BF9479C8F70888037CF17907D692DAF

(No Intro)
File:               BS Super Mario USA - Power Challenge - Dai-3-kai (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C0C90A80
MD5:                62331BFA00172B3E2705DC33DC93E1EE
SHA1:               4078D1756B53C230670BD5AE8285629F6173B373
SHA256:             63276959BF888D159983350157199B325A5EF1B58D4B3B8D2B4B0BF9B4AC59DB

(No Intro)
File:               BS Super Mario USA - Power Challenge - Dai-4-kai (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D05B537C
MD5:                F08E24FFD1C2B1F0C85CD81BA72C66BD
SHA1:               0F8CBA643D66D8DA0D8D05FAEFCF65A79B081EFC
SHA256:             4B550501F40CE3184B8D856D3695517BF5DBA128ACA16B82971012444D6C35D5