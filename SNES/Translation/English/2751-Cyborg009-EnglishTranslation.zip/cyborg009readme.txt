Use with:

(No Intro)
File:               Cyborg 009 (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              4A5263DB
MD5:                0BE736BB76D0A5CCE320886570382362