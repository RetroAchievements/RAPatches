Use with:

(No Intro)
File:               Wrecking Crew '98 (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              A24F85FF
MD5:                94B140BF2AA47D0A8E1663ABD4B256D6