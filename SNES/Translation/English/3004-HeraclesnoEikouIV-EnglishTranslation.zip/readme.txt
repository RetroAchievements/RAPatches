Use with:

(No Intro)
File:               Heracles no Eikou IV - Kamigami kara no Okurimono (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              920A738E
MD5:                F685EAF034D3CF6AFEA7B6040DA2131F
SHA1:               4E14015C23B130DCEB8F887AA0F92A7C86F58068
SHA256:             B17874BAA41A19CF1EA99192EDBE83968446587CB10E581298CD233FBD68DC0D