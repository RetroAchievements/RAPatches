Use with:

(No Intro)
File:               Lodoss-tou Senki (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              1B3E22C3
MD5:                318FE70EF8F291DC3C3090AE7B84FE50