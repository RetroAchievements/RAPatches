Use with:

(No Intro)
File:               Super Robot Taisen EX (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              239621A0
MD5:                05ABAF496F6EFCC34EDE0939821E2B3B
