Use with:

Magic Knight Rayearth (Japan).sfc	(No-Intro)
c8fd6fb87f202db2b3dbbccfe1fdaa24
EDE4B627