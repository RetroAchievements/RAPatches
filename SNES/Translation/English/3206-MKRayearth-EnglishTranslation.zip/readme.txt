https://www.romhacking.net/translations/387/

https://www.romhacking.net/translations/6650/


Use with:

(No Intro)
File:               Magic Knight Rayearth (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              EDE4B627
MD5:                C8FD6FB87F202DB2B3DBBCCFE1FDAA24
SHA1:               B0BD7E46C98C1CCF042BE0EA3401445C461B76BD
SHA256:             9B6B0099F2B97EC3A18FEF7A4935BFAD235FDB83669DD99C3731A69506322CBE