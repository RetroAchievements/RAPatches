Use with:

(No Intro)
File:               Romancing Sa-Ga 3 (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              5399BDDB
MD5:                42561559D91013C63B0FDBA31FC323BF
