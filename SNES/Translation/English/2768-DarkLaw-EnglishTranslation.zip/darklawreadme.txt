Use with:

(No Intro)
File:               Dark Law - Meaning of Death (Japan).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              125A0C22
MD5:                D58849487D0AB3038F5F9CC38EFC8602