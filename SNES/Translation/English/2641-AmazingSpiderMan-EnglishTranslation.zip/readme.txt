Use with:

(No Intro)
File:               Amazing Spider-Man, The - Lethal Foes (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              82F7F710
MD5:                43D5D11A37C66A435FED06AA87DBBDFF