Use with:

(No Intro)
File:               Kouryuu Densetsu Villgust - Kieta Shoujo (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              2A6F930E
MD5:                FFEA48A0AC3C62E43DDCAAD47C690537
SHA1:               8AB97E9281EAF08F3C13AAAFB9BC8D7FA3A45B16
SHA256:             2CA747454D6706C06475C6F46194B0075C8D83FFD9B235844297CB807DF3E477