Use with:

(No Intro)
File:               Neugier - Umi to Kaze no Kodou (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7F0DDCCF
MD5:                D7289C3133E50CB6A3738D9FBC69769E