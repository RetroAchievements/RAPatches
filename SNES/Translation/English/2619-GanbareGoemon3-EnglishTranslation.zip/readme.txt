Use with:

(No Intro)
File:               Ganbare Goemon 3 - Shishi Juurokubee no Karakuri Manjigatame (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              7E5929E8
MD5:                7DA54082F302C3F781539F371691EC2F