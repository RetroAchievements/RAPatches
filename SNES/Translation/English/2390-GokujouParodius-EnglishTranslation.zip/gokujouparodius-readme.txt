Use with:

(No Intro)
File:               Gokujou Parodius (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              04EE98ED
MD5:                D9FA65C567AD9C0E6B8FEF6066E740D8