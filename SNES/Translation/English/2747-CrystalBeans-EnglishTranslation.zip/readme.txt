Use with:

(No Intro)
File:               Crystal Beans from Dungeon Explorer (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              79663A93
MD5:                18C356623AE0407119CEAE8C06EDFA7A