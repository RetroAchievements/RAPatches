Use with:

(No Intro)
File:               Madou Monogatari - Hanamaru Daiyouchienji (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              1354E81E
MD5:                11B40949B167EE0ED6D7ABB9EA32A81F