Use with:

Panic in Nakayoshi World (Japan).sfc (No Intro)
RA Checksum: 340ac051810666f085165f8913e0ba79
