Use with:
Go Go Ackman (Japan).sfc (No-Intro)
698ec39014f45d1ecea6ecc7d5223664
26FB2D11