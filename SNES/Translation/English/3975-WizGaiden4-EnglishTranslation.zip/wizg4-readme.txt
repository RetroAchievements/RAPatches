Use with:

(No Intro)
File:               Wizardry Gaiden IV - Taima no Kodou (Japan) (Rev 1).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              1703D522
MD5:                7BA541A38E7C5E86FB0D4519B490EFE8
