Use with:

(No Intro)
File:               Kaizou Choujin Shubibinman Zero (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              E59E1096
MD5:                06D6F77F59BEF272C5E975056DC6E956