Use with:

(No Intro)
File:               Kaizou Choujin Shubibinman Zero (Japan).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              26A4F6C3
MD5:                DB4DD0305051F7D3CA7BD2E114F4F1DD