Use with:

(No Intro)
File:               Tokimeki Memorial - Densetsu no Ki no Shita de (Japan) (Rev 1).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              AE9F3602
MD5:                CD36EB8982DE4BF8369DEB9F2F23E590