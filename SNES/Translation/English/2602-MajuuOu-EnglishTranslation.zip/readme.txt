Use with:

(No Intro)
File:               Majuu Ou (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              4737370B
MD5:                C48199B6996211AC200B8B2DAAFC18EF