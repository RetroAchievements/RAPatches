Use with:

(No Intro)
File:               Super Famicom Wars (Japan) (NP).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D6EACBEA
MD5:                D88B4ED9A9D834696357CE4C9EF95359