Use with:

(No Intro)
File:               Dark Half (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              7B9793B1
MD5:                55108013F875DB3B39DA04B8F58489AB