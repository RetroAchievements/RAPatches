~Dai-3-Ji Super Robot Taisen (Japan) (En) (1.0) (Aeon Genesis)~

Dai-3-ji Super Robot Taisen (Japan).sfc	(No-Intro)
b5974f5306e8daee96d5fc625e960f0a
DFE9CC90


~Dai-3-Ji Super Robot Taisen (Japan) (Rev1) (En) (1.0) (Aeon Genesis)~

Dai-3-ji Super Robot Taisen (Japan) (Rev 1).sfc		(No-Intro)
a39ea26f27df58ac1c8b507b425c9878
8813029C


~Dai-3-Ji Super Robot Taisen (Japan) (Rev2) (En) (1.0) (Aeon Genesis)~

Dai-3-ji Super Robot Taisen (Japan) (Rev 2).sfc		(No-Intro)
e207d0f97c8d8476bd7b58d81f78864d
C577D666


~Dai-3-Ji Super Robot Taisen (Japan) (Rev3) (En) (1.0) (Aeon Genesis)~

Dai-3-ji Super Robot Taisen (Japan) (Rev 3).sfc		(No-Intro)
1075eb9a226dfbbc8bc8cc2fa3b96d4d
C2941881