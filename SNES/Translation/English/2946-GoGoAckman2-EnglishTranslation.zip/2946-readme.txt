Go Go Ackman 2 (Japan) (En) (v1.0a) (Retroman_X).sfc = Has a splash screen
Go Go Ackman 2 (Japan) (En) (v1.0b) (Retroman_X).sfc = Has no splash screen

Use with:

(No Intro)
File:               Go Go Ackman 2 (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              76C7AA37
MD5:                B835E0F37A804887C6041A6452A51B78