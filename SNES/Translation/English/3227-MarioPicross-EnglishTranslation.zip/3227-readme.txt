Use with:

(No Intro)
File:               Mario no Super Picross (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F64C5AA0
MD5:                34255C940FFDAFA25235A7B3C9093186