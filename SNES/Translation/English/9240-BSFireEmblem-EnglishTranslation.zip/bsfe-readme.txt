Use with:

(No Intro)
File:               BS Fire Emblem - Akaneia Senki Hen - Dai-1-wa - Palace Kanraku (Japan) (4-4) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D42EA2E0
MD5:                A919F44E13FB564066E36840136EF42A

File:               BS Fire Emblem - Akaneia Senki Hen - Dai-2-wa - Akai Ryuu Kishi (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              FCAAFE47
MD5:                204C828DCDEFB7ABEA0A2FC246E23C13

File:               BS Fire Emblem - Akaneia Senki Hen - Dai-3-wa - Seigi no Touzokudan (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              3D3EB686
MD5:                91BBC9FD486E37D54C0CB09BAE8D65A5

File:               BS Fire Emblem - Akaneia Senki Hen - Dai-4-wa - Hajimari no Toki (Japan) (4-28) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F5C19C84
MD5:                D58B996CB4672BEE231E5DE5E53D0B68