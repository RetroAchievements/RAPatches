Use with:

(No Intro)
File:               Chou Mahou Tairiku WOZZ (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              B3258F38
MD5:                E60EAC0054CCED7247F067AEF6F7494F