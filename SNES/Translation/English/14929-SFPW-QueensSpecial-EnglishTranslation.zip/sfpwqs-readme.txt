Use with:

(No Intro)
File:               Super Fire Pro Wrestling - Queen's Special (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              3227F1B1
MD5:                868C5612612444E545EE610245990FC0
