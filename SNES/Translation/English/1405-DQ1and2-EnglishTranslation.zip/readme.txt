Use with:

File:               Dragon Quest I & II (Japan).sfc
BitSize:            12 Mbit
Size (Bytes):       1572864
CRC32:              98BB6853
MD5:                1DEF71B5557CC6BB7402281D888CAE80