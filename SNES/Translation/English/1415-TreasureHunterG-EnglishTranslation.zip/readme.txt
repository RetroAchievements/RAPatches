Use with:

(No Intro)
File:               Treasure Hunter G (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              3CCEED49
MD5:                B1774FC2E0AF8427FD3BCF116A4EC0E0