Use with:

(No Intro)
Great Battle III, The (Japan).sfc
267a6ce87b972ae7800d1b118bcb538e
B311DF48