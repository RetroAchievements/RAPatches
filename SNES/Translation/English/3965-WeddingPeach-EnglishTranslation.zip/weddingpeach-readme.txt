Use with:

(No Intro)
File:               Wedding Peach (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              5FC89932
MD5:                026314480D07C1670197D34FCCA725B1