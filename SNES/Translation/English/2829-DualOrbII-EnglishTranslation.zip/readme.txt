Use with:

(No Intro)
File:               Dual Orb II (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              E8798F65
MD5:                EB42510C01054711BCF04346ABA7ED2F