Use with:

Shin Megami Tensei (Japan).sfc (No-Intro)
9055814b1782cadd538c78ae773826b8
90DE2C78
