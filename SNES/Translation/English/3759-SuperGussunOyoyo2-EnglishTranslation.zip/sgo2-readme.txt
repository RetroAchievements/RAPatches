Use with:

(No Intro)
File:               Super Gussun Oyoyo 2 (Japan).sfc
BitSize:            10 Mbit
Size (Bytes):       1310720
CRC32:              244CF4DF
MD5:                EB752374CAC33FB36827D6CC91BD838F
