Use with:
Bishoujo Senshi Sailor Moon SuperS - Fuwafuwa Panic (Japan).sfc [No-Intro]
1f6b2ff721f8f0d92736d704f922ba37
B6B92AE0