Use with:

(No Intro)
File:               Uchuu no Kishi - Tekkaman Blade (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7E107C35
MD5:                303DB6A77D5A4B353B9D96231E91A481