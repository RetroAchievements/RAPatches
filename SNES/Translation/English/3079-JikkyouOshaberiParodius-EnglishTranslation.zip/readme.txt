Use with:

(No Intro)
File:               Jikkyou Oshaberi Parodius (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              177937AB
MD5:                83BFF16D6C17F3E965E40BB56AF80A90
SHA1:               5D0BF1A3DD8A2AE65EB79ADB8EB4A4E3C34E01A3
SHA256:             6A2F280ED1EF5166D95E3B0EB1A6665564F7DDCFD3FEAF53344A1268B54B85C6