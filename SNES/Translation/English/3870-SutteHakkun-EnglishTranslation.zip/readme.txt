Use with:
Sutte Hakkun (Japan).sfc (No-Intro)
0d3595a81c50d5dda714cd2fd66164b2
DC173550