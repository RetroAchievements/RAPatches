Use with:

(No Intro)
File:               Radical Dreamers - Nusume Nai Houseki (Japan) (2-24).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              660B8CC4
MD5:                5D1C642C23D0BB113ACE249A586F0689