Use with:

(No Intro)
File:               Wizardry VI - Kindan no Mahitsu (Japan).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              C17ECBA5
MD5:                F5AE0C2811AC905F798C70A972184F43
