Use with:

Dossun! Ganseki Battle (Japan).sfc	(No-Intro)
663fbb07dcd22c366cf940bbb9a5db85
1AA002D6