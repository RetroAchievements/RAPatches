Use with:

(No Intro)
File:               Famicom Tantei Club Part II - Ushiro ni Tatsu Shoujo (Japan) (NP).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              28F450AC
MD5:                065DFEB6DA891C18D86464C1ED398869
SHA1:               4D4EEEE0E8ACFED5CF60A7324349DBB46AAA7369
SHA256:             472C87EE9C10A69C45B447246FB29C815C79B56884A8B37172CCF48991E037FB