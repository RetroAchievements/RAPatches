Use with:

(No Intro)
File:               Ashita no Joe (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              6B54BE97
MD5:                C7F80EB13AD9EE5FB5598B24002B6113
