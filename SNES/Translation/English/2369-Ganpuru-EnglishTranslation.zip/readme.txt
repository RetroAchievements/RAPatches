Use with:
Ganpuru - Gunman's Proof (Japan).sfc (No-Intro)
c79ca7c76d169fd42524fa7dba2317f7
AF415C24