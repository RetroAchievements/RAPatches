Use with:

(No Intro)
File:               Cyber Knight II - Chikyuu Teikoku no Yabou (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              ED8BCBF4
MD5:                4244BB90AA722836B746BE0574351874