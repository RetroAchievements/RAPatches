Use with:

(No Intro)
File:               Flying Hero - Bugyuru no Daibouken (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              1A19FC3A
MD5:                150F83E84F913230B8D1F2230E72B041
SHA1:               89A10F5CB9B19DCAABB1C26E884C102A49105F0C
SHA256:             204ECB9B809408C23D5F5772026FC248C70612D9BF6952E6B952ED7A85640867