Use with: 

(No Intro)
Kyuuyaku Megami Tensei (Japan).sfc
9918dbf3f0d349cac24631bdf77939f3
C8D286C9

or

(No Intro)
Kyuuyaku Megami Tensei (Japan) (Rev 1).sfc
8c3ca42a82f451dfecd591bc907f4fdf
E257D574