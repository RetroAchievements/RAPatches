Use with:

(No Intro)
File:               JoJo no Kimyou na Bouken (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              56BA694A
MD5:                CD17D26A8C27B57E0A50043A686923B4
