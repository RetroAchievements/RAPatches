Use with:

(No Intro)
File:               Arabian Nights - Sabaku no Seirei Ou (Japan).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              B6DBF57B
MD5:                EB1AD755DA3310F392CF8BC94962612E