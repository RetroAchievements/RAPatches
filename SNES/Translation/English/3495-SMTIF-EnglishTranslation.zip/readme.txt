Use with:
Shin Megami Tensei if... (Japan) (Rev 1).sfc (No-Intro)
bda3bbc142dae62f35755e364515e9b4
77D02030