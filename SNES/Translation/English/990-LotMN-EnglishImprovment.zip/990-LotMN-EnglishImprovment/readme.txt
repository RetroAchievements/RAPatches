Use with:

Legend of the Mystical Ninja, The (USA).sfc	(No-Intro)
bf6da6f13729c8925d8725d7dd25b420
82479D6A