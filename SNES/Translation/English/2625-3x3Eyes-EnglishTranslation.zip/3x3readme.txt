Use with:

(No Intro)
File:               3x3 Eyes - Juuma Houkan (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              AD4AD163
MD5:                7E55EE60AA3F1E37F7A7A006201EC035