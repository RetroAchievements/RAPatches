Use with:

(No Intro)
File:               Go Go Ackman 3 (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              9A18290C
MD5:                E78DED3BCAE4CFDFE29250DB7F600176