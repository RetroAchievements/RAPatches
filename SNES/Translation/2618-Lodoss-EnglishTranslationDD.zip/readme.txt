Use with:

Lodoss-tou Senki (Japan).sfc	(No-Intro)
318fe70ef8f291dc3c3090ae7b84fe50
1B3E22C3