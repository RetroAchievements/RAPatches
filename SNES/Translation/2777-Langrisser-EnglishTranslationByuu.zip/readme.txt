Use with:

Langrisser, Der (Japan) (Rev 1).sfc		(No-Intro)
91d62c4cb790fc2fb38b10b68616e228
35F9EECC