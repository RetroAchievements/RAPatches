Use with:

Accele Brid (Japan).sfc		(No-Intro)
70688d5943868455f6c515dab44dbf57
4A736C38