Use with:
Lion King, The (USA).sfc (No-Intro)
6a5b2f9bde72f7d72db7dfe9afd0f47a
C8FBFAA8