Use with:
Dragon Quest III - Soshite Densetsu e... (Japan).sfc [No-Intro]
7c7c7db73b0608a184cc5e1d73d7695b
13836BD2