~Kyuuyaku Megami Tensei (Japan) (En) (1.0) (Aerie)~
~Kyuuyaku Megami Tensei (Japan) (En) (1.1) (Aerie)~

Kyuuyaku Megami Tensei (Japan).sfc	(No-Intro)
9918dbf3f0d349cac24631bdf77939f3
C8D286C9



~Kyuuyaku Megami Tensei (Japan) (Rev1) (En) (1.0) (Aerie)~
~Kyuuyaku Megami Tensei (Japan) (Rev1) (En) (1.1) (Aerie)~

Kyuuyaku Megami Tensei (Japan) (Rev 1).sfc	(No-Intro)
8c3ca42a82f451dfecd591bc907f4fdf
E257D574