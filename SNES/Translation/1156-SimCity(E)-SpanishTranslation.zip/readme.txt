Use with:
SimCity (Europe).sfc (No-Intro)
7190c6764031e2e8a208d47bd0e25caa
B75B06B4