Use with:

Captain Tsubasa III - Koutei no Chousen (Japan).sfc	(No-Intro)
3ecad6d88befde8b2bd96c94927b86b2
26B0CEE3