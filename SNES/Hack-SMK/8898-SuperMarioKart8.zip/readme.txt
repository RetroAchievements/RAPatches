Use with:

Super Mario Kart (Europe).sfc	(No-Intro)
f9fe266e91632e68b558d6b43393eaba
56410E5E