Use with:

No Intro
Super Mario Kart (USA).sfc
7f25ce5a283d902694c52fb1152fa61a
CD80DB86