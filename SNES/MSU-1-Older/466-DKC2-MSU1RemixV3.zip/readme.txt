Use with:

(No Intro)
Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr).sf
MD5: 98458530599b9dff8a7414a7f20b777a
CRC: 006364DB