Use with:

Mega Man X2 (USA).sfc (No-Intro)
67905b989b00046db06df3434ed79f04
947B0355
