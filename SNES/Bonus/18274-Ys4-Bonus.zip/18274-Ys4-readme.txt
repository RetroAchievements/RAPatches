Use with:

Ys IV - Mask of the Sun (Japan) NoIntro
a4e5ed2dbd1e3612917b91ab58e6feea
CA7B4DB9

Ys IV - Mask of the Sun (Japan) + Aeon Genesis Translation 2.1
3f70da88558c674577544eedb93d00a5
27577EC8

