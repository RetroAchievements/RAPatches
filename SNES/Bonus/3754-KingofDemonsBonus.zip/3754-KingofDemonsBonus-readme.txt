Use with:

Majuu Ou (J) [T+Eng1.01_Aeon Genesis].sfc (GoodTools)
3e972724ddbac41dec86035f6ebe9fa5
14DCC20D

Majuu Ou (Japan).sfc (No-Intro)
c48199b6996211ac200b8b2daafc18ef
4737370B
