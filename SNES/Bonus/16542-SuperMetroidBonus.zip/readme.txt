Use with:

No Intro
Super Metroid (Japan, USA) (En,Ja).sfc
ROM Checksum: 21f3e98df4780ee1c667b84e57d88675
CRC32 Checksum: D63ED5F8

