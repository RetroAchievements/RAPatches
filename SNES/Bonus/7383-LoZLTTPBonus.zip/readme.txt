Use with:

No Intro
Legend of Zelda, The - A Link to the Past (USA).sfc
RA Checksum: 608c22b8ff930c62dc2de54bcd6eba72
CRC Checksum: 777AAC2F