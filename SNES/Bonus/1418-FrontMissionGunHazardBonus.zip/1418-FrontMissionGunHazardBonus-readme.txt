Use with:

Front Mission Series - Gun Hazard (Japan).sfc (No-Intro)
2fe3c9af984bd684e1fe681d2901587e
FD3FDBAC
