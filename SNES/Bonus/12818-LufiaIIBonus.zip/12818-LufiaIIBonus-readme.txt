Use with:

Frue_Lufia_v4.sfc
bf57e03293d2a09ece8a83177dd78a99
1026D449

Lufia II - Rise of the Sinistrals (USA).sfc (No-Intro)
6efc477d6203ed2b3b9133c1cd9e9c5d
20F2AC29

