Use with:

No Intro
Mega Man X2 (USA).sfc
RA Checksum: e53bac43ed9049ed28751477e4cc844d
CRC Checksum: 4C53A1B7