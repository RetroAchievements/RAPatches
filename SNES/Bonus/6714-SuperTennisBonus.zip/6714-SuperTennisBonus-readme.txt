Use with:

Super Tennis (USA).sfc (No-Intro)
17accf8a0b3d514561cadbdb03715a71
8D383776
