Use with:

(No Intro)
File:               Fire Emblem - Monshou no Nazo (Japan) (Rev 1).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              A427B7E6
MD5:                0CB432DD9D5C1AFA5048334B110FDDC0
SHA1:               B0B03831D9104E3C5DF551D50EBC275A1692149E
SHA256:             CCD5D8E3415D08EE949297D78ADC05D68EC945C6CC1FF195F1975A47095A3F18