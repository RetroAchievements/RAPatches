Use with:

No Intro
Earthbound (USA).sfc
a864b2e5c141d2dec1c4cbed75a42a85
dc9bb451