Use with:

(No Intro)
Final Fantasy III (USA).sfc
e986575b98300f721ce27c180264d890
A27F1C7A

OR

Final Fantasy III (USA) (Rev 1).sfc
544311e104805e926083acf29ec664da
C0FA0464