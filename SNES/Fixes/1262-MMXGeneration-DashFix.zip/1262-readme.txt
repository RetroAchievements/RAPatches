Use with:

Mega Man X (USA).sfc (No-Intro)
a10071fa78554b57538d0b459e00d224
1033EBA4
