Use with:

(No Intro)
File:               Super Mario World 2 - Yoshi's Island (USA).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D138F224
MD5:                CB472164C5A71CCD3739963390EC6A50