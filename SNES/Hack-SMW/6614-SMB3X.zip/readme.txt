Use with:

(No-Intro)
File:               Super Mario World (USA).sfc
Size (Bytes):       524288
CRC32:              B19ED489
MD5:                CDD3C8C37322978CA8669B34BC89C804