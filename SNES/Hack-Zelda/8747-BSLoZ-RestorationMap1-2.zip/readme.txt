BS The Legend of Zelda - Restoration Map 1 (Japan) (En).bps
Use with:

(No Intro)
BS Zelda no Densetsu - Dai-3-wa (Japan) (SoundLink).bs
719a82679b24fd100ff1f8d4545deaed
F01EEB07





BS The Legend of Zelda - Restoration Map 2 (Japan) (En).bps
Use with:

(No Intro)
BS Zelda no Densetsu - Map 2 - Dai-1-wa (Japan) (SoundLink).bs
c27473b1936346daac5252742e522f64
4BC5370D