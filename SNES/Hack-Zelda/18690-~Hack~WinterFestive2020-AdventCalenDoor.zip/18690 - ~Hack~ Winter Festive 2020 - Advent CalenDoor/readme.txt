Use with:
Zelda no Densetsu - Kamigami no Triforce (Japan).sfc (No-Intro)
03a63945398191337e896e5771f77173
3322effc