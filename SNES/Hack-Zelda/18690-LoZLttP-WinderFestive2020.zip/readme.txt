Use with:

(No Intro)
File:               Zelda no Densetsu - Kamigami no Triforce (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              3322EFFC
MD5:                03A63945398191337E896E5771F77173