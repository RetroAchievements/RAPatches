Use with:

File:               F-Zero (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       262160
CRC32:              AA0E31DE
MD5:                6F334790120E1FE1A972FF184D2CFC50

