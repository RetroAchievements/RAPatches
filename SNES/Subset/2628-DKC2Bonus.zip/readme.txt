Use with:

(No Intro)
Donkey Kong Country 2 - Diddy's Kong Quest (USA) (En,Fr) (Rev 1).sfc
md5: d323e6bb4ccc85fd7b416f58350bc1a2
crc: 4E2D90F4