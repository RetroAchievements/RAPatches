Use with:

(No Intro)
File:               Lufia II - Rise of the Sinistrals (USA).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              20F2AC29
MD5:                6EFC477D6203ED2B3B9133C1CD9E9C5D
SHA1:               A89931C1F29B161B8BE717DFAB4A4ADB54B42B84
SHA256:             7C34ECB16C10F551120ED7B86CFBC947042F479B52EE74BB3C40E92FDD192B3A

OR

(No Intro + RAPatches)
https://github.com/RetroAchievements/RAPatches/raw/main/SNES/Fixes/1005-Lufia2-FrueLufia.zip

File:               Lufia II - Rise of the Sinistrals - Frue Lufia (v4.0) (Artemis).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              1026D449
MD5:                BF57E03293D2A09ECE8A83177DD78A99
SHA1:               3BED8B46ED769A60C897C1D64F6564F3DD0AC1E7
SHA256:             B63CA9AF87BA51723BB2DCBB77A9D8311AB24C4DED6C2E0EF5F5649FA3DF70FA

File:               Lufia II - Rise of the Sinistrals - Frue Lufia (v5.2) (Artemis).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              AECA2726
MD5:                F81AF0A9E66E1AA0119419A9F57BF8A7
SHA1:               A473A9FA99322657F7542A215E0B9556512E0172
SHA256:             E717805242880294B7B0049013265C6FE687DAD25E65BEAD6E0176C1CA2D23AC

File:               Lufia II - Rise of the Sinistrals - Frue Lufia (v6.0) (Artemis).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              9B49F154
MD5:                ED37FC950EF8BE02FC7F66CB37424063
SHA1:               592F6288D9F3937BE434321D6D0D715742A7F530
SHA256:             D1F3226C974B194CFE7971DF3EC66CC23D08D803AA337C4E5F40EE5193B02C81