Use with:

(No Intro)
File:               Nightmare Busters (World) (Unl).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              ABAAFF79
MD5:                5B78A0D25CF6E12BDF20C8F6F6B0CDAF