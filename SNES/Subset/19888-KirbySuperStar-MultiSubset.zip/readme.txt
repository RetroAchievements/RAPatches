Use with:

(No Intro)
File:               Kirby Super Star (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              89D0F7DC
MD5:                CB76EA8AC989E71210C89102D91C6C57