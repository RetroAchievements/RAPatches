Use with:

(No Intro)
File:               Final Fantasy V (Japan).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              C1BC267D
MD5:                D69B2115E17D1CF2CB3590D3F75FEBB9
SHA1:               E937B54FFF99838E2E853697E4F559359AA91FD6
SHA256:             C6858D5C02894A6CC71F4DD452C7F288B319D1952CA56FDB185B4BF5E26244A2

(No Intro + RAPatches)
File:               Final Fantasy V - Whirlwind (v1.44) (clymax).sfc
BitSize:            20 Mbit
Size (Bytes):       2621440
CRC32:              DCF53E2C
MD5:                3BB5A7856C2DA218BE0B9FE0DDB3DAB2
SHA1:               EE42913088CC72AD7FB6C2E3258C74CC9A74989C
SHA256:             7246B4BAA9E176B784E9FC1AB01B3B7CEBFF532B5C10FB212E94C18B70F84DCE