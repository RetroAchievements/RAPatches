Use with:

(No Intro)
File:               EarthBound (USA).sfc
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              DC9BB451
MD5:                A864B2E5C141D2DEC1C4CBED75A42A85