Use with:

(No Intro)
Paladin's Quest (USA)
96e0f7d8becb6c203bde703c02a60122
37FE8126