Use with:

(No Intro)
File:               Super Mario World (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              B19ED489
MD5:                CDD3C8C37322978CA8669B34BC89C804

(No Intro + Sure Shot (v1.3) patch)
File:               SMW - Sure Shot (v1.3).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              390F27B1
MD5:                4032F604F1E2A50508C563409FD39E75