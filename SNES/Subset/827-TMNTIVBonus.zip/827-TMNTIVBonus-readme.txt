Use with:

Teenage Mutant Ninja Turtles IV - Turtles in Time (USA).sfc (No-Intro)
807009d25eb31559974daa3e39eeccd7
5940BD99
