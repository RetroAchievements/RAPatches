Front Mission Series - Gun Hazard [Subset - Bonus].bps
Use with:

(No Intro)
Front Mission Series - Gun Hazard (Japan)
2fe3c9af984bd684e1fe681d2901587e
FD3FDBAC





Front Mission - Gun Hazard [Subset - Bonus].bps
Use with:

(No Intro + RAPatches)
Front Mission - Gun Hazard (Japan) (En) (Aeon Genesis)(1.01) 
fd473bc0035cadd46b8eebdfa619275f
5847D80F
