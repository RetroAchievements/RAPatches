Use with:

(No Intro)
File:               Super Mario World (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              B19ED489
MD5:                cdd3c8c37322978ca8669b34bc89c804
SHA1:               6B47BB75D16514B6A476AA0C73A683A2A4C18765
SHA256:             0838E531FE22C077528FEBE14CB3FF7C492F1F5FA8DE354192BDFF7137C27F5B
