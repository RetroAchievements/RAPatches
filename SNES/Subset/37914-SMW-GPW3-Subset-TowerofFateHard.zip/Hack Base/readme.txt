Use with:

(No Intro + RAPatches)
File:               SMW - Grand Poo World 3 (Barbarian).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              BDA4DE31
MD5:                43E3B61A655B4AC5CA9AF3995C49B121
SHA1:               309E8DD89E31579CB85A86AD7EFFF9D19D9DA9C7
SHA256:             227ED744683709689C4F92069BA91297D29189E0B5C11A6905B288250D3CC342
