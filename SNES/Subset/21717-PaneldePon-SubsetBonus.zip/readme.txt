Use with:

(No Intro)
File:               Panel de Pon (Japan).sfc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              14D70786
MD5:                CE9B7F3572867F3C1C6FF889B02A63A4