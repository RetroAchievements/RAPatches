Use with:

(No Intro)
File:               Super Mario World (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              B19ED489
MD5:                CDD3C8C37322978CA8669B34BC89C804

(No Intro + Celeste.smc patch)
File:               SMW - Celeste.smc (v1.0) (MarkAlarm).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              92F7E4D7
MD5:                510680C44D00073DD3C3E7196B504C82