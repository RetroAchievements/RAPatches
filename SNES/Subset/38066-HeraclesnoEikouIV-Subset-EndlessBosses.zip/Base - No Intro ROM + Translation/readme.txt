Use with:

(No Intro + RAPatches)
File:               Heracles no Eikou IV (Japan) (En) (v1.1) (Translation Corporation).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              2704D638
MD5:                2F5BD42095038F078950DF7F1BD0D9F0
SHA1:               8DC24D9F0DF8F9ABD71A8C80C18508409892103D
SHA256:             C8657220201BBC0F2911D15EC83220912F514904B19F64D139F152245C52E4F9


English Patch: https://github.com/RetroAchievements/RAPatches/raw/main/SNES/Translation/English/3004-HeraclesnoEikouIV-EnglishTranslation.zip