Use with:

(No Intro)
File:               Mortal Kombat 3 (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              4E6AF725
MD5:                EC6FA27BFC201DD0EF0000F4C65FB57A