Use with:

(No Intro)
File:               Secret of Mana (USA).sfc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              D0176B24
MD5:                10A894199A9ADC50FF88815FD9853E19