Use with:

Super Mario World 2 - Yoshi's Island (USA).sfc	(No-Intro)
cb472164c5a71ccd3739963390ec6a50
D138F224