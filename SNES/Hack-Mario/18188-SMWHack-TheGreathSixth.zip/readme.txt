Use with:

Super Mario World (USA) [!].smc	(No-Intro)
cdd3c8c37322978ca8669b34bc89c804
A31BEAD4