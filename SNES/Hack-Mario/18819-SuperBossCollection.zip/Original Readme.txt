                                ____   __  __  _____   ______  _____           _____    ____    ____    ____
                               /  __\ |  ||  ||     \ |   ___||     \         |     \  /    \  /  __\  /  __\
                              |  |__  |  ||  ||  ||  ||  |__  |  ||  |        |  ||  ||  ||  ||  |__  |  |__
                               \__  \ |  ||  ||   __/ |   __| |     <         |     < |  ||  | \__  \  \__  \
                               ___|  ||  ||  ||  |    |  |___ |  ||  |        |  ||  ||  ||  | ___|  | ___|  |
                               \____/  \____/ |__|    |______||__||__|        |_____/  \____/  \____/  \____/
                                  ____    ____   __      __      ______    ____  ______  __   ____   __  __
                                 /  __\  /    \ |  |    |  |    |   ___|  /  __\|_    _||  | /    \ |  \|  |
                                |  |    |  ||  ||  |    |  |    |  |__   |  |     |  |  |  ||  ||  ||      |
                                |  |    |  ||  ||  |    |  |    |   __|  |  |     |  |  |  ||  ||  ||      |
                                |  |___ |  ||  ||  |___ |  |___ |  |___  |  |___  |  |  |  ||  ||  ||  |\  |
                                 \____/  \____/ |______||______||______|  \____/  |__|  |__| \____/ |__||__|

                              Version 1.1                                               Released on 16/02/2022

=========
= ABOUT =
=========

A hack with just boss fights!

In this hack, you can fight against 77 bosses, including all the original SMW bosses, bosses ported from other games, and bosses created by other users!

The original title of this hack was going to be "Tower of Bosses", with the original idea being making Mario fight against all bosses one after another, but then I discovered bugs such as the SMB3 Lakitu staying frozen and Elec Man making the game crash. Said bugs wouldn't happen when making Mario go back to the OW after defeating one, so this is what I did.

I'm going to update the hack over time to add more bosses until running out of space. If I need to add more, I'll just do it on a separate ROM, because expanding to 8 MB requires SA-1, and not all bosses used here support SA-1. I would try the SA-1 hybridizer or the SA-1 converter, but some addresses used by the bosses can't be converted.

=============
= BOSS LIST =
=============

Iggy - Super Mario World
Morton - Super Mario World
Lemmy - Super Mario World
Ludwig - Super Mario World
Roy - Super Mario World
Wendy - Super Mario World
Larry - Super Mario World
Bowser - Super Mario World
Big Boo - Super Mario World
Reznor - Super Mario World
Boom Boom - Super Mario Bros. 3
Bowser - Super Mario Bros. 3
Birdo - Super Mario Bros. 2
Mouser - Super Mario Bros. 2
Tryclyde - Super Mario Bros. 2
Fryguy - Super Mario Bros. 2
Clawgrip - Super Mario Bros. 2
Wart - Super Mario Bros. 2
Bowser (With Stun) - Super Mario Bros.
Bowser Jr. - New Super Mario Bros.
Iggy - Custom
Iggy - Custom
Iggy - Custom
Iggy - Custom
Morton - Custom
Morton - Custom
Morton - Custom
Lemmy - Custom
Lemmy - Custom
Roy - Custom
Wendy - Custom
Wendy - Custom
Larry - Custom
Big Boo (Spits Fire) - Super Mario World / Custom
Fishin' Boo - Super Mario World / Custom
Homing Thwomp - Super Mario World / Custom
Blargg - Super Mario World / Custom
Urchin - Super Mario World / Custom
Giant Dry Bones - Custom
Giant Podoboo - Custom
Goomba - Custom
Spiny - Super Mario Bros. 3 / Custom
Giant Beetle - Super Mario Bros. 3 / Custom
Giant Masked Koopa - Super Mario World / Custom
Giant Piranha Plant - Super Mario Bros. 3 / Custom
Ptooie - Super Mario Bros. 3 / Custom
Albatoss - Super Mario Bros. 2 / Custom
Lakitu - Super Mario Bros. 3 / Custom
Thunder Lakitu - Super Mario World 2: Yoshi's Island / Custom
Toy Koopa - Custom
Master Chuck - Custom
Priscilla the Peckish - Yoshi's Island DS / Custom
Ground Pound Koopa - Mario's Time Machine
Kaptain K. Rool - Donkey Kong Country 2: Diddy's Kong Quest
Kirby - Custom
Lololo & Lalala - Kirby series
Acro - Kirby's Dream Land 3
Whispy Woods - Kirby series
King Dedede - Kirby series
Marx - Kirby Super Star
Pix - Kirby 64: The Crystal Shards
Dracula Duck - DuckTales
Jigglypuff - Pokémon series
Bowling Spin - Sonic the Hedgehog 3
Ganon - The Legend of Zelda: A Link to the Past
Master Hand - Super Smash Bros.
Elec Man - Mega Man
Guts Man - Mega Man
Air Man - Mega Man 2
Shadow Man - Mega Man 3
Star Man - Mega Man 5
Bit - Mega Man X3
Undine - Secret of Mana
Xan Bie - Trials of Mana
Fire Pokey - Custom
Sea Pokey - Custom
Crystal Core - Custom

==============
= CHANGE LOG =
==============

V1.1 (16/02/2022):
* Added 21 more bosses, bringing the total to 77.
* Removed the side walls from the Albatoss room to prevent it from exploding itself with its bomb.
* Removed the message block from Major Flare's Lemmy pre boss room, as the level warp display UberASM causes some issues with message boxes.
* Updated all the SMAS songs, I was using the 2019 versions.
* Added layer 3 text to the selection screen explaining the controls.
* Added layer 3 text to each pre boss room with explanations about their attacks and how to defeat them.
* Added teleport blocks at the top of the Crystal Core room, so you can now leave either through the top, or through the bottom. Yeah, this does mean that boss is still not fixed.
* Fixed Shadow Man and his shuriken's palettes. He's now blue instead of red.
* Changed the background in the Thunder Lakitu room to the one usually seen in battles with Burt.
* Fixed 7601 Morton's palette. He's now green instead of gray.
* Replaced the Carnival Night Zone port with an unsampled version. It's the same port, but edited to use SMW samples instead of EB samples.
* Renamed some bosses: Larger versions of normal enemies now have "Giant" before their name.
* Changed the tileset in Undine and Xan Bie to the tileset used by some custom bosses such as Master Chuck and the custom Koopalings. Since Secret of Mana and Trials of Mana are RPG games, this is what I had to do.
* Changed the tileset and music of Giant Goomba, Giant Spiny, Giant Piranha Plant and Giant Ptooie to the SMB3 fortress tileset/music.
* Replaced the title screen HDMA with a ripped one from the Zable Fahr boss from Super Kitiku Mario.
* Added an in-game credits roll. They are now the final entry of the selection screen. After they are over, you're taken back the the OW.

V1.0 (07/01/2022):
* Initial release.

===========
= CREDITS =
===========

Graphics:
---------
army128 (Super Mario All-Stars: Super Mario Bros. 3 - Bowser's Castle Background)
Black Sabbath (Super Mario All-Stars: Super Mario Bros. 3 - Fortress Foreground, Super Mario All-Stars: Super Mario Bros. 3 - Bowser's Castle Foreground)
Brando (The Legend of Zelda: A Link to the Past - Pyramid of Power) - TSR
Brutapode89 (Super Mario All-Stars: Super Mario Bros. 2 - Warehouse Foreground)
carol (Some graphics from Super Kitiku Mario, used them because data.zip didn't include any graphics)
cheat-master30 (Duck Tales - Transylvania Background & Foreground [Unused], Kirby Super Star - Mt. Dedede Background & Foreground)
cheeyev (Super Mario All-Stars: Super Mario Bros. 3 - Fortress Background)
Cirvante (Mega Man X3 - Gravity Beetle Foreground)
codfish1002 (New Super Mario Bros. - Tower Foreground)
CreationProblematic (Mega Man 3 - Shadow Man Foreground)
Daizo Dee Von (Mega Man 2 - Air Man Foreground)
ECS.98 (Vanilla Styled Title Screen Font)
edit1754 (Donkey Kong Country 2: Diddy's Kong Quest - Chain Link Chamber Foreground)
Erik (Mega Man X3 - Vile Stage Background)
Firebar (Mega Man - Guts Man Foreground)
Gamma V (Castle Background, Classic Castle 2021 Foreground)
Green Jerry  (Ripped graphics from TSR)
Hinalyte (Super Mario All-Stars: Super Mario Bros. - Bowser's Castle Background & Foreground, Super Mario All-Stars: Super Mario Bros. 2 - Castle Background, Super Mario All-Stars: Super Mario Bros. 2 - Warehouse Background)
Iceguy (New Super Mario Bros. - Tower Background)
leictreon (Super Mario All-Stars: Super Mario Bros. 2 - Wart's Castle Foreground)
LF (Pokémon FireRed/LeafGreen - Gym 1 Tileset) - TSR
majora211 (Mega Man - Elec Man Foreground)
MisterMike (Mega Man - Guts Man rocks, Mega Man 5 - Star Man Foreground) - TSR
Paraemon (Sonic the Hedgehog 3 - Carnival Night Zone Act 1 (Mini-Boss) Background) - TSR
RaindropDry (Super Mario All-Stars: Super Mario Bros. - Bowser's Castle Background & Foreground)
Roberto zampari (Yoshi's Island DS - Castle Background)
Rykon-V73 (Donkey Kong Country 2: Diddy's Kong Quest - Chain Link Chamber Foreground, Super Mario World 2: Yoshi's Island - Boss Room Background, Super Mario World 2: Yoshi's Island - Castle Background, Super Mario World 2: Yoshi's Island - Tower/Fort Foreground)
SuperArthurBros (Super Mario All-Stars: Super Mario Bros. 3 - Fortress Background) - MFGG

Music:
------
Anas (Kirby Super Star - Boss, Kirby Super Star - Marx)
Atma (Mega Man 3 - Shadow Man)
brickblock369 (Sonic the Hedgehog 3 - Act 1 Boss)
Darius (Donkey Kong Country 2: Diddy's Kong Quest - Krook's March)
Dippy (Sonic the Hedgehog 3 - Carnival Night Zone Act 1)
Gamma V (Mega Man 2 - Air Man)
Giftshaven (Pokémon Gold/Silver/Crystal - Kanto Gym Leader Battle)
imamelia (Mega Man 3 - Boss Battle)
Infinity (Mega Man 5 - Boss Battle)
Jimmy (Mega Man 2 - Boss Battle)
Kipernal (Kirby Super Star - King Dedede Battle)
Kitikuchan (Dragon Quest 3 - Adventure)
Koyuki (Pokémon Gold/Silver/Crystal - Gym)
LadiesMan217 (some SMAS and YI songs)
Lou (Final Fantasy VI - The Decisive Battle)
MidiGuy (The Legend of Zelda: A Link to the Past - Agahnim & Ganon's Theme)
Moose (CUSTOM - Epic Battle)
oL7G5poF4c (Secret of Mana - Danger, Trials of Mana - Black Soup)
Pinci (Mega Man - Elec Man)
qantuum (Trials of Mana - Political Pressure)
Red Chameleon (Secret of Mana - Eight Ringing Bells)
Roberto zampari (New Super Mario Bros. Wii - Castle Boss)
Samantha (The Legend of Zelda: A Link to the Past - The Prince of Darkness)
Segment1Zone2 (CUSTOM - Heavy Calling, Mega Man - Guts Man)
Tornado (Mega Man - Boss Battle, Mega Man 5 - Star Man)
Wakana (New Super Mario Bros. - Tower)
Wyatt (Kirby Super Star Ultra - The Arena)
x-treme (Donkey Kong Country 2: Diddy's Kong Quest - Crocodile Cacophony)

Blocks:
-------
MarioE (ON/OFF block from switch pack)
Sonikku (Passable Ledge)

Sprites:
--------
7601 (Custom Morton #2)
Atma (Blargg)
carol (Donkey Kong Country 2: Diddy's Kong Quest - Kaptain K. Rool, Kirby Super Star - King Dedede, Kirby Super Star - Marx [Demo 6 version], Kirby Super Star - Whispy Woods, Super Mario Bros. 3 - Bowser, Trials of Mana - Xan Bie)
codfish1002 (Mega Man X3 - Bit)
daigaidai (Mega Man 2 - Air Man)
dahnamics (Custom Iggy #2, Custom Lemmy #2, Custom Wendy #2, Custom Larry, Giant Buzzy Beetle, Giant Masked Koopa,  Giant Piranha Plant, DuckTales - Dracula Duck, New Super Mario Bros. - Bowser Jr., Pokémon - Jigglypuff, Super Mario Bros. 2 - Clawgrip, Super Mario Bros. 2 - Tryclyde)
Darolac (Sea Pokey)
Davros (Custom Fishin' Boo)
Dispari Scuro (Super Mario Bros. 2 - Mouser)
Eminus (The Legend of Zelda: A Link to the Past - Ganon)
Erik (Crystal Core)
Ersanio (Spiny)
EternityLarva (Mega Man - Elec Man, Mega Man 3 - Shadow Man, Mega Man 5 - Star Man)
HammerBrother (Giant Masked Koopa)
Ice Man (Super Mario Bros. 3 - Boom Boom)
imamelia (Goomba)
Kickchon (Secret of Mana - Undine)
Koyuki (Custom Iggy #3)
Ladida (Super Smash Bros. - Master Hand)
Major Flare (Custom Iggy #1, Custom Morton #1, Custom Lemmy #1, Custom Roy, Custom Wendy #1)
Mao (Custom Morton #3, Fire Pokey, Giant Dry Bones, Giant Podoboo)
mikeyk (Level Ender, Super Mario Bros. - Bowser, Super Mario Bros. 2 - Birdo, Mario's Time Machine - Ground Pound Koopa)
Nimono (Super Mario Land - Marine Pop (Small))
Roberto zampari (Urchin, Ptooie, Yoshi's Island DS - Priscilla the Peckish, Sonic the Hedgehog 3 - Bowling Spin)
Roy (Super Mario Bros. 2 - Wart)
RussianMan (Big Boo, spits fire)
SkywinDragoon (Master Chuck, Toy Koopa)
smkdan (Super Mario Land Marine Pop (Small))
Sonikku (Super Mario Bros. 2 - Fryguy)
tan-cos (Mega Man - Guts Man)
Tsutarja (Super Mario Bros. 3 - Boom Boom)
Von Farenheit (The Legend of Zelda: A Link to the Past - Ganon)
Yoshi987 (Custom Iggy #4)
yoshicookiezeus (Homing Thwomp, Kirby 64: The Crystal Shards - Pix)

Patches:
--------
Alcaro (Time Up Fix)
Arujus (No More Sprite Tile Limits)
DiscoTheBat (No Title Screen Movement)
edit1754 (No More Sprite Tile Limits)
MathOnNapkins (No More Sprite Tile Limits)
Medic (Widescreen Overworld)
NoelYoshi (No More Sprite Tile Limits)
Tattletale (No More Sprite Tile Limits)
Vitor Vilela (No More Sprite Tile Limits)

UberASM:
--------
Eduard (Invisible Mario)
JackTheSpades (Level Warp Display)
Kevin (Teleport on Level End)

Tools:
------
Alcaro (Asar)
FuSoYa (Lunar Magic)
JackTheSpades (PIXI)
Kipernal (AddmusicK)
p4plus2 (Gopher Popcorn Stew)
Tattletale (PIXI)
TheBiob (Gopher Popcorn Stew)
Vitor Vilela (UberASM Tool)