Use with:

(No Intro)
Super Mario World (USA).sfc
MD5: cdd3c8c37322978ca8669b34bc89c804
CRC: B19ED489