Use with:

(No Intro)
File:               Super Mario RPG - Legend of the Seven Stars (USA).sfc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              1B8A0625
MD5:                D0B68D68D9EFC0558242F5476D1C5B81