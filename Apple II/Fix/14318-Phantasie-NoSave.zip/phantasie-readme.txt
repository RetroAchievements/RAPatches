Use with:

(4am Crack)
File:               Phantasie (4am and san inc crack) side A - boot.dsk
BitSize:            1 Mbit
Size (Bytes):       143360
CRC32:              5D12CB69
MD5:                8421D0F3E66505290C7FC70EA933F779
SHA1:               42CAE93C68CFB5BF7A52DE3D695B876AAC393736
SHA256:             100F673F14527FB55B417B39AE9A87D45223A50CD2662C73056A9F0753A6BF18

Patch Author: Hexadigital