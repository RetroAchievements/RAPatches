Use with:

Doom (Japan, USA).32x (No-Intro)
79339867d9d4f58b169753d9a29ea1a5
208332FD
