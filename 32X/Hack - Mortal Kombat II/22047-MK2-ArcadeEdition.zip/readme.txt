Use with:

(No Intro)
File:               Mortal Kombat II (Japan, USA) (En).32x
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              773C0A85
MD5:                A95C0E7C1D35FD42CD2E3EB7B06CB6D0