Use with:

Big Bird's Egg Catch (USA).a26 (No-Intro)
1802cc46b879b229272501998c5de04f
96DC9A9C
