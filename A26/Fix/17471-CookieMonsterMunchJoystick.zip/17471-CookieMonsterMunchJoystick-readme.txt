Use with:

Cookie Monster Munch (USA).a26 (No-Intro)
57c5b351d4de021785cf8ed8191a195c
97BA488F
