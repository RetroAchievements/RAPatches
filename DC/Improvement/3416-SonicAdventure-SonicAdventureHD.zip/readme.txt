Use with:

While it can be used with the Rev A Redump version, the patcher goes by the TOSEC version,
which is exactly the same aside from the filenames.

(TOSEC)
- Sonic Adventure v1.005 (1999)(Sega)(US)(M5).gdi

- track01.bin
md5: fe340f253871df58bcfa3de35f1db257

- track02.raw
md5: bce8000330b663c25f5b91f9d2508ea1

- track03.bin
md5: 4d0ea0267b5e472812be4e525d14b804


----------------------------------------

Mods/Codes in patcher:
Required:
- 60 FPS
- Bugfixes
- Draw Distance Hacks
- Analog Drift Fix (mod)
- SADX Style Water Lift
- Skippable Cutscenes (Hold B before a cutscene loads to skip it.)
- Skippable Videos

Optional:
- Widescreen 16:9
- Widescreen fix
- Analog Drift Fix (cheat)

Not Allowed:
- Expanded Windy Valley
- All Characters Unlocked in Adventure Mode
- Easy Fishing

-----------------------------------------