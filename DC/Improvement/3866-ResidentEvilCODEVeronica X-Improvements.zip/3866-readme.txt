__Usage__
Only use 1 patch per disc from this archive; and only patch Track 3. These are not translation patches, please use the patches found in their respective archives first.

__Widescreen__
Alters aspect ratio from 4:3 to 16:9.

__1st Person__
Allows First Person mode in Main Game. Press L+START to enable/disable. Some interactions are impossible while enabled.