Use with:

(Redump)
Shenmue (Europe) (En,Fr,De,Es) (Disc 1) (Track 3).bin
md5: 3753e9d495afabab3ef68228a4864b88
crc: 466D51AD

Shenmue (Europe) (En,Fr,De,Es) (Disc 2) (Track 3).bin
md5: 815f5a90c4d746a442fd3a250c6b502e
crc: 79A72E00

Shenmue (Europe) (En,Fr,De,Es) (Disc 3) (Track 3).bin
md5: b73bec645a4ca28cce1a57bea6d1fb45
crc: 6257E733

Patched bins, .cue files, and .m3u file can share directory
with base game since only track 3 has been renamed in the
.cue files.