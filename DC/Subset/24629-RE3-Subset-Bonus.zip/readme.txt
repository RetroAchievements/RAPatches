Use with:

(Redump)
File:               Resident Evil 3 - Nemesis (USA) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              E623BBEF
MD5:                B004911AB74851E0937E4076B9D781D3
SHA1:               C77930F2DDAC5E11E6434F50387B34F3C417073A
SHA256:             A6286BFAB427D80FA34A20431B89336E96D64B62F31DA3F25B0F71952EE1DD8F