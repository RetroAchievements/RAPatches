Use with:

(Redump)
Sonic Adventure 2 (USA) (En,Ja,Fr,De,Es) (Track 3).bin
MD5: 88b7360c6cbd79c3ca7fbece3df801f9
CRC: BF6CC48F