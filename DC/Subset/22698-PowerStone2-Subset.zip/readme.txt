Use with:

(Redump)
Power Stone 2 (Europe) (Track 1).bin
b31cc9ebf52aff65421606e7ae18526d
D730187C

Power Stone 2 (Europe) (Track 3).bin
e3a4c253c4889feefd36d90950d6296b
219E0C9B