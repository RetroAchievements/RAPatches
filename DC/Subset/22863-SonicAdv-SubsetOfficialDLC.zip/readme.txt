Use with:

(Redump)
File:               Sonic Adventure (USA) (En,Ja,Fr,De,Es) (Rev A) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              00C55860
MD5:                4D0EA0267B5E472812BE4E525D14B804

File:               Sonic Adventure (Europe) (En,Ja,Fr,De,Es) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              CB447185
MD5:                4DF671C2091877BC3DD9B8907649DED4

File:               Sonic Adventure (Japan) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              4E7E341A
MD5:                DFA7A7DF2B6C22128F3AFE4697CC4433

(Gross TOSEC)
File:               track03.bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              7A0E5368
MD5:                E97BF2118A059AFAF01D05C3FD416CB3