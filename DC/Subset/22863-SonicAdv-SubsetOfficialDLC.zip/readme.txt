Use with:

(Redump)
File:               Sonic Adventure (USA) (En,Ja,Fr,De,Es) (Rev A) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              00C55860
MD5:                4D0EA0267B5E472812BE4E525D14B804