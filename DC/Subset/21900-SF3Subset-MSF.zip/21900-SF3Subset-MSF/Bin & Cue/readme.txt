Replace CUE file with the one provided.

Apply xdelta patches to the following:

(Redump)
Street Fighter III - 3rd Strike (USA) (Track 1).bin
MD5: 38bd0264e5383c9b4747154c879b34e2
CRC: 4704C191

Street Fighter III - 3rd Strike (USA) (Track 3).bin
MD5: d285e360b8c7d8cb4954b41677c307ab
CRC: FD3EC7D3