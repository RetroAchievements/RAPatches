Replace GDI file with the one provided.

Apply xdelta patches to the following:

(Redump)
track01.bin
MD5: 3507ddbe9b2e0b8599a7ff544f83bfa0
CRC: 09ECCDC3

track03.bin
MD5: 50a416208d6fd41097d8c4cf8b4dc400
CRC: 04FBD0C1