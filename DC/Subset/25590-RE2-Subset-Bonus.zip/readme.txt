Use with:

(Redump)
File:               Resident Evil 2 (USA) (Disc 1) (Track 3).bin
BitSize:            2 Gbit
Size (Bytes):       284773104
CRC32:              2B185183
MD5:                36BBE410AAC74C71215B51102AD7742D
SHA1:               E441AA0FD42C2FD71C8AEB81C8B68E4CD2ECF4A2
SHA256:             CAE48ED5B2E30846428346448E301469623EA139EA452F23C2A01028A5906437
-------------------------------------------------------------------

File:               Resident Evil 2 (USA) (Disc 2) (Track 3).bin
BitSize:            2 Gbit
Size (Bytes):       282621024
CRC32:              6971FE9F
MD5:                B26E3891DB4C4B81890C904C4F50BCD8
SHA1:               330F9CA0553F08C333CA5203B91460C88C7D2C18
SHA256:             A0B2B496070C53EDDF8E1F6D99953C04369FE5BFAC6B01DC9F767D880E792138
-------------------------------------------------------------------