Use with:

Berzerk (USA).a26 (No-Intro)
136f75c4dd02c29283752b7e5799f978
2E8B4B5F
