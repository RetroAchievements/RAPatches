Use with:

Tutankham (USA).a26 (No-Intro)
085322bae40d904f53bdcc56df0593fc
EC959BF2
