Use with:

MegaMania - A Space Nightmare (USA).a26 (No-Intro)
318a9d6dda791268df92d72679914ac3
33EDC33E
