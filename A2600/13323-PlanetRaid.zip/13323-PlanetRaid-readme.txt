Use with:

River Raid (USA).a26 (No-Intro)
393948436d1f4cc3192410bb918f9724
C3EB7E1E
