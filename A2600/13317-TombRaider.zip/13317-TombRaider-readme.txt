Use with:

Montezuma's Revenge - Featuring Panama Joe (USA).a26 (No-Intro)
3347a6dd59049b15a38394aa2dafa585
E680A1C9
