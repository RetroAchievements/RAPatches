For README, visit:
https://github.com/DerekPascarella/TeamInnocent-EnglishPatchPCFX