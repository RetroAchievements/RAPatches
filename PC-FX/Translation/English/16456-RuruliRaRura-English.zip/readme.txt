`Ruruli ra Rura` Menu Translation, "Quick and Dirty"-style
	Version 1/infinity

The patch is intended to be used with a 2048-byte-per-sector rip of Ruruli ra Rura's data track, track 2.

The menu borders are ugly because the original game used 2-byte shift-JIS text for the borders, and the shift-JIS code needed to be
mangled to support the 1-byte ANK character set, which has very few special boxy characters.  It could be fixed by redirecting the
function call to the BIOS to a custom function, but I don't have the energy to do that.


Untranslated parts:

	Movies.
	Ending credits.
	Title screen logo.
