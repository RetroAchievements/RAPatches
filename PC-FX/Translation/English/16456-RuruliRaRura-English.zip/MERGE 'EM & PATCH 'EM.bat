@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\RuruliRaRuraMerged.bin
set delta_file=%CD%\patch\Ruruli Ra Rura (Japan) (En) (v1.0) (Nekozomb).xdelta
set output_file=%CD%\Ruruli Ra Rura (Japan) (En) (v1.0) (Nekozomb).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Ruruli Ra Rura (Japan)\Ruruli Ra Rura (Japan).cue" "%CD%\RuruliRaRuraMerged"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\RuruliRaRuraMerged.bin"
DEL "%CD%\RuruliRaRuraMerged.cue"

pause
