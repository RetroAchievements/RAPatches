Use with:

Sylvan Tale (Japan).gg (No Intro)
6657230e92f13ed98474523efc29d6b3

Original Patch: https://www.romhacking.net/translations/67/