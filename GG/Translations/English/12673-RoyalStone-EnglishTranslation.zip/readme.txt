Use with:

Royal Stone - Hirakareshi Toki no Tobira (Japan).gg (No Intro)
c05b51ea07c8017a6d12badaea9daf29

Original Patch: https://www.romhacking.net/translations/2076/