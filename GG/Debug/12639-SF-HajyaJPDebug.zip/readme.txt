Use with:

(No Intro)
Shining Force Gaiden II - Jashin no Kakusei (Japan).gg
MD5: 8857422e565412a59c77cb29550715e4
CRC: 30374681