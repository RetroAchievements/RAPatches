Use with:

(No Intro)
Shining Force Gaiden - Ensei, Jashin no Kuni e (Japan).gg
MD5: 8eafd80d35251b5d3f07d5cae27241c1
CRC: 4D1F4699