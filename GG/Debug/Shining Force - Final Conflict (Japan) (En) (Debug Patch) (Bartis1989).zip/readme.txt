Use with:

(No Intro) + Patch
Shining Force Gaiden - Final Conflict - English.gg
MD5: abdef9e89d2963c70c5573d37edd9d9d
CRC: 23BAC434