Use with:

(No Intro)
Shining Force - The Sword of Hajya (USA).gg
MD5: 0a0fa9cbcc3db467191e907794c8c02b
CRC: A6CA6FA9