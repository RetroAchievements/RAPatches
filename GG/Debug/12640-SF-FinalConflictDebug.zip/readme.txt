Use with:

(No Intro)
Shining Force Gaiden - Final Conflict (Japan).gg
MD5: 35ef27f6b4b4ddc4a6ad6c78db8c890b
CRC: 6019FE5E