Use with:

Shining Force Gaiden - Final Conflict (Japan).gg (No Intro)
35ef27f6b4b4ddc4a6ad6c78db8c890b

Original Patch: https://www.romhacking.net/translations/876/