Use with:

Kishin Douji Zenki (Japan).gg (No Intro)
ac6ed281ac8e9d71af186602951cfd7a

Original Patch: https://www.romhacking.net/translations/3767/