Use with:

Tails Adventures (World) (En,Ja).gg (No Intro)
a8bdb1beed088ff83c725c5af6b85e1f
