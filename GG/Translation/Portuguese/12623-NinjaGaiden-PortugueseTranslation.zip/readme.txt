Use with:

Ninja Gaiden (USA, Europe, Brazil).gg (No Intro)
764388b8b5dc2e762fab9badd0eca6ba

Original Patch: https://www.romhacking.net/translations/1856/