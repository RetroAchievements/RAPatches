Use with:

Gojira - Kaijuu Daishingeki (Japan).gg (No Intro)
e550267f3ae767bed5d0e2a126f44a10

Original Patch: https://www.romhacking.net/translations/4140/