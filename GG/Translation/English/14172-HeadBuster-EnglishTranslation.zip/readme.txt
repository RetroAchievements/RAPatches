Use with:

Head Buster (Japan).gg (No Intro)
aa52a741b2952c3713ab791e659c37b5

Original Patch: https://www.romhacking.net/translations/903/