Use with:

Phantasy Star Gaiden (Japan).gg (No Intro)
54be96ca21885145108f1c02e4d88eba

Original Patch: https://www.romhacking.net/translations/63/