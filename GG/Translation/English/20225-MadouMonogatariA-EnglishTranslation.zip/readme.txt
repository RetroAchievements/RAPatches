Use with:

(No Intro)
File:               Madou Monogatari A - Dokidoki Vacation (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              7EC95282
MD5:                AB0D1EB20AC63A984D874A885CA2588D