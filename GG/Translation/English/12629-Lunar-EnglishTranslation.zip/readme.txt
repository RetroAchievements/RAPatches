Use with:

Lunar - Sanposuru Gakuen (Japan).gg (No Intro)
72cea1d3e02b74f10293aff3f2677683

Original Patch: https://www.romhacking.net/translations/1454/