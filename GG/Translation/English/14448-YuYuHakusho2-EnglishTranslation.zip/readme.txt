Use with:

Yu Yu Hakusho II - Gekitou! Nanakyou no Tatakai (Japan).gg (No Intro)
3ccef570d91851265472c90d523971b4

Original Patch: https://www.romhacking.net/translations/68/