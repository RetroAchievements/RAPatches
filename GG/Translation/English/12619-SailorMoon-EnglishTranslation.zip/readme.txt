Use with:

Bishoujo Senshi Sailor Moon S (Japan).gg (No Intro)
33ca01d639aef0b2fecf2d059175abbe

Original Patch: https://www.romhacking.net/translations/4175/