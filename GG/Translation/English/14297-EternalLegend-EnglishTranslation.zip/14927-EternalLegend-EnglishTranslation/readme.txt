Use with either:

Base - Eternal Legend - Eien no Densetsu (Japan).gg (No Intro)
Eternal Legend - Eien no Densetsu (Japan).gg + Eternal Legend EN [v1.0] Disable.bps

Or

Translation - https://www.romhacking.net/translations/5553/
Eternal Legend - Eien no Densetsu (Japan).gg (No Intro) + Eternal Legend EN [v1.0].ips
Eternal Legend EN [v1.0].gg + Eternal Legend Disable.bps


ROM|RA Checksum: e8f49ea568e174b50079f725ce29f45d 
CRC: 75988AB3