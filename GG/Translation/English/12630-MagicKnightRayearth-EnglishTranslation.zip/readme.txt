Use with:

Magic Knight Rayearth (Japan).gg (No Intro)
846d48d0f4024c8094117599d0e1eef1

Original Patch: https://www.romhacking.net/translations/3726/