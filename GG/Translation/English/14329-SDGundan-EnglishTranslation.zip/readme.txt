Use with:

SD Gundam - Winner's History (Japan).gg (No Intro)
2ff122c0eb474e362cbccfb7c72b1a38

Original Patch: https://www.romhacking.net/translations/64/