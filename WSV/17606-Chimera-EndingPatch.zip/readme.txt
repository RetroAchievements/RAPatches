Use with: 

Chimera (USA, Europe).sv (No Intro)
b0cd30f6b9d94b301346300d2b5341d9