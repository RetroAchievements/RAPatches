Use with:

Witty Cat (USA, Europe).sv (No Intro)
RA Checksum: 1cce14e748212e75c21966f12ac5fe1a