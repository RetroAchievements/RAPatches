Use with:

(Redump)
File:               Chrono Cross (USA, Canada) (Disc 2).bin
BitSize:            5 Gbit
Size (Bytes):       741797280
CRC32:              c7f6ab73
MD5:                6463d040aae5156ac146d34402a7988d
SHA1:               0ad65d093b36ae9ecf02aa9abb15952503cb5adf
SHA256:             bcacf57cc9fd6b6bb4aef4298a4b95e74a1c21b8524cabe8e8cca8c46fa90fc3