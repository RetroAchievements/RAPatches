Use with:

(Redump)
O.D.T. (USA) (Track 1).bin
MD5: f63ba68b659e16d9a01cd87af1bfca81
CRC: 7EB6560A