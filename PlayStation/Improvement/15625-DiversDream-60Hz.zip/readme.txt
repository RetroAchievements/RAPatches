Use with:

File:               Diver's Dream (Europe) (En,Fr,De).bin (redump)
BitSize:            4 Gbit
Size (Bytes):       546040320
CRC32:              632AC875
MD5:                B7C02FC845159B38D6312FA0A2E1849A
