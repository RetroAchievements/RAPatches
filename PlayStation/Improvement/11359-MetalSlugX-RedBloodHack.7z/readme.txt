Use with:

(Redump)
Metal Slug X (USA).bin
MD5: 37d9e1179a32661800e74858009a4f8b
CRC: 34100B04