Use with:

(Redump)
File:               Disney-Pixar Toy Story 2 - Buzz Lightyear to the Rescue! (USA).bin
BitSize:            4 Gbit
Size (Bytes):       633125472
CRC32:              5942DB1F
MD5:                A3F77918DC0FB2227E976A2EC75921E2
SHA1:               EF20F5FCAE59C80DD1D0D1BFC51BA51D8C64E967
SHA256:             57A27AE6E34C099424BEF81E9B1F176C34B57A2D114BF2CAC2FD3CD6C73C1B70