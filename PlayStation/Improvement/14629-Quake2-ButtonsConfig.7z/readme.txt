Use with:

(Redump)
Quake II (USA) (Track 1).bin
MD5: ca6eb702916d24f928a265bbaca00235
CRC: EFBD3060