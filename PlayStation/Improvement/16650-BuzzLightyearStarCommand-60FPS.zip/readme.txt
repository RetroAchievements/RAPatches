Use with:

(Redump)
File:               Disney-Pixar Buzz Lightyear of Star Command (USA).bin
BitSize:            4 Gbit
Size (Bytes):       545920368
CRC32:              60BB940A
MD5:                08EE967BDA1550E0CB7B42C6B7E9EE84
SHA1:               D9D3FD40148A074DA3A15856DABB3339D21642E8
SHA256:             F05311CF96CDA4AC0119F01F35D557A19BD09B6F729C42B70A6F6A200062452F