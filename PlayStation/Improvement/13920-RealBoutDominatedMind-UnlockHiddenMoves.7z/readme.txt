Use with:

(Redump)
File:               Real Bout Garou Densetsu Special - Dominated Mind (Japan) (Track 01).bin
CRC32:              29703810
MD5:                CAF7074994AEAB4F9067E4E26B71D78F