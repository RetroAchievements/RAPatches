Use with:

(Redump: http://redump.org/disc/512/)
Crash Bash (USA).bin
MD5: 637f2286b1071d42f883e5592cf2df69
CRC32: 69a6cd83