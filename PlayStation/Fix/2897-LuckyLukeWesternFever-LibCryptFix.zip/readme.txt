Use with:

(Redump)
Lucky Luke - Western Fever (Europe) (En,Fr,De,Es,It,Nl).bin
md5: c04def633121b8e01a2ee791034f286c
crc: 03438C39