Use with:

(Redump)
File:               Clock Tower II - The Struggle Within (USA).bin
BitSize:            3 Gbit
Size (Bytes):       428922480
CRC32:              46A5E547
MD5:                8D50A909B995D23D4D3087A66EE9AF57
SHA1:               A3F9742D9D94AE8E88ADE8A4AA9B80939DD5AA9A
SHA256:             92EB041BE63E71C0BAE1113A8F6957DBD6373A9000CD4364211B7CDA282DA599