Use with:

(Redump)
Suikoden (USA).bin
MD5: c10448fdabcce4dd8efccd5b6d369fa6
CRC: 5CB74712