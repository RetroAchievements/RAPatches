Use with:

(Redump)
Final Fantasy VIII (USA) (Disc 1)
MD5: 50d5b62e81b5369f18c8a145af716af9
CRC: 2691D2DE

Final Fantasy VIII (USA) (Disc 2)
MD5: 2ae4e2022d376a0775e66369de96dc59
CRC: E3EB68DF

Final Fantasy VIII (USA) (Disc 3)
MD5: 58461d8ea573b990c7bbcc32d0feb8a8
CRC: D38EE91E

Final Fantasy VIII (USA) (Disc 4)
MD5: 5a83d022aa592d4e91c02943467d1fd6
CRC: 6CFB6ADF