FILE "Spyro the Dragon - Speedway Mod (v1.0.3) (LuminescentSky).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
