Use with:

(Redump)
File:               Spyro the Dragon (Europe, Australia) (En,Fr,De,Es,It).bin
BitSize:            5 Gbit
Size (Bytes):       732391632
CRC32:              ADB35999
MD5:                8802A4466BE7E522DB3F6FC3DA4830F8
SHA1:               52BBA2F6A7EEC6AC7DC4D08DE13A01B0BBCE30B6
SHA256:             DFBA8B1C19F21AC235347D39B17B1BE5633D8D00D57F6B0173CAF7B04A21FF8B