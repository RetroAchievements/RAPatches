FILE "Spyro the Dragon - Grim Garden (v1.0) (Cyreides, Ello Officer).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
