FILE "Spyro the Dragon - ReverseMod (GnastyLoot).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
