Pete's Gauntlet mod by Husbjörn

The mod was originally hosted on Discord via link but it has since expired. This copy was re-uploaded to preserve it.
I wrote the readme to help provide info to the best of my knowledge of the mod, some things may be inaccurate. -dessertmonkeyjk

--How to play--

You need to own a copy of Spyro the Dragon for the PS1 and convert it into a disc image (bin/cue) to play. 
I personally used the NTSC-U (SCUS-94228) version but other versions may work as well.

1. Run the petemod-patcher.exe, then drag-and-drop the bin or iso file onto the cmd window. (Dropping it on the .exe directly won't work)
2. Follow the on-screen instructions, you'll be propmted to choose a section of the disc to patch the mod into (source.trd, crash 3 demo data, etc.)
3. You'll be prompted to save the new .bin file, place it somewhere where you can find it later. The patcher will also create a .cue file in some instances.
4. Run the new .bin on an emulator or burn it to disc to play on hardware.

The mod can take a moment to load, be patient.

--The setup menu--

When you start the mod, you'll be presented with a menu to configure your experience:
- Time scale: Acts as a multiplyer to increase/decrease the time limit, ranging from 20%-300%.
- First/second/third/forth seed: The random seed value that determines what level, time, and mutations for this session, handy for challenging other players.
- Randomize: Does what it says, randomizes the seed values

Once you choose Start Game, you will need to complete a list of random levels and Gnasty Gnorc to complete it.
Some levels are excluded (homeworlds, flight levels).

--How it works--

Your goal is to gather the collectables listed on screen as fast as possible and then run for the exit. 
Failure to do so will earn you a time penalty to your final time at the end of your gauntlet run.
Each run can take around 40 minutes to complete.

Lives are now infinite, the HUD will now simply count the number of times you died instead.
Collecting extra lives or "pearls" (dropped by enemies) will now freeze the clock for a few seconds.

You can move and hide the new "collectables list" hud by using Start/Select. Unfortunately, that also means you can't pause the game or change settings.

Here is a list of known mutations you can encounter in this mod:
-Superflame: You start with superflame which can be used to anything made of metal (try it on the big gnorcs in Ice Cavern lol)
-Homing gems: Any container with gems will home in on your location, making gem collection easier. 
-Lazy Sparx: Sparx cannot be bothred with gems, you do it
-Sparxless: Sparx has abandoned you, so you die in one hit and must pick up gems manually :(
-Hypersparx: Sparx will grab gems further way like it's his job or something
-Chargeless: You cannot charge at all in this level.
-Flameless: You're a dragon who forgot how to breath fire.
-Free flight: You can fly instead of glide, but only from the highest point you started flying from. (Works similar to Gnasty's Loot)
-x% Speed: Your speed is increased/decreased, making some things easier or harder. This can sometimes make certian jumps impossible.

--Known issues--

-Some emulators may not run this, as of writing it hangs on the latest version of Duckstation. It should run fine on things such as bizhawk 2.8 or ePSXe 2.0.
-You can CRASH the game by gliding or supercharging into the base of a dragon statue. Recommend using save states if possible.
-You cannot pause the game due to the new HUD.
-You may encounter some conditions that are very difficult to complete (Ex. 100% Blowhard in 2 minutes Sparxless)
-Spyro is now green and will occassionally blend into the grass, this is normal
