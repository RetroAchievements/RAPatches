Use with:

(Redump)
Resident Evil 2 - Dual Shock Ver. (USA) (Disc 1) (Track 1).bin
567c05e11fd950e8a9cae38594b65466
5E5F2B34

Resident Evil 2 - Dual Shock Ver. (USA) (Disc 2) (Track 1).bin
a18681f89fa6f4f42f4d84a4f540f9ea
BD82A3CB