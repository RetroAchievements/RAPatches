//========================================//
//                                        //
//           Alternate Fantasy            //
//             by Tirlititi               //
//                                        //
//========================================//

This patch is a mod for the game Final Fantasy IX.

PATCH THE GAME:
---------------
You need an image ISO (.bin) of Final Fantasy IX.
This patch is only compatible with the US version of the game.

1) Extract the files ppf-o-matic3.exe and the patches
2) Run ppf-o-matic3.exe
3) For each discs
  3-a) Select a disc of Final Fantasy IX as your "ISO File"
  3-b) Select the related patch file as your "Patch"
  3-c) Click on "Apply"

If everything went fine, ppf-o-matic3 should tell you.
If it popups a warning about bin/block fail, you either didn't select the disc 1 or don't have the US version.

You can unpatch the game by checking the box "Apply Undo-Patch-Data" in ppf-o-matic3.exe.

INFOS:
------

Version 3.2

This patch has been essentially made with the tool Hades Workshop available on Qhimm's forum for instance :
http://forums.qhimm.com/index.php?topic=14315.0

The tool PPF-O-MATIC and the PPF format were developped by Icarus/Paradox

You can contact me either at forums.qhimm.com
or at laroche.clement1@gmail.com

Have fun !
