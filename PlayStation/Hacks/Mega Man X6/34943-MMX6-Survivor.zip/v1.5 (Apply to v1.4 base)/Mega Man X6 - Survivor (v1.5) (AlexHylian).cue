FILE "Mega Man X6 - Survivor (v1.5) (AlexHylian).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
