Use with:

(Redump)
File:               Chrono Cross (USA, Canada) (Disc 1).bin
BitSize:            5 Gbit
Size (Bytes):       736651104
CRC32:              a07898cc
MD5:                3b29ee931df29f51ecf0817f30e103d7
SHA1:               91ce7726d264111c068a0bee89784f6ebd42ac54
SHA256:             01a0716ed46b6bce7717be1f9220f9bf323cee52404c9cd7fd4ef747d41a98da

File:               Chrono Cross (USA, Canada) (Disc 2).bin
BitSize:            5 Gbit
Size (Bytes):       741797280
CRC32:              c7f6ab73
MD5:                6463d040aae5156ac146d34402a7988d
SHA1:               0ad65d093b36ae9ecf02aa9abb15952503cb5adf
SHA256:             bcacf57cc9fd6b6bb4aef4298a4b95e74a1c21b8524cabe8e8cca8c46fa90fc3