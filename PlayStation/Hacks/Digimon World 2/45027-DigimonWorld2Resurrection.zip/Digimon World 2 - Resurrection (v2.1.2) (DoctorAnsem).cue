FILE "Digimon World 2 - Resurrection (v2.1.2) (DoctorAnsem).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
