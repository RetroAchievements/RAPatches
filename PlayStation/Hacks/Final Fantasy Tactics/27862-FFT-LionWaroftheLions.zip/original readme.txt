*******************************************************************************
                       FFT - The Lion War of the Lions 1.02
*******************************************************************************
                                                              
-------------------------------------------------------------------------------
                              General Information
-------------------------------------------------------------------------------
Title................: Final Fantasy Tactics - The Lion War of the Lions
Type.................: Game
Platform.............: Playstation
More Info............: http://ffhacktics.com/smf/index.php?board=78.0
Image Format.........: .bin/.img/.iso
Burn Tested..........: Yes

-------------------------------------------------------------------------------
                               Post Information
-------------------------------------------------------------------------------
Posted by............: Team TLW (aka Team JotF)
Posted on............: 09/18/2022
Version..............: 1.02
-------------------------------------------------------------------------------
                                  Patch Notes
-------------------------------------------------------------------------------
Play through the playstation classic, Final Fantasy Tactics, with all the bonus
scenes & battles from War of the Lions (PSP). Includes many extras, such as the 
Dark Knight job from WotL, Balthier and Ashley Riot in luei of Luso, party size
increased from 16 to 20,  and the Bench as well bringing your total roster size 
up to 30!

You can even experience the  Rendezvous missions  from WotL in single player as 
you unlock them throughout the game,  as well as the new and massively improved
Treasure Wheel made custom just for TLW 2.0

You also get all the WotL  dialogue, spell, job, skillset, unit names, statuses
and nearly any other instance of new or changed dialogue within WotL  has  been
ported to the PS1 in this mod!

Don't forget about New Game+ and Continue+! That's right! It's finally here, we
we aren't going to spoil all the extras included there just yet, so you'll have
to beat the game and see for yourself.

For the first time ever, play 3 of the 4 sound novels, previously untranslated,
in proper english (images  included) without crashing or softlocking your game.  

View the somewhat informative and more then often hilarious unit quotes for the
first time ever in english!

Enjoy tackling the existing and new side-quests in Chapter 4, without  many  of 
the restrictions imposed on you while playing vanilla.

Create your own mod using TLW as a base, with all the resources created to make
TLW, at your disposal, the possibilites are endless!

All  this and  much  more  await  you  in   FFT - The Lion War of the Lions 1.0
-------------------------------------------------------------------------------
                                 Install Notes
-------------------------------------------------------------------------------
Patch to a clean, unexpanded image file of Final Fantasy Tactics.
-------------------------------------------------------------------------------
                              Install WotL Movies
-------------------------------------------------------------------------------
AFTER patching TLW to a clean unexpanded image file.    Download the file here:
https://www.dropbox.com/s/8i82fdg4jikrfdl/TLW%20Movies.7z?raw=1

- Extract the .ppf file anywhere
- Patch overtop of TLWotL 1.02 patched FFT rom using PPF-o-Matic 3
-------------------------------------------------------------------------------
                                  Bug Reports
-------------------------------------------------------------------------------
If you encounter any bugs or glitches, please make sure you take video, picture
or otherwise, of the issue,  as well as a savestate directly before it happens,
if possible.                          

Post all bugs and visuals for them, here 
https://ffhacktics.com/smf/index.php?topic=12952.0
