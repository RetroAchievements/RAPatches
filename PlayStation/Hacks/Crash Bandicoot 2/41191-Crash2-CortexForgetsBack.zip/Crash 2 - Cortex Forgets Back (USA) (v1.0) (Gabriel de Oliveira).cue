FILE "Crash 2 - Cortex Forgets Back (USA) (v1.0) (Gabriel de Oliveira).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
