Use with:

(Redump)
File:               Crash Bandicoot 2 - Cortex Strikes Back (Europe) (En,Fr,De,Es,It).bin
BitSize:            1 Gbit
Size (Bytes):       259602000
CRC32:              F5E2EC49
MD5:                10DABEBD6A3EFC1E1E9DB4F8F3B864CB
SHA1:               B077862D2C6E1B8060C2EAE2FE82E708B228DE7C
SHA256:             363EF6E65479EE6FC67CBC285262FF697356AB58B5CA5765C82258666650CF8B