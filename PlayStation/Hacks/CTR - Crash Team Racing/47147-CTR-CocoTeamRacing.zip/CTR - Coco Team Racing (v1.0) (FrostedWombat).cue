FILE "CTR - Coco Team Racing (v1.0) (FrostedWombat).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
