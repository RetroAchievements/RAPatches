FILE "CTR 30th Anniversary Custom Adventure (v20260725) (LoloTheSamurai Play).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
