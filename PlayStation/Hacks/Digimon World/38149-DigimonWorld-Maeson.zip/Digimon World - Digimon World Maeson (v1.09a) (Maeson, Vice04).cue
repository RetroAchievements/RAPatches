FILE "Digimon World - Digimon World Maeson (v1.09a) (Maeson, Vice04).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
