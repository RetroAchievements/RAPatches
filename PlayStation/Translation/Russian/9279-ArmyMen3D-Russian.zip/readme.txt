Use with the Redump version of "Army Men 3D (USA)"

- It will consist of 21 tracks and a cue file:
0bf1f7ec4c8242a2be2987aa42c5439b Army Men 3D (USA) (Track 01).bin
c4a83d7396ea8438f63bc6ff66802adb Army Men 3D (USA) (Track 02).bin
542061a048b77f455688e5b8befcd302 Army Men 3D (USA) (Track 03).bin
d86960251179b5625405fb589762c905 Army Men 3D (USA) (Track 04).bin
05eb7c5bdf5e1eb89bbe3669dcd8130f Army Men 3D (USA) (Track 05).bin
5c99d5d03923f5719493a5c7068ee59a Army Men 3D (USA) (Track 06).bin
e16f1e73d4b6d91ed3d752672e6d7624 Army Men 3D (USA) (Track 07).bin
73a6f8840c50b62c99f3d473374dc097 Army Men 3D (USA) (Track 08).bin
a297259383469b4a7c661ba7df0d80f8 Army Men 3D (USA) (Track 09).bin
61f5a42c7e8186d28bafc69821537e9c Army Men 3D (USA) (Track 10).bin
cee95bd7f556b7a40e23693de00164fe Army Men 3D (USA) (Track 11).bin
e50db367b030931104e42dedb4c927be Army Men 3D (USA) (Track 12).bin
56d21c814270b089dc55153b348d7c33 Army Men 3D (USA) (Track 13).bin
715c445c6fb4fd6181abf06397eb3b07 Army Men 3D (USA) (Track 14).bin
5c18c1c8eeb41740a6b36db79a2950b4 Army Men 3D (USA) (Track 15).bin
3ff5b1ce2069417306d86342cace162b Army Men 3D (USA) (Track 16).bin
5c61ffd6e3b63477d00c3d046cd497a1 Army Men 3D (USA) (Track 17).bin
e7a2adb9d59ccb3857309d2bbb690a4e Army Men 3D (USA) (Track 18).bin
fc7e55501bc1edb01ab6c794791b242c Army Men 3D (USA) (Track 19).bin
5a1b83ce5f85b876e247554f94199838 Army Men 3D (USA) (Track 20).bin
5e17d5fb7a134c04e6f0602adf79a975 Army Men 3D (USA) (Track 21).bin
e6e7e2fa396ebbda0983c10c44c1b715 Army Men 3D (USA).cue

- Grab binmerge from here: https://github.com/putnam/binmerge or from RAPatches' Utilities subdirectory

- To merge, use the following command: "binmerge -o "<directory you want the merged bin in>" "<path to Army Men 3D (USA).cue>" "Army Men 3D (USA)"

- Resulting bin should have the following md5: db2c0761bc0511dda4792ee556e9882c

- Apply patch to the merged bin