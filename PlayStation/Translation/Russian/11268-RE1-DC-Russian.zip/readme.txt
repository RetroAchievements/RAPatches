Use with:

(Redump)
File:               Resident Evil - Director's Cut (USA).bin
BitSize:            5 Gbit
Size (Bytes):       707027664
CRC32:              A973B63A
MD5:                50D96C24761EBF5926719C7090F8BF22
SHA1:               D926CEC7AC6A1665CC00039AB92DEE6A6BEBE824
SHA256:             7BB6483E04FC5D99A64256B706309EB64D4D35466FE44A626B90051C54DE2AB9