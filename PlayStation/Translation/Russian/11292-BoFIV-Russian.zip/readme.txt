Use with the Redump version of "Breath of Fire IV (USA)"

- It will consist of 2 bin files and a cue file:
145a7d7ac3469fcb974bbb309ebd61b1 Breath of Fire IV (USA) (Track 1).bin
c5f4302e3c783b0b9c22f15db7f6b6a9 Breath of Fire IV (USA) (Track 2).bin
cf849dd605bed2e13b28937bf4c20584 Breath of Fire IV (USA).cue


- Grab binmerge from here: https://github.com/putnam/binmerge or from RAPatches' Utilities subdirectory

- To merge, use the following command: "binmerge -o "<directory you want the merged bin in>" "<path to Breath of Fire IV (USA).cue>" "Breath of Fire IV (USA)"

- Resulting bin should have the following md5: 96d1bec91f1c8e956a94dd7dd7326d9b

- Apply patch to the merged bin