FILE "Shin Megami Tensei (Japan) (Ru) (v2.1) (Dima Dolgov).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
