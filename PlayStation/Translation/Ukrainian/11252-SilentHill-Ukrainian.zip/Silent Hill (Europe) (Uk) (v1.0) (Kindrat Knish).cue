FILE "Silent Hill (Europe) (Uk) (v1.0) (Kindrat Knish).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
