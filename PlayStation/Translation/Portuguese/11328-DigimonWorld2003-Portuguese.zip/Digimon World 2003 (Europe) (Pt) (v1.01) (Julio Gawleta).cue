FILE "Digimon World 2003 (Europe) (Pt) (v1.01) (Julio Gawleta).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
