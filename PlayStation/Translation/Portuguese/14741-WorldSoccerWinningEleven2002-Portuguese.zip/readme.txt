Use with:

(Redump)
File:               World Soccer Winning Eleven 2002 (Japan) (Track 1).bin
BitSize:            2 Gbit
Size (Bytes):       306834864
CRC32:              2C75AF69
MD5:                95358C340B1CC980F8EEB61DAC18BAA1
SHA1:               2FE78A4AD41158742DF6EE0644788963B0E49750
SHA256:             C0379482CFCE777D6F2CD82CE1AD5DB04A530901AFBC54FD1C808A4BF82F7953