Use with:

(Redump)
File:               Clock Tower - The First Fear (Japan) (Track 1).bin
BitSize:            578 Mbit
Size (Bytes):       75793200
CRC32:              DAB05773
MD5:                6968BA39636641C4D8895335A13F7E98
SHA1:               47BD38FE28333E7898CCD8C495A9B5CE1A2034C0
SHA256:             98C38D74B916B135E0F072E1669D2B5ADCEDD60F478A220CC1282D2EE2BA68D8