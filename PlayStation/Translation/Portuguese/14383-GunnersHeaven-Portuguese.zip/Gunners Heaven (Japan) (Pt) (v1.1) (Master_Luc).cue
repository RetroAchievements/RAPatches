FILE "Gunners Heaven (Japan) (Pt) (v1.1) (Master_Luc).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
