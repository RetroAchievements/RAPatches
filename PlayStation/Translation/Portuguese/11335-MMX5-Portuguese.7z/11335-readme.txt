Use with:

(Redump)
Mega Man X5 (USA).bin
MD5: 98c0d278dc4a795a0a7562d950d37cc9
CRC: 0D0CE609