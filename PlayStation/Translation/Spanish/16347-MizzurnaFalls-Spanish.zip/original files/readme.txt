-------------------------------------------------------------------------
Spanish Translation of Mizzurna Falls v.1.1 by Mr.Nobody
-------------------------------------------------------------------------

This is a Spanish translation for the PS1 game Mizzurna Falls. 
The translation all text dialog in the game and subtitles for the videos.
The translation have no accents or characters that created technical or time issues.
Apply the PPF patch to the bin images using a tool like PPF-o-Matic
or any other compatible software.
Enjoy!

Hacking & ES translation:	Mr.Nobody
Hacking: 			Nikita600
EN-JP Translation: 		Evie Nyan

Big thanks to starplayer and espernight for the technical help.
Also, big thanks to Evie and Gemini for their original work. 

PS. Don't forget to support more translations by subscribing 
and following me on the links below:

------------------------------------------------------------------------------
Traducci�n de Mizzurna Falls v.1.1 al espa�ol por Mr.Nobody
------------------------------------------------------------------------------

Este parche traduce el videojuego Mizzurna Falls al espa�ol. 
Todos los textos est�n traducidos al espa�ol, pero por problemas t�cnicos y de tiempo
no contiene vocales acentuadas ni car�cteres especiales como: "�","�","�","�","�","�","�","�"
Los v�deos estan subtitulados.
Aplica cada archivo en su perspectiva iso utilizando
ppf-o-matic o cualquier otro programa compatible.
�Disfruta del juego!

Hacking & traducci�n:	Mr.Nobody
Hacking: 			Nikita600
EN-JP Traducci�n: 		Evie Nyan

Big thanks to starplayer and espernight for the technical help.
Also, big thanks to Evie and Gemini for their original work. 


PD: No olvides seguirme en los siguientes enlaces para 
apoyar pr�ximas traduciones y proyectos:


- Youtube:
https://goo.gl/sE58x7

- Blogger:
https://mrnobodystudios.blogspot.com/

- Twitter:
https://twitter.com/mrnobodystudios

- Traducciones:
http://www.romhacking.net/community/4650/