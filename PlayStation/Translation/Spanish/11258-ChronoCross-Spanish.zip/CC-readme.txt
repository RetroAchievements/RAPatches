Use with:

(Redump)
Chrono Cross (USA) (Disc 1).bin
MD5: 3b29ee931df29f51ecf0817f30e103d7
CRC: A07898CC

Chrono Cross (USA) (Disc 2).bin
MD5: 6463d040aae5156ac146d34402a7988d
CRC: C7F6AB73