Use with:

(Redump)
File:               Aconcagua (Japan) (Disc 1).bin
CRC32:              C262518D
MD5:                114568B1E8EDE52142152DEFD4607314

File:               Aconcagua (Japan) (Disc 2).bin
CRC32:              28783402
MD5:                28CBB8AC352B755AF6754AF3EBC5C06E