FILE "Breath of Fire IV (USA) (Fr) (v1.0a) (team CR-Hack) (Track 1).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
FILE "Breath of Fire IV (USA) (Fr) (v1.0a) (team CR-Hack) (Track 2).bin" BINARY
  TRACK 02 MODE2/2352
    INDEX 01 00:00:00
