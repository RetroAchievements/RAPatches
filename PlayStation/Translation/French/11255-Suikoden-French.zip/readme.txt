Use with: 

(Redump)
Suikoden (Europe).bin
md5: fa873f86edf4811aca51395218f704f0
crc; 66176DB6