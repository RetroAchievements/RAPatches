FILE "Suikoden (Europe) (Fr) (v1.2) (Chaos Romhack Traduction).bin" BINARY
  TRACK 01 MODE2/2352
    FLAGS DCP
    INDEX 01 00:00:00
