FILE "Suikoden II (USA) (Id) (v1.0) (Pi-Man).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
