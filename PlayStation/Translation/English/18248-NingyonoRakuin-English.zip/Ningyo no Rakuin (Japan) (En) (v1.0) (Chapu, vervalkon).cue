FILE "Ningyo no Rakuin (Japan) (En) (v1.0) (Chapu, vervalkon).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
