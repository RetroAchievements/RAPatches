Use with:

(Redump)
File:               Moon - Remix RPG Adventure (Japan).bin
BitSize:            4 Gbit
Size (Bytes):       640491936
CRC32:              1DF0DBFF
MD5:                F057A24F1772F300363C56B14B5094F0