Use with:

(Redump)
File:               Ganbare Goemon - Ooedo Daikaiten (Japan).bin
CRC32:              702F95BC
MD5:                ad7c68d71479ca78749af3623afcdce4