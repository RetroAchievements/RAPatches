FILE "Adventure of Little Ralph, The (Japan) (En) (v0.9) (zander3312).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
