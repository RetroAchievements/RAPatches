Use with:

(Redump)
File:               Adventure of Little Ralph, The (Japan) (Rev 1).bin
BitSize:            751 Mbit
Size (Bytes):       98454720
CRC32:              3547C6E2
MD5:                AAD8C523462127FF751C8F30B868141B
SHA1:               E76B38ADF940782D9F84327BB518ECFC33602700
SHA256:             F8AE219988683A3C411CDB4FA534B308359B726563E92B75195A28C9EB5711C9
-------------------------------------------------------------------

