An English translation patch for the PlayStation original of *Boku no Natsuyasumi*
(SCPS-10088, 2000). Version 1, built from commit `fe807a34998b0dd88e933a467a92842104acd600` (tag `v1`).

**This is a patch, not the game.** You need your own dump of the Japanese disc; nothing here
contains it, and nothing here is ever sold.

## What is in English

The build wrote 2,983 lines of English into the game. The translation's 40 units (`translation/status.tsv`): 2 reviewed, 38 checked. The voices stay Japanese on purpose: this is a translation with subtitles, not a dub.

## Download

`boku-ps1-v1.zip` is the download, under the names the instructions below use:

* `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].xdelta` — the patch (xdelta3).
* `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].cue` — the cue sheet for the patched image.
* `PATCH.json` and `README.txt` — both sides' hashes, for a script and for a person.

## What you need

A raw dump of the Japanese disc, one MODE2/2352 track, matching Redump (http://redump.org/disc/4890/). Hash it
before you patch: if these do not match, the patch is not for your file.

| | |
|---|---|
| File | `Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin` |
| Size | 658,959,840 bytes |
| CRC32 | `39d1fe3f` |
| MD5 | `ee044864753c75ce0aea4ba777735fcd` |
| SHA-1 | `5959bf7d9835d0a60aeb0143e2d0fc564bfea9fa` |

## How to apply it

1. **Extract** your CHD to a raw image ([chdman](https://docs.mamedev.org/tools/chdman.html)
   ships with MAME; `brew install rom-tools` on macOS):

   ```
   chdman extractcd -i "your dump.chd" -o "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).cue" -ob "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin"
   ```

   A BIN/CUE dump needs no extraction; use its `.bin`. Never patch a `.iso` (2048-byte
   sectors) or the `.chd` itself.

2. **Hash** the image and compare its SHA-1 with `5959bf7d9835d0a60aeb0143e2d0fc564bfea9fa`:

   ```
   # macOS
   shasum -a 1 "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin"
   # Linux
   sha1sum "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin"
   # Windows
   certutil -hashfile "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin" SHA1
   ```

3. **Patch** it with [xdelta3](https://github.com/jmacd/xdelta/releases) (`brew install xdelta`
   on macOS; [MultiPatch](https://github.com/Sappharad/MultiPatch) is a macOS app for the same
   job):

   ```
   xdelta3 -d -s "Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin" "Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].xdelta" "Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].img"
   ```

   The browser patcher RomPatcher.js cannot apply this patch.

4. **Play**: put `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].cue` beside `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].img` and open the `.cue` in your emulator. You
   can recompress with `chdman createcd -i "Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].cue" -o "patched.chd"`.

### Optional: the PPF, for DuckStation

While the release page lists it, `boku-ps1-v1-ppf.zip` is a separate download holding the same patch as a
PPF, with its own `PATCH.json`, `README.txt` and the cue sheet. DuckStation applies it
without patching anything: give `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].ppf` your CHD's name with `.ppf` in place of `.chd`
(`Boku.chd` → `Boku.ppf`), put it beside the CHD, and tick *Settings → CD-ROM → Apply Image
Patches*, which is off by default. DuckStation checks nothing, and the hashes above are of
the extracted image, not the CHD — extract it once (steps 1 and 2) to check your dump.

## What you should get

**A patched image whose SHA-1 is `3ab94dcb5338bd17a8cf848d931efc0476fc9aa4` is v1**, whatever the file is called.
The README on the project's GitHub page lists every version's, under "Which version do I have?".

| | |
|---|---|
| File | `Boku no Natsuyasumi (Japan) [T-En boku-ps1 v1].img` |
| Size | 658,959,840 bytes |
| CRC32 | `01040247` |
| MD5 | `1990984d00fe36b8d05ce2640a65d47a` |
| SHA-1 | `3ab94dcb5338bd17a8cf848d931efc0476fc9aa4` |

`README.txt` in the download says all of this again, including what the patch does and does
not check for you.

## Where it is played

The project is developed and played on Beetle PSX (the mednafen core, as in RetroArch) and
DuckStation. It has never been tested on a real PlayStation.

## How the translation was made

**The English script is written by AI agents** — Claude, the strongest model available, under
Jay's direction — not a sentence-at-a-time machine translation. The game's event scripts were
decoded so that a translator sees a whole scene as the game plays it — which line follows
which, where the choices branch, who is speaking — after reading a story bible, a style guide
and a glossary written for this project. A second agent reviews every line against the
Japanese, Jay reads the script and rules on the questions it raises, and then it gets played.
The reverse engineering and the assembly patches that make room for English were done with
Claude too. The project is made for Jay and his friends and published for anyone who wants it;
everything that produced the script is in the repository to inspect, and pull requests that
improve it are welcome.

## Credits

None of these target the PS1 original's text, and all of them made this project's first day
shorter. What each one knows is written up in
`research/related-projects.md`.

* [pleonex/Boku-no-Natsuyasumi](https://github.com/pleonex/Boku-no-Natsuyasumi) — PSP port
  extraction tools and a format wiki; its glyph table is what first decoded the PS1 script.
* [HilltopWorks/BokuNoNatsuyasumi2](https://github.com/HilltopWorks/BokuNoNatsuyasumi2) — the
  PS2 sequel's complete English patch toolchain.
* [GriffithVIII/Boku-no-Natsuyasumi-ESP](https://github.com/GriffithVIII/Boku-no-Natsuyasumi-ESP) —
  the PSP port's Spanish patch (TraduSquare).
* [psyouloveme/boku1-reversing](https://github.com/psyouloveme/boku1-reversing) — PS1 original:
  Ghidra scripts, a jPSXdec index of the disc, and a RAM map from speedrunning.
* [KendritPy/Boku_ESP_JP](https://github.com/KendritPy/Boku_ESP_JP) and
  [snake7594/boku-natsu-portable-kr-patch](https://github.com/snake7594/boku-natsu-portable-kr-patch) —
  PSP port: a precise dialogue-format spec, and a 2,020-code character table.

## Licence

The tools and patches' source are MIT; the English script and its context notes are
CC BY-SA 4.0 — both in the source archive attached to this release. These patches were
built from a clone of the repository at this release's tag, with `./make.sh import` on a
dump and then `./make.sh release`. *Boku no Natsuyasumi* is © Sony
Interactive Entertainment; this project distributes none of it and is not affiliated with
Sony or Millennium Kitchen. Paths in `code` above are files in the source archive.
