Use with:

(Redump)
File:               Boku no Natsuyasumi - Summer Holiday 20th Century (Japan).bin
BitSize:            4 Gbit
Size (Bytes):       658959840
CRC32:              39D1FE3F
MD5:                EE044864753C75CE0AEA4BA777735FCD
SHA1:               5959BF7D9835D0A60AEB0143E2D0FC564BFEA9FA
SHA256:             7C3C0A3B7E4DDE160B5EE975013B441F089E9F462622342CD02F3298EDBC3142