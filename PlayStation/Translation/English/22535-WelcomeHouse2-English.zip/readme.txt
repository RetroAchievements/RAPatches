Use with:

(Redump)
Welcome House 2 - Keaton and His Uncle (Japan) (Track 1).bin
aa99387a368d1dd3b790e8cf24ade279
73729266