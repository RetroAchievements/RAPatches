Use with:

(Redump)
Fantastic Night Dreams - Cotton Original (Japan).bin
575dabd69484cfcc6a8a0e64958e8db3
EBB3ED2C