Use with:

(Redump)
Kakuge Yarou - Fighting Game Creator (Japan).bin
a4028675a789d0012a7ebf50f243baf1
9FA4195E