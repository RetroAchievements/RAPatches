Use with:

(Redump)
File:               Langrisser IV & V - Final Edition (Japan) (Disc 1) (Langrisser IV Disc) (Track 1).bin
BitSize:            4 Gbit
Size (Bytes):       576338784
CRC32:              AFF30325
MD5:                FC0E02B6F2221B6E84E86FA41A193BE1
SHA1:               2F7FABA4E6EE24E9ED825103231984419FD85562
SHA256:             7630F52373123E23FB2C6AC1BB674F8F8C8D4CF1650BBC197F536AB9A32E45CA

File:               Langrisser IV & V - Final Edition (Japan) (Disc 2) (Langrisser V Disc) (Track 1).bin
BitSize:            4 Gbit
Size (Bytes):       569407440
CRC32:              B04469A3
MD5:                78ACB11D5FDD91B9361F29CCD9B944A4
SHA1:               1EA5C85AE8BDF4282E72DAFBB2FC39B3E35D3619
SHA256:             EC9A15E84D82DF498FD85B267FB1494547B2074ED34F3257C983F5E67AEDD14D

