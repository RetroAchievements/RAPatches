Use with:

(Redump)
Bomberman Wars (Japan, Asia).bin
7e37f361549d63ac1aaa4f5e192a0e24
0D123C88