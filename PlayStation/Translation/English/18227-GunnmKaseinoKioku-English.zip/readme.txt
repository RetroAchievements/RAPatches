Use with:

(Redump)
File:               Gunnm - Kasei no Kioku (Japan).bin
BitSize:            3 Gbit
Size (Bytes):       530639424
CRC32:              156C4055
MD5:                F50F9D35A5F141EB473BF244BDA5C1E2
SHA1:               856DA69190B13B3A3502006364D5EE13626F5830
SHA256:             095EBF216BA9A4C8E0146C54CFF3309FDA3280F592C29EC844B3F395FA130783