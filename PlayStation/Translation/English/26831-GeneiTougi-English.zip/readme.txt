Use with:

(Redump)
File:               Gen'ei Tougi - Shadow Struggle (Japan) (Track 01).bin
BitSize:            140 Mbit
Size (Bytes):       18413808
CRC32:              7FC9A967
MD5:                22CBAA79E7CE4011DD52E1DBDDA1DD19
SHA1:               8C40D8C0765F7A8514583CD3667587EF4DBA884B
SHA256:             74793E0E45CCB9A59FEAC98A2C1615CF57CD3CD4FA6F6A85B24C0834CEE60C21