Use with:

(Redump)
File:               Athena - Awakening from the Ordinary Life (Japan) (Disc 1) (Track 1).bin
BitSize:            3 Gbit
Size (Bytes):       423616368
CRC32:              E0EC28F3
MD5:                AE46BE2DBDB703678489AA44FA20D939
SHA1:               436F79D427CC0A32D2D6F712B0F88139B6569A92
SHA256:             C4397A931C27E4CF1DEFAA373C6D243D3C155E60309DD670A73C28556F7CD134
-------------------------------------------------------------------
File:               Athena - Awakening from the Ordinary Life (Japan) (Disc 2) (Track 1).bin
BitSize:            4 Gbit
Size (Bytes):       606891264
CRC32:              EFEDC911
MD5:                E2A0F4E087FAF0A23C31A97EC3788B32
SHA1:               66A8236E63460086F2211C7CACA9A3F4ECB5F719
SHA256:             695540F7B61979D739AB209D3F12F01E29462C2A2A1921E3D7E154B9DE89FB24
-------------------------------------------------------------------
File:               Athena - Awakening from the Ordinary Life (Japan) (Disc 3) (Track 1).bin
BitSize:            4 Gbit
Size (Bytes):       655951632
CRC32:              2BFECC2B
MD5:                673395A1621AEFF26D1093695D249B5E
SHA1:               DF13CCB7AC65150870E96D2ECFD13D8E3712581B
SHA256:             90801F9DE7D6D566904F7B3D44C9B3BF25952581F380AF28A8EC891DBC5B3F4C
-------------------------------------------------------------------