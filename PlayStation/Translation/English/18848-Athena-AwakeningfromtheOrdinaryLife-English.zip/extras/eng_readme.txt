JAP CD1 MD5 5a6ddabaf8e41a82331725d1b05cf1cb
JAP CD2 MD5 231bda44d1631946444bb8bf6bfa3989
JAP CD3 MD5 7f5fffb7509d35505c1231706b68746b

Input images are single bin/cue (all tracks merged)

Romhacking by Plissken
Translation by Deep_wolf and playerrr

History:
1.0.0 - Initial release

Other translations: https://boosty.to/plissken
Twitter/X: https://x.com/Plissken___
Discord: https://discord.gg/n9vp4yhs5r

Deep_wolf's blogs (in Russian):
https://vk.com/yellowsimpsons
https://www.youtube.com/@Deep_wolf
https://bettertranslationteam.wordpress.com

playerrr's blogs (in Russian):
https://bettertranslationteam.wordpress.com


Known issues:
Game will crash on DuckStation if "PGXP Geometry Correction" is enabled 