FILE "Athena - Awakening from the Ordinary Life (Japan) (En) (v.1.0) (Plissken) (Disc 1) (Track 1).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
FILE "Athena - Awakening from the Ordinary Life (Japan) (Disc 1) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
