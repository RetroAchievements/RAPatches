FILE "Chocobo no Fushigi na Dungeon (Japan) (En) (v1.0) (Specialagentape).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
