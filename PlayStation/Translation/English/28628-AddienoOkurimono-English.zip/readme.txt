Use with:

(Redump)
File:               Addie no Okurimono - To Moze from Addie (Japan) (Track 1).bin
BitSize:            770 Mbit
Size (Bytes):       101011344
CRC32:              8785F7C0
MD5:                131E6CBDA2A6A2805AC96AA5589CF6B6
SHA1:               A897213AE6EF830FB89F5E193223956CAC9B566D
SHA256:             641A918CDB9C2CE6599B990314C89641E8AEF561126AB1EE7D25AFA3900E2E5C
-------------------------------------------------------------------

File:               Addie no Okurimono - To Moze from Addie (Japan) (Track 2).bin
BitSize:            189 Mbit
Size (Bytes):       24794784
CRC32:              1EFFBEC4
MD5:                A02A3938E5EF45491B892049868CA401
SHA1:               BF5BF38E718B615AD3D55FFDD9FFBABDF6884492
SHA256:             9988ECD9585360F18BD0CD69B348B03FBFE560058976513E8557BF011D04DF85
-------------------------------------------------------------------

File:               Addie no Okurimono - To Moze from Addie (Japan) (Track 3).bin
BitSize:            223 Mbit
Size (Bytes):       29247120
CRC32:              C13D44A7
MD5:                CF5E38D6683B14B1353E19C9F688DE36
SHA1:               E36BC2EE410358B180DAD539BCE18A904655EC80
SHA256:             54C495A2776813D7E382B692E492E9243257190739006073E89D34192A6D3414
-------------------------------------------------------------------

File:               Addie no Okurimono - To Moze from Addie (Japan) (Track 4).bin
BitSize:            213 Mbit
Size (Bytes):       28002912
CRC32:              1C4886DD
MD5:                E6D9C9A3E35905CBAFA3408D3A921539
SHA1:               39F3710FAE10CBF1AD38269244B760FED241C896
SHA256:             A3D263FA6D32669E42EF0BD04C41AC71203A14CDA55F6FF99807AD56E0172338
-------------------------------------------------------------------