Use with:

(Redump)
File:               Yutona Eiyuu Senki - TearRingSaga (Japan).bin
BitSize:            4 Gbit
Size (Bytes):       594054048
CRC32:              A0888540
MD5:                E9F64A96497C3CA6DB81EEA06500E3E0
SHA1:               0139D9DB18FEC21B09F0FF608B8872A5D3819DC7
SHA256:             D494D77951ECDE06E5281F26AEE8C83522011D6F09CC257D8059165820E5DC45