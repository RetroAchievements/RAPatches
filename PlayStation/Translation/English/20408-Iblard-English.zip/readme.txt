Use with:

(Redump)
File:               Iblard - Laputa no Kaeru Machi (Japan).bin
BitSize:            4 Gbit
Size (Bytes):       631293264
CRC32:              A75639F0
MD5:                78564C5952B8D4AF2A2F96195035E820
SHA1:               5F4D841E3743ED14B4DD3F9DE8CFE8B7BD4440AE
SHA256:             DFE4DEEF177851417BDD87C2A2EDEABCD8D7C888EB29B4FC006072307872D448