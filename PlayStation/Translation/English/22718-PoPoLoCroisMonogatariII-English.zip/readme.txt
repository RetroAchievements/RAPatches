Use PopoloCrois Story II (English v1.31) (Disc 1).xdelta with:

File:               PoPoLoCrois Monogatari II (Japan, Asia) (Disc 1).bin (redump)
BitSize:            4 Gbit
Size (Bytes):       660977856
CRC32:              D1195D21
MD5:                DF6581B73EEBCAA5CF066493D49DE828
SHA1:               1245E1378C78D5FCB40A0D0082AABBBAF4F18A7D
SHA256:             C31CD2C615A5D42C9B3C0F422D1CBAA9057103F228CD54E236BF40EAC3F992D8


Use PopoloCrois Story II (English v1.31) (Disc 2).xdelta with:

File:               PoPoLoCrois Monogatari II (Japan, Asia) (Disc 2).bin
BitSize:            5 Gbit
Size (Bytes):       732958464
CRC32:              1A6795BC
MD5:                4FDFF32B0D997D25E3FB6163F379081C
SHA1:               178ED1522CCA6164B13082758A2131536616BAA2
SHA256:             C073B7AC1ECE43BA96B0110A1FD927ACADC8202E0C1202A2D77629DC0DA49A62


Use PopoloCrois Story II (English v1.31) (Disc 3).xdelta with:

File:               PoPoLoCrois Monogatari II (Japan, Asia) (Disc 3).bin
BitSize:            5 Gbit
Size (Bytes):       712223232
CRC32:              3AB533CC
MD5:                10D7E7D44B0D870615924729C4844EDC
SHA1:               74F27430AA3533956BA4CE10C8E16DB64B8625B9
SHA256:             FFC54DCB0145A88979D052EE9C24DC3D04009111CF752BAEAB6B155666962F45