Use with:

(Redump)
File:               Rockman Dash 2 - Episode 1 - 'Roll-chan Kiki Ippatsu!' no Maki (Japan) (Demo) (Track 1).bin
BitSize:            723 Mbit
Size (Bytes):       94884384
CRC32:              2FB53FDC
MD5:                DB692E3CACFC4BDE1979098563819993
SHA1:               9053516E976A25E6D4A8575F58A2D28074C8B728
SHA256:             4CB4344526C95AA6C1183AE286901AF9D8F1E439CB03286C2FC39EB4BB39567B