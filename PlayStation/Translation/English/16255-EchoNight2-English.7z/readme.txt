Use with:

(Redump)
Echo Night 2 - Nemuri no Shihaisha (Japan).bin
7f57d3c2b5b9fc25f0783115da106903
6EFF036C