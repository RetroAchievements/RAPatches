Use with:

(Redump)
File:               Super Robot Taisen Alpha Gaiden (Japan).bin
CRC32:              1DA43687
MD5:                5a4ba6bc50728f16c55e47c5051328a3