FILE "Tall - Twins Tower (Japan) (En) (v2.2) (puppy).bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
