Introduction:

Mizzurna Falls is a 1998 PlayStation adventure game developed by Human Entertainment. Heavily inspired by cult classic TV show Twin Peaks, the game follows high schooler Matthew Williams as he searches for his close friend, Emma Roland, who has gone missing. Notable for its unique blend of open-world gameplay, a real-time clock that sees NPCs and events following their own schedules, emphasis on exploration, and elaborate action sequences, Mizzurna Falls is considered a forerunner to later titles such as Deadly Premonition, Shenmue, and Majora's Mask. However, Mizzurna Falls was on the bleeding edge of technology at the time, and its ambitious open-world was ultimately too much for the PlayStation to handle, resulting in a number of bugs.

Many efforts have been made to translate Mizzurna Falls into English, the most notable of which involved professional translator Resident Evie and PlayStation hacker Gemini. While Evie produced a full translation of the game's enormous script, the effort ultimately fizzled out. The primary obstacle was that, when translated into English, the game's script was simply too large to fit on a PlayStation disk. However, Evie released her translated script in the hopes that another hacking group could one day use it to develop a working patch.

This project, developed by nikita600 and Cirosan, does exactly that, using Evie's script as a base. Nikita, a professional mobile game developer, and Cirosan, a professional translator and localization editor, collaborated over the course of several months to finally develop a working translation patch for Mizzurna Falls. Nikita developed a tool specifically for use with Mizzurna Falls that used a new compression algorithm to fit more text onto the disk than was ever possible before. Despite that, the game's script was still too large to fit, which is where Cirosan came in. Fundamentally rewriting and editing a majority of Evie's script (with her blessing), Cirosan produced a script for Mizzurna Falls that was able to fit onto the disk without sacrificing coherence, quality, or significant plot points. The result of Cirosan's rewrites is a full localization of Mizzurna Falls that helps dialogue sound more natural and conversational, in addition to altering certain characters and elements to be more effective with Western audiences. Most of the work on the patch was done under quarantine during the Covid-19 pandemic; Nikita and Cirosan communicated via Discord to develop the patch.

This patch represents a supreme effort by Evie, Nikita, and Cirosan, across three countries and over a period of many months and years, to bring this revolutionary game to Western audiences. Welcome to Mizzurna Falls - we've been waiting for you.



Discord Server & Contact Info:
https://discord.gg/dTYDcJGpcn



Installation:

1. Obtain an unmodified ISO of Mizzurna Falls. We cannot help you do this. It will consist of two files, a .bin file and a .cue file. You will only be modifying the .bin, but keep the .cue around. Your BIN should have the following checksum values:
File MD5      36A96B8E813C1F902446F7FED7D88DD3        
File SHA-1    C49B2A1203831165E63E1129CFE413D4D23D7656
File CRC32    A87F3497                                                              

If you don't know what that means, this tool can help you: https://www.romhacking.net/utilities/1002/

2. If you have not already, download Delta Patcher from here: https://www.romhacking.net/utilities/704/

3. Extract your unmodified BIN, DeltaPatcherLite.exe, and ProjectMizzurnaBeta.xdelta to the same folder.

4. Open DeltaPatcherLite.exe.

5. Click the folder button next to "Original file" and select your unmodified Mizzurna Falls BIN.

6. Click the folder button next to "XDelta patch" and select ProjectMizzurnaBeta.xdelta.

7. Click "Apply patch".

8. Your unmodified BIN has now been patched with the translation, and is the file you should use to play the game. You should keep the .cue file in the same folder as the BIN. The BIN's checksums should now be:equal to:
File MD5      B376BF1ECD1524F4CA5EF97855C1656F        
File SHA-1    8239544D8EE3AF231964D435FC6D9D8C5B496FE0
File CRC32    96DE976D                                

IMPORTANT: If you receive an error message, it's because you tried to patch the wrong BIN. Make sure your ISO's checksum values are equal to those provided above.



Warnings:

Mizzurna Falls suffers from a bug that may cause the world to fail to load when driving in the overworld. This bug may have occured in the original game, as a result of the game's open-world design pushing the PS1 to its limits, but more testing is needed. It may or may not happen during your playthrough, but in case it does, it's recommended that you play on an emulator with a rewind feature, and that you keep the rewind feature enabled. If the bug occurs, simply reload to about 30 seconds before it happened, and continue normally. We do not believe this bug occurs when playing on actual hardware, but do not have enough data to confirm this. If choosing to play the game on actual hardware, save frequently.

You should also be aware of a bug Evie documents in her walkthrough, which she dubs "Event Layering". As she writes:

"Event Layering is a phenomenon that can occur as a result of inarguably poor game design. (But let's give Human Entertainment a break, because this game is years ahead of its time.) An example of Event Layering would be if Matthew arrives at a location and a scene begins automatically with character A whilst character B is calling him at that exact moment on the phone. Matthew will either be unable to answer the phone, or he will answer the phone and proceed to have two different conversations simultaneously. In this case your best option is to restart from your last save and try to readjust your timing, for example by waiting for the phone call and making sure to hang up before arriving at the location where the other event will be triggered."



Credits and Acknowledgments:

Project Leads:
nikita600 & Cirosan

Original Script by Resident Evie

Cirosan:
Final Script, Localization Editor, Text Insertion, Menu Translation, Documentation

nikita600:
Developer of Mizzurna Falls Editor tool, Hacking, Graphic Editing, Video Insertion


Additional Hacking:
starplayer

Video Editor:
Cap'n Neon

Playtesters:
GoronMegaZord
ChickenHunter

Additional Art Assets for Intro Video:
mr.nobody
Tio Victor

Voice of Narrator:
Dazz