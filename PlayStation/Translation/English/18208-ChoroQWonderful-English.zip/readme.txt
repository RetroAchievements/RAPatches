Use with:

(Redump)
File:               Choro Q Wonderful! (Japan) (Track 1).bin
BitSize:            320 Mbit
Size (Bytes):       42042000
CRC32:              8CEF4498
MD5:                68EE95407F1DC5874F68F3931B3B62CE
SHA1:               0DA5B026B134E56B7D457BAA4DCC32D6C0FC57A0
SHA256:             457E2927AD2B231FBB11A02A58D9D5B39EBC7378BD3C29A3F48F2C4D5ADD68C0