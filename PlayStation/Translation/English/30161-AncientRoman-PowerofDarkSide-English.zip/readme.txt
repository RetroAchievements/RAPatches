Use with:

(Redump)
File:               Ancient Roman - Power of Dark Side (Japan) (Disc 1).bin
BitSize:            3 Gbit
Size (Bytes):       498703968
CRC32:              44E1DC27
MD5:                DD7CFB6DFC45E2AF7ED07C17711C060A
SHA1:               0C643477C01329736A6756DB80EB3AA65193BD9F
SHA256:             0AA14007783BAAE369811FC306651359C0055C4C44382285F3E7ECC0B61AB5E5

File:               Ancient Roman - Power of Dark Side (Japan) (Disc 2).bin
BitSize:            4 Gbit
Size (Bytes):       607500432
CRC32:              AD10B7E4
MD5:                AB1ACA2639CCCDB9EA7F17DD7A03EE6E
SHA1:               F17EEB21D7BA2FC528220F2AFFD301B5401F8635
SHA256:             4333032347D737DA6BBD8D0EB490A0D4AB19BDF2FF5829C93EF63C596B774303