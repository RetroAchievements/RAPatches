Use with:

(Redump)
File:               Prisoner of Ice - Jashin Kourin (Japan).bin
CRC32:              7D7A841A
MD5:                417d2e329d8e41d0c4ef034f5d6518f6