Use with:

(Redump)
Moorhuhn 2 - Die Jagd Geht Weiter (Germany) (Track 1).bin
MD5: A7BB480EFA9237C1A7922A3298FE21A2
CRC32: DBAECB9F
File Size: 302 Mbit (39654720 Bytes)