Use with:

(Redump)
File:               Colin McRae Rally 2.0 (USA) (En,Fr,Es) (Track 1).bin
BitSize:            2 Gbit
Size (Bytes):       454448736
CRC32:              6dac1904
MD5:                3fd9c72a3d4bafef12e78bf4bd61b5d1
SHA1:               4d595880ebb6c6f7a2b63d9503b733f44b1ef230
SHA256:             09f49dc090fde4a8c6bb46f0556654e065a1b069efe085d9ab0d655df7810308