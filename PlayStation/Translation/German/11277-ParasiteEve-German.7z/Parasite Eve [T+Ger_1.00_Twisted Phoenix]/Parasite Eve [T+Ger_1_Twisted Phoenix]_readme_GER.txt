1997 & 1998 waren starke Jahre für Squaresoft und die Playstation 1. 
Final Fantasy  7 und Xenogears erblickten u. a. das Licht der Welt und setzten neue Maßstäbe. 
Mit dieser starken Konkurrenz war es für ein bestimmtes Action/Horror RPG nicht sehr leicht aufzufallen. Die Rede ist von "Parasite Eve". 

Es wurde jedoch sehr schnell klar, dass dieses Spiel nicht nur ein Nischenprodukt von Squaresoft war.
Schnell etablierte sich eine Fanbase um diesen PS1 Hit. Die Story, die Grafik, die FMV Szenen, waren alle auf höchstem Niveau. 
Leider schaffte es diese PS1 Perle nie nach Europa und die beiden Nachfolgerteile (Parasite Eve 2 – PS1 & The third Birthday – PSP,  jeweils in Europa erschienen) 
konnten nicht an die Qualität des ersten Teils anschließen. 

Wer sich das Spiel jedoch aus den USA importierte und seiner PS1 einen Chip verpasste, der kam in den Genuss dieses Ausnahmetitels, 
musste aber auch mit guten Englischkenntnissen sehr schnell feststellen, dass es keine einfache Kost war. 
Viele biologische und chemische Fachbegriffe vermischt mit Science-Fiction und alles drehte sich um diese Mitochondrien (die es wirklich gibt). 
Viele konnten die Story daher nicht in ihrer Tiefe voll begreifen.

Parasite Eve auf Deutsch spielen zu können ist auch jetzt über 20 Jahre nach dem Erscheinen dieses Spiel ein Traum vieler deutschen Fans. 

Daher hat sich die Twisted Phoenix Crew an die Arbeit gemacht, das Spiel ins Deutsche zu übersetzen und das Ergebnis kann sich wirklich sehen lassen. 
Böse Zungen behaupten, das Spiel wäre sogar verbessert worden.

Wer jetzt einen "AYA-Effekt" haben will, hat nun die Chance dazu.


Wir wünschen allen Fans der Reihe viel Spaß mit der deutschen Übersetzung von Squaresofts „Parasite Eve“ für die Playstation 1 !!!


Benötigt:
DeltaPatcher
 - Findet ihr in diesem Archiv

Parasite Eve CD 1&2
 - Erstellt ihr aus euren originalen CDs mit IMGBurn
 - https://www.imgburn.com/
 - CD1 Info: http://redump.org/disc/116/
 - CD2 Info: http://redump.org/disc/117/
Anfragen wo man das Spiel runterladen, oder anderweitig herbekommt, werden nicht beantwortet!

Wie patche ich mein Spiel?
Als Erstes benötigt ihr ein Image eurer beiden Spiele-CDs, diese könnt ihr zum Beispiel mit dem kostenlosen Programm "IMGBurn" erstellen.
Danach startet ihr den DeltaPatcher und wählt unter "Original file" die Disc, die ihr patchen wollt, und den dazugehörigen Patch, für CD1 PE_GER100B_D1.xdelta und für CD2 PE_GER100B_D2.xdelta und rückt dann einfach auf "Apply Patch".


Twisted Phoenix Crew:

bentpg
- Initiator, Übersetzung

Karlhungus
- Projektleitung, Übersetzung, Script-Korrektur, Beta-Test

manakoDE
- Programmierung, Script-Korrektur, Beta-Test

Mr. Mad
- Übersetzung

Celes
- Übersetzung

pixeltechie
- Übersetzung, Script-Korrektur

Poe
- Übersetzung, Beta-Test

Retro-Magic
- Beta-Test (Twitch)

Stoepke
- Übersetzung, Script-Korrektur, Beta-Test via Twitch Stream

TundraG3ckO
- Grafikbearbeitung, Beta-Test

Antimatzist
- Beta-Test

Speziellen Dank an
- www.snes-projects.de und Murat vom Playstation The Collectors Club (Facebook)