
  *********************************************************************************************************************
  *********************************************************************************************************************
  **                                                                                                                 **
  **  ############                       #                #       ######   #                                         **
  **  #####  #####                       #                #       ##   ##  #                                         **
  **      #  #     #       #  #   ###  ######  ####    ## #       ##   ##  ####     ####    ####   #####   #  #   #  **
  **      #  #     #   #   #     #       #    #    #  #   #       ## ###   #   #   #    #  #    #  #    #      # #   **
  **      #  #      #  #  #   #   ##     #    #####   #   #       ##       #    #  #    #  #####   #    #  #   ###   **
  **      #  #      # # # #   #     #    #    #       #   #       ##       #    #  #    #  #       #    #  #   # #   **
  **      ####       #   #    #  ###     #     ####    ###        ##       #    #   ####    ####   #    #  #  #   #  **
  **                                                                                                                 **
  *********************************************************************************************************************
  *********************************************************************************************************************


Parasite Eve (Playstation 1)
Patch Version: Beta 1.00 - 2021/05/15
Release in German language


--------------------------------------------------------------------------
	History
--------------------------------------------------------------------------

1997 & 1998 were strong years for Squaresoft and PlayStation 1. Final Fantasy 7 and Xenogears saw the light of the day
and created new milestones.
Concerning such a strong competition it wasn't easy for a certain action/horror RPG to attract attention.
We're talking about „Parasite Eve“.

However it became pretty soon clear that this game wasn't just a niche product from Squaresoft.
A fanbase established itself quite fast regarding this PlayStation 1 hit.
The story, the graphics and  FMV scenes were at the highest stage.
Unfortunately this PlayStation 1 pearl never made it to Europe and both sequels (Parasite Eve 2 (PS1) and
The third Birthday (PSP) – each released within Europe) couldn't follow the quality of the first part.

That one who imported the game from the US to Germany could enjoy this exceptional title but also had to realize that it
wasn't easy to understand even with good English speaking skills. Many biological and chemical technical terms were mixed
with science fiction and everything was about these mitochondria (which really exist). Therefore many players couldn't
understand the deeper sense of the story.

Playing Parasite Eve in German language is even 20 years after the game's release a dream of many German fans.

For this reason the team of Twisted Phoenix took a special trouble to translate the game into German language – and the
result is impressive.

Who ever wanted to experience an „Aya-effect“ has got now the chance.

We wish all fans of the series a lot of fun with the German translation of Squaresoft's „Parasite Eve“ for the PlayStation 1!


--------------------------------------------------------------------------
	Patch information
--------------------------------------------------------------------------

This patch is for Parasite Eve for Playstation 1.
The whole game including graphics has been translated into German language.
For the patch the NTSC-U-version of the game is required.

Serial:	SLUS-00662 (disc No.1)
	SLUS-00668 (disc No.2)

DeltaPatcher is needed (e.g. in the game's download file)
Link: disc 1 - http://redump.org/disc/116/
Link: disc 2 - http://redump.org/disc/117/

For patching the game you need the images of both discs. Start DeltaPatcher and chose under "original file"
the disc you want to patch. There's a patch for each disc.

Disc 1: PE_GER100B_D1.xdelta
Disc 2:	PE_GER100B_D2.xdelta


--------------------------------------------------------------------------
	Project team
--------------------------------------------------------------------------

bentpg		- initiator, translation
Karlhungus	- project leader, translation, script correction, beta testing
manakoDE	- hacking, programming, script correction, beta testing
Mr. Mad		- translation
Celes		- translation
pixeltechie	- translation, script correction
Poe		- translation, beta testing
Retro-Magic	- beta testing (Twitch)
Stoepke		- translation, script correction, beta testing via Twitch stream
TundraG3ckO	- graphics, beta testing
Antimatzist	- beta testing


--------------------------------------------------------------------------
	General information
--------------------------------------------------------------------------

This patch is for free and we disassociate ourselves from commercial abuse.
Using the patch happens on your own risk.
The members of Twisted Phoenix can't be prosecuted for loss or damage when your're using the patch.


--------------------------------------------------------------------------
	Greetings & thanks
--------------------------------------------------------------------------

Special thanks to the community of SNES-Projects (www.snes-projects.de) and Murat of "Playstation The Collectors Club" (facebook).