Use with:

(Redump)
File:               Final Fantasy Origins (USA).bin
Size (Bytes):       589557024
CRC32:              d41ab110
MD5:                3ec86e30d99c75e64a04e9f5828a904f
SHA1:               495620e1c35756f53f1d0cbec9ee000f947eb79b