Use with:

(Redump)
Monster Rancher 2.bin
md5: d84a42e1ad160c40d5049f398704dec6

All this patch does is add some extra benign content near the "Sony Computer Entertainment Inc. for North America" to allow the game's hash to be differentiated. It specifically replaces 16 bytes starting at 0xdcb7 with the following:
```
53 75 62 73 65 74 2d 4d 52 32 2d 33 38 39 4d 34 
```

To make use of the included .cue/.m3u files, it's recommended that you rename your patched .bin to "Monster Rancher 2 [Subset - 389 Major 4].bin"