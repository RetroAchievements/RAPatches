Use with:

(Redump)
File:               Walt Disney's The Jungle Book - Rhythm n' Groove (USA).bin
BitSize:            5 Gbit
Size (Bytes):       749403648
CRC32:              60F0C8C9
MD5:                B58E1B0715BD442BE70941D846E13A7F
SHA1:               696212819A652F9DD9FF6CC4B627CD3D454E1540
SHA256:             7D69135D3AD3B7BF6E41567D37A4AEF3FDEC14593876E808D5211BC7A5ACD39E