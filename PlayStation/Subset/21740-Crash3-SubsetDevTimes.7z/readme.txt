Use with:

(Redump)
File:               Crash Bandicoot - Warped (USA).bin
Size (Bytes):       285130608
CRC32:              05e3012b
MD5:                a66777800f028b8443d8a5e278ba69bd