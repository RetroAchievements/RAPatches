Use with:

File:               Threads of Fate (USA, Canada).bin
BitSize:            2 Gbit
Size (Bytes):       357454608
CRC32:              59B2F8A3
MD5:                BF49E5E7A09ACC46625B5CED33DD45F5
SHA1:               375E4A344C4FEEF969BEF6042FF1F90E350FA5D5
SHA256:             10EC26EA0C15B4605058543E61077824C37C7FD485A070604B8EA8805B0EE8F8



1)  Patch the game with this using Delta Patcher or xDelta
2)  If you need a new .cue file, make a copy of your original .cue file and name it the same as the patched .bin

	Example:
	Patched file = Threads of Fate Subset.bin
	New CUE = Threads of Fate Subset.cue

3)  Edit the .cue file (notepad or similar) so that the first line is
	FILE "[name of patched .bin]" BINARY

	Example:
	Patched file = Threads of Fate Subset.bin
	Line 1 reads
		FILE "Threads of Fate Subset.bin" BINARY

	Quotations must be included