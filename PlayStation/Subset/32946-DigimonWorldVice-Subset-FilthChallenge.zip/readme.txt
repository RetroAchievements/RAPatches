Use with:

(Redump)
File:               Digimon World (USA).bin
BitSize:            2 Gbit
Size (Bytes):       381771936
CRC32:              E6FDD00E
MD5:                8520EDAC0F7F1454F8A008AC5E599C1A
SHA1:               5611645DA66183E30D11FB6C11A2784FF47E1FDB
SHA256:             06084490EA0DB34099B31495CCBA4EC18FB0FF25C7683C508E9D2DB93D4495F4



Digimon World - Vice [Subset - Filth Challenge].xdelta
- Digimon World (USA) + Vice + Hardcore + Filth Challenge + Super Dirt Reduction + Super Low Monochromon Goal + Training Boost Fix