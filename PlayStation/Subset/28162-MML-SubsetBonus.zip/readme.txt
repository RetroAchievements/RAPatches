Use with:

(Redump)
Mega Man Legends (USA) (Track 1).bin
md5: 5d275ab5d6e4ab79b792990c70cc5970
crc: 1F55BD97