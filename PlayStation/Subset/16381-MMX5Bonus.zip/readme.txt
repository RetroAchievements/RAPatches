Use with:

Redump
Mega Man X5 (USA)
RA Checksum: e587ff4a17ca07291a0deb17a6ea4640