Use with:

(Redump)
File:               Final Fantasy Chronicles - Final Fantasy IV (USA) (v1.1) [Subset - Rare Drops].bin
BitSize:            2 Gbit
Size (Bytes):       385810320
CRC32:              BD5E5707
MD5:                6AD32893D80B8BE73B3B2F26F0DC9145
SHA1:               BA56F21CEAC1E5EE8DC22391992C9A3B8E197162
SHA256:             D9F9C27C6EAB593147AC1F7713FF7BB2C84EFC5FA4CA7B168D5D00C4D99370F1