Use with:

https://gamebanana.com/mods/download/333528 -> vshaggyv2_5psxupdate3.zip

File:               funkin.bin
BitSize:            3 Gbit
Size (Bytes):       403328016
CRC32:              7B463F93
MD5:                ADC7A8392277E3393F25509460C64092
SHA1:               70567ED9F4EBD69BE28EEE1AD4D213EF56BFF6EA
SHA256:             73BA21B0B439ED63325C82FB06A8BD7F06DDBB0D43DE6AA1FBB72C2745DF4FEB