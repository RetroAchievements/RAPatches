Use with:

[Redump]
File:               Racing Lagoon (Japan, Asia).bin
BitSize:            5 Gbit
Size (Bytes):       748634544
CRC32:              22F8241C
MD5:                7A7358B2169D6B85B5FFC6CBFF364771
SHA1:               D7799AAA009CA173D4B538691E0156163EB458E3
SHA256:             3C475793E4090967D345D0763BB9C0EEF0237C41DFB9F36BF33823C301D7036E

[Redump + RAPatches]
File:               Racing Lagoon (Japan, Asia) (En) (v1.1) (Hilltop).bin
BitSize:            5 Gbit
Size (Bytes):       748996752
CRC32:              13279D1D
MD5:                133C6A8BBD1EBA7E448B44F4FB6E7046
SHA1:               B5283A15E0FEB11D54051280757E0E79146BF214
SHA256:             3E2BC91495E145F427136BA827DA1778A4DC2B9B65F0167240B29AB6EB0BD29A