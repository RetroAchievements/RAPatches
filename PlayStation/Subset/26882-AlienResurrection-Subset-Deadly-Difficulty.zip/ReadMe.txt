Patch to enable Deadly Difficulty in Alien Resurrection (PS1)
This also disables the Cheat Menu and all Button Combinations to activate Cheats

Use with: Alien Resurrection (Subset Deadly Difficulty) (v1.0) (manakoDE) (Track 1)
http://redump.org/disc/7489/
CRC32: f9b6964f
MD5: 0542c7e2ed28db4aaffc1534e8760d78
Rash: 057fef3c52eb043ac02675e11013ff40