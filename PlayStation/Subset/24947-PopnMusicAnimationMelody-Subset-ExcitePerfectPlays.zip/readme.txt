Use with:

(Redump)
File:               Pop'n Music - Animation Melody (Japan).bin
BitSize:            1 Gbit
Size (Bytes):       218451408
CRC32:              34A5E309
MD5:                DB38B3DAD1100888303457591154D65D