Use with:

(Redump)
Monster Rancher 2.bin
md5: d84a42e1ad160c40d5049f398704dec6

All this patch does is add some extra benign content near the "Sony Computer Entertainment Inc. for North America" to allow the game's hash to be differentiated. It specifically replaces 31 bytes starting at 0xdd20 with the following:
```
4D 4F 4E 53 54 45 52 52 41 4E 43 48 45 52 32 20 53 55 42 53 45 54 20 33 38 39 20 4C 43 55 50
```
The above is just ASCII "MONSTERRANCHER2 SUBSET 389 LCUP".

To make use of the included .cue/.m3u files, it's recommended that you rename your patched .bin to "Monster Rancher 2 [Subset - 389 Legend Cup Champions].bin". 

To play this subset with your save file from the core set, you likely already have memory card sharing enabled. You can make a copy of your save onto a shared memory card when a given Monster is ready to win the Legend Cup and load that save using your patched .bin!