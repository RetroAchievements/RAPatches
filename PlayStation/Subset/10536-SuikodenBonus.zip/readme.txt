Use with: 

(Redump)
Suikoden (USA).bin - use 1.0, NOT 1.1/Rev 1
md5: c10448fdabcce4dd8efccd5b6d369fa6
CRC: 5CB74712

(Redump)
Gensou Suikoden (Japan) (v1.0).bin - again, use the 1.0, not 1.1/Rev 1 aka "The Best"
md5: 851403e727d6910ea91a8f259c9390f8
CRC: 6F9E9AC3
