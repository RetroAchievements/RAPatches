Use with:

[Redump]
[Street Fighter EX2 Plus (USA)]
[6058AF65FA68F2FBE0B49F41106C0C71]
[1DA1E361]