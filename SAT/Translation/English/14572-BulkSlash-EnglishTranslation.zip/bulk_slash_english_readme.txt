I. INTRO 
II. HOW TO APPLY THE PATCH
III. HOW TO PLAY THE PATCHED GAME
IV. TIPS FOR PLAYING BULK SLASH
V. CONTENT WARNING
VI. TEAM CREDITS

[I. INTRO - So you’ve downloaded the Bulk Slash English patch. Now what?]
Thanks so much for downloading the Bulk Slash English Localization patch! We hope this labor of love aids in your enjoyment of one of the Sega Saturn’s finest action games.  

The existence of this patch and the team who created it are thanks only to the community-building efforts of SHIRO Media Group. We’ll be sharing more detailed info about Bulk Slash and the localization project on the SHIRO! blog in the near future, so please check them out!

Blog: https://www.segasaturnshiro.com 
Discord: https://discord.gg/SSJuThN
YouTube: https://www.youtube.com/channel/UCfTSQ67HNTG7ENRNU_XGFUA
Twitter: https://twitter.com/playsegasaturn

Please be aware that in addition to the patch (.SSP) file itself, the package you’ve downloaded includes a few other goodies: 
-Fully translated versions of the original Bulk Slash fold-out instruction manual and back-of-box art 
-A completely original, North American-style manual and back-of-box art for longbox lovers

Enjoy these goodies, but please do not use or distribute them for financial gain!


[II. HOW TO APPLY THE PATCH]
What you need:
-Knight0fDragon’s Sega Saturn Patcher - https://segaxtreme.net/resources/sega-saturn-patcher.73/ 
-A Bulk Slash disc image (BIN/CUE). If you have a copy of the game, you can rip your own image using CD mounting software like ImgBurn.
-The Bulk Slash English Localization patch file (.SSP) included in this package.

1. Open the Sega Saturn Patcher.
2. Click “Select Saturn Game” > “CD Image””
3. Select your Bulk Slash CUE file. 
4. Click the “+ Game Patch (SSP)” button on the far right.
5. Select the Bulk Slash English Localization patch file (.SSP).
6. Click “Build Image.” This will bring up a “Save As” dialogue box. Choose a destination for the new, patched version of the game, and click “Save.” 
7. If everything worked, the patcher should give you a message saying "Success! CD Image successfully created." Voila. You now have a patched disc image. This is what you need to play Bulk Slash in English! 


**If you wish to EXCLUDE the dubbed voiceover, see below. Otherwise you can skip to Section III.**
What you need (in addition to the items listed above):
-CD Mage - https://www.romhacking.net/utilities/1435/

1. Patch an original Japanese copy of Bulk Slash with our English localization patch, using the steps above — don't save over the original game files, though.
2. Open the original Japanese copy of Bulk Slash in CD Mage. You may have to choose "Track 1" as an M1/2352 track to see all of the game's internal files.
3. Right-click and choose "Extract Files..." on each of the following files and save them wherever you want on your computer:
   - VCP0.DAT
   - VCP1.DAT
   - VCP2.DAT
   - VCP3.DAT
   - VCP4.DAT
   - VCP5.DAT
   - VCP6.DAT
   - CORON_ED.CPK
   - KINA_ED.CPK
   - MAIN_ED.CPK
   - METHI_ED.CPK
   - NIRA_ED.CPK
   - REONE_ED.CPK
   - RIRA_ED.CPK
   - RUPIA_ED.CPK
4. Now close the Japanese copy of Bulk Slash and then use CD Mage to open the copy of Bulk Slash that you patched with our English localization patch.
5. On each of the .DAT and .CPK files named in Step 3, right-click and choose "Import File..." then select the corresponding file that you extracted from the original Japanese game.
6. Now your patched copy of Bulk Slash has all Japanese voices but all on-screen text will be in English. 


[III. HOW TO PLAY THE PATCHED GAME]
What you need:
-A Sega Saturn emulator, such as Yaba Sanshiro or Mednafen
OR
-An ODE that allows you to play Saturn games off an SD card, using a real Saturn. Popular options are the Satiator, MODE, and Fenrir.
OR
-A Pseudo Saturn Kai cartridge or other way of playing games off a burned CD

Emulator Method:
1. Open your emulator
2. Choose “Open ISO…” and select your patched Bulk Slash “CUE” file.
3. Enjoy!

ODE method:
1. Copy the patched Bulk Slash BIN and CUE files onto your SD card.
2. Insert SD card in ODE.
3. Power on Saturn and boot game from SD card as normal.

Burned CD method:
1. Use disc mounting software such as ImgBurn to write your patched Bulk Slash image to a blank CD-R (not a DVD-R!) 
2. Insert burned game disc into your Saturn.
3. Power on Saturn and enjoy!
*Note that Sega Saturns can’t run burned discs by default, so you MUST have a workaround such as Pseudo Saturn Kai, which can be flashed to a Pro Action Replay cartridge. You can also buy custom cartridges preloaded with Pseudo Saturn Kai.  

[IV. TIPS FOR PLAYING BULK SLASH]
-Chaining
In Bulk Slash, explosions can create chain reactions, which greatly increase your score. This is the backbone of the game’s scoring system, so if you care about score, always be chaining!

In Robot mode, try lobbing a fully charged bomb into the center of a group of enemies (or other destructible objects). See? And the navigators love it.

-How to unlock a “M.I.S.S.” navigator
There are seven navigators (including one secret one) you can permanently unlock across multiple playthroughs of the game. Here’s how:
1. Find the “M.I.S.S.” power-up icon hidden in each stage. Each one houses a specific navigator. 
2. The navigator will introduce herself and you can choose to bring her aboard. Choose “Yes.”
3. Complete the game using the navigator you want. 
4. You can now select that navigator at the start of every new game. 
*Note that you MUST clear the game using that navigator to permanently unlock them! If you’re in a rush to unlock a navigator, try playing through the game on Easy mode.

-How to unlock the secret seventh navigator
1. Clear the game with each of the other six navigators.
2. On the seventh playthrough, in Stage 7, look left from the starting point. On previous playthroughs, there was a door here labeled “Kina.” That door is now open. Enter it!

-Saving Progress
Be aware you can NOT save your progress mid-game. Progress is only saved upon clearing the game. So, what data is actually saved?
1. Which Navigators are unlocked
2. The “romantic affinity” level of each navigator (1-3)
3. High scores
4. Unlocked bonus artwork (“Visual Bonus”) and voice samples

Take heart—a playthrough of Bulk Slash only takes around an hour, so it’s meant to be cleared in a single sitting, many times over. Also, you have infinite continues!

-Upgrading your Navigator’s “Romantic Affinity” Level
Each navigator has an affinity level that rises (to a maximum of level 3) the more you use them. In general, clearing stages quickly and without taking damage is a good way to level up your navigators, but each nav also has secret criteria that help them level up faster, so experiment with different play styles. 

When your navigator levels up, she’ll offer more precise assistance and new voiceover lines.

-Boss Tips
--During boss fights, pressing the X, Y, or Z button (or left stick button on the Twin Stick) will recenter the camera on the boss. Use liberally! 
--Your radar tracks bosses’ bullets. If you’re overwhelmed by the number of projectiles onscreen, try using your radar to dodge. 
--Most bosses can be defeated using Plane mode and launching salvos of homing missiles. In general, flying at higher speed makes dodging easier while lower speed makes aiming easier.

[V. CONTENT WARNING]
Bulk Slash is a Japanese game from 1997, and borrows elements from the teen dating sim genre, which was popular in Japan at that time. Although the game was rated suitable for all ages and doesn’t contain much explicit content, it does contain themes that some players may find objectionable. These are outlined below, but please be aware they do contain spoilers.

1. One of the game’s endings implies that a character who is sixteen years old during the events of the game later marries the protagonist, who is nineteen during the events of the game.  
2. Similarly, one of the game’s endings implies that a character who is twelve years old during the events of the game later marries the protagonist. (She is depicted as an adult in the ending.)
3. The game manual uses the term “romantic affinity” in regards to your relationship with the navigators in general, although there is no specific suggestion of a romantic relationship with any of the navigators until the ending FMVs, which take place an undetermined amount of time after the events of the game.

We have deemed it beyond the scope of this project, which is inherently a preservation effort, to censor/alter these elements, but we thought players should know, just in case. 
 

[VI. LOCALIZATION TEAM CREDITS]
Project Lead, Translator, Voice Director - Greg Moore
Script Editors - Dan “Danthrax” Myers, Chanh “Burntends” Nguyen, Chris “Ghaleon Unlimited” Hatala
Code Insertion, Video Editor - Mamdouh “Mampfus” Maduar
Graphics and Font Editor, Tile Setter, Manual Layout - Dan “Danthrax” Myers
Talent Scout, Community Manager - Chanh “Burntends” Nguyen
Reverse Engineer, Developer - Anthony "Knight0fDragon" Randazzo
Recreated Musical Score - Jiggle85, Jiggle85's brother, Shadowmask
Recreated Sound Effects - Shadowmask
Audio Engineers - Mamdouh “Mampfus” Maduar, Greg Moore, Shadowmask
Edited Bulk Slash Logo in the Manual - SaturnDave
Original Japanese Manual Scan - Chris “Ghaleon Unlimited” Hatala

ENGLISH CAST
Chris Dooley - Jonathan Boncher
Riesen Lavia - Luuzine

Leone Rhodes - Edobean
Lira Hart - Erin Lefe
Metical Flair - Dark Mysty
Naira Savage - Raycher
Rupia Rude - Diana Allocco
Colón Steiner - Saskia Amira
Kina Dibiase - CrouchingMouse

Narrator - Nick “PandaMonium” Broadway
Protecting Boy, Mana - CrouchingMouse
Bully #1 - Eugene
Bully #2 - Edobean
Adult Kina, Computer - Cargodin
Reporter - Sara Biebuyck
King Flair - Ucial
Lira Fans - Danthrax, Mampfus, Burntends, Greg Moore
Motor Show Men - SaturnDave, Patrick “TraynoCo” Traynor

SPECIAL THANKS
TrekkiesUnite118
Malenko
Kris Taquka’angcuk Knigge
Thorsten Roth
Connor
Bofner
The localization team's families
Shiro Media Group
SegaXtreme forum
The original Bulk Slash dev team



This localization patch was initially released to the public on December 10, 2021.