Use with:

(Redump)
Shining Force III - Scenario 2 - Nerawareta Miko (Japan) (Track 1).bin
D88476EE
ef890d2f6ed900ec8cc96e83a7b1c41d

Shining Force III - Scenario 2 - Nerawareta Miko (Japan) (Track 2).bin
8C119B40
d4048c1e705f5c576dbd3dcdda9b9c19