Use with:

(Redump)
Shining Force III - Scenario 1 - Outo no Kyoshin (Japan) (Track 1).bin
DFAEE920
b991cc1a933fa785ed3f92c131a5a891

Shining Force III - Scenario 1 - Outo no Kyoshin (Japan) (Track 2).bin
8C119B40
d4048c1e705f5c576dbd3dcdda9b9c19