Use with:

(Redump)
Shining Force III Premium Disc (Japan) (Track 1).bin
4064BC3E
0cde397b0f369631e4051e1f76ccfc25

Shining Force III Premium Disc (Japan) (Track 2).bin
8C119B40
d4048c1e705f5c576dbd3dcdda9b9c19