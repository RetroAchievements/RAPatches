Use with:

(Redump)
Shining Force III - Scenario 3 - Hyouheki no Jashinguu (Japan) (Track 1).bin
E6F03EAB
455c90108d57b4570cca42adb221bfbd

Shining Force III - Scenario 3 - Hyouheki no Jashinguu (Japan) (Track 2).bin
8C119B40
d4048c1e705f5c576dbd3dcdda9b9c19
