Use with:

(Redump)
File:               Lode Runner - The Legend Returns (Japan) (Track 01).bin
BitSize:            89 Mbit
Size (Bytes):       11672976
CRC32:              8B6D4938
MD5:                87D7456C6F460DCD0C1B8355417853F9
SHA1:               68CBCD997C2406F043119FD4BFC077E254E770E6
SHA256:             6C0B6DB0DEC957F585D4FCE8F84F27DC08BFF77C48B1AD7AFA5DD5E07B6BC815