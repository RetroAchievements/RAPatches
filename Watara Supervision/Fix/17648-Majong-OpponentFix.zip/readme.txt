Use with:

(No Intro)
Majong (USA, Europe).sv
57c7f913afe11d5c30252280a31eb04a
96E2E6D7