Use with: 

Thunder Shooting.sv (No Intro)
5a578d07bb4da9215acdc2343e337059