Use with:

Penguin Hideout (USA, Europe).sv (No Intro)
RA Checksum: 0ec15e7b722003989ec0094423e691f9