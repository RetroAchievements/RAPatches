Use with:

Togepi no Daibouken (Japan).min (No Intro)
a4eb2facaa5beb947f306ced2bf5cd15
