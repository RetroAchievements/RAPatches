Use with:

(Homebrew)
File:               foryster_sg1000.sg
BitSize:            32 Kbit
Size (Bytes):       32768
CRC32:              F8D7FA2C
MD5:                7AEB05029BDB9A571B1B72482DAAD5EB
