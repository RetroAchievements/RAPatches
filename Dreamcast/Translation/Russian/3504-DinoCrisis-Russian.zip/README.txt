Dino Crisis DC Russian Translation
===============================================

DCP patch made by Whoops

Patching Instructions
===============================================
The .DCP patch file is designed for use with
Universal Dreamcast Patcher:

https://github.com/DerekPascarella/UniversalDreamcastPatcher

1) Click "Select GDI or CUE" to open the source disc image.

2) Click "Select Patch" to open the .DCP patch file.

3) Click "Apply Patch" to generate the patched GDI.
 - The patched GDI will be generated in the folder from which the
     application is launched.

4) Click "Quit" to exit the application.
