Use with:

(Redump)
File:         Skies of Arcadia (Europe) (En,Fr,De,Es) (Disc 1) (Track 3).bin
BitSize:      8 Gbit
Size (Bytes): 1185760800
CRC32:        495F4A18
MD5:          3bd713024d4d607c48fd4f8233506072

File:         Skies of Arcadia (Europe) (En,Fr,De,Es) (Disc 2) (Track 3).bin
BitSize:      8 Gbit
Size (Bytes): 1185760800
CRC32:        2CC0842A
MD5:          0aa4ff01b1cfbafa3de47326d338b2e6