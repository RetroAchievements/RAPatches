Use with:

(Redump)

File:               Capcom vs. SNK 2 - Millionaire Fighting 2001 (Japan) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              39A72365
MD5:                FF8E199324FC11D4F638E5C99315CDBB
SHA1:               7CAD2ADF8F04784838E5559291B178FCB0AA7FAC
SHA256:             4680E1E32DE2624105CBDD3759F06B98A4D27EC3D2A9A4F828841EFAD8319017