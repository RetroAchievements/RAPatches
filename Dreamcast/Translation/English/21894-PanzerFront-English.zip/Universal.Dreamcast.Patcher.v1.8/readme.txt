Universal Dreamcast Patcher v1.8
Written by Derek Pascarella (ateam)

Package Contents:
 * Universal Dreamcast Patcher.exe
    - Utility for end-users to apply a DCP patch to an original GDI.
 * Universal Dreamcast Patch Builder.exe
    - Utility for developers to build a DCP patch from their modified GDI.

For full usage instructions and details, visit:
https://github.com/DerekPascarella/UniversalDreamcastPatcher/blob/main/README.md