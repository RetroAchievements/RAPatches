Use with:

(Redump)
3ed9b1aca555aa38f8ef6c0a78c86c47 *Panzer Front (Japan) (En,Ja) (Track 1).bin
d03ec9a9fab111ba842b9c27663b8673 *Panzer Front (Japan) (En,Ja) (Track 2).bin
224cfed14f53a90a19467a70151ca63b *Panzer Front (Japan) (En,Ja) (Track 3).bin
b7fe4b1056741ff0013f9f80857e137b *Panzer Front (Japan) (En,Ja) (Track 4).bin
cd55dd88e1c269f3157883165728fb8e *Panzer Front (Japan) (En,Ja) (Track 5).bin
aca038f4ccca01293a35d2ea0a342a71 *Panzer Front (Japan) (En,Ja) (Track 6).bin
205ad1c4540b8d1fa27c200c8427fe23 *Panzer Front (Japan) (En,Ja) (Track 7).bin
fb3f5f3c27a3e5719f22295e6c858751 *Panzer Front (Japan) (En,Ja) (Track 8).bin
737960ffafcba88f464efb71ddd2247e *Panzer Front (Japan) (En,Ja) (Track 9).bin
4a3f3260e516857ac91b93a6897da5a3 *Panzer Front (Japan) (En,Ja).cue
