Use with:

(Lost Level Archive)
File:               Skies of Arcadia (Europe) (En,Fr,De,Es) (Uncensored) (Disc 1) (Track 03).bin
CRC32:              2651A685
MD5:                cec9030b6f67f29649b9a166035f4569

File:               Skies of Arcadia (Europe) (En,Fr,De,Es) (Uncensored) (Disc 2) (Track 03).bin
CRC32:              ABC78C36
MD5:                09390f3a6437eb028855e8dc4fe17094
