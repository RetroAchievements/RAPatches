Use with:

(Redump)
File:               Skies of Arcadia (Europe) (En,Fr,De,Es) (Disc 1) (Track 3).bin
CRC32:              495F4A18
MD5:                3BD713024D4D607C48FD4F8233506072

File:               Skies of Arcadia (Europe) (En,Fr,De,Es) (Disc 2) (Track 3).bin
CRC32:              2CC0842A
MD5:                0aa4ff01b1cfbafa3de47326d338b2e6