Use with:

http://redump.org/disc/42654/

(Redump)
File:               Pop'n Music 4 - Append Disc (Japan) (Track 1).bin
BitSize:            8 Mbit
Size (Bytes):       1058400
CRC32:              BE1A8511
MD5:                7B062DCA6FCD13BDF1A506B356DF7DD8
SHA1:               D12AD7D6C9ED2970FFC3252E83ABF5C5368319C8
SHA256:             229829C95060DBC31AC5DB82BE8019D990C9E445B9E54BD1184A263CA71A247F

File:               Pop'n Music 4 - Append Disc (Japan) (Track 2).bin
BitSize:            52 Mbit
Size (Bytes):       6823152
CRC32:              F9ED9CF2
MD5:                4800680C21EF36D217DD1FA018FDAA3A
SHA1:               C16E7AC67085FFF8C3465B4C43E0D2E86B328765
SHA256:             36FA03FA06C12B07E7BB8002C9523545857D1268F42C671A22DA22E4628B8D22

File:               Pop'n Music 4 - Append Disc (Japan) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              B19F3293
MD5:                8371392BD20A94093EAE5DF93BC5EE30
SHA1:               F40F151D0EEF04827B590A838A33CA6ADCD768E0
SHA256:             0B6CF3A23AEFD32A600F4358169DB4027A0F4C4C7A07B23D3D0153701E3F1106

File:               Pop'n Music 4 - Append Disc (Japan).cue
BitSize:            3 Kbit
Size (Bytes):       399
CRC32:              A73A84E3
MD5:                F6E8B235EA438D3549C82D8A4536FB33
SHA1:               629025474DE74BE69F1377B2439EA8D70DB14A96
SHA256:             89A419B9C230B97D5171BD855DB8A3E691E590E4F18967FE66F292AD3AA29B73