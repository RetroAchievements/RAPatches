Use with:

(Redump)
4520aabcaaf33699aeba6e21522d6b9e Typing of the Dead, The (USA).cue
0a861752889a9c50877f31e6922b4600 Typing of the Dead, The (USA) (Track 1).bin
824ff123fbce45b5883962eb3fa43cab Typing of the Dead, The (USA) (Track 2).bin
921978ae4681205770a5a7e0e247df21 Typing of the Dead, The (USA) (Track 3).bin
cb9f913312fff0782cd8c87568bcc047 Typing of the Dead, The (USA) (Track 4).bin
827c27993ca3f624025bf91377a6cce5 Typing of the Dead, The (USA) (Track 5).bin

or

(TOSEC)
5520674b66f1b244308fbfdc78f13550 Typing of the Dead, The v1.004 (2000)(Sega)(US)[!][req. keyboard].gdi
0a861752889a9c50877f31e6922b4600 track01.bin
94fde9cacd7a4b3c18d8918836e9cda5 track02.raw
921978ae4681205770a5a7e0e247df21 track03.bin
166d547d4b80a87ad3538f9377fbf6d8 track04.raw
1cabe896fc1d7b94dd46796b5ed32f58 track05.bin