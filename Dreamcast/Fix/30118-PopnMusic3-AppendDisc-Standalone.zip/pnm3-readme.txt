Use with:

http://redump.org/disc/40635/

(Redump)
File:               Pop'n Music 3 - Append Disc (Japan) (Track 1).bin
BitSize:            8 Mbit
Size (Bytes):       1058400
CRC32:              2E02D88F
MD5:                66DFD28AB1F354BBA9CE0B15FB5EEF6A
SHA1:               D3620918B3FB819C38349899915ACADFBCC563C3
SHA256:             47DC69916C502933A0CA3C99FC00B8C6F2AE2C968009722929C79F479DC68C21

File:               Pop'n Music 3 - Append Disc (Japan) (Track 2).bin
BitSize:            52 Mbit
Size (Bytes):       6924288
CRC32:              59B0718F
MD5:                CD9009CDDDE67962CACFD21F729A3894
SHA1:               820AC3183947074D3CEA3F1DD2FEAAEB10C67384
SHA256:             9AB85A1D0903924F68C0514FABE5A82DEBF847A0D0A60EB913EE8565D046956A

File:               Pop'n Music 3 - Append Disc (Japan) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              D44DE701
MD5:                06E8E03BB98BF6BE4A91933D71A09791
SHA1:               F98EDA9B5692A8C77B7B220A2A1060D4DC05CB24
SHA256:             1FE13698165FE8BFC3ECD15F93C378546C9D64CB3713DDD45FC0750262BA9DD6

File:               Pop'n Music 3 - Append Disc (Japan).cue
BitSize:            3 Kbit
Size (Bytes):       399
CRC32:              B2DEEDE3
MD5:                6ECA0A80B4C840EBB2710A4F5DFBDED4
SHA1:               0AE6FD896B6CACD1F7F97F8C74E1FDEE7F2CC258
SHA256:             956F21CD02B28D72EB99B75236B07204FB82D66663DB083BC904C3C03EDC56E6