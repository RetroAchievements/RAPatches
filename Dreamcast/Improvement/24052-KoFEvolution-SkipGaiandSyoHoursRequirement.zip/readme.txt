Use with:

(Redump)
File:               King of Fighters, The - Evolution (USA) (En,Ja,Es,Pt) (Track 3).bin
BitSize:            8 Gbit
Size (Bytes):       1185760800
CRC32:              9E9DEC31
MD5:                8F9B07766493A862BF57F7ED4F8B4475
SHA1:               0B7609B273384F0EB197BC33C3F17E8DCCDF9EFD
SHA256:             6E13053D4B545506CB14D791FFF4E639EB37A46595E60D109606E8A1E381495B