Use with:

PAL
track03.bin	(redump)
5982e72019b19277ec83cacceacf7140
50856cfb

NTSC
track03.bin	(redump)
88b7360c6cbd79c3ca7fbece3df801f9
bf6cc48f
