Use with:

(Redump)
File:               ToraDora Portable! (Japan).iso
CRC32:              60291298
MD5:                5a7dc070c37034941c2d526319c1eceb
