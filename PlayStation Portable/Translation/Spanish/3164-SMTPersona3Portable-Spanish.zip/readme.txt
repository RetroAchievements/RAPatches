Use with:

(Redump)
File:               Shin Megami Tensei - Persona 3 Portable (USA).iso
BitSize:            9 Gbit
Size (Bytes):       1321861120
CRC32:              FA047515
MD5:                72C194C04FBD2657ACB418413C0DE873
SHA1:               06B7ACE9BC5293DF7BF8609E652185543AB7D062
SHA256:             52E9E6E0A5E22EC05B29B6A994EEFEFB6F1A32F89634D65F00916C8C2C83F5EA