Use with:

(Redump)
File:               Star Ocean - First Departure (Europe).iso
BitSize:            8 Gbit
Size (Bytes):       1150746624
CRC32:              434CFD0F
MD5:                1F3E0128E5C2F1A10A4A55CCAC1D00A1
SHA1:               2C7AFAC802D2E868980FFDFE0BD5AAC8BE89C6D6
SHA256:             05CD21D7A55D74C29B1A0AFF66FBD6876A4ABDD9DE8284B27E4FA90642F54DEA