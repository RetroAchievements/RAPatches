Patch is available here: https://sites.google.com/view/imas-sp-en-tl/home


Instructions
First of all, make a backup of your .iso. The patched file will be replaced the original file used for this process.
Download the patch for your game version and Delta Patcher (https://www.romhacking.net/utilities/704/). Extract delta patcher and double-click the .exe to open it.
In Original file, select your .iso.
In XDelta patch, select the patch.
Press Apply patch and enjoy.

Made for the following versions:
The Idolmaster: Perfect Sun
UMD version (CRC: D49CF27D)
PSN version (CRC: 763176D6)

The Idolmaster: Wandering Star
UMD version (CRC: 2B45CB84)
PSN version (CRC: 98E6C400)

The Idolmaster: Missing Moon
UMD version (CRC: CA4469D0)
PSN version (CRC: 3ADF4ACB)

Other releases are not tested or supported. Patch was made with the PSN versions as basis, so no compatibility issues with those.

Extra Step: DLC Mails
Add the files from mail_dlc into your \PSP\GAME\NPXP00100\MAIL\ folder.