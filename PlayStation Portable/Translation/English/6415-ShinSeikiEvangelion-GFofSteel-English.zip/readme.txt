Use with:

(Redump)
File:               Shin Seiki Evangelion - Koutetsu no Girlfriend 2nd Portable (Japan).iso
BitSize:            3 Gbit
Size (Bytes):       407568384
CRC32:              D4AA9284
MD5:                D015A4201CCF45738F11A3CBC9A5CA96
SHA1:               D01C166C75532D81E7EBD2910B5F6DC35D6FCB63
SHA256:             70995696666FC0A2943975C5240FE2F1EB6D0045E815FB3F00AA741B3ADD05C2