Use with:

(Redump)
File:  Adventure Player (Japan).iso
CRC32: A3CA9117
MD5:   fd325910d2665bc6ef30c682ff73794a