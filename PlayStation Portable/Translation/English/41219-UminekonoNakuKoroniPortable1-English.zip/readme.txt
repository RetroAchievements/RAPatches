Use with:

(Redump)
File:               Umineko no Naku Koro ni Portable 1 (Japan).iso
BitSize:            8 Gbit
Size (Bytes):       1183383552
CRC32:              4B81E5A9
MD5:                E23AF333E3C9C6346EAE05247AB4A42E
SHA1:               5819B5CFA90065C63605E544D3BE0262AF3ACC99
SHA256:             05A3696776D314AC40D55F3B125DC3EC2E60AD12FEC12DE4995A4E4E1C9E17EA