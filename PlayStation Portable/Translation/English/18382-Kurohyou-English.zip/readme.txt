Use with:

(Redump)
File:               Kurohyou - Ryuu ga Gotoku Shinshou (Japan, Asia).iso
BitSize:            9 Gbit
Size (Bytes):       1238171648
CRC32:              5DA1AFC2
MD5:                7BBAA6D23D31C5554CF5349EBA50C7C5
SHA1:               E9AF145E16FC25A9223F911844FE05026A2029A8
SHA256:             7956EDCB423602848FAABCDFFDE6D7A7A176B771644DCFB62370A14D8672C04D