Use with:

(Redump)
File:               Tales of Phantasia - Narikiri Dungeon X (Japan).iso
Size (Bytes):       1171161088
CRC32:              4841790E
MD5:                aa49c716783766aa5913e6a5ca8bb822