Use with:

(Redump)
File: ToraDora Portable! (Japan).iso
MD5:  5a7dc070c37034941c2d526319c1eceb
CRC:  60291298