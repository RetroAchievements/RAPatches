Use with:

(Redump)
File:               Tantei Opera - Milky Holmes (Japan).iso
Size (Bytes):       821985280
CRC32:              6EF51DAC
MD5:                2d2d40b70d06f44109054e12dc6fa369