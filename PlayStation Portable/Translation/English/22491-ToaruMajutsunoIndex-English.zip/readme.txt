Use with:

(Redump)
Toaru Majutsu no Index (Japan).iso
md5: 786ef722be44f8e558736131990a0dd1
crc: 9DA98DFB