Use with:

(Redump)
File:               Dai-2-ji Super Robot Taisen Z Hakai-hen (Japan).iso
BitSize:            9 Gbit
Size (Bytes):       1217986560
CRC32:              C02BA2AF
MD5:                D85D9CB5B39F2393F83AA0447891FD15
SHA1:               CF7A93805FA79B158A060512A7D80F38A97CF7CD
SHA256:             9C45AC15305C2C795802AD9202E1C5B730664B43DE6DE7B411F92F0E214E22CD