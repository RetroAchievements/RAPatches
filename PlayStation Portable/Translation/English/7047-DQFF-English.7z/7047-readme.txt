Use with:

(No Intro,Redump)
File:               Dragon Quest & Final Fantasy in Itadaki Street Portable (Japan).iso
BitSize:            2 Gbit
Size (Bytes):       309166080
CRC32:              F4D7331E
MD5:                DFB9219DD39B7B0BE49A57F617BF3DC8
SHA1:               3825E6DB28D116924AF345A3EA107055A7B8A078
SHA256:             E513D0169BD794C5F3E88FBA4B43C812DAC3AB841DE6D81FB23A51CCE5DA0AFD