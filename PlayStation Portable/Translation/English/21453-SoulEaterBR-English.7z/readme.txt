Use with:

(Redump)
Soul Eater - Battle Resonance (Japan).iso
eb20e36c7eb23d94ac6288d8d765b5c8
D3D7DFEC