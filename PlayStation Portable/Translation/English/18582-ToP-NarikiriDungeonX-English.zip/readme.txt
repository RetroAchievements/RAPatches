Use with:

(Redump)
File:               Tales of Phantasia - Narikiri Dungeon X (Japan).iso
BitSize:            8 Gbit
Size (Bytes):       1171161088
CRC32:              4841790E
MD5:                AA49C716783766AA5913E6A5CA8BB822
SHA1:               A8BA8878C6D626806518B8A538D19094E1062CA9
SHA256:             C77F8B5C53531471FBE6E770AC623C1B1470A88F2C21341821139002906AD137