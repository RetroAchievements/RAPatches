Use with:

(Redump)
File:               Persona 2 - Batsu - Eternal Punishment (Japan).iso
BitSize:            9 Gbit
Size (Bytes):       1297285120
CRC32:              93C35B9B
MD5:                124E4A453AFED1946873912823716B84
SHA1:               99AC0EA50E0789582CDFC053A8604944C98603DA
SHA256:             06785412B46EB67E5341A6B3171BD2E1A1DED1558904C8528E9F8CA71F400A45