Use with:

(Redump)
File:               Sol Trigger (Japan).iso
CRC32:              CF0239E8
MD5:                82ef48ea6ae1b444071fea169cadfa66
