Use with:

(Redump)
File:               Kurohyou 2 - Ryuu ga Gotoku Ashura-hen (Japan).iso
CRC32:              D360B096
MD5:                0a5a379d0edffcab5a503966140965dc
