Use with:

(Redump)
File:               Eiyuu Densetsu - Zero no Kiseki (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1386217472
CRC32:              5179B4B0
MD5:                3002BBF9862D9ADBAB4226C38EB35F49
SHA1:               E3C526D65ADC1CCD11D4F12220AD05832962EB20
SHA256:             50DF4C6A63E9DF1F7066C3FBDAEF11F7E276EC60EE05FDDA00532B69117DE9BB