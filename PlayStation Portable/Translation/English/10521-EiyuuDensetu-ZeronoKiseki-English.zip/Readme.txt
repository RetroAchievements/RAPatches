Use with:

The base rom
Redump
Eiyuu Densetsu - Zero no Kiseki (Japan).iso
3002BBF9862D9ADBAB4226C38EB35F49
5179B4B0

To play the main set, apply the Trails from Zero - (v1.0) Geofront Translation Port (WanderingHeiho).xdelta patch to the above rom.
To play the subset, apply the Trails from Zero - English to Subset.xdelta patch to your patched ISO.