Use with:

(Redump)
File:               Eiyuu Densetsu - Ao no Kiseki (Japan) (v1.01).iso
BitSize:            11 Gbit
Size (Bytes):       1519321088
CRC32:              EFDD7E79
MD5:                DF3DF715FB2A0366BFA65C926AB40B48
SHA1:               A0010FB19ED6CA941EBFF2E251EFB0773673E59C
SHA256:             5FE6C25EC2244E94BA7ECC695F21E995F7FC9558F167A6159019B3289DB4A107