Use with:

(Redump)
File:               Tales of the Heroes - Twin Brave (Japan, Korea).iso
BitSize:            9 Gbit
Size (Bytes):       1285160960
CRC32:              28356530
MD5:                B13EBC2C2086E3095ADA19F29E97CAB1
SHA1:               ACC3E9E3AC454BBA1B9747C9261B3F3D48BEBE9D
SHA256:             C0DC5E223FF67D89D9EB469C4E88A4DE31320EE5F9BF78A3821A84D78E50CAC3