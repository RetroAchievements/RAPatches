Use with:

(Redump)
File:               Hatsune Miku - Project Diva (Japan, Asia).iso
BitSize:            10 Gbit
Size (Bytes):       1402929152
CRC32:              1AD74675
MD5:                E4886B42939A47E39486414388061042
SHA1:               098758B6D50C584B874E032B15E5B68AA97E5A16
SHA256:             3B41BD59D3D4A79E63414CC908CBBFB3D8B5B15F2B6F6F84BF528A547F8271FE