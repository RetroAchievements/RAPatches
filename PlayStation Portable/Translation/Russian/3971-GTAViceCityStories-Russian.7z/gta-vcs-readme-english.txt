Use UMDGen to open the following:

Grand Theft Auto - Vice City Stories (Europe) (En,Fr,De,Es,It) (v3.00).iso
bf17f0cabd2f3d9ba3c30413c070758e
B44AC795

Replace the EBOOT.BIN with the one included here.