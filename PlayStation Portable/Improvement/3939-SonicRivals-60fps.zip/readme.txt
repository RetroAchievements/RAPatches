Use with:

(Redump)
Sonic Rivals (Europe) (En,Fr,De,Es,It).iso
md5: 7dfe83392b4a3cbdfeaa974bb97c2eb1
crc: dcbc235d