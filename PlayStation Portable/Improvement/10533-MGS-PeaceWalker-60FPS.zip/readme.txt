Use with:

(Redump/No Intro)
File:               Metal Gear Solid - Peace Walker (USA) (En,Fr,Es) (v1.01).iso
BitSize:            12 Gbit
Size (Bytes):       1646002176
CRC32:              1A2C5CA5
MD5:                B8FE04E4FBEAEFD67AF2AC2622ED983A
SHA1:               957D88FEA235B9DA5716155B2445F06DF50AEC67
SHA256:             50ABB13256444D83D75C272B0B51DF0F88F636C844F839EE737D2F60F18D13A5