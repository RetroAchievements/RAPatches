Use with:

(Redump)
WipEout Pure (USA) (En,Fr,Es) (v2.00).iso
md5: 33de1457c7b66662a3ba2712a66882bb
crc: 4502C588