Use with:

(Redump + Patch)
File:               Monster Hunter Portable 3rd (HD ver.) (Japan) (En) (v5) (Team Maverick ONE).iso
BitSize:            9 Gbit
Size (Bytes):       1323565056
CRC32:              80874121
MD5:                44761DF383BD7E23C43911DA0D82020A
SHA1:               7BDF4F925F72AE2822A161882AF1B543FC218128
SHA256:             CEC342BA025C36675CE0D9E5FF4A3DF67094260A795131EE7EF5881F74917781