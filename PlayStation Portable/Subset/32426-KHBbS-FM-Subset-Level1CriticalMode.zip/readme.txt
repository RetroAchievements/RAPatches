Use with:

(Redump + RAPAtches)
File: Kingdom Hearts - Birth by Sleep - Final Mix (Japan) (En) (v1.0.12) (Truthkey).iso
MD5:  01ddc23924854c3ef733a0d6a0f04349
CRC:  5D10B30A