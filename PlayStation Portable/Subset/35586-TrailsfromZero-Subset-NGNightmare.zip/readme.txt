Use with:

(Redump + RAPatches)
File:               Eiyuu Densetsu - Zero no Kiseki (Japan) (En) (v1.0) (GeoFront Port - WanderingHeiHo).iso
BitSize:            10 Gbit
Size (Bytes):       1039544320
CRC32:              c2d08f64
MD5:                3df8c14f70b2db80de4ff59cb307bb85
SHA1:               bd455507576fa149f628a652b1ffb27659c69152

File:               Eiyuu Densetsu - Zero no Kiseki (Japan) (En) (v1.1) (GeoFront Port - WanderingHeiHo).iso
BitSize:            10 Gbit
Size (Bytes):       1039544320
CRC32:              c4b35e17
MD5:                153f385aa0d546e644e681f3d63cb6fb
SHA1:               523fb6a8e07fc2e966504cbd04738cf146bdaa45

