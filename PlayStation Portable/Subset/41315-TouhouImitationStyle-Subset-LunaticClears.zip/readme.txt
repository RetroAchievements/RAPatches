Use with:

(Lost Level Archive)
File:               EBOOT.PBP
BitSize:            9 Mbit
Size (Bytes):       1187247
CRC32:              B6174D00
MD5:                94D2EB37A05CC08185DFF731BF5F5AB0
SHA1:               3F0411F9482CCB5910CD3777F54B307E1A032EC7
SHA256:             12E549E8770A2063D21AC83C2C8B877D8CC32179DB45817021C5802E5476A642

This is "Touhou Imitation Style (World) (En) (r44u2) (Aftermarket)"

https://archive.org/download/toho-imitation-style-english/Toho%20Imitation%20Style%20%5BENG%5D.rar

Be sure to rename the patched version back to "EBOOT.PBP"