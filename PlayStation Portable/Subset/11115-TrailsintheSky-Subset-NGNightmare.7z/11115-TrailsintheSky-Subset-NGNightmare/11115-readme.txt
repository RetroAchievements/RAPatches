Apply patch to:

(Redump)
Name: Legend of Heroes, The - Trails in the Sky (USA).iso
RA Checksum: cff66ecd124db9624bfda5cd4cbb40a0
md5: d819e90488c6d075d3f8a6cec1047203
CRC: E653AC5E


To use included save data, drop RASS105400001 directory in SAVEDATA directory.

RALib -> Saves -> PSP -> SAVEDATA [\RALibretro\Saves\PSP\SAVEDATA\RASS105400001\]
RetroArch -> Saves -> PSP -> SAVEDATA [\RetroArch\Saves\PSP\SAVEDATA\RASS105400001\]