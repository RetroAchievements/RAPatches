Use with:

(Redump)
File:               Bleach - Heat the Soul 7 (Japan).iso
BitSize:            4 Gbit
Size (Bytes):       560496640
CRC32:              B245B08E
MD5:                B31EEEDC05DF9C7889AD6FE29726D3F6
SHA1:               D8FC21AC3977F48EDC4486F7F216759EE8A4EA77
SHA256:             895B827184AEB4403567D258A52D140BEC2AF302F723759E08F5889CF89BC26A