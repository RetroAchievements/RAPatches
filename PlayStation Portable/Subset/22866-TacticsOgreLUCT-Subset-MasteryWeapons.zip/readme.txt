Use with:

[Redump]
Tactics Ogre - Let Us Cling Together (USA)
RAHash: 00af730ca0fd034a59ee26f55a6b3682
md5: 3570038c9c35ef8ea3982a54ea911df6
CRC: A15F40B7