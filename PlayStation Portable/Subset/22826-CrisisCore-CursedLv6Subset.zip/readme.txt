Use with:

(Redump)
Crisis Core - Final Fantasy VII (USA).iso
a36a1884647146c607215134e1836228
4C7E2442