Use with:

(Redump)
File:               Patapon 3 (Europe) (En,Fr,De,Es,It,Nl,Pt,Pl,Ru).iso
BitSize:            4 Gbit
Size (Bytes):       582418432
CRC32:              39150910
MD5:                C781BB038321B0EB52FBB2BEB9B8B9A9
SHA1:               022DFDC6CBE071A8E5EC0DFD47A77F5C8FA377F4
SHA256:             ED3A0FC93BCB40B055987C057DECC0D64643EA7C4AB187E40568CADEE48D2E95