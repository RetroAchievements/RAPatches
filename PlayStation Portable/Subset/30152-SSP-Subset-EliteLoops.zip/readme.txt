Use with:

(No Intro)
File:               Super Stardust Portable (Europe) (En,Fr,De,Es,It,Nl,Pt,Ru) (PSP) (PSN).iso
BitSize:            1 Gbit
Size (Bytes):       197197824
CRC32:              84C6DD15
MD5:                ED94CB99CC8F2262575CCBC43932BCD7
SHA1:               E20B410179E493EE2E07143082E03F2344E7A835
SHA256:             254B409B3B773B12E11A6C20E6CD099E71C4821F98990D7AA0BDA0333E3CFD80