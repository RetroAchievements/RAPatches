Use with:

(Redump)
Megpoid the Music#.iso
8a29a914f78eede846e125a5f14d4dab
e6068dfb