Use with:

(Redump)
File:               Taiko no Tatsujin Portable DX (Japan, Korea).iso
BitSize:            6 Gbit
Size (Bytes):       891977728
CRC32:              DDCC23C2
MD5:                7DB90CC61CADFAFE533FD20A7C37314B
SHA1:               D15278DA6E9570BE05655F9B62AFB81C0EB1ED49
SHA256:             888B8B6029C1834CEEA92C9942239771FFFB0A6CA9397FC261EFFAF81B276CED