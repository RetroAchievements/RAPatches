Use with:

(Lost Level Archive)
(Syobon Action (World) (v1.3) (Aftermarket) (Daniel Riberio))
File:               EBOOT.PBP
BitSize:            15 Mbit
Size (Bytes):       2056348
CRC32:              B2434A5C
MD5:                3B970AA70D18538B8F31EC5C92A18B6B
SHA1:               2EAF8FD5CD0617A27B67362DD2DB4D652054E1FE
SHA256:             EBEE3C4D21623247CBC77B729FE46D3E117B592BEBDEE66BB4FDFE54008E21EF


https://danielbr-dev.blogspot.com/2012/07/syobon-action-psp-version-r3.html
https://www.gamebrew.org/wiki/Syobon_Action_PSP
https://archive.org/details/syobon_DA_r3.7z