Use with:

(Redump)
Filename: Tekken 6 (Europe) (En,Ja,Fr,De,Es,It,Ko,Ru).iso
MD5: d6b3214a00438f5442807eec3dc24944
CRC: 1712A669