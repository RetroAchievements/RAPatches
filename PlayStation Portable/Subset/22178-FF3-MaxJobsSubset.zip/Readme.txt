Base game

Final Fantasy III (USA) (En,Fr,Es) (PSN)
RAHash: f7590869f703e942a0942ac8ec489bb3