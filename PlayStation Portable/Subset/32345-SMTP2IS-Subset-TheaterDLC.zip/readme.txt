Use with:

(Redump)
File:               Shin Megami Tensei - Persona 2 - Innocent Sin (USA).iso
BitSize:            8 Gbit
Size (Bytes):       1130889216
CRC32:              58AE311A
MD5:                F7015D746B5B14B9194C29DF5EEDA845
SHA1:               D970D2CCA78E46639F5191AC51B29A89F8E4EDFC
SHA256:             311F97A9B83CD5660A84B7F48D9D67D443F1F6CB685C2B13EB1540ECC7956E25