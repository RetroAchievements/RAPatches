FFT Slowdown fix and unstretch screen patch V1.1

This is a patch for the USA and EUR versions of the PSP game 
"Final Fantasy Tactics - The War of the Lions". 

It allows you to remove the battle animation slowdown and/or unstretch the 
screen to the original 4:3 aspect ratio.

It is based on the patches provided by the LivePatch plugin, created by 
endrift ( http://ffhacktics.com/smf/index.php?topic=8490.0 ).
In fact, she is the responsable for doing the hard work of reverse engineeering 
of the game and figuring out how to fix both issues. 

I simply converted the patches for those who can't/don't want to use the 
plugins. The conversion was was fairly straight forward (things were properly documented).


DESCRIPTION OF THE PATCH FILES:

	fft_usa_eur_fast.ppf			slowdown fix
	fft_usa_eur_unstretch.ppf		unstretch screen
	
You can use the patches individually or both at the same time.

HOW TO APPLY:
	01. Open the ISO with UMDGen
	02. Go to the PSP_GAME\SYSDIR folder
	03. Select the EBOOT.BIN file, right click on it
	04. Press the "Extract Selected" and extract to the "encrypted" folder 
	    included with the patch
	05. Run decrypt_eboot_bin.bat file to decrypt the EBOOT.BIN
	    This should create a decrypted EBOOT.BIN file in the "decrypted" folder
	06. Drag and drop the decrypted\EBOOT.BIN to the UMDGen window to replace 
		the original file
	07. Press the right mouse button in the EBOOT.BIN file on the UMDGen window
	08. Apply the PPF patches you want to the file (fast and/or unstretch)
	09. Save your ISO.

SPECIAL THANKS & CREDIT FOR THE ACTUAL WORK INVOLVED HERE
	endrift (thanks a lot!)
	
DISCLAIMER
	In no event I can be responsable for any damage caused by the patches.
	You should not use the patches if you don't own the original game.
	YOU CAN NOT INCLUDE THIS IN ANY FORM WITH PIRATED COPIES OF THE GAME
	YOU CAN NOT DISTRIBUTE PRE-PATCHED VERSIONS OF THE GAME
