Use with:

(Redump,No Intro)
File:               Final Fantasy Tactics - The War of the Lions (Europe).iso
BitSize:            3 Gbit
Size (Bytes):       418873344
CRC32:              0F7AE43C
MD5:                4B97913C0423B879A9321FEBAEB4892A
SHA1:               5104E61A886C1FB62FAE98FA3BF96E1B0C545DC6
SHA256:             BD040D417CD34810F648E0E10642FC3B52F3EC4B7CA269EA2F7E5E5A4B911704