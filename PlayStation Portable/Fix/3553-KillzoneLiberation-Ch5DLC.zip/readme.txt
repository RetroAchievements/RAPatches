Use with:

(Redump)
File:               Killzone - Liberation (USA) (En,Fr,De,Es,It,Nl,Pl,Ru).iso
BitSize:            4 Gbit
Size (Bytes):       581632000
CRC32:              A4F123EB
MD5:                88D913FDF33172A3CFDB857B5C92BE5B
SHA1:               DDA1A72C28CCDD8DDD2F3CBFD2FA3188962B0458
SHA256:             0C22536197DFE21F5E55DB83DCFFB81D987F673BF3ED4E0D6FE5A7CB6DBD9EA2