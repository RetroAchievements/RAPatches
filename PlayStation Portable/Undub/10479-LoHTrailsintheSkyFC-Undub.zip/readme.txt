Use with:

(Redump)
File:               Legend of Heroes, The - Trails in the Sky (USA).iso
BitSize:            10 Gbit
Size (Bytes):       1421639680
CRC32:              1F8C6BEA
MD5:                716F86D6631D0702829B97B0AEF2F937
SHA1:               37ED4E7F374F4FCDAF400223D7AEFA870343E950
SHA256:             03A5EEFF2739CDF2EC879139E92D8754DBB7FF84B920F2433D373957F38C6A80