Use with:

(No Intro)
File:               Legend of Heroes, The - Trails in the Sky SC (USA) (Disc 1).iso
CRC32:              692B4894
MD5:                5FCDC01D4049D9F6E7259DE495F071B8

File:               Legend of Heroes, The - Trails in the Sky SC (USA) (Disc 2).iso
CRC32:              56E99ECD
MD5:                fb9b050d8f58461cbb5dcef8e6e82175
