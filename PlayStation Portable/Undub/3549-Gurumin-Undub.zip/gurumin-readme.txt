Use with:

(Redump)
File:               Gurumin - A Monstrous Adventure (USA).iso
BitSize:            7 Gbit
Size (Bytes):       1064009728
CRC32:              CE8381FF
MD5:                5539E5BEB44B2873E13CD541A2D9BA47
SHA1:               EE621DFC2D9B603FEA8067611CE137A2988674D7
SHA256:             08544B64C13303B56FF28DB8EB01166226F757A9DD2550E12848944FCC55D9BC