Use with:

(Redump)
File:  Yu-Gi-Oh! GX - Tag Force 3 (Europe) (En,Fr,De,Es,It).iso
Size:  1792999424
CRC32: 5d2dff66
MD5:   c28c8b13078919255d7623c921f8d82e
SHA-1: 379601a07d73374fa4a03272488fd195133d7c0d
