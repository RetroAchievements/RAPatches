Use with:

(CleanCPC)
File:               Hero Quest (1991)(Gremlin Graphics Software).dsk
BitSize:            1 Mbit
Size (Bytes):       195635
CRC32:              EC279622
MD5:                2BEC802CAFD431812CBE1FE337A4BF92
SHA1:               AEDC01141151B0F7214199648AF1617093779A27
SHA256:             420262956EFCA996D15499E8D025432D66A391F876C562F88D40D97C8EF4D258

File:               Hero Quest - Return of the Witchlord (1991)(Gremlin Graphics Software)(extension).dsk
BitSize:            1 Mbit
Size (Bytes):       195635
CRC32:              F1FFF06C
MD5:                ABDCDC34D63DCB46ED72EA4466D63262
SHA1:               22CC0D287162E536E45741E8E0C721C2BF038185
SHA256:             F69C61F6A908181B58FAB99F34C379478D6D32F4C511EE9669DA0D822EBE47A0