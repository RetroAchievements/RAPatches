Use with:

(Clean CPC DB)
File:               Nemesis (UK) (1987) (CPM) [Original].dsk
Size (Bytes):       88231
CRC32:              0B35ED50
MD5:                ec53de122c1a9072ebef116727139d5d