Use with:

(No-Intro)
File:               1941 - Counter Attack (Japan).sgx
Size (Bytes):       1048576
CRC32:              8c4588e2
MD5:                30686dba4795521174658de2492e0046
SHA1:               66873b0e0cc699aa75daf06a3f74c0508037e605