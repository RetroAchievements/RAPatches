Use with:

(No Intro)
File:               Mega Man 2 (World) (v0.87) (Proto) (Aftermarket) (Unl).pce
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              2FC86AFF
MD5:                83079124C8EFCE1EEE4C3A34A89441A5
SHA1:               3BAD484A43682A11B79BB5E3CA39755922807E19
SHA256:             9DF952718D5B20228CBC4E8CC64CC456A35337AE7ACCE406CA32520E11B9CE22