Use with:

(No Intro)
File:               Splatterhouse (Japan) (En).pce
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              6B319457
MD5:                EA2EAF7AA11A639D13A6119DD3C3F6DC
SHA1:               B0BDBB7729D775496581DC3141C4447614AAAC46
SHA256:             C9ABB31A87C8CA7A8AB7AB9D3FA144C77D655DA1A80FEB4A0FD78183802AF75E