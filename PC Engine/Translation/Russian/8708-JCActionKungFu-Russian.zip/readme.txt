Use with:

Jackie Chan's Action Kung Fu (USA).pce (No Intro)
5a8c0f70f333ff03c8eb836eeb5f2ff9