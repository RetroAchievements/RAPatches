TERMINUS TRADUCTION pr�sente

CITY HUNTER
----------------------------------------------------------------
*******************Table des mati�res******************
----------------------------------------------------------------

1.    L'HISTOIRE DU JEU
2.      CONTENU DE L'ARCHIVE ET UTILISATION
3.    LES PATCHS PUBLIES
4.      TOUT CE QUI A ETE FAIT
5.    L'�QUIPE DE LA TRADUCTION
6.      CONTACTS
7.    REMARQUES LEGALES

----------------------------------------------------------------
1.  L'HISTOIRE DE CITY HUNTER
----------------------------------------------------------------

On ne pr�sente plus Nicky Larson ou City Hunter sous son nom
original. L'adaptation sur PC Engine de cette s�rie nous fera
�norm�ment penser � Rolling Thunder, en rajoutant une pointe
d'exploration. Pas exceptionnel mais un tr�s bon jeu tout de
m�me, surtout pour les fans de la s�rie.

----------------------------------------------------------------
2.  CONTENU DE L'ARCHIVE ET UTILISATION
----------------------------------------------------------------

Normalement, l'archive ZIP doit contenir:
CityHunterFr.ips  - Le patch IPS du jeu
LisezMoi.txt - Le fichier que vous �tes en train de lire

Pour utiliser cette traduction, il faut utiliser un PATCHEUR
(le Patcheur Terminus par exemple).
Ce patch est � utiliser avec la ROM No-Intro:
City Hunter (Japan).pce

----------------------------------------------------------------
3.  LES PATCHS PUBLIES
----------------------------------------------------------------

-V1.00

----------------------------------------------------------------
4.  TOUT CE QUI A ETE FAIT
----------------------------------------------------------------

Traduction complete du jeu

----------------------------------------------------------------
5.  L'�QUIPE DE LA TRADUCTION
----------------------------------------------------------------

Kazan:   Hacking, Traduction
Mooz:    Extraction de la font
FlashPV: Modification et r�insertion de la font

----------------------------------------------------------------
6.  CONTACTS
----------------------------------------------------------------

Une remarque, une question ou une correction � apporter � la
traduction du jeu.

Kazan - newkazan@hotmail.fr

Vous voulez mieux conna�tre le groupe, t�l�charger nos derniers
patchs ou vous renseigner sur un projet.

Site Web - http://terminus.romhack.net

----------------------------------------------------------------
7.  REMARQUES LEGALES
----------------------------------------------------------------

Le patch de traduction fran�aise de ce jeu n'est pas officiel et
n'est pas support� par Nec et Hudson Soft.

Ce patch est gratuit et peut �tre distribu� gratuitement tant 
qu'il n'est pas modifi�, appliqu� ou distribu� avec une rom, 
et que l'archive originale n'est pas modifi�e non plus. Ni 
argent, biens ou services ne peuvent �tre demand�s pour ce 
patch, dans sa forme originale ou appliqu�e.

Tous ceux qui utilisent ce patch le font � leurs propres 
risques. Aucune personne cit�e dans cette documentation ne 
pourra �tre responsable de n'importe quels dommages 
provenant de son usage.

----------------------------------------------------------------

Merci d'avoir lu jusqu'au bout et � bient�t !

Kazan

