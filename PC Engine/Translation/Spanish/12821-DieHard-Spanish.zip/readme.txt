Use with:

Die Hard (Japan).pce (No Intro)
7dd298a6e9f2abce6f85d262ec37f483