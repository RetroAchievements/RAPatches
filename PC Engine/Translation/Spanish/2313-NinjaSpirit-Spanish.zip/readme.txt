Use with:

(No Intro)
Ninja Spirit (USA).pce
adecf9e9d9be8a300818ad2cc09d49fe
DE8AF1C1