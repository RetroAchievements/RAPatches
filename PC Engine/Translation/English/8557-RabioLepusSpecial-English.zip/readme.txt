Use with:

(No Intro)
File:               Rabio Lepus Special (Japan).pce
BitSize:            3 Mbit
Size (Bytes):       393216
CRC32:              D8373DE6
MD5:                4B942FF45A454222DD4EC1951E75A72C
SHA1:               EBD12A22E2D139A904B8AFF535787ABC128AD61A
SHA256:             D5984E1C46CB906D279151A026A17EE87CF6276FB2C4316DFEC63DAE0896FB07