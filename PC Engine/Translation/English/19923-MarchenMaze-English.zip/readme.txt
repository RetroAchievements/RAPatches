Use with:

(No-Intro)
File:               Maerchen Maze (Japan).pce
Size (Bytes):       262144
CRC32:              a15a1f37
MD5:                887b9fa8296ff3c98839e11cc7039763
SHA1:               04175b93e52653fa61111210538a5582ba152180
SHA256:             f82c2ef0f4820dc9f753d1539c9a5c11fcad930bb7dc608df181adabdeaad4ce