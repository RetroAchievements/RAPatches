Use with:

Druaga no Tou (Japan).pce (No-Intro)
df4fa7ddc1a4e8cc29dc67e700b2a55a
72E00BC4
