Use with:

(No Intro)
File:               Bubblegum Crash! - Knight Sabers 2034 (Japan).pce
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              0D766139
MD5:                8AA27A2CDC063B278E063166A168A307
SHA1:               03D0638F27D35B28B7E5E7DB16F823DE0726C2C5
SHA256:             E96600058F35178C78A88EB9596678C973E0095AE8BD9CB060668065197F8895