Use with:

(No Intro)
File:               Lady Sword - Ryakudatsu Sareta 10-nin no Otome (Japan) (Unl).pce
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C6F764EC
MD5:                71C5CFFEAB1CB60A04B5E77A338117AC
SHA1:               7384D0D863DA43C64D704F4F36CE55502E3B6159
SHA256:             EE93A855EE69197CC1FEED5405A7663250A52B74B4F867A25F4100AC2147DA8F