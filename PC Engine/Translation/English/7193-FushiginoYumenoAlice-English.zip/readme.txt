Use with:

(No Intro)
File:               Fushigi no Yume no Alice (Japan).pce
BitSize:            3 Mbit
Size (Bytes):       393216
CRC32:              12C4E6FD
MD5:                3E0CD9AF31EFE11ACF733FB15DC31131
SHA1:               C266B05DD367B2973399B8DAFF7C4DC33BEBEDD9
SHA256:             D37BB8A54B1300DC88D55E7E05FE7EBD5C6F6B62A3FFFC6DEC87F62B2390638E