Use With:

(Redump)
Shinsetsu Samurai Spirits - Bushidou Retsuden (Japan) (Track 01).bin
543537ffd1a975df94987bc21e19d0a1
6D0FAABA