Use with:

(No Intro)
File:               Emi-chan no Moero Yakyuuken! (Japan) (Unl).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              13B688B4
MD5:                1ABEC9090440920265737A5B57992B38
SHA1:               C317500C50955DABA14EC8CB71246D1FB9B1CB8F
SHA256:             5AA734A4E3E11E75C871985392DD32A6C13A06391872F84385505A01184A22CF