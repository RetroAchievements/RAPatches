Use with:

(No Intro)
File:               Dracula II - Noroi no Fuuin (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              3A0BB17B
MD5:                0EDA1DABCA3CDD01CFE34E24EF5155B7
SHA1:               82BE8E77C41C2E9D0675DAC8F20D6BF85C7F8F19
SHA256:             7F4A1E9B430F915C7A1C9974D0D90C3CE0E0B02750DA05078F93E6150330CA36