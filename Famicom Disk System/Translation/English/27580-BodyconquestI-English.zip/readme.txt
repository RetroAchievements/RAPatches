Use with:

(No Intro)
File:               Bodyconquest I - Abakareshi Musumetachi (Japan) (Disk 1) (Unl).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              6E59EC4F
MD5:                B4A97E97261DA9DF74E41ED67AE4663D
SHA1:               E75644E590A38487D39DD7B811F4EB6893D8A01A
SHA256:             513631D321B2DAAE5F6F19649EAC5591C05D7D7491C2E9940571065320221D38