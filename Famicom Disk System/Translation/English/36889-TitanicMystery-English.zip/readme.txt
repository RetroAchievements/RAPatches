Use with:

(No Intro)
File:               Titanic Mystery - Ao no Senritsu (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              FB36075C
MD5:                089D20E91E17A0C9C1871CAD1A7BB0F4
SHA1:               716786692CF9CBA9C5B02745025D648237571C43
SHA256:             7D934EF9CC8F4504E6D32412E94D571C22547B3B00E38EC6694B1C645A93BC8C