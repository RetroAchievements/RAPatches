Use with:

File:               Dead Zone (Japan).fds (nointro)
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              DE673254
MD5:                0032B506D04AE902C44B8269CE902A55