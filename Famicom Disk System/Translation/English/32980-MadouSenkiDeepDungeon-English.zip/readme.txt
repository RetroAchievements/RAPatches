Use with:

(No Intro)
File:               Madou Senki - Deep Dungeon (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              56F522D8
MD5:                D8927B0FCEEF207487B6F4DDB9D87EAB
SHA1:               AB207B80754AD078FA7CEB22D22F831898126D79
SHA256:             BC621FCCEE317595AA9E2DD25D3B799EE07854BAE04A79F75B872A3EB546CAC3