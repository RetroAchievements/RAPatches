Use with:

(No Intro)
File:               Esper Dream (Japan) (Rev 1) (Disk Writer).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              7AECF9D8
MD5:                6B6CF238668429511A027B1739403975
SHA1:               4DDDCE65694344DA9F83C9B85D6524DA0958962C
SHA256:             B6527373AAA483636C25AA3DAC564636BA5314BCBCAAD2F0F4D988F09589FCA8