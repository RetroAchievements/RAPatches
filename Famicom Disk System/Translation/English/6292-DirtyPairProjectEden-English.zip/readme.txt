Use with:

(No Intro)
File:               Dirty Pair - Project Eden (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              5F0A149B
MD5:                3339FE118797D085A272F89578F83DD4
SHA1:               8710825437166A6C20687A9CA2D86EBA5B28B26C
SHA256:             773C225C308466A5AAC9EEE896F960A49A10879C5E44330038A162395374E162