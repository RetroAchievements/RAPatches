Use with:

(No Intro)
File:               Apple Town Monogatari - Little Computer People (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              1967673E
MD5:                CB3984D82C60541CAFAA8A6786647791
SHA1:               C6B15E0FE1887F60D31E95D72D9C8E19A3C6FEF1
SHA256:             99DC425B21606C3F65D8BC6E0A5D5A61E1B260038ED17335D2D4BB14D0275B04