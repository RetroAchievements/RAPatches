Use with:

(No Intro)
File:               Knight Lore - Majou no Ookami Otoko (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              70E55476
MD5:                8F72FF90D8A70C7E94602E6979F463E5
SHA1:               F672554A637497098368F7E7397174574E6E6628
SHA256:             6E1F9AB3E6AFFAE8E6219B4EDD7DB34E9792028F7A095BE98952815EBBE54431