Use with:

(No Intro)
File:               Link no Bouken - The Legend of Zelda 2 (Japan) (Rev 1).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              3024CAD5
MD5:                4673E288B392EFC26326D8FC00C18B26
SHA1:               9D29FD1E38993AE67564262434B775E0A7DA1DE2
SHA256:             E700DED6700405654EA4C127D502EFFC1BEDA1A669822EDB5AE2D36949FAC64F