Use with:

(No Intro)
File:               Akumajou Dracula (Japan) (Rev 2) (Disk Writer).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              7448FB40
MD5:                33DEF5907D3561F6649A5E0CCF9A1D09
SHA1:               14366A2ABA5905896418D8B7FE05F4229489A980
SHA256:             87CB89F18CEB4CE0389D5D6A597C56D46C71D8F6F319BB67A456A5B2B7CFAE4A