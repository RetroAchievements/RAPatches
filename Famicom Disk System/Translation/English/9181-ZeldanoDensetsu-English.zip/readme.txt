Use with:

(No Intro)
File:               Zelda no Densetsu - The Hyrule Fantasy (Japan) (Rev 1).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              8F2202BF
MD5:                18D20A07FD107D9DB045451578914C94
SHA1:               1429FBE3E62059994B6FF7C5E5E2A330831FAF63
SHA256:             C6AFBC7CEBFF86BA1793524AE633F5F7812F589975BD052807E17D170C52E74B