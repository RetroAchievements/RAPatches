==========================================================
========================Dandy=============================
========================V 1.00============================
Genre: action rpg

Source language: Japanese

Platform: famicom disk system

Patch language: English

Author: Pennywise

E-mail: antoniusblocko@protonmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About Dandy
======================================================
Project History:

This project began some time last year for whatever
reason. Probably boredom, but I don't remember why
I picked the game other than the fact that the old
translation wasn't very good. In addition to translating
the game, I cleaned up the engrish in the credits and
fixed a bug where you could walk into the sky at the
end of the game.

Dandy's not a terrible game per se, but rather a
short, simple and not too long Zelda clone. I believe
the game was licensed from another Atari game called
Dandy, but it bears no relation to its western counterpart.
It's part of a trend where Japanese companies would
license western games and instead of porting them,
they would just make their own game.

Ryusui was kind enough to translate the story from the
manual which is as follows:

THE CURSED BEAST RETURNS!

Hear ye now the tale of the beast Zeon, passed down from ancient times.
At the end of the First Age, when man's avarice knew no bounds and the earth
was despoiled for its riches, the great beast Zeon rose up from the shadow of
the earth, and in three days and three nights laid waste to all that man had made.
Yet the merciful gods interceded, and Zeon was banished to the labyrinths of
Zera, a forbidding mountain to the north. Thus did the surviving humans take the
lesson of this tragic time and hand it down to their children and their children's
children for generations...

The ages did pass, and as the tale faded into myth, so too were its lessons
forgotten. Wickedness and selfishness spread like a plague, and once more did
humanity begin to despoil the earth in its arrogance.

Terror struck in an instant. By hands unknown were the four orbs of the seal
spirited away into the bowels of the earth, and Zeon stirred once more.
The land trembled, and by magicks foul did vile mockeries of the beasts of
the air, land, and sea spill forth from the abyss. Oldra burned, and the cries
of the dying filled the air. Yet none would bring succor to the blighted realm...

Like thunder, the voice of the gods rolled across the land:
"Ye foolish mortals, we grant thou one final chance. Recover the four lost orbs
of the seal, retrieve the sacred blade Artaion from its resting place in the
depths of the earth, and banish the beast once more into the labyrinths of Zera.
Send forth thy bravest. He who achieves this task shall thus be named 'Dandy',
the true king."

And thus your journey into battle begins!


======================================================
Patching Instructions
======================================================
Due to limitations in the IPS format and the changes I
made to the ROM, I'm only supporting BPS and xdelta formats
for this game. You can download a program to patch from here:

https://www.romhacking.net/patch/

Apply the patch to the Japanese ROM:

Dandy - Zeuon no Fukkatsu (Japan).fds


We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking, text editing

Ryusui - translation, manual translation

Bunkai - initial translation

TheMajinZenki - misc spot translation

cccmar - testing

All those who contributed into this process.

======================================================


Compiled by Pennywise. December 2021