Use with:

(No Intro)
File:               Dandy - Zeuon no Fukkatsu (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              F027228E
MD5:                AA1C671D6B5D3D3BFBE114588578B524
SHA1:               51062CC3E4806B1B94662ACEA969EF49C7C8FFED
SHA256:             C83476A43E43F937BF85EA7509B1D635B7BFE11A1BF62279A49FA8C25BF0F70B