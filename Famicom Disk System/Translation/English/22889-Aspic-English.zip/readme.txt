Use with:

(No Intro)
File:               Aspic - Majaou no Noroi (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              1999ADDB
MD5:                7D6153486D7103C639659A2256E88E5C
SHA1:               BEFB31B3FFBBE26993DE0DD8F15443DBD69F5D15
SHA256:             3B373AE3A834B74FD799F07FA742732455B71A5DED6C196F1FECBD7BAEBB089F