Use with:

(No Intro)
File:               Silviana - Ai Ippai no Little Angel (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              09F95CB9
MD5:                25DDE5ACF812C1DC5BAB53F6D4638A9E
SHA1:               46A777B0A245A02F1257F4619387AF9DBD52693A
SHA256:             8C803D0E6A1CFF3449B7B69ED3DC82CDD7216B8F3EBC1141A9841C6ADB412EEF