Use with:

(No Intro)
File:               Super Mario Bros. 2 (Japan) (En).fds
BitSize:            511 Kbit
Size (Bytes):       65500
CRC32:              F04CD4CD
MD5:                7F38210A8A2BEFB8D347523B4FF6AE7C
SHA1:               20E50128742162EE47561DB9E82B2836399C880C
SHA256:             FF8AFB9AE6B705B4E51DBCB193DCEBADF4C049800A71003D3A45052648E52EDA