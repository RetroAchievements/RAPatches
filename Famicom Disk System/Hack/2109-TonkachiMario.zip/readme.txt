Use with:

(No Intro)
File:               Tonkachi Editor (Japan) (Unl).fds
BitSize:            511 Kbit
Size (Bytes):       65500
CRC32:              BEA8B9A2
MD5:                E19FCB32FF02B557B55CC39D6A9377E6
SHA1:               3F8594BDC787944835CE73692D5529BA1230EF7F
SHA256:             C6C572DCFA80AFCF6DCC03156CCAB4278E2585DA5E4D4F817381496381E188BC