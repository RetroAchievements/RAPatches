Use with:

(Redump)
File:  Resident Evil - The Darkside Chronicles (USA).iso
CRC32: 0908A1FC
MD5:   e5437dffa882abb3e85dc44348a02f37

Patch is to be applied via GeckoPatcher:
- https://github.com/zsrtp/geckopatcher
- Web version: https://geckopatcher.com/
