Use with:

(Redump)
File:  Resident Evil - The Umbrella Chronicles (USA).iso
CRC32: C1572F7F
MD5:   d25f7f58343886238a58e5c22830b449

Patch is to be applied via GeckoPatcher:
- https://github.com/zsrtp/geckopatcher
- Web version: https://geckopatcher.com/
