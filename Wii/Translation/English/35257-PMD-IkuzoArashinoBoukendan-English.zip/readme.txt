Use with:

(No Intro)
File:               Pokemon Fushigi no Dungeon - Ikuzo! Arashi no Boukendan (Japan) (WiiWare).wad
BitSize:            216 Mbit
Size (Bytes):       28391552
CRC32:              ECA431E2
MD5:                38B75093FC9C21D20ED24D58C343F985
SHA1:               4FC3F48831147A4F1F1A968A034DB0D43A1F7C6C
SHA256:             18E19411AA75585550A3B4A936A33FF8D146B9ED167E6A7E0D578A3069F51310