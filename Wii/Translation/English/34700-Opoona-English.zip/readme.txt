Use with:

(Redump)
File:  Opoona (USA).iso
CRC32: E28F7468
MD5:   edfe2980f1ffd6b56a5d5d3b2df2dc32

Patch is to be applied via GeckoPatcher:
- https://github.com/zsrtp/geckopatcher
- Web version: https://geckopatcher.com/
