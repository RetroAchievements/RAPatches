Use with:

(Redump)
File:  Tales of Graces (Japan) (Rev 2).iso
CRC32: 3078DF88
MD5:   9fb2927815059e65708647944f55bc4d

Patch is to be applied via GeckoPatcher:
- https://github.com/zsrtp/geckopatcher
- Web version: https://geckopatcher.com/
