Opoona Re-localization patch
By: Opoonaproject

Table of contents:
  1) Introduction
  2) Patching instructions
     A) Extracting the .iso from your game disc
     B) Patching the game for playing on a backup loader or Dolphin
     C) Playing the game with Riivolution
     
  3) Error reporting


1) Introduction:

Opoona is a jRPG for the Wii, which I consider to be one of the greatest games to come out in the last decade. Unfortunately, the game suffers from a poor localization riddled with grammar, syntax, and continuity errors. This patch is the end result of 2 years of intermittent effort and fixes these errors, making for an experience I hope is more in line with what the game was intended to be.

All text in a blue box at the bottom of the screen has been edited and tested, with the exception of the opening cutscene (this was encoded as a video file). Menu text was not edited.



2) Patching Instructions:


  A) Extracting the .iso from your game disc

I do not promote or condone piracy of any kind. You can very simply make a backup of your legitimate copy of Opoona by following these steps:

Items needed:
   - A Wii
   - An Opoona game disc
   - An SD card (I believe the Wii can only accept cards up to 4GB, but that might be a lie)
   - A USB drive

  i) Install the Homebrew Channel on your Wii. There are tutorials online. The letterbomb method is extremely easy.

  ii) Install a USB loader app on your Wii, such as USB loader GX or configurable USB loader. Again, there are tutorials online. BE CAREFUL and precise when following instructions, as installing these will require you to change your operating system. Remember, BACKING UP A GAME YOU LEGITIMATELY OWN IS NOT ILLEGAL OR PIRACY.

  iii) Open the USB loader. You will need to have a USB inserted in the closest USB slot to the edge of the Wii. With the Opoona game disc in the drive, click "install for USB loader GX" or push B in configurable USB loader to back up the iso to your USB drive.

  iv) Download Wii Backup Manager on your computer.

  v) Insert your USB drive. DO NOT FORMAT THE DRIVE as you will lose your file.

  vi) Run Wii Backup Manager. Open the USB drive as drive 1, then click the "transfer" tab, then "ISO." Choose the folder, then wait for it to transfer.



B) Patching the game

  i) Download Wimms ISO tools

  ii) Extract the .zip file and go into the created folder

  iii) Enter the folder called "bin"

  iv) Place OPOONA.iso into the "bin" folder

  v) While in the windows explorer window of the "bin" folder, type "cmd" into the navigation bar and push enter

        - A black command window should pop up

  vi) Type "wit EXTRACT OPOONA.iso DUMP" and push enter

   	- A line should appear saying "wit: EXTRACT 1/1 ISO:OPOONA.iso -> DUMP/
	- Wait until text appears beneath this (it may take several minutes)

  vii) Back in the file explorer, a new folder called DUMP will have appeared

  viii) Open the DUMP forder and go to files\system

  ix) Replace msg_usa.bin with the file from the patch

  x) Back in the command prompt window, type "wit COPY DUMP OPOONANEW.iso"

	- It will take several minutes to rebuild the .iso. When it is done, a file called OPOONANEW.iso will appear in the "bin folder

  xi) Use Wii Backup manager to transfer the file back to your flash drive

	- Set Drive 1 to your flash drive
	- Remove Opoona from drive 1 and from the files tab if it is there
	- Select file -> add -> files and find OPOONANEW.iso
	- Select transfer -> drive 1    

  xii) Enjoy Opoona!


C) Playing the game with Riivolution

Required programs:
  - Riivolution (Wii channel that requires the homebrew channel to load) [note: see step vi for how to set up the SD card].
  - WiiScrubber (with key.bin)
  - LunarIPS, or another IPS patcher

  i) Open opoona.iso with WiiScrubber, and find the file DATA/system/msg_usa.bin

  ii) Extract msg_usa.bin

  iii) Run LunarIPS (or another IPS patcher), and use the included opoona.ips file to patch msg_usa.bin (if the .bin doesn't show up, change the file type to "all files")

  iv) Place the patched msg_usa.bin into the folder called "opoona"

  v) Place the contents of the folder titled "Place the contents in the root of your SD card" into the root of your SD card.

  vi) This is how your SD should look after being done with the process:

SD:\
    apps\
         riivolution\
                     boot.elf
                     icon.png
                     meta.xml
                     readme.txt
    opoona\
           msg_usa.bin
    riivolution\
                opoona.xml

  vii) Put your Opoona disc in the Wii disc drive.

  viii) Open the Homebrew Channel and run Riivolution

  ix) After it loads (takes 20-30 seconds), make sure it says "enabled," then click "launch."  You will need to run Riivolution every time you boot up the game in order for it to use the patched file.

  x) Enjoy Opoona!

  Note) If you select "install" in riivolution, it will install riivolution to your home menu so you don't have to load through homebrew channel.




3) Error reporting

If you spot errors or problems (spelling errors, lines taking two screens to display, extra periods, etc.) please email them to opoonaproject@gmail.com.
Include enough of the text that I can find it and the problem if it's not totally obvious.  If enough errors come in, I will create an updated version of the patch.


Thanks, and I sincerely hope you enjoy this game as much as I do!
