# La-Mulana - One Hit Ruins

This is a ROM hack patch for the North American WiiWare release of La-Mulana.

## Use With
(No-Intro)
File:         `La-Mulana (USA) (WiiWare).wad`
Size (Bytes): 44990592
CRC32:        6F11702B
MD5:          022705c7952cc307b12526a5c8936303
SHA1:         63290fcd9fbfaae2b01a466f8262b4ca1cdcb1d0
SHA256:       25330d6ba6df1fa00caa2d2be2763704733344355ae6135e0fb13ba300f31d60

## Patching Instructions
### Web Patcher
1. The web patcher is available at https://https://mulbruk.github.io/wiiware-patcher
2. Use with `La-Mulana (USA) (WiiWare).wad` and `La-Mulana - One Hit Ruins (v1.0) (Mulbruk).wwpf`

#### Local Patcher
1. Drag `La-Mulana (USA) (WiiWare).wad` onto `patch.bat`.
2. The patched ROM `La-Mulana - One Hit Ruins.wad` will be placed in the same folder as the patcher.
