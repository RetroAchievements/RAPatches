Use Metroid Prime Trilogy (USA) (RA MP2 Wii).xdelta with:

File:               Metroid Prime Trilogy (USA).iso (redump)
BitSize:            63 Gbit
Size (Bytes):       8511160320
CRC32:              8A4B439D
MD5:                823DF1C3C425F1383529F368F6479359
SHA1:               2204E5B19039D44B2379AB2065FD548C800BA680
SHA256:             21A2124319D22D7599A4E6140A41C3DE488DEF677498F9B8DA267258B8901A7B




Use Metroid Prime Trilogy (USA) (RA MP2 Wii).xdelta with:

File:               Metroid Prime Trilogy (Europe) (En,Fr,De,Es,It).iso (redump)
BitSize:            63 Gbit
Size (Bytes):       8511160320
CRC32:              7506B685
MD5:                735C0D0C16177E3294F5E0FAF7A69571
SHA1:               0C80815EEDCA8F597F01D5A380489766C56ACF88
SHA256:             AE911C815100DD1B44228A8EC6CFD9AA3B04179536215ADBA9DE925EB30F2998