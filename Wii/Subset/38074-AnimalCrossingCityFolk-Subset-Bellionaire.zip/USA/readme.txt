Use with:

(Redump)
File:               Animal Crossing - City Folk (USA) (En,Fr,Es).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              2F468135
MD5:                732D7CDDFD2F958D30B98FFEB72EEAC4
SHA1:               A75C7389877B331A520803529798F909B0DD0122
SHA256:             FE2CAA095B30189825A56ED7DF3BCC286CB7F811CEE3730BC71BC6D2A6B03E63