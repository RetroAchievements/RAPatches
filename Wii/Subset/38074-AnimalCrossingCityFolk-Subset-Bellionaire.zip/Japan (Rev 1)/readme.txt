Use with:

(Redump)
File:               Machi e Ikou yo - Doubutsu no Mori (Japan) (Rev 1).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              337C2AEF
MD5:                EB03EB3BC9491609E6273DE76F59D2EE
SHA1:               B4FD78369C25314A445390970A3DB0D34BA48D94
SHA256:             1D8FC1A75BED18CEBD57C5635FADB6D61B15492925A955E6D151EAE890F8F5D4