Use with:

(Redump)
File:               Animal Crossing - City Folk (USA, Asia) (En,Fr,Es) (Rev 1).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              90F2A29F
MD5:                91052ED3347AB216158A99C6C483B20F
SHA1:               D89F999354065C4B6071AC79D7AB854819DD012D
SHA256:             9C8E25FFCC6F6988E7E3F87636B74CDCA6AFD0185B6E99D16346FADB70D3DFDF