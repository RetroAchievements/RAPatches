Use with:

(Redump)
File:               Animal Crossing - Let's Go to the City (Europe) (En,Fr,De,Es,It).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              ECDBCE00
MD5:                68039075BD476D0F0BD5D31D1E474F76
SHA1:               E406847A2350A9D188817DFAE75D3A5E89485116
SHA256:             093A80A6EA348571F16E551AD526C1EA478D84023E786AF79FF495B703CD5D47