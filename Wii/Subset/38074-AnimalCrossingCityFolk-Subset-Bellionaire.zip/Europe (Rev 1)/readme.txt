Use with:

(Redump)
File:               Animal Crossing - Let's Go to the City (Europe) (En,Fr,De,Es,It) (Rev 1).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              381FFBD3
MD5:                F2BCBBBF9D5156738E0EEEA104C2098D
SHA1:               1BB9F2014361F2957313BFE5ABFCFA3E8090B385
SHA256:             5D25F55C6ACDDFBA0ABD12C7E8807C6A8DC2FB5859200533DDD91AAA1197958E