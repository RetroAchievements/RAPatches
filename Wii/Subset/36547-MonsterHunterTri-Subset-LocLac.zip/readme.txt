Use with:

(Redump)
File: Monster Hunter Tri (USA) (En,Fr,Es).iso
MD5:  a56b231600a6a084eb91514e124194eb
CRC:  46848F76

File: Monster Hunter Tri (Europe) (En,Fr,De,Es,It).iso
MD5:  b4b777ced147aecb45d4c87ac9ac4b4c
CRC:  E6A54872

1) Extract the ISO Patcher zip file somewhere, it should extract a folder named iso-patcher
2) Extract the content of the ISO Patches zip file into the [b]iso-patcher` folder. (It must say that it would replace existing files, you must hit yes)
3) Copy the Monster Hunter Tri ISO file into the iso-patcher folder. (The game must be in ISO Format, if you have it in any other format, you must convert it first)
4) Execute patch-images.bat located in the iso-patcher folder. Shortly, a screen should appear with a messages that explain what is patching.
5) When the patching is done you should see the message that say Press any key to continue....
6) The patched ISO should be located on the folder called mh3sp-images inside the iso-patcher.


ISO Patcher: https://github.com/sepalani/MH3SP-patcher/releases/download/local-v2022.12/local-iso-patcher-v2022.12.zip
ISO Patches: https://drive.google.com/uc?export=download&id=1T6X49pLewXRo8n8PpEHV1mza83n9zTdB
MH3SP GitHub: https://github.com/sepalani/MH3SP
MH3SP Discord Server: https://discord.gg/4sBmXC55V6