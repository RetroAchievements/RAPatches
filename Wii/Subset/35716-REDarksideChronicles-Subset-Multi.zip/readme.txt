Use with:

(Redump)
File:               Resident Evil - The Darkside Chronicles (USA).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              0908A1FC
MD5:                E5437DFFA882ABB3E85DC44348A02F37
SHA1:               A1474D7B9AB42397873CCF05A6523B708F76535B
SHA256:             21C28A760E6208D28CAF717A6EFDF26338780A5C0C288F841347A5714E259102