Use with:

(Redump)
File:               Legend of Sayuki (Europe) (En,Fr,Es,It).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              1B41D6F0
MD5:                CE28F3606AD64A8300B9349490636CC2
SHA1:               BA079759E777CD90891F9AF99FD56453A2518BF6
SHA256:             8DFAE82A062265387A736FEC617E233B2C786FFAAE150B7C52513A7BBFF4DABB