Use
Kirby's Epic Yarn (USA) [Subset - High Streaks].xdelta
with:

(Redump)
File:               Kirby's Epic Yarn (USA) (En,Fr,Es).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              EB41477E
MD5:                ACDBD566BAF471A45A53C8D8C93539A4
SHA1:               934683F734412386042060F7036D5F3DB20CB53F
SHA256:             BFD33F41EAF8C8CFFE8EABB72BC8EB5F10A473446AB23990C3B71F3FA5ACFA7B

Or use
Kirby's Epic Yarn (Europe) [Subset - High Streaks].xdelta
with:

(Redump)
File:               Kirby's Epic Yarn (Europe) (En,Fr,De,Es,It).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              88E2F649
MD5:                8AEEF7BC4B90BF45209A8F88FBDF9465
SHA1:               547AA7CA4D045594237154814786306F7645551F
SHA256:             E8E500CC848FEFEC89CBDA9F5362EB3BFFCDE1EABE678B5BA3E1562F9BF09318