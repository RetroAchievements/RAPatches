Use with:

(Redump)
File:               New Super Mario Bros. Wii (USA) (En,Fr,Es) (Rev 2).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              8C30D1D7
MD5:                B31A7DA0D493EC1F558B4E1899406A14
SHA1:               9AC7242A5FEEBE1D0A6E2775C21F482C471B2240
SHA256:             F5CA1F07F55C76C16F5A6809E039BD7D0E61084A864222E966F98C1159D45DDF