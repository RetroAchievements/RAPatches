@echo off

REM STEP #0 - Run relative to the script's directory
CD /D "%~dp0"

REM STEP #1 - Verify WLMJ hash
SET "EXPECTED_HASH=1821b164ab5c674616ed088b640b9f86d91f0b77d06a6b04d029ded0dce625183a4d31eddb815e38e891b2039cc67366ad8ae33b0c6656a08e8ecbc1637e4cb2"
SET "HASH_ALGORITHM=SHA512"

FOR /F "skip=1 tokens=1" %%A IN ('certutil -hashfile %1 %HASH_ALGORITHM%') DO (
    IF NOT DEFINED CALCULATED_HASH SET "CALCULATED_HASH=%%A"
)
SET "CALCULATED_HASH=%CALCULATED_HASH: =%"


REM Compare the hashes
IF /I "%CALCULATED_HASH%" EQU "%EXPECTED_HASH%" (
    ECHO SUCCESS: %1 matches the expected hash.
) ELSE (
    ECHO FAILURE: %1 does not match the expected hash.
    ECHO Expected hash: %EXPECTED_HASH%
    ECHO Calculated hash: %CALCULATED_HASH%
    ECHO .
    ECHO .
    ECHO .
    ECHO Please ensure you are using the correct WAD file and try again.
    PAUSE
    EXIT
)

REM STEP #2 - Verify the patch exists
IF NOT EXIST ".\LaMulana-Glitch-Subset.wwpf" (
    ECHO ERROR: .\38550-LaMulana.wwpf not found
    PAUSE
    EXIT
)

REM STEP #3 - Verify wiipyrite exists
IF NOT EXIST ".\wiipyrite_cli.exe" (
    ECHO ERROR: .\wiipyrite_cli.exe not found
    PAUSE
    EXIT
)

REM STEP #4 - Patch the WAD
ECHO Patching %1...
.\wiipyrite_cli.exe patch apply LaMulana-Glitch-Subset.wwpf %1 --output "La-Mulana (US) (WiiWare) (Glitch Subset).wad"
ECHO Successfully patched game!
ECHO Output: .\La-Mulana (US) (WiiWare) (Glitch Subset).wad

PAUSE
