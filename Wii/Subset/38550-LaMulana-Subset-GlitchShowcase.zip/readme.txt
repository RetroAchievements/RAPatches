Use with:

(No-Intro)
File:               La-Mulana (USA) (WiiWare).wad
BitSize:            343 Mbit
Size (Bytes):       44990592
CRC32:              6F11702B
MD5:                022705c7952cc307b12526a5c8936303
SHA1:               63290fcd9fbfaae2b01a466f8262b4ca1cdcb1d0
SHA256:             25330d6ba6df1fa00caa2d2be2763704733344355ae6135e0fb13ba300f31d60
