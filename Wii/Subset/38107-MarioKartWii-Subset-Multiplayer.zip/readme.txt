Use with:

(Redump)
File:               Mario Kart Wii (Europe, Australia) (En,Fr,De,Es,It).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              3A70D78B
MD5:                E7B1FF1FABB0789482CE2CB0661D986E
SHA1:               4FDE5CE38D68F632D92C5B0D52BBAB0B1D355A95
SHA256:             2FC548BAD45F373BAD953D410A32E042E7EFEEF86A90F9FF63DDC5B62F9E6971