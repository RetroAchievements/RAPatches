Use with:

(Redump)
File:               Donkey Kong Country Returns (Europe) (En,Fr,De,Es,It).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              A1C33316
MD5:                8ECFCD59ED3FA9241AF62F694EBCB343
SHA1:               9C957BB34E46C3C6FD9E48ACB09DFCB9933301CF
SHA256:             15C00E940DB09F4FBD8AA4EA3EDB4DEE66D360ACCB94130A75A67D0038DB6E43