Use with:

(Redump)
File:               Kirby's Return to Dream Land (USA) (En,Fr,Es).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              AE51EC85
MD5:                DADE208216BD03A370E8217439BEDBD8
SHA1:               D7ADCDC8E3FE7F164EB95F53094974FC31E76CCB
SHA256:             61C045F5646100CBE40288BD8E2D62A0CE8C4BB4A5FA45AEC3E0EE56C69EE7DE