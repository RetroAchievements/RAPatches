Use with:

(Redump)
File:               Puyo Puyo!! Puyopuyo 20th Anniversary (Japan).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              92439A17
MD5:                776566D3324BBA55CC214158F45D1B84
SHA1:               0A7BBB9732C9F05D34004D4FEEF5479F4EDE8107
SHA256:             3DFC6401349B7924544287B0DD49BA46EE26CD5DE4702763E31BDF4DC1BC7FEF