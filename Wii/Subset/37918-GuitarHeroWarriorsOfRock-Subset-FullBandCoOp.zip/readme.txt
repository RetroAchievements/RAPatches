Use with:

(Redump)
File:               Guitar Hero - Warriors of Rock (USA) (En,Fr).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              9794B23A
MD5:                B377D52E40C58547E5B1D9FFBF7AE6E9
SHA1:               292F89307A162084B221C7110DB68EF4C73C569F
SHA256:             405EBDEF574BF87D8272A91941811FC905A62EAEDAA952423DE135519C66DC6C