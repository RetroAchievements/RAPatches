Use with:

(Redump)
File:               Link's Crossbow Training (USA) (En,Fr,Es) (Rev 1).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              98D41086
MD5:                EB15265DC42A5963B1A581AA4F09ED90
SHA1:               80AD2D15078BCE3E41DCB0B6E57825824DBA390E
SHA256:             76EC213E26DA7D59C31D7E25D6A7C3E978E9A71787B94FA52A7F664AFB01C870