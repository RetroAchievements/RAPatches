Use with:

(Redump)
File:               Indiana Jones and the Staff of Kings (USA) (En,Fr,Es).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              69D95C0E
MD5:                16CEA398FFA8FF6EF6D7F3D916271080
SHA1:               23CF8684C04F97C95151912A8FD8051B072376A4
SHA256:             F7F0EA8A3EDD2FD9CBBA57F11A5200F4FA07D26A34566AF717C1B11F0FE59B13