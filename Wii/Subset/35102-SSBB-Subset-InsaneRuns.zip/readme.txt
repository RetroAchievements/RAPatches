Use with:

(Redump)
File:               Super Smash Bros. Brawl (Europe) (En,Fr,De,Es,It) (Rev 1).iso
BitSize:            63 Gbit
Size (Bytes):       8511160320
CRC32:              CB762C85
MD5:                C2255D53E08D6E1E6D25114BE9F1BEC1
SHA1:               666AD47A8C4010FAECF77A92565E1F4E077A586B
SHA256:             602AC82F00D27695680BC7862B09A5EDFD857A9F4833339B748A97B90B9684E5