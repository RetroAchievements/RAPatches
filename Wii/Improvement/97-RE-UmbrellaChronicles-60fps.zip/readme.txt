To apply the .patch file:
- Use gui-patcher.exe
OR
- Use romhack.exe via command line:
  - romhack apply my_patch.patch original_game.iso patched_game.iso
OR
- Use the online patcher: https://geckopatcher.com/

- gui-patcher.exe and romhack.exe are in the provided geckopatcher-windows-x86_64.zip
- It can also be found here: https://github.com/zsrtp/geckopatcher/releases


Use with:

(Redump)
File:               Resident Evil - The Umbrella Chronicles (USA).iso
BitSize:            35 Gbit
Size (Bytes):       4699979776
CRC32:              C1572F7F
MD5:                D25F7F58343886238A58E5C22830B449
SHA1:               AE52BCA6E1A0BF90D8E91CB62FBFBA7A9BA750F7
SHA256:             5A1CC935F183F0E7ED1C2740560375FCA9327F84773F60D071B8815C3CE11150