Use with:

(No-Intro)
File:               Alien Crush Returns (Japan) (WiiWare).wad
BitSize:            298 Mbit
Size (Bytes):       39122560
CRC32:              1F7C7B50
MD5:                02EAD6D214A2E5288E11D6061A91CB82
SHA1:               793DFE3FEB0B26629F33E0A64077786FF75968F1
SHA256:             F6D71EE3F9C843192B252A807A758B040F8B585F1AEDFB6392B2A0E8FE6EA39A