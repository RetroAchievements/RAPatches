Use with:

(No-Intro)
File:               Alien Crush Returns (Europe) (WiiWare).wad
BitSize:            298 Mbit
Size (Bytes):       39067136
CRC32:              9B26AA32
MD5:                12E3747C2FA6248BF1806412BB62A655
SHA1:               641E431D60E1E128916B33D780F89640C9F00D2E
SHA256:             FB4EE1D50D428B1AB601F71CA36AF4D63A280D2F55BCAB892E1E20898B17CB0A