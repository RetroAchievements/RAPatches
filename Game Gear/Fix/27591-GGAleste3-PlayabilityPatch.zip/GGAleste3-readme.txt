Patch designed to be used on
GG Aleste 3 (Japan) (En) (Aleste Collection).gg
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              5AE64731
MD5:                BA860AFBF7B7EB2B1BA08C957D44B34C