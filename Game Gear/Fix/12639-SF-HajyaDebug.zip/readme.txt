Use with:

(No Intro)
Shining Force - The Sword of Hajya (USA).gg
MD5: 0a0fa9cbcc3db467191e907794c8c02b
CRC: A6CA6FA9

(No Intro)
Shining Force Gaiden II - Jashin no Kakusei (Japan).gg
MD5: 8857422e565412a59c77cb29550715e4
CRC: 30374681