Use with:

Coca-Cola Kid (Japan).gg (No Intro)
dbede5c20828e3d251b05356d9176c79

Original Patch: https://www.romhacking.net/translations/1189/