Use with:

(No Intro)
File:               SD Gundam - Winner's History (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              5E2B39B8
MD5:                2FF122C0EB474E362CBCCFB7C72B1A38
SHA1:               24E217098845AB5A0EB29E9DC6AF2E86BE1B0A84
SHA256:             B456C2F22CC3CB8EE8DB408A662D6C7A5F1D9C9F9017D7932F9F367C1D44E2E4