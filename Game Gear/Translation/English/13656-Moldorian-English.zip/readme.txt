Use with:

Moldorian - Hikari to Yami no Sister (Japan).gg (No Intro)
95fb42e84a2b08acce481b0894ea3cea

Original Patch: https://www.romhacking.net/translations/4084/