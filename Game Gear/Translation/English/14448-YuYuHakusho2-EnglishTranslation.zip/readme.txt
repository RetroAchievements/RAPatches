Use with:

(No Intro)
File:               Yu Yu Hakusho II - Gekitou! Nanakyou no Tatakai (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              46AE9159
MD5:                3CCEF570D91851265472C90D523971B4
SHA1:               140EFE67E886F52AEDA2089A73599F7680C89F24
SHA256:             94EBF64DDA4ECBA8245B8DB3C902166F4B9AF4D5750D1937C4EEC0DCF4571DA8