Use with:

(No Intro)
File:               Madou Monogatari A - Dokidoki Vacation (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              7EC95282
MD5:                AB0D1EB20AC63A984D874A885CA2588D
SHA1:               C027AA76FE0E09A2D1B982EEA0DF2C8B687AADF7
SHA256:             6679B88D3DB2CA62A78B1904CFE8364F7E6D5D74FFDA27B7DBE49417ED2D02EC