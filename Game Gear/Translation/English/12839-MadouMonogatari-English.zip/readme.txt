Use with:

(No Intro)
File:               Madou Monogatari I - 3tsu no Madoukyuu (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              00C34D94
MD5:                ABCA338C5F08D06526D09B70588ADD2C
SHA1:               5CCD474CEFCB8E086E2E1F77C0FDD5C1D2BF82E7
SHA256:             4A87F02F358688BC7680D0D34F527E10A087FEC95DBF7ED131241D8FFE4C0654