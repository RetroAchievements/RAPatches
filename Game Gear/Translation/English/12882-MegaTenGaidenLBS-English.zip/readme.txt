Use with:

Megami Tensei Gaiden - Last Bible Special (Japan).gg (No Intro)
aab2b02c831252f6a2eb369df39f7c73

Original Patch: https://www.romhacking.net/translations/3160/