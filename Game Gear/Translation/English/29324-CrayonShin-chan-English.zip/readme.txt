Use with:

(No Intro)
File:               Crayon Shin-chan - Taiketsu! Kantam Panic!! (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              03D28EAB
MD5:                41EEC91E3C4E546D93053F2C234517A6
SHA1:               65BCBD89637B8E6837CF36C7F1241EACF85ABAA9
SHA256:             CDF6B1A7E172D02877DA96EBFACE3EFBAA1AE23A54FB7C2AE0DEF3457C000E14