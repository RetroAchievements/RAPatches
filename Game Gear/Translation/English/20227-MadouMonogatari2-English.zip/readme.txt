Use with:

(No Intro)
File:               Madou Monogatari II - Arle 16-Sai (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              12EB2287
MD5:                81A57F26B7A1CCAA21BF7678B3596CB2
SHA1:               DEEAD79FA4CB2E87652A9C8A76F2A7174F48F37A
SHA256:             9DA7D65D1772AE9B5FA71CEE68B19F78BFC4848451AD6BBB5662498B2DBB997A