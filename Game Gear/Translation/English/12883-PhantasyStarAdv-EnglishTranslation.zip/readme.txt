Use with:

Phantasy Star Adventure (Japan).gg (No Intro)
8fad420b7dc93cd7ed10bfc54ec04f07

Original Patch: https://www.romhacking.net/translations/62/