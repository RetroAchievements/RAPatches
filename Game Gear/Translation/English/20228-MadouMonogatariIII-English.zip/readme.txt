Use with:

(No Intro)
File:               Madou Monogatari III - Kyuukyoku Joou-sama (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              0A634D79
MD5:                B8B5305EC2F68D7BB3C9F622A13EBA7C