Use with:

(No Intro)
File:               Megami Tensei Gaiden - Last Bible (Japan).gg
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C06FEACD
MD5:                16879FE9FDFF6822DBF48560CA7BF6BB
SHA1:               168E170A764068494A4998FA712646657D484339
SHA256:             EC315679F0ED015D46D9D27B964A91CC54E0FEFE07A73553F3B0D0BE4AE3CE42


Original Patch:
https://www.romhacking.net/translations/4259/