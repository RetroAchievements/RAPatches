Use with:

(No Intro)
File:               Madou Monogatari III - Kyuukyoku Joou-sama (Japan).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              0A634D79
MD5:                B8B5305EC2F68D7BB3C9F622A13EBA7C
SHA1:               DD590C9086161B1F97573C48720C32CC5506DABC
SHA256:             A02710B5CBF71E49A3AAA18C1E28BE769BB634139FD987101C448575467F8CA3

File:               Madou Monogatari III - Kyuukyoku Joou-sama (Japan) (Rev A).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              568F4825
MD5:                1294C965ABDD845F554B30B311DEE272
SHA1:               673670F954176FFAB28A0280AA49856A457F36B1
SHA256:             75A284CFE95BF5EECED55AA958B1592C6ECFC556CEF4D82F5E4F148B9394F375