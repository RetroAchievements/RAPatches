Use with:

(No Intro)
File:               Tails Adventures (World) (En,Ja).gg
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              5BB6E5D6
MD5:                A8BDB1BEED088FF83C725C5AF6B85E1F
SHA1:               DA3DF145B8E9F2A2E680D2C92939084D4530ED90
SHA256:             92A9985333DF0EE46E9A44B97BDA37C565DE831BBCBC9B740CD43637B0F5072A