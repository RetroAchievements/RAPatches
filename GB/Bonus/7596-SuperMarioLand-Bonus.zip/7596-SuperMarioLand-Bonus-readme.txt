Use with:

Super Mario Land DX.gb (No-Intro)
b45f850d25943a636d9999f90a2bbaa8
6862D7F8

Super Mario Land (World).gb (No-Intro)
b48161623f12f86fec88320166a21fce
90776841
