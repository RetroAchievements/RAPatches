For standard ~Bonus~ Set or ~Bonus~ Set + Fast Hack
Use with:

No Intro
Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
RA Checksum: 50927e843568814f7ed45ec4f944bd8b
CRC Checksum: D6DA8A1A

No Intro
Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
RA Checksum: 3d45c1ee9abd5738df46d2bdda8b57dc
CRC Checksum: 9F7FDD53


To add Fast Hack to existing ~Bonus~ Set ROM, simply apply the provided .ips to either.