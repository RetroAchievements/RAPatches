Use with:

No Intro
Legend of Zelda, The - Link's Awakening (USA, Europe) (Rev B).gb
RA Checksum: cf93cae1fe45f74b6f6fdd3a7bb6f6e1
CRC Checksum: 1f8b197b