Use with:

(No Intro)
File:               Mega Man V (USA) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              72E6D21D
MD5:                CEB17D831B410D91AA41BF2819CBED82