Use with:

[No Intro]
File:               Kirby's Dream Land 2 (USA, Europe) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              8DC07C35
MD5:                DDB5BFAE32B0CA39CF8AB6C46880126C
SHA1:               8A2898FFA17E25F43793F40C88421D840D372D3C
SHA256:             08DDC36709D551B6C2B768E8280E0213EBE89A5088B34E1CC6C0E14977B8E312