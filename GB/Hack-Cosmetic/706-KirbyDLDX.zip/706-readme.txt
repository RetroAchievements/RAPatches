Use with:

(No Intro)
File:               Kirby's Dream Land (USA, Europe).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              40F25740
MD5:                A66E4918EDCD042EC171A57FE3CE36C3