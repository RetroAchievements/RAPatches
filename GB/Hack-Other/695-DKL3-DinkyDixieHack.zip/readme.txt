Use with:
Donkey Kong Land III (USA, Europe) (Rev 1) (SGB Enhanced).gb (No-Intro)
333444e90c0bfb99c4ff89fdcb920fe4
A19ACDB6