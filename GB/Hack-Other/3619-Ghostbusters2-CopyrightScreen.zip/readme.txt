Use with:
Ghostbusters II (USA, Europe).gb (No-Intro)
0841a527b116a52ad26de023b20b1a42
5821ECD4