Use with:

(No Intro)
File:               Final Fantasy Legend II (USA).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              58314182
MD5:                2BB0DF1B672253AAA5F9CAF9AAB78224