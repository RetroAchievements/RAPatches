Use with:

(No-Intro)
Super Mario Land (World) (Rev 1).gb
b259feb41811c7e4e1dc200167985c84
2C27EC70
