Use with:

Crayon Shin-chan 4 - Ora no Itazura Daihenshin (Japan) (SGB Enhanced).gb (No-Intro)
bcb3d47c291fd0a26b2c7b1082c3ad88
37D4AA8C
