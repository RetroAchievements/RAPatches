Use with:

Mario's Picross (USA, Europe) (SGB Enhanced).gb (No-Intro)
ccaf9331318d4dfe3d1ee681928a74fd
F2D652AD
