Use with:
Super Mario Land (World) (Rev 1).gb (No-Intro)
b259feb41811c7e4e1dc200167985c84
2C27EC70