Use with:
Bomberman GB (USA, Europe) (SGB Enhanced).gb (No-Intro)
7e4c9c3620bea7b633394beb67e9680b
F372D175