Use with:
Batman - The Video Game (World).gb (No-Intro)
03c6d84a951be6703b7458478f4277b9
6C41D3CD