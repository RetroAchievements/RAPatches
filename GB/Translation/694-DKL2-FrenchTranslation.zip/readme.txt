Use with:
Donkey Kong Land 2 (USA, Europe) (SGB Enhanced).gb (No-Intro)
6e30394fd7ef4a4dc3fe1edd9fc69f72
2827E5D4