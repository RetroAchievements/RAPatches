Use with:
Avenging Spirit (USA, Europe).gb (No-Intro)
e88eab57ab4614966748280bf3c97f52
CF2BA5F7