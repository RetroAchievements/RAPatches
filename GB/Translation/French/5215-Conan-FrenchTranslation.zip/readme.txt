Use with:

Meitantei Conan - Chika Yuuenchi Satsujin Jiken (Japan) (SGB Enhanced).gb
7ab8eb19c5356f62bcc3fa2a8f1aba1f
3945BC0D