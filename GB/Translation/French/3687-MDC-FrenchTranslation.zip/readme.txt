Use with:
Mickey's Dangerous Chase (USA).gb (No-Intro)
16bc18ef00088094e9fad502e613be5e
7B822D8F