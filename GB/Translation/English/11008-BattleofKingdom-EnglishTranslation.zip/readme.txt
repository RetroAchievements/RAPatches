Use with:

Battle of Kingdom (Japan).gb
f7aa9880db8e7884618ff0dcab6fba85
35914DEB