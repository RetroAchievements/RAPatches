Use with:

(No Intro)
File:               Wizardry Gaiden I - Joou no Junan (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              4D640E73
MD5:                14D6A5E430452DCA394BD3E641DC327B