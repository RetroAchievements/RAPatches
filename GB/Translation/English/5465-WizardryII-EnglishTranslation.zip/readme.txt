Use with:

(No Intro)
File:               Wizardry Gaiden II - Kodai Koutei no Noroi (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              F6826D12
MD5:                177F5FC642F650E45BAE33B10BA1FE48
SHA1:               8DC0AB82462D4AB287D8155E8EAB7E796EB7C766
SHA256:             2E2D7ED9EFBD9B972BAC2E248A4A02BB03603D456ACA1CAFC3CA5658E4D755CD