Use with:

Makaimura Gaiden - The Demon Darkness (Japan).gb
de731a5f2f4e7d16bcdc4b5953ddcc12
CFA358DE