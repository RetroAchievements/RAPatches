Use with:

(No Intro)
God Medicine - Fantasy Sekai no Tanjou (Japan).gb
52e110882a9f42c8b5c97489a29005f5
A1B29AB8