Use with:

(No Intro)
Yu-Gi-Oh! Duel Monsters (Japan) (SGB Enhanced).gb
770a917f18e0aa1f3bb027d0783f548b
8875EC54