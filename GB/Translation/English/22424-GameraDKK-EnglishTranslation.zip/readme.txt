Use with:
No Intro
Gamera - Daikaijuu Kuuchuu Kessen (Japan) (SGB Enhanced).gb
88c33c0fc3dbdc848b9be604cdda5744
62769ec1