Use with:

(No Intro)
File:               Wizardry Gaiden III - Yami no Seiten (Japan).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              32C94538
MD5:                2BE59D4C20728300C84A71FCFCB565F9
SHA1:               E169014CF1F12B956F8DFF040DDB063EA4F7CAB9
SHA256:             AEB5380F81A8B4E05B9ECA3F5D0178923A5460C2632BE4B1173269B6BD043612