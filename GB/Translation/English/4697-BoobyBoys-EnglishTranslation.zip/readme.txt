Use with:
Booby Boys (Japan).gb (No-Intro)
d17aa3dd0a52bc3dc03bfe20f27c8b07
EC83C0B6