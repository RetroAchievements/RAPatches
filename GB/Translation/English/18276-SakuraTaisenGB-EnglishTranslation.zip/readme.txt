Use with:

(No Intro)
File:               Sakura Taisen GB - Geki Hana Gumi Nyuutai! (Japan).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              EF503D50
MD5:                70883B45A97984CB033C2B95028BEF65
SHA1:               4E30A9B06B5048449057376C8F37B3F687FABD18
SHA256:             8A3AA431ED863ED8AEB4BEA6BFBD792FC59C2E78BE4D89805F16FBC0723C17B1