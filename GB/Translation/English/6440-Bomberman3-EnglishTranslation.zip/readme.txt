Use with:

(No Intro)
Bomberman GB 3 (Japan) (SGB Enhanced).gb
3addab2611566ab072fc996f8a81b224
F658B7A7