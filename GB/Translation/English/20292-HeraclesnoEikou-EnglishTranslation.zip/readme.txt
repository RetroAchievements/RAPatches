Use with:

(No Intro)
File:               Heracles no Eikou - Ugokidashita Kamigami (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              4F8A61BF
MD5:                CCBD8D97A61883E05EAB21A5546188B2
SHA1:               C12C60B0C0A2EE1AADED61020FA72B5B467459E1
SHA256:             E9C9C567573CB568104F498920FD200F74BBC90B0F9E52AE0AF1B45F59F94ADD