Use with:
Final Fantasy Legend III (USA).gb (No-Intro)
db156bc96b528996ce1bf771195171af
3E454710