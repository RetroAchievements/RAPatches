Use with:

Ayakashi no Shiro (Japan).gb
8f3095c4d98694f19270d8c2788d5e46
DA90F5FC