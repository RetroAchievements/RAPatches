Use with:
Cave Noire (Japan).gb (No-Intro)
10d92861e262069ce31559e12b927aa0
44256A2F