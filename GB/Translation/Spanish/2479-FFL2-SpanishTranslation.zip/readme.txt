Use with:
Final Fantasy Legend II (USA).gb (No-Intro)
2bb0df1b672253aaa5f9caf9aab78224
58314182