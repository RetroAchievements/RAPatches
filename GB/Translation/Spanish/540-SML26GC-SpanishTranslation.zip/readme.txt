Use corresponding patch with:

(No-Intro)
Super Mario Land 2 - 6 Golden Coins (USA, Europe).gb
a8413347d5df8c9d14f97f0330d67bce
D5EC24E4

Super Mario Land 2 - 6 Golden Coins (USA, Europe) (Rev 1).gb
1d2c316f9f32727261328c7a49b22e2c
E6F886E5

Super Mario Land 2 - 6 Golden Coins (USA, Europe) (Rev 2).gb
4bd6e929ec716a5c7fe7dc684860d551
635A9112