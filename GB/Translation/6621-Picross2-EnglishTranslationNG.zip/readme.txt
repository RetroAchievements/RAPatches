Use with:
Picross 2 (Japan) (SGB Enhanced).gb (No-Intro)
142d1f9f4b868780824cca20010ad4d8
F5AA5902