Use with:
DuckTales (Europe).gb (No-Intro)
ca7a62e5e14aafd813bc806d0cf54117
AC6483DC