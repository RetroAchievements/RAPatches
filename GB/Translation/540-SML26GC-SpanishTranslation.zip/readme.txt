Use with:
Super Mario Land 2 - 6 Golden Coins (USA, Europe) (Rev 2).gb (No-Intro)
4bd6e929ec716a5c7fe7dc684860d551
635A9112