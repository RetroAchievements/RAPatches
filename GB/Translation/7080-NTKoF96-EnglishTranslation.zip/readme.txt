Use with:
Nettou The King of Fighters '96 (Japan) (SGB Enhanced).gb (No-Intro)
16ee9b10c27c136d2959ae87105a8a2e
FECDAE42