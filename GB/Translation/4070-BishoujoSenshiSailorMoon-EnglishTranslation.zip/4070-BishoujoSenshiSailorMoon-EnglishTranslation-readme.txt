Use with:

Bishoujo Senshi Sailor Moon (Japan).gb (No-Intro)
7afb675171d58105112dbacf2ced77cb
C2763E73
