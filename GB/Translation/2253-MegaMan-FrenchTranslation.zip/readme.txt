Use with:
Mega Man - Dr. Wily's Revenge (USA).gb (No-Intro)
4ba4398181d98958fa7434ba7716f11a
47E70E08