Use with:
Aerostar (USA, Europe).sfc (No-Intro)
f777a4526089a83ca758efbf01007ec1
F6FD275E