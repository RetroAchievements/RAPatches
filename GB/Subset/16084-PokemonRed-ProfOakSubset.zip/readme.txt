Use with:

(No Intro)
Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
3d45c1ee9abd5738df46d2bdda8b57dc
9F7FDD53