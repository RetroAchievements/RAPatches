Use with:

(No Intro)
Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
RA Hash: D9290DB87B1F0A23B89F99EE4469E34B