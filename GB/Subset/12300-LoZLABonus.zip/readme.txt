Use with:

(No Intro)
File:               Legend of Zelda, The - Link's Awakening (USA, Europe) (Rev 2).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              34D08E7B
MD5:                69D643BF4E37B3C133518517338B6A1C