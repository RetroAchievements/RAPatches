Use with:

Pocket Monsters - Midori (Japan) (SGB Enhanced).gb
e30ffbab1f239f09b226477d84db1368
BAEACD2B