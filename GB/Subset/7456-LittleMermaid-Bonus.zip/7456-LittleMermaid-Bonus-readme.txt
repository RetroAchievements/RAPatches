Use with:

Little Mermaid, The (USA).gb (No-Intro)
a4dee5de1b4c3d9083f307d910fa0c3f
D7C517E5
