Use with:

(No Intro)
Pocket Monsters - Ao (Japan) (SGB Enhanced).gb
CRC32 Checksum: E4468D14
MD5 Checksum: C1ADF0A77809AC91D905A4828888A2F0
RA Checksum: fa37cdb33108b88ade1a3d4a53a039e8