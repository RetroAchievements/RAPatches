Use with:

Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb (No-Intro)
50927e843568814f7ed45ec4f944bd8b
D6DA8A1A
