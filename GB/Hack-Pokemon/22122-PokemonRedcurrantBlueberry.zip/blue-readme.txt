Use with:

(No Intro)
Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
MD5 - 50927e843568814f7ed45ec4f944bd8b
CRC - D6DA8A1A