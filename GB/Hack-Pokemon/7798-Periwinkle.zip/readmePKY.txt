Use with:

(No Intro)
Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
d9290db87b1f0a23b89f99ee4469e34b
7D527D62