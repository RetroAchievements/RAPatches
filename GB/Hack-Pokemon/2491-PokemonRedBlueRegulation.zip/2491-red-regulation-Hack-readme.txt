

Use with:

Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb (No-Intro)
3d45c1ee9abd5738df46d2bdda8b57dc
9F7FDD53
