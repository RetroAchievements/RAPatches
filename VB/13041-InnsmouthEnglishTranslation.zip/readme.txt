Use with:

Innsmouth no Yakata (Japan).vb (No Intro)
1eb964d0eaa3223cfefdcc99a6265c88