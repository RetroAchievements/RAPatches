Use with:

(No Intro)
File:               Virtual Lab (Japan).vb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              8989FE0A
MD5:                1CEC316ACA8827FDF99C685A1EE49DBC