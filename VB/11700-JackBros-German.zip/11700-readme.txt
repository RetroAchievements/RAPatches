Use with:

(No Intro)
Jack Bros. (USA).vb
md5: ee873c9969c15e92ca9a0f689c4ce5ea
crc: A44DE03C