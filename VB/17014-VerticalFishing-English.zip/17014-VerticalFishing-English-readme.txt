Use with: 

(No Intro)
Virtual Fishing (Japan).vb
md5: c03e792d8628c3c5729fdcae1620fb9a
crc: 526cc969 