Use with:

(No Intro)
Niko-chan Battle (Japan) (Proto).vb
md5: d9a0215782dcacee5a3c4cc83d1c5189
crc: F3CD40DD