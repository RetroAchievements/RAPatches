Use with:

Space Invaders - Virtual Collection (Japan).vb (No Intro)
7607f6f918615263512b17e56797c9aa