Use with:

(Redump)
File:               Monster Lair (USA) (Track 02).bin
Size (Bytes):       20163696
CRC32:              5e46ab78
MD5:                3f3dfb767630c469fe7747ceef1e9797
SHA1:               456b64de05699e3431d14e76a71cdb9ea7cbad4c