@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\ZiriaMerged.bin
set delta_file=%CD%\patch\Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).xdelta
set output_file=%CD%\Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7)\Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7).cue" "%CD%\ZiriaMerged"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\ZiriaMerged.bin"
DEL "%CD%\ZiriaMerged.cue"

pause
