Use with:

(Redump - Split)
Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (Track 2).bin
37a81f21cd4c085fbe0817b40a42b6eb
84472B6A

Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (Track 6).bin
4562a8f55177304c6ef8e0404210b194
1BB0E5CC

or

(Redump - Merged)
Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7).bin
2deae1bfcc13ffe0d4e52b59883a9376
ED6BC123