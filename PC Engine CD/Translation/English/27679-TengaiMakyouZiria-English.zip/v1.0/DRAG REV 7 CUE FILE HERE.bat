if exist "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.0) (LIPEMCO! Translations).bin" del "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.0) (LIPEMCO! Translations).bin"
set binfullname=%~n1
copy /b "%binfullname% (Track 1).bin" + "%binfullname% (Track 2).bin" + "%binfullname% (Track 3).bin" + "%binfullname% (Track 4).bin" + "%binfullname% (Track 5).bin" + "%binfullname% (Track 6).bin" "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.0) (LIPEMCO! Translations).bin"

xdelta3 -d -s "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin" "../redump_patch/Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).xdelta" "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin_patched"

if exist "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin" del "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin"
move "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin_patched" "Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (En) (v1.2) (LIPEMCO! Translations).bin"