﻿********************************************************************************
*               Ginga Ojousama Densetsu Yuna 2: Eien no Princess               *
*                          English Translation Patch                           *
*                              v1.1 (08 May 2023)                              *
*                                                                              *
*                               Supper -- Hacking and Translation              *
*                             Mafoo343 -- Manual Translation,                  *
*                                         Translation Support,                 *
*                                         Testing                              *
*                        TheMajinZenki -- Translation Support                  *
*                               cccmar -- Testing                              *
*                             Xanathis -- Testing                              *
********************************************************************************

With the forces of darkness once again at bay, life seems to have returned to 
normal – or as close to normal as it gets for high school idol and galactic 
savior Yuna Kagurazaka. But trouble is brewing! After an unfortunate encounter 
with her self-proclaimed rival Erika Kousaka, Yuna accidentally summons a 
planet-destroying warship, the "Eternal Princess," to Earth. Now Yuna, 
partnering with mysterious android girl Yuri Cube, has scant days to try to take 
out the beacons guiding the ship before it arrives and annihilates the Earth, 
all while battling the deadly assassins of the "Erika 7." Is there any hope for 
the planet!?

Ginga Ojousama Densetsu Yuna 2: Eien no Princess (Galaxy Fraulein Yuna 2: The 
Eternal Princess) is a 1995 adventure game/visual novel for the PC-Engine Super 
CD-ROM² system, developed by Red Company and Will and published by Hudson Soft. 
The sequel to the original Galaxy Fraulein Yuna, it mostly follows in its 
predecessor's footsteps on a larger budget, with bigger and better visuals, full 
voice acting, and much more polish all around. Compared to the first game, it 
drops most pretenses of interactivity in favor of basically being a low-res OVA 
that requires periodic button presses to watch, with the occasional battle or 
minigame to break things up. And there's sometimes dungeon crawling, for some 
reason?

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Known Issues
  IV.   Additional Features
  V.    Debug and Unused Stuff
  VI.   Authors' Comments
  VII.  Special Thanks
  VIII. Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image 
format it reasonably can. Though a Redump-verified disc image is a definite 
plus, options are provided to patch pretty much any image so long as it has the 
correct data track. If you don't have one of the Redump images, just go ahead 
and try to patch whatever you have using whichever of the options below applies 
to it.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

There are two known versions of this game: the FABT version and the FAAT 
version, distinguished by the last four characters of their disc mastering code. 
Curiously, these versions are actually identical save that the audio tracks are 
offset by exactly one sample between them. Don't ask me why. This patch is based 
on the FABT version, which appears to be more common, but an additional patch is 
provided for the FAAT version.

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches a verified 
"good" image as listed on Redump.org, and if all the tracks on the disc are 
combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches one of the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  FABT VERSION: http://redump.org/disc/32566/
    Redump name: Ginga Ojousama Densetsu Yuna 2: Eien no Princess
                 (mastering code "HCD5075   HRH750414-2FABT")
    CRC32:       a5eaf3d2
    MD5:         acb64430c3a5204ed5839d2364e31710
    SHA-1:       b6764a3e10dba73bf043bb327d4c4832c31dfa54

  FAAT VERSION: http://redump.org/disc/52124/
    Redump name: Ginga Ojousama Densetsu Yuna 2: Eien no Princess
                 (mastering code "HCD5075   HRH750414-2FAAT")
    CRC32:       7807f68e
    MD5:         cde2ceef0022a25348b9f1888b5d340b
    SHA-1:       74073958cd6560d6206c83786c457a41daa7b0d5

Consult the Redump links for full details.

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch files in the "redump_patch" folder. Pick the 
.xdelta file whose version label matches your disc: "[v1.1-fabt]" for the FABT 
version, or "[v1.1-faat]" for the FAAT version.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the 
appropriate patch to the BIN or IMG file. If you get an error, you'll need to 
try one of the other patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Ginga Ojousama Densetsu Yuna 2 EN [v1.1] Redump.cue". Rename your patched disc 
image so it has *exactly* the same name as the CUE, except with a .bin extension 
instead of .cue. Note that at this point, it doesn't matter which version you 
patched – the output disc image will always be the same, regardless of which 
version you started with.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc images, but splits them up into separate tracks instead of 
combining them into a single file. These are easily recognized by the presence 
of 23 separate BIN files and a single CUE.
  
  Before patching:
  
  - Make sure that your disc's CUE file has a name like "Ginga Ojousama Densetsu 
Yuna 2 - Eien no Princess (Japan) (FABT).cue" (for the FABT version) or "Ginga 
Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FAAT).cue" (for the FAAT 
version).
  
  - Make sure that the BIN files are named like this:
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
01).bin
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
02).bin
      …
      Ginga Ojousama Densetsu Yuna 2 - Eien no Princess (Japan) (FABT) (Track 
23).bin.
    If patching the FAAT version, the code at the end should of course be 
"(FAAT)" instead of "(FABT)".
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch_fabt.bat" (if patching the FABT 
version) or "binpatch_faat.bat" (if patching the FAAT version).
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match one of the Redump dumps, or you otherwise couldn't 
get method A to work, it may still be possible to patch it. If your disc is in 
BIN+CUE format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"yuna2.bin" and "yuna2.cue", or "yuna2.img" and "yuna2.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat". Note that unlike with 
the above methods, it doesn't matter if the disc is the FABT or FAAT version; 
there is only one patch for both.
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

** NOTE: This translation was developed and tested on the most recent stable 
release of Mednafen as of this writing, version 1.27.1. Overall, it has the most 
accurate PC-Engine emulation currently in existence…though it still has bugs 
that cause Yuna 2's opening scenes to display incorrectly in the unpatched game. 
The translation modifies it to ensure those issues don't happen, so I'd still 
recommend Mednafen over the competition.

If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up. Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

Additionally, make sure to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with the game not accepting input or pressing buttons on its 
own, check your emulator's settings.

                    ****************************************
                    *          III. Known Issues           *
                    ****************************************
  
  - While this isn't so much an "issue" as a design choice, the opening and 
ending credits have been left untranslated. Nobody expects the credits sequences 
from an actual anime to get an on-screen translation, and this game is trying as 
hard as it can to be an anime, so let's just give it what it wants and leave 
them as they are, huh? It's frankly not worth the trouble when 99% of players 
are just going to be looking at the song lyrics anyway. If you want to know who 
worked on the game, some very industrious people on MobyGames have the full 
credits already translated for you (albeit with some amusing errors like "Celica 
from the Bicycle Club" – that's "jidousha", not "jitensha"!).
  
  - Related to the above, there are a few minor display errors in the ending 
credits where graphics for the song subtitles conflict with the sprites for the 
credits text, causing bits of the latter to disappear. If I'd actually been 
translating the credits, I'd have moved these lines out of the way to prevent 
the issue…but I wasn't doing that, so I didn't bother. Sorry, but again, who's 
actually reading them anyway?
  
  - On rare occasion, skipping certain voice clips at certain times may cause 
small visual errors. The only instance of this that I know of is in Chapter 4; 
when Yuna is getting up after the ice beam, quickly skipping the voice clip 
before the animation finishes will make Yuna's face pop in before the rest of 
her body reaches the right position. (This can also occur without the patch by 
using debug mode.) Also, fast-forwarding with Button II during scenes that 
automatically advance the dialogue will make the text go out of sync with the 
audio, but don't blame me for that one – it's just how the game engine works.

                    ****************************************
                    *       IV. Additional Features        *
                    ****************************************

In addition to translating the game, this patch makes some small but important 
changes aimed at eliminating needless frustrations and annoying bugs:

  - Voiced lines and sound clips can now be skipped by default. Though the 
original game allows a limited form of this when debug mode is enabled, the 
translation expands on it: any time that the game is waiting for a voice clip or 
sound effect to finish playing, pressing Button I will immediately cut it off 
and move on. In battles, this can also be done by holding Button II. Note that 
this does not skip animations or text printing, so you'll still have to wait for 
those to finish before you can skip the sound.
  
  - Fast-forwarding text has been made less awkward. The original game 
fast-forwards when Button I is held. Since this is also the button to advance to 
the next text box, that sometimes makes it difficult to avoid fast-forwarding 
the text even when you're not trying to. To make things easier, the patch 
changes the controls to work the same way they did in the translation for the 
previous game: holding Button II fast-forwards, while pressing Button I advances 
to the next text box.
  
  - The original game had a nasty bug with the save menu. When prompted to save 
the game, choosing "Save" but then cancelling at the file select menu by 
pressing Button II erroneously left the RCR interrupt disabled. In practical 
terms, this means that if the save prompt was not immediately followed by a 
"widescreen" event, the display window would be completely blacked out, with the 
game only showing text, until one occurred. This has been fixed for the 
translation.
  
  - As mentioned in the previous section, in the unpatched game, Mednafen 
versions at least up through 1.27.1 have problems displaying some parts of the 
visual scenes. Specifically, the very first two scenes of the intro (the Hudson 
logo/distance shot of the fleet, and the following close-up of it) will both be 
completely blacked out, as will at least one later scene. Though this doesn't 
happen on real hardware, the translation modifies the game to prevent the issue 
from occurring as a convenience.

                    ****************************************
                    *      V. Debug and Unused Stuff       *
                    ****************************************

  Having had some years to refine their technique, Will did a much better job of 
organizing this game than the first, resulting in much less unused content on 
the disc (unfortunately for us). But there's still some interesting bits and 
bobs to be found, so I'll list what I know of here.

  +------------+
  | Debug Mode |
  +------------+

  This code was known long before I ever had anything to do with the game, but 
I'll list it here for reference (and because no one seems to have ever bothered 
to fully explain all the effects).

  On the title screen, press Up, Down, Right, Left, Button I, Button II, Up, 
Down, Right, Left, Button I, Button II. Then, press Run (don't hit any other 
buttons before pressing Run or the code will reset). You'll be taken to a "menu" 
to confirm that you're in debug mode; press Button I or II to clear it and 
return to the title screen. Fun fact: this was originally a real menu that gave 
you the option to turn voices on (音声あり) or off (音声なし) and set the game to debug 
mode or release mode (製品モード). For the final game, they removed everything except 
the debug mode option, leaving only the text behind.

  In any case, after returning to the title screen, start the game as normal and 
you'll be taken to a scenario select menu.

  When debug mode is on, the game will not force you to wait for voice clips to 
end before being able to advance to the next text box during the visual novel 
portions. You're also given the option before each battle and dungeon crawler 
segment to skip it. At predetermined points, you'll also be kicked to the 
scenario select menu, where you can either go on to the next scene 
chronologically or select a different one.

  Finally and perhaps most importantly, debug mode enables a bunch of debug 
features during battles:

  - Select + Run:         Empties your current character's health.
  - Select + Right/Left:  Moves the Mood Meter (the little flying Elner that
                          weights offense/defense for/against you) in the
                          corresponding direction.
  - Select + Down:        Restores a small amount of health to your current 
character.
  - Select + Up:          Makes the opponent's cards visible.
                          (Why wasn't this the default!?)
  - Select + Button II:   Sets all the opponent's cards to the same type.
                          Pressing this multiple times will cycle through the
                          different card types.
  - Select + Button I:    Sets all your cards to the same type.
                          Pressing this multiple times will cycle through the
                          different card types.

  +----------------------+
  | Primitive Debug Menu |
  +----------------------+
  
  Somewhat impressively for a game that isn't that complicated gameplay-wise, 
Yuna 2 actually has no less than *three* debug menus with overlapping 
functionality. Aside from the scenario select enabled by the above menu, there 
are two other debug menus that aren't accessible by any normal means.
  
  The more basic of these can be accessed by modifying the game's main data 
track (track 2). After converting to ISO, set the three bytes at offset 0x800 to 
the hexadecimal sequence "00 00 22". This will force the game to boot directly 
into the menu. (Incidentally, do this on the original game, not the translation 
– not only is the menu not translated, it's been overwritten with new resources, 
so trying this will just crash the game.)
  
  This menu is a standalone executable with a very barebones appearance, 
consisting of plain off-white text on a black screen. Proclaiming itself the 
"YUNA-2 DEBUG MODE", it lists some basic system information in the right column 
(System Card version, amount of main memory, and whether or not the Arcade Card 
is present – though this game doesn't actually use the Arcade Card for 
anything). The left column provides options to start any battle, watch any of 
the seven cutscenes, and play Star Bowl or Space Duck.
  
  The last option in the menu, and the only one not covered by the standard 
debug menu, is a somewhat mysterious "CD-DA Counter" (ＣＤ−ＤＡ　カウンター). When 
selected, the game will display a black screen and start playing CD audio track 
3, the audio for the first part of the opening cutscene. On this screen, each 
press of Button I will print the number of frames that have elapsed since the 
audio started. Pressing Run will exit, though the audio will continue playing.

  +-----------+
  | Test Menu |
  +-----------+
  
  The third debug menu is an in-game menu, like the standard one. It might have 
been intended to be accessed through the standard debug menu, but this isn't 
possible in the finished game.
  
  To replace the normal scenario select menu with this menu, go to offset 
0x173D02A in the ISO for track 2 and change the byte there from "5A" to "EC". 
(This will work in the translation too.) Then start the game, enter the debug 
code at the title screen as described above, confirm the debug mode prompt, and 
after being returned to the title screen, choose "Start". You'll be taken to a 
menu with eight options:
  
  - Maze Test (迷路テスト) – Allows you to choose one of two test layouts for the 
dungeon crawler segments and play it. Maze 1 uses the lunar ruins tileset, while 
Maze 2 uses the ruined battleship tileset. Both dungeons are completely empty; 
all you can do is wander around. The only way out is to reset.
  
  - Demo Test (デモテスト) – Allows you to view any of the seven visual scenes.
  
  - Battle Test First Half (バトルテスト前半) – Allows you to start any of the first 6 
battles.
  
  - Battle Test Second Half (バトルテスト後半) – Allows you to start any of the last 6 
battles.
  
  - Bonus (おまけ) – Automatically flashes through an endless loop of the exact 
slideshow featured on the bonus CD that was packed in with the 1995 rerelease of 
the original Galaxy Fraulein Yuna. Yeah, that's right, it's all in this game. 
But wait, there's more…
  
  - PSG Test (ＰＳＧテスト) – A series of dialogue boxes that play back various PSG 
sound effects while displaying their corresponding filenames. Not terribly 
interesting.
  
  - HuVIDEO (ＨＵＶＩＤＥＯ) – Plays back an FMV of the anime footage for the Yuna 1 
commercial…you know, the footage they stuck on a CD and used as an incentive to 
get people to buy the Yuna 1 rerelease? Yep, it's not just the slideshow – 100% 
of the content from the bonus CD is contained in Yuna 2 itself, just 
inaccessible. Real thoughtful, huh? The video is followed by an interactive 
version of the slideshow accessible above, though for some reason, many of the 
pictures have display errors where large chunks show up as black. Clicking 
through the whole thing will loop back to the video.

  +---------------+
  | Miscellaneous |
  +---------------+
  
  - During cutscene transitions, the game loads sprites for an animation of a 
ticking clock to the very end of video memory (not in the translation, though – 
I needed the space for other things). Presumably, this was going to be displayed 
when the game was loading data from the CD, but no such thing happens in the 
finished product.
  
  - The special "checkerboard" eyecatches in Chapter 3 that show tiled 
backgrounds of Yuna and Yuri/Polylina also load in an alternate version of the 
Yuna tile that shows her smiling, but never use it. Presumably, the idea was to 
have her smile after the other character is revealed.

                    ****************************************
                    *        VI. Authors' Comments         *
                    ****************************************
  
  ------------
  -- Supper --
  ------------
  
  Well, this happened. I've got regrets about the way I went about it, but it 
happened, and however it did, I'm glad the whole thing came together in the end.
  
  After the release of the Yuna 1 translation a few months back, I was busy with 
other things for a while. But one day, I happened to stumble across that game's 
kiosk demo, and had a fun afternoon modifying it to break out of the demo area 
so I could play the whole thing. (Guess I should probably release that as a 
patch sometime, huh?) That got me going on Yuna again, and I decided to get 
started on the translation for the sequel right away.
  
  That part's all fine and dandy. The problem is that I got extremely carried 
away with things and, after dumping the script, fully implementing script 
insertion, porting over the subtitle system from the first game, etc. etc., I 
proceeded to just start translating the game on my own. Which might have been 
okay except that I never told Mafoo about any of this, and didn't do so until 
I'd finished the entire script. At which point, very big OOPS! – it turned out 
he'd been working on translating it himself and I'd basically rendered all of 
that useless.
  
  So while it wasn't my intention to do anything underhanded, I owe Mafoo a lot 
of apologies for not being forward enough about things, and a lot of gratitude 
for the fact that he was still willing to help out with the project after that 
fiasco. Having his partial translation to compare against helped me fix no small 
number of errors I'd made in mine, and brought the whole thing to a much higher 
level than it would have been otherwise. It's also Mafoo who provided the lyrics 
to the insert song "Gomen Ne", which I didn't have and originally thought I was 
just going to have to leave blank. So while neither of the phrases suffices for 
conveying the depth of my feelings, they're all I can say: I'm sorry, and thank 
you.
  
  So, with that mess out of the way, let's talk about the actual game!
  
  From a technical perspective, Yuna 2 was both easier and harder to work with 
than Yuna 1. It eliminates the use of multiple executables with redundant code, 
i.e. there's now a single unified cutscene player instead of having 50 cutscenes 
that are each their own self-contained program, which greatly simplifies the 
hacking process. But the game also uses CD audio tracks for cutscenes instead of 
ADPCM clips, which among other things meant the subtitle code had to be modified 
to make it possible to switch subtitles in the middle of loading transitions. 
Though the subtitles are visually identical to the previous game, the actual 
integration into the game engine is very different, and it took some doing to 
get it all to work right.
  
  The developers also took note of the issue from Yuna 1 where printing text 
would cause animations to lag or stall entirely, and took measures to prevent it 
with Yuna 2. Unfortunately, part of their strategy was to cap the maximum 
printing speed at one character per frame, which caused problems when I needed 
to double it to keep it from being too slow with the increased number of 
characters in the translation. In the end, I had to partially redo the printing 
system to avoid needless VRAM readbacks, which were badly throttling 
performance, just to allow this to happen. Felt pretty good, though.
  
  On the translation side of things, this game was actually a lot easier than 
Yuna 1. The script is considerably shorter due in part to the near-total absence 
of narration – it's something like two-thirds to three-fourths the size, I think 
– and it has far fewer voice-only scenes, which are the most painful part to 
deal with. The script itself is mostly straightforward comedy material that 
isn't too taxing even for me…though there were some curveballs in there, like 
the fancy-dancy space battle full of military terminology at the start, or Yuri 
suddenly spouting off some weird prophecy written in classical Japanese. Fun. 
Big thanks to TheMajinZenki for checking the script over for me and catching 
some things I never would have (fun fact: I had no idea what "Armani" was).
  
  Overall, it wasn't an easy project by any stretch of the imagination, but with 
a reasonably solid foundation from the previous game to build off of for both 
the hacking and the translation, I was able to hammer this one out pretty 
quickly.
  
  One more time, my apologies and my eternal thanks to Mafoo for enduring my 
idiocy. I don't know if I'll be doing more Yuna in the future or not, but I've 
really enjoyed working on the series so far. Hope you'll all get a kick out of 
this one.
  
  P.S. Don't bother trying to beat Star Bowl or Space Duck. There are no win 
conditions. Yeah, I really don't know what the point was supposed to be.
  
  --------------
  -- Mafoo343 --
  --------------
  
  Well, this all came together a lot sooner than I expected. Originally I was 
planning to handle the translation for Yuna 2 myself, but it looks like Supper 
got so pumped up for the sequel that before he knew it, he ended up completing 
work for the whole game at breakneck speed. Serious props to him, I wish I could 
work that fast. Even though this didn’t go down the way I expected it, I’m glad 
I still got the chance to help out here and there at least a little bit. I had 
fun working on this and I hope you enjoy :)

                    ****************************************
                    *         VII. Special Thanks          *
                    ****************************************

Thanks to the members of LIPEMCO! Translations (other than that selfish jerk 
Supper) for their support throughout development and assistance in testing the 
translation.

Thanks to Yerna…I mean, Elner…I mean, elmer for providing resources and 
documentation for the PC-Engine that were very extensively referenced during the 
production of this patch, and for the special bugfixed Windows binary of bchunk 
that's used in the patching process.

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *        VIII. Version History         *
                    ****************************************

v1.0 (18 Dec 2021): Initial release.

v1.1 (08 May 2023): Update to coincide with the release of the Yuna 3 
translation. This game was my first time doing a translation alone, so I guess 
it's not terribly surprising that, upon replaying the game in Japanese and 
scrutinizing my work more carefully, it turns out I screwed some things up. I 
thought I'd just be editing a few lines, but ended up with quite a list of 
corrections...Honestly, in retrospect, I probably should have done another pass 
over the translation before the initial release. Oh well, all I can do is fix it 
now.

This update makes the following translation fixes:

  - Intro: "What happened!?" -> "I got fat!". You know, between the sci-fi 
warfare technobabble, the blaring music, the constant background sound effects, 
and, just to cap it all off, Yuna mumbling nonsense in her sleep at the end, 
this game's intro is pretty much the opposite of what you want to be the very 
first thing you encounter for your very first solo translation project. After 
carefully going over everything again, though, I think I actually got most of it 
right on the first go-around, though I did make this correction to Yuna's 
mumbles at the end. I still can't swear to some of what she's saying because it 
borders on unintelligibility, but this line is definitely more correct than it 
was.

  - Newscaster: "Kousaka High-Class Girls Academy" -> "Kousaka Girls Academy". 
The full name of the school is 香坂女子高等学園, literally "Kousaka Girls High [School] 
Academy". The 高等 part of the name is just saying it's a high school, not that 
it's a high-class school (though it would certainly fit, given who we're talking 
about -- surely you can understand how I got tripped up here!). It's hard to 
make "high school" work in the same name as "academy" in English, so I've 
ultimately just dropped it for the translation, which is actually what the 
original text does in all but the first instance anyway.

  - Yuna in first battle: "Why are you saying that!?" -> "How could you say 
that!?". Original translation was overly literal for the context.
  
  - Yuna: "But you just said they were!" -> "But you just called them that, 
didn't you!?". More accurate to the original text and to the events that 
actually occurred.
  
  - Yuri: "I was assigned the role of controller of the solar system's beacon" 
-> "I held the duty of managing the solar system's beacon". More accurate (I'm 
not sure where I pulled "assigned" from) and sounds less clunky.
  
  - Yuri: "Well...It was a very long time ago..." -> "No...It was a very long 
time ago...". I intially took Yuri's ええ as an expression of confusion, but it's 
pretty clearly an affirmation to Yuna's question "You don't remember?".

  - Mami: "I'm the first assassin of the Erika 7" -> "I'm the top assassin of 
the Erika 7". The word that's been translated differently is 第一, which can mean 
either "first" or "best/foremost"; I interpreted it in the former sense when 
initially working on this game, since she's the first of the Erika 7 that you 
fight, but in Yuna 3, the exact same term is used in situations where it clearly 
has the latter meaning, so I decided it's probably meant the same way here.
  
  - Yuna: "That's right―those girls who were standing behind Erika!" -> "Now 
that I think about it, you're one of the girls who was behind Erika earlier!". A 
more likely interpretation of the line.
  
  - Elner: "While this Eternal Princess business is regrettable, you must 
resolve it" -> "Regrettably, you must resolve this Eternal Princess business". 
Overly literal reading of the original text.
  
  - Yuna: "It's a game where you hit stereoscopic monsters with a ball!" -> 
"It's a game where you take down holographic monsters with a ball!". 立体映像 is 
conventionally used to mean "hologram", a fact I wasn't aware of at the time 
(though it really should have been obvious from the visuals), and やっつける means 
"defeat" far more than it implies "hit".
  
  - Yuna: "Try to avoid eye contact!" -> "I'm gonna try to avoid eye contact..." 
Misunderstood this as an imperative sentence.
  
  - All instances of the names of Polylina's signature attacks "Bakkin Bou" and 
"Bakkin Byuu", which were originally just quasi-transliterated as "Back-In Bo" 
and "Back-In Byu", are now "Penalty Staff" and "Penalty Lash" respectively. It 
wasn't readily apparent from anything in the game or manual what the names were 
supposed to mean, but while working on Yuna 3, I noticed a scrawled note in the 
margins of a piece of early Polylina concept art that appears in the 1999 Yuna 
artbook: 「イイ子にしないとバッキンよ！」のかけ声で悪人を次々と倒していくぞ！！ "With a cry of 'If you don't behave 
yourself, there will be a bakkin [fine/penalty]!' she takes down bad guys one 
after another!!" The "penalty" bit of this seems to be parodying Sailor Moon's 
famous "oshioki yo" ("I'll punish you") catchphrase. So with that in mind, we 
can actually do something sensible with her attack names.
  
  - Rui: "You, at least, will fall by my hand!" -> "You, I'll take down by my 
own hand!". You could go various ways with the あなただけは subject for this sentence, 
but "at least" probably isn't the right one.
  
  - Rui: "Every player's got to rest sometimes!" -> "Getting ejected's just part 
of being a star player!". Ouch. On top of misreading 名プレイヤー (star player) as 
各プレイヤー (each player), I didn't realize 退場 is the Japanese term for a soccer 
player getting sent off (e.g. due to a red card). I really should've known 
something was up with this one, but didn't even have it flagged as a line to 
double-check.
  
  - Yuri: "trinary star system" -> "tri-planet system". Several people more 
scientifically-minded than I am observed that a system with three planets is 
very much NOT a "trinary star system". Sorry, I always went more for fantasy 
novels than sci-fi as a kid...
  
  - Yuna: "Aaaagh...Let's just get this warp over with!" -> "Aaaagh! We have to 
warp RIGHT NOW!" I thought this was making a reference to Yuna's repeated warp 
sickness in the first game, but looking at it again, she's pretty clearly just 
in a panicked rush.
  
  - Yuna: "Daddy" -> "Papa". Not sure why I didn't use "Papa" to begin with 
here, since that's what she says in the original text and I didn't change it in 
any other instance.
  
  - Yuri: "But me not eating will not change the remaining time" -> "But time 
will still pass even if I stop eating". More accurate and sounds better IMO.
  
  - Yuna: "If it works, we'll have a giant feast!" -> "If it works, dinner's on 
me!" I wasn't familiar with the "treat to a meal" meaning of ごちそう at the time, 
which is clearly what Yuna means here. (If you want to be a stickler, she's 
merely promising her a "meal" or "food" rather than "dinner" specifically, but 
that would sound pretty stilted in English.)
  
  - Celica: "My, my! A little slow on the draw, aren't we?" -> "Hey, hey! Better 
get your rear in gear!". Not only did I misread おら as あら, I didn't realize んじゃねー 
was imperative, AND somehow managed to completely forget about the obvious slang 
tone of the line when I went to translate it. Yikes.
  
  - Security guard: "Don't let her get away! Get ready!" -> "We won't let you 
get away! Better get ready!". Got in a hurry and misread the first sentence as 
an imperative.
  
  - Miki: "I'm a pretty lady...and YOU are a B-R-U-T-E!" -> "If I'm 
'beauty'...then I guess YOU'RE the 'beast'!". A reference I didn't pick up on 
the first time around.
  
  - Shiori: "I will be here...for another whole...month..." -> "I have been 
here...for a whole...month...". One of those idiomatic things you just have to 
know: Despite the sentence being literally phrased in the non-past tense 
(あたしは〜もう１カ月も〜〜いるんです), this formulation is used to indicate time which has 
already passed ("I am here for a month" = I've been here a month). If you don't 
know that, it sure looks like it means what I originally wrote, though!
  
  - Yuri: "Were you able to clear the hot spring?" -> "You able to clear the hot 
spring, were you not?" It's got a でしょ, so she's assuming the answer is "yes".
  
  - Midori: "Laugh while you still can! Go ahead and get this memorized!" -> 
"Your mirth will last but a moment! Remember you this!". More probable 
interpretation of the line.
  
  - Yuna: "I'm OUTTA here" -> "I've got NO idea". Wasn't really a sensible 
translation for ぜーんぜん.
  
  - Ryudia: "It's a rogue warrior" -> "It's just a berserker". Didn't know what 
a 狂戦士 was and managed to miss 単なる while I was at it.
  
  - Erika: "But you, at least, I will dispose of" -> "But you, I will dispose 
of". Same change as with Rui's line that uses あなただけは.
  
  - El-Line transformation: "Back up" -> "Light up". Okay, yeah, this one's just 
stupid and I'm sure some people got a laugh out of it. In fact, I'm quite 
surprised no one said anything to me about it. Does no one care about Yuna 
anymore? (Don't answer that.) On the one hand, I don't feel so bad about 
flubbing this because it's legitimately hard to understand it in this game, 
where five people are chanting it in unison. On the other hand...the same phrase 
is used in all the OVAs and the third game, and I'd easily have found that out 
if I'd done the slightest research. Sorry.
  
  - Yuna: "I'll turn you into scrap metal" -> "I'll take you out in one shot". 
On listening to the audio again, this line is quite clearly 一気にいっちゃうもんね and not 
whatever crazy thing I made up about 浮き荷. Sometimes I amaze even myself with 
these screw-ups.
  
  - Yuna: "It looks like the passage leads up to that person" -> "It looks like 
the passage leads further in". Far more likely interpretation.
  
  - Lia: "Awfully absent-minded, aren't you!?" -> "Time to quit spacing out!". 
Same misinterpretation of んじゃない as with Celica's line above.
  
  - Mirage: "You shall all burn to ash!" -> "Be burnt to naught but ashes!". 
Imperative sentence.
  
  - Mirage: "Like the planets which met their demise, die now a noble death in 
vain" -> "Like the planets to their demise, fleetingly scatter and vanish". I 
hadn't seen はかなく散る before and couldn't make sense of it; some more thorough 
research shows that it's a phrase often used to characterize the ephemeral 
nature of things like flowers or fireworks. Not to mention I sloppily ignored 
the tense of the first clause.
  
  - Yuna: "That's right! Everybody, anyone, can become my friend...If they'll be 
honest with me, anybody can be my friend! That's right...even you!" -> "That's 
right! Everybody, anyone, can become friends...If they're honest with each 
other, anybody can be friends! Yes...even with you!". This is almost certainly 
meant to be a general statement rather than applying solely to Yuna (Yuna is 
more explicit about her highly optimistic philosophy in other works).
  
  - Mirage: "Your...friend?" -> "Friends...with me?". Changed to match the 
above.
  
  - Mirage: "suppress the people's strife" -> "prevent the people's strife". The 
original wording made this come off as more sinister than intended -- it's 
supposed to sound like a good thing.
  
  - Mirage: "And the one who brought their destruction was..." -> "And what was 
destroyed was...". Probably my most significant goof. The original phrase here 
is 「そして　滅んだのが…」. I got confused because this isn't a complete sentence, and it's 
not fully clear even with context what it's trying to express. I thought it was 
implicating Mirage in the destruction of the society that created her, but 滅ぶ is 
intransitive, which means that's simply not a valid interpretation. In the end, 
I can't tell you for sure what this is actually saying because it's so vaguely 
phrased -- most likely it's Mirage emotionally reflecting on the fact that "the 
people who created me perfished" -- but in any case, it absolutely doesn't mean 
what I originally wrote.
  
  - Mirage: "I lost myself" -> "I lost sight of myself". I'm not sure if I 
misread the original line or if this was a deliberate edit, but either way, I've 
decided I don't like it.
  
  - Yuna: "What was the Eternal Princess...?" -> "What was the Eternal Princess, 
I wonder...?". Self-directed question with かな; I don't think she's actually 
asking anyone for an answer, which was what the original translation made it 
sound like.
  
  - Several fixes to the final scene:
    Yuna: "Looks like we made it in the nick of time" -> "Looks like we somehow 
made it in time"
    Mai: "I want you to give me more of a, like, starring role here" -> "Give me 
more of a, like, starring role like these guys"
    Elner: "The curtain falls on another adventure" -> "Now the admirers are 
just lining right up"
    Yuna: "I want to be able to come to school　normally" -> "I want to live 
normally"
    The last two lines there are particularly egregious, you'll note. I listened 
to them probably a hundred times each, but for the life of me couldn't make any 
sense out of some of the words. I finally gave up in frustration and shamefully 
went with something that I was pretty sure were wrong but at least resembled 
what I could hear, because however stupid it was, I wasn't going to cancel the 
whole project over not being able to make out two lines at the very end. 
Eventually, I found a transcription of the scene by a native Japanese speaker 
which supplied the missing content. My very grateful acknowledgements to ジーク for 
the unintended save: https://w.atwiki.jp/opedmiroor/pages/616.html
