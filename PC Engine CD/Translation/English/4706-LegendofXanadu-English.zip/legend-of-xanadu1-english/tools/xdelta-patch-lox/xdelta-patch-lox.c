// ****************************************************************************
// ****************************************************************************
//
// xdelta-patch-lox1 / xdelta-patch-lox2
//
// Patching progam for both PC Engine "Kaze no Densetsu Xanadu" English Translations.
//
// Copyright 2015-2026 John Brandwood.
//
//  Distributed under the Apache Public License version 2.0.
//  (See accompanying file "LICENSE.txt" or the copy at
//    http://www.apache.org/licenses/LICENSE-2.0)
//
// This program applies the xdelta3 code and data patches which insert the new font
// and subtitling code and data into a copy of the game's ISO image.
//
// The game's data files are decompressed before patching, and recompressed again
// afterwards in a different and more-efficient format in order to free up memory
// for the extra code and data that the translation needs to run.
//
// This patching program absolutely requires images of the original game CDs
// that are made to the REDUMP Disc Preservation Project standards, and have
// the identical MD5 checksums to the REDUMP ones for each track!
//
//   Legend of Xanadu: Kaze no Densetsu Xanadu
//   http://redump.info/disc/36269/
// 
//   Legend of Xanadu: Kaze no Densetsu Xanadu II
//   http://redump.info/disc/36270/
//

#include "xdelta3/xdelta3.h"
#include "elmer.h"

#ifndef _WIN32
#include <strings.h>
#endif

#define REMOVE_SRCTRACK     1
#define PATCHED_DIRECTORY   0



// ****************************************************************************
// ****************************************************************************
//
// Structure for defining META_BLOCK locations on the CD. 
//

// struct meta_block_location;

typedef struct meta_block_location
{
  const char *     m_pDirectoryName;
  uint32_t         m_uMetaBlock1st;
  uint32_t         m_uMetaBlockEnd;
  uint32_t         m_uMetaBlockMax;
  uint32_t         m_uMetaStartAdd;
  uint32_t         m_uDataChunkCnt;
#if !IS_XANADU1
  uint32_t         m_uPauseMenuChunk;
#endif
} META_BLOCK_LOCATION;



#if IS_XANADU1

// ****************************************************************************
// ****************************************************************************
//
// XANADU 1 META_BLOCK locations on the CD.
//

  META_BLOCK_LOCATION aMetaBlocks [] =
  {
    { "z00", 0x00027800, 0x00033e25, 0x38000,      0,  20 },
    { "z01", 0x00061800, 0x00079aac, 0x38000,      0,  38 },
    { "z02", 0x0009b800, 0x000b18bd, 0x38000, 0x2000,  31 },
    { "z03", 0x00d53800, 0x00d89677, 0x38000,      0,  88 },
    { "a03", 0x00d8b800, 0x00d953ae, 0x10000,      0,  15 },
    { "z04", 0x00d9d800, 0x00dccc5e, 0x38000, 0x2000,  91 },
    { "a04", 0x00dd5800, 0x00ddf32e, 0x10000,      0,  15 },
    { "z05", 0x01ab7800, 0x01ae7137, 0x38000, 0x2000,  79 },
    { "a05", 0x01aef800, 0x01afb405, 0x10000,      0,  16 },
    { "z06", 0x01b01800, 0x01b0ddb9, 0x38000,      0,  17 },
    { "a06", 0x01b39800, 0x01b4332e, 0x10000,      0,  15 },

    { "z10", 0x000d9800, 0x00101222, 0x2C000,      0,  71 },
    { "z11", 0x00105800, 0x0012a555, 0x2C000,      0,  69 },
    { "z12", 0x00131800, 0x0015d6a2, 0x2C000,      0,  85 },
    { "z13", 0x0015d800, 0x00188e34, 0x2C000,      0,  83 },
    { "z14", 0x00189800, 0x001b2ca2, 0x2C000,      0,  76 },
    { "z15", 0x001b5800, 0x001e06d2, 0x2C000,      0,  78 },
    { "z16", 0x001e1800, 0x0020b1b5, 0x2C000,      0,  80 },
    { "z17", 0x0020d800, 0x002395c4, 0x2C000,      0,  79 },
    { "z18", 0x00239800, 0x00260dfc, 0x2C000,      0,  67 },
    { "z19", 0x00265800, 0x002911b6, 0x2C000,      0,  84 },
    { "z1a", 0x00291800, 0x002b2346, 0x2C000,      0,  60 },
    { "z1b", 0x002bd800, 0x002e8ed9, 0x2C000,      0, 102 },

    { "z20", 0x0089b800, 0x008d3455, 0x20000, 0x2000,  91 },
    { "a20", 0x008d3800, 0x008e3085, 0x10000,      0,  29 },
    { "z21", 0x008e5800, 0x008f4ff9, 0x38000, 0x2000,  32 },
    { "z22", 0x00a5f800, 0x00a6d6d0, 0x38000, 0x2000,  28 },
    { "z23", 0x00b99800, 0x00baf2a5, 0x38000, 0x2000,  41 },
    { "z24", 0x00de7800, 0x00dfa953, 0x38000, 0x2000,  44 },
    { "z25", 0x00fe1800, 0x00ff3a2a, 0x38000, 0x2000,  36 },
    { "z26", 0x0115b800, 0x0116da1f, 0x38000, 0x2000,  36 },
    { "z27", 0x01315800, 0x0133054a, 0x38000, 0x2000,  52 },
    { "z28", 0x014cf800, 0x014f4072, 0x38000, 0x2000,  84 },
    { "z29", 0x017c9800, 0x017d9ce0, 0x38000, 0x2000,  32 },
    { "z2a", 0x01943800, 0x01953988, 0x38000, 0x2000,  36 },
    { "z2b", 0x01a7d800, 0x01aa3d0e, 0x38000, 0x2000,  77 },

    { "z30", 0x002ef800, 0x0030f51d, 0x26000,      0,  58 },
    { "z31", 0x0036d800, 0x00385478, 0x26000,      0,  43 },
    { "z32", 0x003cf800, 0x003f2e1f, 0x26000,      0,  65 },
    { "z33", 0x00485800, 0x0049ef04, 0x26000,      0,  46 },
    { "z34", 0x004e7800, 0x00502ba6, 0x26000,      0,  60 },
    { "z35", 0x00551800, 0x0057072c, 0x26000,      0,  63 },
    { "z36", 0x005d3800, 0x005f9009, 0x26000,      0,  75 },
    { "z37", 0x00639800, 0x0065ca93, 0x26000,      0,  64 },
    { "z38", 0x006a3800, 0x006c6e58, 0x26000,      0,  66 },
    { "z39", 0x00711800, 0x0072dcf6, 0x26000,      0,  59 },
    { "z3a", 0x00757800, 0x00776403, 0x26000,      0,  57 },
    { "z3b", 0x0080d800, 0x008336d5, 0x26000,      0,  80 },
    { "z3c", 0x00853800, 0x00877110, 0x26000,      0,  63 },

    { NULL, 0, 0, 0, 0, 0 }
  };

#else

#endif



#if defined (_WIN32)

// ****************************************************************************
// ****************************************************************************
//
// Structure for memory-mapped file.
//

typedef struct {
  uint8_t *    m_pViewAddr;
  size_t       m_uViewSize;
  const char * m_pFileName;
  HANDLE       m_hFileHnd;
  HANDLE       m_hFileMap;
} MAPPEDFILE_T;



// **************************************************************************
// **************************************************************************
//
// CloseMemoryMappedFile() - Close a memory-mapped file.
//
// WINDOWS version.
//

bool CloseMemoryMappedFile (
  MAPPEDFILE_T *pMapping )

{
  if (pMapping->m_pViewAddr) {
    FlushViewOfFile(pMapping->m_pViewAddr, 0);
  }
  if (pMapping->m_pViewAddr) {
    UnmapViewOfFile(pMapping->m_pViewAddr);
  }
  if (pMapping->m_hFileMap) {
    CloseHandle(pMapping->m_hFileMap);
  }
  if (pMapping->m_hFileHnd) {
    CloseHandle(pMapping->m_hFileHnd);
  }

  pMapping->m_pFileName = NULL;
  pMapping->m_pViewAddr = NULL;
  pMapping->m_uViewSize = 0;
  pMapping->m_hFileMap = NULL;
  pMapping->m_hFileHnd = NULL;

  return (true);
}



// **************************************************************************
// **************************************************************************
//
// OpenMemoryMappedFile() - Open a memory-mapped file.
//
// WINDOWS version.
//

bool OpenMemoryMappedFile (
  MAPPEDFILE_T *pMapping, const char *pName, bool bReadOnly )

{
  int           iErrorCode = -1;
  DWORD         uOpnFileMode;
  DWORD         uMapFileMode;
  DWORD         uMapViewMode;
  LARGE_INTEGER cFileSize;

  // Make sure that any existing file is closed.

  CloseMemoryMappedFile(pMapping);

  //

  uOpnFileMode = (bReadOnly) ? (GENERIC_READ) : (GENERIC_READ | GENERIC_WRITE);
  uMapFileMode = (bReadOnly) ? (PAGE_READONLY) : (PAGE_READWRITE);
  uMapViewMode = (bReadOnly) ? (FILE_MAP_READ) : (FILE_MAP_WRITE);

  pMapping->m_pFileName = pName;

  printf("Processing file \"%s\".\n\n", pMapping->m_pFileName);

  pMapping->m_hFileHnd = CreateFile(pMapping->m_pFileName,
            uOpnFileMode, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

  if (pMapping->m_hFileHnd == INVALID_HANDLE_VALUE) {
    iErrorCode = GetLastError();
    printf("Unable to open file for reading!\n\n");
    goto errorExit;
  }

  if (GetFileSizeEx(pMapping->m_hFileHnd, &cFileSize) == 0) {
    iErrorCode = GetLastError();
    printf("Unable to find size of file!\n\n");
    goto errorExit;
  }

  if (cFileSize.HighPart != 0 || cFileSize.LowPart == 0) {
    printf("File has a bad file size! (Must be > 0 and < 4GB.)\n\n");
    goto errorExit;
  }

  pMapping->m_hFileMap = CreateFileMapping(pMapping->m_hFileHnd, NULL, uMapFileMode, 0, 0, NULL);

  if (pMapping->m_hFileMap == NULL) {
    iErrorCode = GetLastError();
    printf("Windows error %d!\n\n", iErrorCode);
    goto errorExit;
  }

  pMapping->m_pViewAddr = (uint8_t *)MapViewOfFile(pMapping->m_hFileMap, uMapViewMode, 0, 0, 0);

  if (pMapping->m_pViewAddr == NULL) {
    iErrorCode = GetLastError();
    goto errorExit;
  }

  pMapping->m_uViewSize = cFileSize.LowPart;

  return (true);

  //

errorExit:

  CloseMemoryMappedFile(pMapping);

  return (false);
}



// **************************************************************************
// **************************************************************************
//
// FileExists() - Check if a file exists and is a regular file.
//
// WINDOWS version.
//

bool FileExists (
  const char *pName )

{
  struct __stat64 cStat;

  return ((_stat64(pName, &cStat) == 0) && (S_ISREG(cStat.st_mode)));
}



#else // Linux or macOS

// ****************************************************************************
// ****************************************************************************
//
// Structure for memory-mapped file.
//

#include <errno.h>
#include <sys/mman.h>

typedef struct {
  uint8_t *    m_pViewAddr;
  size_t       m_uViewSize;
  const char * m_pFileName;
  int          m_hFile;
} MAPPEDFILE_T;



// **************************************************************************
// **************************************************************************
//
// CloseMemoryMappedFile() - Close a memory-mapped file.
//
// POSIX version.
//

bool CloseMemoryMappedFile (
  MAPPEDFILE_T *pMapping )

{
  if (pMapping->m_pViewAddr) {
    msync(pMapping->m_pViewAddr, pMapping->m_uViewSize, MS_ASYNC);
  }
  if (pMapping->m_pViewAddr) {
    munmap(pMapping->m_pViewAddr, pMapping->m_uViewSize);
  }
  if (pMapping->m_hFile > 0) {
    close(pMapping->m_hFile);
  }

  pMapping->m_pFileName = NULL;
  pMapping->m_pViewAddr = NULL;
  pMapping->m_uViewSize = 0;
  pMapping->m_hFile = -1;

  return (true);
}



// **************************************************************************
// **************************************************************************
//
// OpenMemoryMappedFile() - Open a memory-mapped file.
//
// POSIX version.
//

bool OpenMemoryMappedFile (
  MAPPEDFILE_T *pMapping, const char *pName, bool bReadOnly )

{
  struct stat   cStat;
  int           iErrorCode = -1;
  int           iMode;

  // Make sure that any existing file is closed.

  CloseMemoryMappedFile(pMapping);

  //

  pMapping->m_pFileName = pName;

  iMode = (bReadOnly) ? (O_RDONLY) : (O_RDWR);

  pMapping->m_hFile = open(pName, O_BINARY | iMode);

  if (pMapping->m_hFile == -1) {
    iErrorCode = errno;
    printf("Unable to open file for reading!\n\n");
    goto errorExit;
  }

  if ((fstat(pMapping->m_hFile, &cStat) != 0) || (!S_ISREG(cStat.st_mode))) {
    iErrorCode = errno;
    printf("Unable to find size of file!\n\n");
    goto errorExit;
  }

  if (cStat.st_size > SSIZE_MAX) {
    printf("File has a bad file size! (Must be > 0 and < 4GB.)\n");
    goto errorExit;
  }

  pMapping->m_uViewSize = cStat.st_size;

  iMode = (bReadOnly) ? (PROT_READ) : (PROT_READ | PROT_WRITE);

  pMapping->m_pViewAddr = mmap(NULL, pMapping->m_uViewSize, iMode, MAP_SHARED, pMapping->m_hFile, 0);

  if (pMapping->m_pViewAddr == MAP_FAILED) {
    pMapping->m_pViewAddr = NULL;
    iErrorCode = errno;
    goto errorExit;
  }

  return (true);

  //

errorExit:

  CloseMemoryMappedFile(pMapping);

  return (false);
}



// **************************************************************************
// **************************************************************************
//
// FileExists() - Check if a file exists and is a regular file.
//
// POSIX version.
//

bool FileExists (
  const char *pName )

{
  struct stat   cStat;

  return ((stat(pName, &cStat) == 0) && (S_ISREG(cStat.st_mode)));
}

#endif



// ****************************************************************************
// ****************************************************************************
//
// read_binary_file() - Patch binary data from a file.
//

bool read_binary_file( const char * pBinaryName, uint8_t ** ppBuffer, unsigned * puLength )
{
  FILE *        pBinaryFile = NULL;
  uint32_t      uBinarySize = 0;

  uint8_t *     pBinaryBuff = NULL;

  // Load up the data file into memory.

  pBinaryFile = fopen(pBinaryName, "rb");

  if (pBinaryFile == NULL)
  {
    printf("Unable to open binary file \"%s\"!\nAborting!\n",
      pBinaryName);
    goto errorExit;
  }

  fseek(pBinaryFile, 0, SEEK_END);
  uBinarySize = ftell(pBinaryFile);
  fseek(pBinaryFile, 0, SEEK_SET);

  pBinaryBuff = (uint8_t *) malloc(uBinarySize);

  if (uBinarySize != fread(pBinaryBuff, 1, uBinarySize, pBinaryFile))
  {
    printf("Unable to read binary file \"%s\"!\nAborting!\n",
      pBinaryName);
    goto errorExit;
  }

  fclose(pBinaryFile);
  pBinaryFile = NULL;

  // Return successful.

  *ppBuffer = pBinaryBuff;
  *puLength = uBinarySize;

  return true;

  // Handle errors.

  errorExit:

  if (pBinaryBuff) free(pBinaryBuff);
  if (pBinaryFile) fclose(pBinaryFile);

  *ppBuffer = NULL;
  *puLength = 0;

  return false;
}



// ****************************************************************************
// ****************************************************************************
//
// DecompressOldFalcom() - Decompress a block in Falcom's Xanadu II OLD_FORMAT.
//
// Command $00     (+0) : STOP ... All Done!
//      params          : -
//
// Command $01-$1f (+0) : Copy ($01..$1f) bytes from file to output
//      params          : -
//
// Command $20-$3f (+1) : Copy ($0000..$1fff) bytes from file to output
//      params          : count-lo
//
// Command $40-$4f (+1) : Fill ($00..$0f + 4) bytes with value
//      params          : value
//
// Command $50-$5f (+2) : Fill ($0000..$0fff + 4) bytes with value
//      params          : count-lo, value
//
// Command $60-$7f (+0) : Copy ($01..$1f, or 256) more bytes from earlier
//      params          : -
//
// Command $80-$9f (+1) : Copy 4 bytes from earlier in output (offset $0000-$1fff)
//      params          : offset-lo
//
// Command $a0-$bf (+1) : Copy 5 bytes from earlier in output (offset $0000-$1fff)
//      params          : offset-lo
//
// Command $c0-$df (+1) : Copy 6 bytes from earlier in output (offset $0000-$1fff)
//      params          : offset-lo
//
// Command $e0-$ff (+1) : Copy 7 bytes from earlier in output (offset $0000-$1fff)
//      params          : offset-lo

uint8_t * DecompressOldFalcom ( uint8_t * pInput, uint8_t * pOutput, uint8_t * pInputEnd )
{
  uint8_t * pWindow;
  unsigned  uOffset;
  unsigned  uLength;
  unsigned  uCommand;
  uint8_t   uByte;

  uint8_t * pStarts = pOutput;

  while ((uCommand = *pInput++) != 0x00)
  {
    // Sanity Check!

    if (pInput > pInputEnd)
    {
      printf( "The compressed data is corrupt!\n" );
      break;
    }

    //

    switch (uCommand & 0xf0)
    {
      case  0x00:
      case  0x10:
      {
        uLength = (uCommand & 0x1f);

        while (uLength--)
        {
          *pOutput++ = *pInput++;
        }
        break;
      }

      case  0x20:
      case  0x30:
      {
        uLength = ((uCommand & 0x1f) << 8) + *pInput++;

        while (uLength--)
        {
          *pOutput++ = *pInput++;
        }
        break;
      }

      case  0x40:
      {
        uLength = (uCommand & 0x0f) + 4;
        uByte   = *pInput++;
        while (uLength--)
        {
          *pOutput++ = uByte;
        }
        break;
      }

      case  0x50:
      {
        uLength = ((uCommand & 0x0f) << 8) + *pInput++ + 4;
        uByte   = *pInput++;
        while (uLength--)
        {
          *pOutput++ = uByte;
        }
        break;
      }

      case  0x60:
      case  0x70:
      {
        uLength = (uCommand & 0x1f);

        if (uLength == 0)
        {
          printf( "!!!Warning!!! Found OLD_FORMAT code $60, check this!\n" );
          uLength = 256;
        }

        while (uLength--)
        {
          *pOutput++ = *pWindow++;
        }
        break;
      }

      case  0x80:
      case  0x90:
      case  0xA0:
      case  0xB0:
      case  0xC0:
      case  0xD0:
      case  0xE0:
      case  0xF0:
      {
        uLength = ((uCommand >> 5) & 3) + 4;
        uOffset = ((uCommand & 0x1f) << 8) + *pInput++;

        pWindow = pOutput - uOffset;
        while (uLength--)
        {
          *pOutput++ = *pWindow++;
        }
        break;
      }
    }
  }

  return pOutput;
}



// ****************************************************************************
// ****************************************************************************
//
// DecompressNewFalcom() - Decompress a block in Falcom's Xanadu II NEW_FORMAT.
//
// This is basically the next step beyond a traditional 4/12 LZSS format.
//
// If you analyze the length/offset pairs and run them through Huffman
// compression, you figure out that you can improve the compression by
// using variable bit-oriented encodings for the "length" and "offset".
//
// Falcom are using one of the many variants on that scheme with interleaved
// bit-oriented and byte-oriented "command" and "data" values.
//

uint8_t * pByteStream;
unsigned  uBitBuffer;
unsigned  uBufferLen;

//

unsigned FalReadByte ( void )
{
  return *pByteStream++;
}

//

unsigned FalReadBit ( void )
{
  if (uBufferLen == 0)
  {
    uBitBuffer  = FalReadByte();
    uBitBuffer += FalReadByte() << 8;
    uBufferLen  = 16;
  }

  unsigned uBit = uBitBuffer & 1;

  uBitBuffer >>= 1;
  uBufferLen  -= 1;

  return uBit;
}

//

unsigned FalReadBits ( unsigned uCount )
{
  unsigned uValue = 0;

  while (uCount--)
  {
    uValue = (uValue << 1) + FalReadBit();
  }

  return uValue;
}

//

unsigned FalReadLength ( void )
{
  if (FalReadBit() != 0) return 2;
  if (FalReadBit() != 0) return 3;
  if (FalReadBit() != 0) return 4;
  if (FalReadBit() != 0) return 5;
  if (FalReadBit() != 0)
  {
    return FalReadBits(3) + 6;
  }
  else
  {
    return FalReadByte() + 14;
  }
}

//

uint8_t * DecompressNewFalcom ( uint8_t * pInput, uint8_t * pOutput, uint8_t * pInputEnd )
{
  uint8_t * pWindow;
  unsigned  uOffset;
  unsigned  uLength;
  unsigned  uFlag;
  uint8_t   uByte;

  int iReport = 0;

  pByteStream = ++pInput; // Skip leading zero.

  uBitBuffer = FalReadByte();
  uBufferLen = 8;

  for (;;)
  {
    // Sanity Check!

    if (pByteStream > pInputEnd)
    {
      printf( "The compressed data is corrupt!\n" );
      break;
    }

    // Is this a BYTE?

    if (FalReadBit() == 0)
    {
      // Immediate byte

      *pOutput++ = FalReadByte();

      continue;
    }

    // Get LZSS window offset.

    if (FalReadBit() == 0)
    {
      // Get 8-bit offset (always COPY).

      uOffset = FalReadByte();
    }
    else
    {
      // Get 13-bit offset.

      uOffset = FalReadBits( 5 );
      uOffset = (uOffset * 256) + FalReadByte();

      // uOffset = 0 : END
      // uOffset = 1 : FILL (i.e. RLE)
      // uOffset > 1 : COPY (i.e. LZSS)

      if (uOffset == 0) break;

      if (uOffset == 1)
      {
        // FILL (RLE)

        uFlag   = FalReadBit();
        uLength = FalReadBits( 4 );

        if (uFlag != 0)
        {
          uLength = (uLength * 256) + FalReadByte();
        }

        uLength = uLength + 14;

        uByte = FalReadByte();

        while (uLength--)
        {
          *pOutput++ = uByte;
        }

        continue;
      }
    }

    // COPY (LZSS)

    pWindow = pOutput - uOffset;
    uLength = FalReadLength();

    while (uLength--)
    {
      *pOutput++ = *pWindow++;
    }

    continue;
  }

  return pOutput;
}



// **************************************************************************
// **************************************************************************
//
// find_lzss_match ()
//
// Simple hash-based string search for Lempel-Ziv compression.
//
// HASH_WIN_SIZE is the size of the hash window used to track previous string
// occurrences, and it is not the maxLzssDelta to search for a current match!
//
// HASH_WIN_SIZE must be a power-of-two >= maxLzssDelta.
//
// There is no harm to having a HASH_WIN_SIZE > maxLzssDelta, it just takes
// up more memory during compression.
//

#define HASH_VAL_SIZE 65536
#define CALC_HASH( srcOffset ) (srcBuffer[ srcOffset + 0 ] + 256 * srcBuffer[ srcOffset + 1 ])

#define HASH_WIN_SIZE 0x2000
#define HASH_WIN_MASK (HASH_WIN_SIZE - 1)

static int * hashOffset;
static int * prevOffset;

static void inline find_lzss_match(
  int * foundOffset, int * foundLength,
  const uint8_t * srcBuffer, const int srcLength,
  int fromOffset, int maxLzssDelta, int maxLzssLength, int copyCount )

{
  // Local Variables.

  int minOffset  = fromOffset - maxLzssDelta;
  int bestOffset = minOffset;
  int bestLength = 0;
  int testOffset = hashOffset[ CALC_HASH( fromOffset ) ];
  int testLength;

  // Don't read beyond the srcBuffer.

  maxLzssLength = (maxLzssLength < (srcLength - fromOffset)) ? maxLzssLength : (srcLength - fromOffset);

  // Stop searching when the previous hash-location is beyond the window.

  while (testOffset >= minOffset)
  {
    // Quickly reject strings that won't be longer than the current-best.

    if (srcBuffer[ fromOffset + bestLength ] == srcBuffer[ testOffset + bestLength ])
    {
      testLength = 0;

      while ((testLength < maxLzssLength) &&
        (srcBuffer[ fromOffset + testLength ] == srcBuffer[ testOffset + testLength ])) {
        ++testLength;
      }

      if (testLength > bestLength) {
        bestOffset = testOffset;
        bestLength = testLength;
        if (bestLength == maxLzssLength) break;
      }
    }

    testOffset = prevOffset[ testOffset & HASH_WIN_MASK ];
  }

  *foundOffset = bestOffset;
  *foundLength = bestLength;
}



// **************************************************************************
// * BitIO_Init ()
// * BitIO_ByteSend ()
// * BitIO_ByteFlush ()
// **************************************************************************
// * Bit-oriented buffered output
// **************************************************************************
// * Inputs  -
// *
// * Output  -
// **************************************************************************

// Bit-oriented I/O variables.

uint8_t *           g_pDstBuffer;
unsigned            g_uDstLength;

static  unsigned    g_uOutData;
static  unsigned    g_uOutMask;
static  uint8_t *   g_pOutBits = NULL;

static  void BitIO_Init ( void )
{
  g_pOutBits = NULL;
}

static void BitIO_ByteSend ( unsigned uBitCount, unsigned uBitValue )
{
  if (uBitCount != 0)
  {
    for ( unsigned uValueMask = 1 << (uBitCount - 1); uValueMask != 0; uValueMask >>= 1 )
    {
      if (g_pOutBits == NULL)
      {
        g_uOutData = 0;
        g_uOutMask = 1;
        g_pOutBits = g_pDstBuffer;
        g_pDstBuffer += 1;
      }

      if (uBitValue & uValueMask)
      {
        g_uOutData |= g_uOutMask;
      }

      g_uOutMask <<= 1;

      if (g_uOutMask == (1 << 8))
      {
        g_pOutBits[0] = (uint8_t) (g_uOutData);
        g_pOutBits = NULL;
      }
    }
  }
}

static  void BitIO_ByteFlush ( void )
{
  if (g_pOutBits != NULL)
  {
    g_pOutBits[0] = (uint8_t) (g_uOutData);
    g_pOutBits = NULL;
  }
}



// **************************************************************************
// * SaveLengthSWD4_1_3_7 ()
// **************************************************************************
// *
// * Lengths are encoded ...
// *
// *     2       : 0
// *
// *     3-5     : 1 xx
// *
// *     6-20    : 1 00 xxxx
// *
// *    21-275   : 1 00 0000 xxxxxxxx
// *
// *   276-65535 : 1 00 0000 00000000 hhhhhhhh llllllll
// *
// *   65536-4GB : 1 00 0000 00000000 00000000 00000000 + 32-bits
// *
// *     EOF     : 1 00 0000 00000000 00000000 00000001
// *
// **************************************************************************

static  void SaveLengthSWD4_1_3_7 ( int iLength )

{
  if (iLength == 0)
  {
    // EOF marker ?
    //
    // Bitstream: 1 + 00 + 0000 + 00000000 + 00000000 + 00000001

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(6, 0);
    *g_pDstBuffer++ = 0;
    *g_pDstBuffer++ = 0;
    *g_pDstBuffer++ = 1;

    return;
  }
  else
  if (iLength == 1)
  {
    printf("SaveLengthSWD4_1_3_7 - Illegal length of 1!\n");
    exit(-1);
  }
  else
  if (iLength == 2)
  {
    // LZSS length of 1 bytes.
    //
    // Bitstream: 0

    BitIO_ByteSend(1, 0);
  }
  else
  if (iLength <= 5)
  {
    // LZSS length of 3-5 bytes.
    //
    // Bitstream: 1 + nn

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(2, iLength - 2);
  }
  else
  if (iLength <= 20)
  {
    // LZSS length of 6-20 bytes.
    //
    // Bitstream: 1 + 00 + nnnn

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(6, iLength - 5);
  }
  else
  if (iLength <= 275)
  {
    // LZSS length of 21-275 bytes.
    //
    // Bitstream: 1 + 00 + 0000 + nnnnnnnn

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(6, 0);
    *g_pDstBuffer++ = iLength - 20;
  }
  else
  if (iLength <= 65535)
  {
    // LZSS length of 276-65535 bytes.
    //
    // Bitstream: 1 + 00 + 0000 + 00000000 + nnnnnnnn nnnnnnnn

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(6, 0);
    *g_pDstBuffer++ = 0;
    *g_pDstBuffer++ = (iLength >> 8);
    *g_pDstBuffer++ = (iLength >> 0);
  }

  // All done.

  return;
}



// **************************************************************************
// * SaveOffsetSWD4_7_10_13 ()
// **************************************************************************
// *
// * Offsets are encoded ...
// *
// *   $0001-$0020 : 00        x xxxx
// *
// *   $0021-$0120 : 01     xxxx xxxx
// *
// *   $0121-$111F : 1 xxxx xxxx xxxx
// *
// *   EOF         : 1 0000 0000 0000
// *
// **************************************************************************

static  void SaveOffsetSWD4_7_10_13 ( int iOffset )

{
  if (iOffset > 0x111F)
  {
    printf("SaveOffsetSWD4_7_10_13 - Illegal offset value !\n");
    exit(-1);
  }

  if (iOffset == 0)
  {
    // EOF marker ?
    //
    // Bitstream: 1 + 0000 + 00000000

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(4, 0);
    *g_pDstBuffer++ = 0;

    return;
  }
  else
  if (iOffset <= 0x0020)
  {
    // Save LZSS offset of <= 0x0020 bytes.
    //
    // Bitstream: 00 + ooooo

    BitIO_ByteSend(2, 0);
    BitIO_ByteSend(5, iOffset - 0x0001);
  }
  else
  if (iOffset <= 0x0120)
  {
    // Save LZSS offset of <= 0x0120 bytes.
    //
    // Bitstream: 01 + oooooooo

    iOffset = iOffset - 0x0021;

    BitIO_ByteSend(2, 1);
    *g_pDstBuffer++ = (uint8_t) (iOffset & 255);
  }
  else
  {
    // Save LZSS offset of <= 0x111F bytes.
    //
    // Bitstream: 1 + oooo + oooooooo

    iOffset = iOffset - (0x0121 - 1);

    BitIO_ByteSend(1, 1);
    BitIO_ByteSend(4, (iOffset >> 8));

    *g_pDstBuffer++ = (uint8_t) (iOffset & 255);
  }

  // All done.

  return;
}



// **************************************************************************
// * CompressSWD4 ()
// **************************************************************************
// * Compress data in new SWD4 format.
// **************************************************************************
// *
// * The data is encoded as offset/length pairs.
// *
// * Offsets are encoded ...
// *
// * $0001-$0020 : 00        x xxxx
// *
// * $0021-$0120 : 01     xxxx xxxx
// *
// * $0121-$111F : 1 xxxx xxxx xxxx
// *
// * EOF         : 1 0000 0000 0000
// *
// * Lengths are encoded ...
// *
// *     1       : 1  dddddddd (i.e. COPY not LZSS)
// *
// *     2       : 0 0
// *
// *     3-5     : 0 1 xx
// *
// *     6-20    : 0 1 00 xxxx
// *
// *    21-275   : 0 1 00 0000 xxxxxxxx
// *
// *   276-65535 : 0 1 00 0000 00000000 hhhhhhhh llllllll
// *
// *   65536-4GB : 0 1 00 0000 00000000 00000000 00000000 + 32-bits
// *
// *     EOF     : 0 1 00 0000 00000000 00000000 00000001
// *
// **************************************************************************

uint8_t * CompressSWD4 (
  uint8_t * srcBuffer, unsigned srcLength,
  uint8_t * dstBuffer, unsigned dstLength,
  int maxRepeat )

{
  // Local Variables.

  int srcOffset = 0;
  int copyCount = 0;
  int skipCount;

  int i;
  int hashValue;
  int srcRemain;
  int bestOffset;
  int bestLength;
  int nextOffset;
  int nextLength;

  // Set the search parameters for this particular LZSS-variant.

  const int minMatch = 2;
  const int maxDelta = 0x111F;

  // Allocate these the first time that this function is called.

  if (hashOffset == NULL) {
    hashOffset = (int *) malloc( sizeof(int) * (HASH_VAL_SIZE + HASH_WIN_SIZE) );
    prevOffset = hashOffset + HASH_VAL_SIZE;
  }

  // Initialize the hash table.

  for (i = 0; i < HASH_VAL_SIZE; ++i) {
    hashOffset[i] = - (HASH_WIN_SIZE * 2);
  }

  // Initialize the output.

  g_pDstBuffer = dstBuffer;
  g_uDstLength = dstLength;

  BitIO_Init();

  // Loop around encoding strings until the buffer is empty.

  for (;;)
  {
    // Update the window and calc how much data is left to compress.

//  srcRemain = min(65536, srcLength - srcOffset);
    srcRemain = srcLength - srcOffset;

    if (srcRemain < minMatch) {
      srcOffset += srcRemain;
      copyCount += srcRemain;
      break;
    }

    // Find the best match at the current position.

    bestLength = 0;

    if (srcOffset != 0) {
      find_lzss_match( &bestOffset, &bestLength, srcBuffer, srcLength, srcOffset, maxDelta, maxRepeat, copyCount );
    }

    // Move the window on by 1 byte.

    hashValue = CALC_HASH( srcOffset );

    prevOffset[ srcOffset & HASH_WIN_MASK ] = hashOffset[ hashValue ];
    hashOffset[ hashValue ] = srcOffset;

    // Lazy match (compresses approx 1% better).

    if ((bestLength >= minMatch) && (srcRemain != minMatch)) {
      find_lzss_match( &nextOffset, &nextLength, srcBuffer, srcLength, srcOffset + 1, maxDelta, maxRepeat, copyCount + 1 );
      if (nextLength > (bestLength + ((copyCount == 2) ? 1 : 0))) {
        ++copyCount;
        ++srcOffset;
        bestLength = nextLength;
        bestOffset = nextOffset;
      }
    }

    // Keep track of COPY bytes, but don't process them, yet.

    if (bestLength < minMatch) {
      ++copyCount;
      ++srcOffset;
      continue;
    }

    // First, write any COPY bytes.

    if (copyCount) {
      uint8_t * cpyBuffer = srcBuffer + srcOffset - copyCount;
      while (copyCount--) {
        // Mark this as a COPY and not an LZSS.
        BitIO_ByteSend(1, 1);
        *g_pDstBuffer++ = *cpyBuffer++;
      }
      copyCount = 0;
    }

    // Then write the LZSS "match".
    //
    // Mark this as an LZSS and not a COPY.

    BitIO_ByteSend(1, 0);

    // Save LZSS offset.

    SaveOffsetSWD4_7_10_13( srcOffset - bestOffset );

    // Save LZSS length.

    SaveLengthSWD4_1_3_7( bestLength );

    // Skip passed "matched" bytes, updating the window contents.

    ++srcOffset;

    skipCount = bestLength - 1;

    while (skipCount--)
    {
      hashValue = CALC_HASH( srcOffset );

      prevOffset[ srcOffset & HASH_WIN_MASK ] = hashOffset[ hashValue ];
      hashOffset[ hashValue ] = srcOffset;

      ++srcOffset;
    }

  } // End of "for (;;)"

  // Encode the last COPY byte(s) (if there are any).

  if (copyCount) {
    uint8_t * cpyBuffer = srcBuffer + srcOffset - copyCount;
    while (copyCount--) {
      // Mark this as a COPY and not an LZSS.
      BitIO_ByteSend(1, 1);
      *g_pDstBuffer++ = *cpyBuffer++;
    }
    copyCount = 0;
  }

  // Send EOF token.
  //
  // Bitstream: 1 + 1 + 0000 + 00000000

  // Mark this as an LZSS and not a COPY.

  BitIO_ByteSend(1, 0);

  SaveOffsetSWD4_7_10_13( 0 );

  // Flush out the last few bits.

  BitIO_ByteFlush();

  // Free up the hash buffer (which can just be permanent).

#if 0
  if (hashOffset) {
    free( hashOffset );
    hashOffset = NULL;
  }
#endif

  // All done.

  return (g_pDstBuffer);
}



// ****************************************************************************
// ****************************************************************************
//
// unpack_meta_block() - Unpack a META_BLOCK into it's constituent DATA_CHUNKs.
//

#define MAX_DATA_CHUNKS 192

#define DATA_CHUNK_SIZE 8192

#if 0

uint16_t g_aDataChunkOrigin [MAX_DATA_CHUNKS];
uint16_t g_aDataChunkLength [MAX_DATA_CHUNKS];
uint16_t g_aExtraDataOrigin [MAX_DATA_CHUNKS];
uint16_t g_aExtraDataLength [MAX_DATA_CHUNKS];
uint8_t  g_aMetaBlockChunks [MAX_DATA_CHUNKS * DATA_CHUNK_SIZE];
uint8_t  g_aMetaBlockExtras [MAX_DATA_CHUNKS * DATA_CHUNK_SIZE];

#else

// The META_BLOCK buffers have been converted so that the entire set
// of origin/length/data/extra buffers can be xdelta compressed as a
// single block of memory.

uint16_t g_aMetaBlockSource [MAX_DATA_CHUNKS * (DATA_CHUNK_SIZE + 4)];
uint16_t g_aMetaBlockTarget [MAX_DATA_CHUNKS * (DATA_CHUNK_SIZE + 4)];

uint16_t *g_aDataChunkOrigin = g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 0);
uint16_t *g_aDataChunkLength = g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 1);
uint16_t *g_aExtraDataOrigin = g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 2);
uint16_t *g_aExtraDataLength = g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 3);
uint8_t  *g_aMetaBlockChunks = (uint8_t *) (g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 4));
uint8_t  *g_aMetaBlockExtras = (uint8_t *) (g_aMetaBlockTarget + (MAX_DATA_CHUNKS * 4) + (MAX_DATA_CHUNKS * DATA_CHUNK_SIZE / sizeof(uint16_t)));

#endif

unsigned g_uMetaBlockChunks;

uint8_t * unpack_meta_block( uint8_t * pSrcMetaBlock, META_BLOCK_LOCATION * pMetaBlockList
 )
{
  int iErrorCode = -1;

  // Clear the buffers before decompressing for a clean xdelta.

  memset(g_aMetaBlockTarget, 0, sizeof(g_aMetaBlockTarget));

  //

  uint32_t uNumChunks = pSrcMetaBlock[0x00] + (pSrcMetaBlock[0x01] * 256) +  (pSrcMetaBlock[0x02] * 8192);

  uNumChunks >>= 2;

  g_uMetaBlockChunks = uNumChunks;

  if (g_uMetaBlockChunks != pMetaBlockList->m_uDataChunkCnt)
  {
    printf( "\npMetaBlockList->m_uDataChunkCnt is wrong in unpack_meta_block()!\n" );
    return ( NULL );
  }

  uint8_t * pSrcMetaHead = pSrcMetaBlock;
  uint8_t * pSrcMetaData;
  uint8_t * pSrcMetaStop;
  uint8_t * pDstMetaData;

  for (unsigned uChunkNum = 0; uChunkNum < uNumChunks; uChunkNum++)
  {
    //

    unsigned uSrcOffset = pSrcMetaHead[0x00] + (pSrcMetaHead[0x01] * 256) +  (pSrcMetaHead[0x02] * 8192);

    pSrcMetaHead += 4;

    //

    pSrcMetaData = pSrcMetaBlock + uSrcOffset;

    unsigned uSrcLength = pSrcMetaData[0x00] + (pSrcMetaData[0x01] * 256) - 1;

    pSrcMetaData += 2;

    pSrcMetaStop = pSrcMetaData + uSrcLength;

    pDstMetaData = g_aMetaBlockChunks + (uChunkNum * DATA_CHUNK_SIZE);

    uint8_t * pEndDataChunk = NULL;

    if (pSrcMetaData[0] == 0)
      pEndDataChunk = DecompressNewFalcom( pSrcMetaData, pDstMetaData, pSrcMetaStop );
    else
      pEndDataChunk = DecompressOldFalcom( pSrcMetaData, pDstMetaData, pSrcMetaStop );

    if (pEndDataChunk == NULL)
    {
      printf("Decompression error!\n");
      return NULL;
    }

    unsigned uDstLength = (unsigned) (pEndDataChunk - pDstMetaData);

    if (uDstLength > DATA_CHUNK_SIZE)
    {
      printf("Decompressed data overrun!\n");
      return NULL;
    }

    g_aDataChunkOrigin[uChunkNum] = 0xA000u;
    g_aDataChunkLength[uChunkNum] = uDstLength;

    g_aExtraDataOrigin[uChunkNum] = 0;
    g_aExtraDataLength[uChunkNum] = 0;
  }

  // Remember the initial contents if we're going to xdelta the differences.

  memcpy( g_aMetaBlockSource, g_aMetaBlockTarget, sizeof(g_aMetaBlockTarget) );

  //

  return pSrcMetaStop;
}



// ****************************************************************************
// ****************************************************************************
//
// pack_meta_block() - Pack a META_BLOCK from it's constituent DATA_CHUNKs.
//

uint8_t   g_aDstMetaBlock1st [512 * 1024];
uint8_t * g_pDstMetaBlockEnd;

uint8_t * pack_meta_block( uint32_t uMetaBlock1st, unsigned uNumChunks,
  uint8_t * pSrcChunkBuffers, uint16_t * pSrcChunkLengths, uint16_t * pSrcChunkOrigins,
  uint8_t * pSrcExtraBuffers, uint16_t * pSrcExtraLengths, uint16_t * pSrcExtraOrigins,
  unsigned uPauseMenuPalettesAreInChunk )

{
  //

  uint8_t * pDstMetaHead = g_aDstMetaBlock1st;
  uint8_t * pDstMetaData = g_aDstMetaBlock1st + (uNumChunks << 2);

  for (unsigned uChunkNum = 0; uChunkNum < uNumChunks; uChunkNum++)
  {
    //

    unsigned uDstOffset = (unsigned) (pDstMetaData - g_aDstMetaBlock1st);

    pDstMetaHead[0x00] = 0xff & (uDstOffset >>  0);
    pDstMetaHead[0x01] = 0x1f & (uDstOffset >>  8);
    pDstMetaHead[0x02] = 0xff & (uDstOffset >> 13);
    pDstMetaHead[0x03] = 0;

    pDstMetaHead += 4;

    //

    uint8_t * pSrcBuffer = pSrcChunkBuffers + (uChunkNum * DATA_CHUNK_SIZE);
    unsigned  uSrcLength = pSrcChunkLengths[uChunkNum];

    uint8_t * pEndDataChunk = NULL;

#if IS_XANADU1
    // Compress Weapon Shop dialog boxes with a lower compression so that they don't
    // glitch when the TII instruction delays an interrupt during decompression.

    int iMaxRepeatLen = 32;
#else
    int iMaxRepeatLen = 1024;

    // Does this META_BLOCK contain the data for the Pause Menu?

    if (uPauseMenuPalettesAreInChunk != 0)
    {
      // If so, then compress the Pause Menu data chunks with a lower maximum
      // repeat so that the audio doesn't glitch when the blocks are decompressed.
      //
      // chunk $05 -> VRAM $1000-$1fff ->  menu CHR (empty from $1780-$1fff)
      // chunk $06 -> VRAM $5000-$5fff ->  menu SPR
      // chunk $07 -> palettes
      // chunk $08 -> VRAM $2000-$2fff ->  weapon icons
      // chunk $09 -> VRAM $3000-$3fff ->  weapon icons, mostly empty
      // chunk $0A -> VRAM $4000-$4fff ->  special item icons

      if ((uChunkNum >= (uPauseMenuPalettesAreInChunk - 2)) &&
          (uChunkNum <= (uPauseMenuPalettesAreInChunk + 3)))
      {
        // Stop the audio glitch on the Pause Menu!
        iMaxRepeatLen = 32;
      }
    }
#endif

    pEndDataChunk = CompressSWD4( pSrcBuffer, uSrcLength, pDstMetaData + 2, 65536, iMaxRepeatLen );

    // Is there any "extended", aka "extra", data to compress?

    *pEndDataChunk++ = 0;

    if ((pSrcExtraLengths != NULL) && (pSrcExtraLengths[uChunkNum] != 0))
    {
      // Get the address of the extra buffer in the PCE's RAM.
      //
      // If it's above $e000, then subtract $2000 because we're mapping
      // that area into $c000 for decompression.

      unsigned uOrigin = pSrcExtraOrigins[uChunkNum];

      if (uOrigin >= 0xe000u) uOrigin -= 0x2000u;

      // Replace the last byte of the SWD5 EOF marker with the
      // high byte of the decompression address.

      pEndDataChunk -= 1;

      pEndDataChunk[0] = (uOrigin >> 8) & 255;
      pEndDataChunk[1] = (uOrigin >> 0) & 255;

      pEndDataChunk += 2;

      // Compress the extra data.

      pSrcBuffer = pSrcExtraBuffers + (uChunkNum * DATA_CHUNK_SIZE);
      uSrcLength = pSrcExtraLengths[uChunkNum];

      pEndDataChunk = CompressSWD4( pSrcBuffer, uSrcLength, pEndDataChunk, 65536, 65536 );

      *pEndDataChunk++ = 0;
    }

    //

    unsigned uDstLength = (unsigned) (pEndDataChunk - (pDstMetaData + 2)) + 1;

    pDstMetaData[0] = 255 & (uDstLength >> 0);
    pDstMetaData[1] = 255 & (uDstLength >> 8);

    pDstMetaData = pEndDataChunk;
  }

  g_pDstMetaBlockEnd = pDstMetaData;

  return pDstMetaData;
}



// ****************************************************************************
// ****************************************************************************
//
// md5_memory() - Patch the ISO using xdelta3 files.
//
// Public domain MD5 code originally written by Bryce Wilson.
//
// This version changes the whitespace and capitalization to make it a little
// easier for me to read.
//
// From:
//   https://github.com/Zunawe/md5-c
// With modifications from:
//   https://github.com/MilchRatchet/md5-c
//

//
// Derived from the RSA Data Security, Inc. MD5 Message-Digest Algorithm
// and modified slightly to be functionally identical but condensed into control structures.
//

typedef struct{
  uint64_t size;         // Size of input in bytes
  uint32_t buffer[4];    // Current accumulation of hash
  uint8_t  input[64];    // Input to be used in the next step
  uint8_t  digest[16];   // Result of algorithm
} MD5Context;

//
// Constants defined by the MD5 algorithm
//

#define A 0x67452301
#define B 0xefcdab89
#define C 0x98badcfe
#define D 0x10325476

static uint32_t S[] = {
  7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
  5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20, 5,  9, 14, 20,
  4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
  6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21};

static uint32_t K[] = {
  0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
  0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
  0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
  0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
  0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
  0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
  0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
  0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
  0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
  0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
  0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
  0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
  0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
  0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
  0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
  0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391};

//
// Padding used to make the size (in bits) of the input congruent to 448 mod 512
//

static uint8_t PADDING[] = {
  0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

//
// Bit-manipulation functions defined by the MD5 algorithm
//

#define F(X, Y, Z) ((X & Y) | (~X & Z))
#define G(X, Y, Z) ((X & Z) | (Y & ~Z))
#define H(X, Y, Z) (X ^ Y ^ Z)
#define I(X, Y, Z) (Y ^ (X | ~Z))

//
// Rotates a 32-bit word left by n bits
//

uint32_t rotateLeft( uint32_t x, uint32_t n )
{
  return (x << n) | (x >> (32 - n));
}

//
// Initialize a context
//

void md5_init( MD5Context *ctx )
{
  ctx->size = (uint64_t) 0;

  ctx->buffer[0] = (uint32_t) A;
  ctx->buffer[1] = (uint32_t) B;
  ctx->buffer[2] = (uint32_t) C;
  ctx->buffer[3] = (uint32_t) D;
}

//
// Step on 512 bits of input with the main MD5 algorithm.
//

void md5_step( uint32_t *buffer, const uint32_t *input )
{
  uint32_t AA = buffer[0];
  uint32_t BB = buffer[1];
  uint32_t CC = buffer[2];
  uint32_t DD = buffer[3];

  uint32_t E;

  unsigned int j;

  for ( unsigned int i = 0; i < 64; ++i )
  {
    switch (i / 16)
    {
      case 0:
        E = F(BB, CC, DD);
        j = i;
        break;
      case 1:
        E = G(BB, CC, DD);
        j = ((i * 5) + 1) % 16;
        break;
      case 2:
        E = H(BB, CC, DD);
        j = ((i * 3) + 5) % 16;
        break;
      default:
        E = I(BB, CC, DD);
        j = (i * 7) % 16;
        break;
    }

    uint32_t temp = DD;
    DD = CC;
    CC = BB;
    BB = BB + rotateLeft( AA + E + K[i] + input[j], S[i] );
    AA = temp;
  }

  buffer[0] += AA;
  buffer[1] += BB;
  buffer[2] += CC;
  buffer[3] += DD;
}

//
// Add some amount of input to the context
//
// If the input fills out a block of 512 bits, apply the algorithm (md5Step)
// and save the result in the buffer. Also updates the overall size.
//

void md5_update( MD5Context *ctx, const uint8_t *input_buffer, size_t input_len )
{
  uint32_t input[16];
  unsigned int offset = ctx->size % 64;
  ctx->size += (uint64_t)input_len;

  // Copy each byte in input_buffer into the next space in our context input

  for ( unsigned int i = 0; i < input_len; ++i )
  {
    ctx->input[offset++] = (uint8_t) *(input_buffer + i);

    // If we've filled our context input, copy it into our local array input
    // then reset the offset to 0 and fill in a new buffer.
    // Every time we fill out a chunk, we run it through the algorithm
    // to enable some back and forth between cpu and i/o

    if (offset % 64 == 0)
    {
      for ( unsigned int j = 0; j < 16; ++j )
      {
        // Convert to little-endian
        // The local variable `input` our 512-bit chunk separated into 32-bit words
        // we can use in calculations

        input[j] =
               (uint32_t) (ctx->input[(j * 4) + 3]) << 24 |
               (uint32_t) (ctx->input[(j * 4) + 2]) << 16 |
               (uint32_t) (ctx->input[(j * 4) + 1]) <<  8 |
               (uint32_t) (ctx->input[(j * 4)]);
      }
      md5_step( ctx->buffer, input );
      offset = 0;
    }
  }
}

//
// Pad the current input to get to 448 bytes, append the size in bits to the very end,
// and save the result of the final iteration into digest.
//

void md5_finalize( MD5Context *ctx )
{
  uint32_t input[16];
  unsigned int offset = ctx->size % 64;
  unsigned int padding_length = offset < 56 ? 56 - offset : (56 + 64) - offset;

  // Fill in the padding and undo the changes to size that resulted from the update

  md5_update( ctx, PADDING, padding_length );
  ctx->size -= (uint64_t) padding_length;

  // Do a final update (internal to this function)
  // Last two 32-bit words are the two halves of the size (converted from bytes to bits)

  for( unsigned int j = 0; j < 14; ++j )
  {
    input[j] =
           (uint32_t) (ctx->input[(j * 4) + 3]) << 24 |
           (uint32_t) (ctx->input[(j * 4) + 2]) << 16 |
           (uint32_t) (ctx->input[(j * 4) + 1]) <<  8 |
           (uint32_t) (ctx->input[(j * 4)]);
  }
  input[14] = (uint32_t) (ctx->size * 8);
  input[15] = (uint32_t) ((ctx->size * 8) >> 32);

  md5_step(ctx->buffer, input);

  // Move the result into digest (convert from little-endian)

  for( unsigned int i = 0; i < 4; ++i )
  {
    ctx->digest[(i * 4) + 0] = (uint8_t) ((ctx->buffer[i] & 0x000000FF));
    ctx->digest[(i * 4) + 1] = (uint8_t) ((ctx->buffer[i] & 0x0000FF00) >>  8);
    ctx->digest[(i * 4) + 2] = (uint8_t) ((ctx->buffer[i] & 0x00FF0000) >> 16);
    ctx->digest[(i * 4) + 3] = (uint8_t) ((ctx->buffer[i] & 0xFF000000) >> 24);
  }
}

//
// Functions that run the algorithm on the provided input and put the digest into result.
// result should be able to store 16 bytes.
//

void md5_memory( const uint8_t *input, size_t length, uint8_t *result )
{
  MD5Context ctx;
  md5_init( &ctx );
  md5_update( &ctx, input, length );
  md5_finalize( &ctx );

  memcpy( result, ctx.digest, 16 );
}



// ****************************************************************************
// ****************************************************************************
//
// redump_to_isowav() - Convert a REDUMP image into a .ISO/.WAV image.
//

#if IS_XANADU1

static const unsigned aLoxRedumpSizes [] =
{
         0,
   8415456, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 01).bin
  33741792, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 02).bin
   9607920, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 03).bin
  51085440, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 04).bin
  51370032, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 05).bin
  28275744, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 06).bin
  43610784, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 07).bin
   6221040, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 08).bin
  61695312, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 09).bin
  51828672, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 10).bin
  27624240, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 11).bin
  52374336, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 12).bin
  50485680, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 13).bin
  60070080, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 14).bin
  55286112, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 15).bin
   3664416, // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 16).bin
  33396048  // Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (Track 17).bin
};

static const uint8_t aLoxRedumpMd5 [][16] =
{
  { 0x6a, 0xd2, 0x59, 0xd7, 0xcb, 0x4c, 0x89, 0x3a, 0xb4, 0x3e, 0x5f, 0x82, 0xc5, 0x0e, 0x0d, 0x11 },
  { 0x15, 0xf3, 0x37, 0x60, 0xe9, 0xe5, 0xfe, 0xd5, 0x39, 0xff, 0xe0, 0xdd, 0x25, 0x64, 0xaa, 0x32 },
  { 0xb9, 0x52, 0x69, 0xc1, 0x33, 0x84, 0xd6, 0x4f, 0x83, 0x1b, 0x9b, 0x6a, 0xa4, 0xd3, 0xe9, 0x98 },
  { 0x90, 0x8f, 0x11, 0x9f, 0x22, 0x25, 0xae, 0xdd, 0x8b, 0x33, 0x4a, 0xc7, 0xe0, 0x5a, 0x73, 0x95 },
  { 0xa6, 0xaa, 0xf2, 0x42, 0xef, 0xc7, 0x9a, 0x0e, 0x0d, 0x26, 0xd8, 0xa7, 0x76, 0xd4, 0xcf, 0xe3 },
  { 0xd8, 0xe6, 0x5f, 0xdd, 0xf6, 0xa5, 0x8e, 0x86, 0xe8, 0xb2, 0xdd, 0xd8, 0xad, 0x47, 0x7a, 0x8a },
  { 0xc0, 0x80, 0x23, 0xbb, 0x84, 0xf7, 0x4b, 0x78, 0xe5, 0x3a, 0x59, 0xa4, 0xdd, 0xbb, 0x51, 0xeb },
  { 0x1e, 0xdf, 0xe9, 0x9b, 0xa8, 0x64, 0xd3, 0xb7, 0x9d, 0x72, 0xf9, 0xa8, 0xe1, 0x9f, 0x71, 0xf4 },
  { 0x8a, 0xba, 0x58, 0xfb, 0x8f, 0xfd, 0x2a, 0x3b, 0xa6, 0x14, 0x0e, 0xb2, 0x75, 0xe1, 0x03, 0x88 },
  { 0xe6, 0x6a, 0xd3, 0x51, 0x68, 0x05, 0x61, 0x22, 0x8f, 0xdd, 0xf9, 0xaf, 0xa1, 0xdf, 0x5c, 0x65 },
  { 0x49, 0x66, 0x2f, 0x81, 0xb5, 0x07, 0xc5, 0x03, 0x59, 0x57, 0xb9, 0x0a, 0xb7, 0x74, 0x75, 0x34 },
  { 0x3f, 0xd3, 0x57, 0x5e, 0x1f, 0x0b, 0xb3, 0x35, 0xf4, 0xcf, 0x2f, 0xeb, 0xa4, 0xc1, 0x95, 0x49 },
  { 0x25, 0xe5, 0xf8, 0x35, 0x6e, 0x0b, 0x4b, 0xf3, 0xcc, 0x4d, 0x09, 0xf9, 0x94, 0x33, 0x6a, 0xe4 },
  { 0x13, 0x10, 0xd5, 0xa3, 0x98, 0x61, 0xd3, 0xf3, 0x5e, 0xf9, 0x60, 0xdb, 0x19, 0xad, 0x79, 0x8c },
  { 0x83, 0xca, 0x67, 0xff, 0xd2, 0x12, 0x85, 0x66, 0x09, 0x08, 0xad, 0xb5, 0x32, 0xdf, 0x71, 0x7a },
  { 0x91, 0xf6, 0xe1, 0x70, 0xef, 0xad, 0xac, 0x61, 0x26, 0xdb, 0xc1, 0x75, 0xbe, 0xcc, 0xf6, 0x5c },
  { 0x15, 0x3e, 0x10, 0xd9, 0x80, 0xe3, 0x62, 0xe2, 0x28, 0x1f, 0x35, 0xb8, 0x96, 0x77, 0x2f, 0x2b }
};

static const uint8_t aLoxPatchedMd5 [16] =
{
  0xf6, 0x62, 0xdc, 0x53, 0x40, 0xfe, 0x16, 0xb9, 0x9b, 0x95, 0x9e, 0xbd, 0xf8, 0x3b, 0x7a, 0x39
};

const char *aLoxSubtitledCue[] =
{
  "FILE \"%s (%s) (Track 01).wav\" WAVE\n"
  "  TRACK 01 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 02).iso\" BINARY\n"
  "  TRACK 02 MODE1/2048\n"
  "    PREGAP 00:03:00\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 03).wav\" WAVE\n"
  "  TRACK 03 AUDIO\n"
  "    PREGAP 00:02:00\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 04).wav\" WAVE\n"
  "  TRACK 04 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 05).wav\" WAVE\n"
  "  TRACK 05 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 06).wav\" WAVE\n"
  "  TRACK 06 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 07).wav\" WAVE\n"
  "  TRACK 07 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 08).wav\" WAVE\n"
  "  TRACK 08 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 09).wav\" WAVE\n"
  "  TRACK 09 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 10).wav\" WAVE\n"
  "  TRACK 10 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 11).wav\" WAVE\n"
  "  TRACK 11 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 12).wav\" WAVE\n"
  "  TRACK 12 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 13).wav\" WAVE\n"
  "  TRACK 13 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 14).wav\" WAVE\n"
  "  TRACK 14 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 15).wav\" WAVE\n"
  "  TRACK 15 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 16).wav\" WAVE\n"
  "  TRACK 16 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 02).iso\" BINARY\n"
  "  TRACK 17 MODE1/2048\n"
  "    PREGAP 00:03:00\n"
  "    INDEX 01 00:00:00\n",
  NULL
};

#else

static const unsigned aLoxRedumpSizes [] =
{
         0,
  13992048, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 01).bin
  18613728, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 02).bin
  14203728, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 03).bin
  10743936, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 04).bin
  13237056, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 05).bin
  16438128, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 06).bin
  14147280, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 07).bin
  10591056, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 08).bin
  79154208, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 09).bin
  42498288, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 10).bin
  32786880, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 11).bin
   6700848, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 12).bin
  11557728, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 13).bin
  18597264, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 14).bin
  23324784, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 15).bin
  26551728, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 16).bin
  18180960, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 17).bin
  17002608, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 18).bin
  11917584, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 19).bin
  26250672, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 20).bin
  18877152, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 21).bin
  24599568, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 22).bin
  44144688, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 23).bin
   5557776, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 24).bin
   1133664, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 25).bin
   5411952, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 26).bin
   5931744, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 27).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 28).bin
    856128, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 29).bin
    889056, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 30).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 31).bin
   1521744, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 32).bin
   1220688, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 33).bin
   1084272, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 34).bin
   1220688, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 35).bin
   1215984, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 36).bin
   1373568, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 37).bin
   1444128, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 38).bin
   1128960, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 39).bin
   1117200, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 40).bin
   1425312, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 41).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 42).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 43).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 44).bin
    705600, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 45).bin
   1634640, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 46).bin
  60940320, // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 47).bin
  18263280  // Legend of Xanadu - Kaze no Densetsu Xanadu II (Japan) (Track 48).bin
};

static const uint8_t aLoxRedumpMd5 [][16] =
{
  { 0x8d, 0x30, 0x20, 0x35, 0x4e, 0xd8, 0x0a, 0x5b, 0x07, 0x34, 0xa5, 0x5c, 0x7f, 0xbb, 0x7e, 0x9e },
  { 0x59, 0xe8, 0x6a, 0xc2, 0x4c, 0x7f, 0x44, 0x56, 0xb0, 0xb7, 0xb3, 0x97, 0x90, 0x32, 0x53, 0x96 },
  { 0xfb, 0xa4, 0xe8, 0x7c, 0xc5, 0x41, 0xc1, 0xcd, 0x7e, 0xb4, 0x3e, 0xf3, 0xac, 0x66, 0x31, 0x0d },
  { 0xbb, 0xb9, 0xfc, 0xac, 0xac, 0x90, 0x2c, 0xe7, 0xfe, 0x70, 0xd9, 0x08, 0xa5, 0x30, 0x26, 0x06 },
  { 0x53, 0x16, 0xa5, 0x82, 0x81, 0x7c, 0x72, 0x15, 0x79, 0x28, 0x1d, 0x79, 0x5c, 0x46, 0x50, 0x97 },
  { 0x76, 0xdf, 0xa7, 0x7c, 0x22, 0x24, 0xe5, 0x20, 0x45, 0x98, 0x16, 0x7c, 0x4b, 0xf5, 0xab, 0x90 },
  { 0x86, 0xe7, 0xb0, 0xcc, 0xa2, 0x55, 0x87, 0x18, 0x86, 0xf0, 0xd2, 0xa2, 0xd7, 0x65, 0x93, 0x7c },
  { 0x15, 0x87, 0x23, 0x07, 0x2c, 0xe1, 0xb0, 0xf7, 0x48, 0x22, 0x44, 0xae, 0x36, 0x8c, 0x7b, 0x37 },
  { 0xd2, 0xde, 0x9a, 0x36, 0x98, 0xa5, 0xf1, 0x3b, 0x4c, 0x57, 0x7d, 0xfc, 0xbc, 0xa1, 0x2b, 0xa1 },
  { 0xda, 0xa3, 0x51, 0xa2, 0x51, 0xc4, 0x1e, 0x2d, 0x70, 0x57, 0xa0, 0x3f, 0x0e, 0x74, 0x6e, 0xd9 },
  { 0x11, 0x1a, 0x4a, 0xdb, 0x7d, 0xea, 0xd7, 0x06, 0x50, 0x91, 0x12, 0x1f, 0x17, 0x40, 0xf1, 0x73 },
  { 0x9e, 0xb9, 0x63, 0x10, 0x37, 0xf6, 0x2d, 0x43, 0x71, 0xa8, 0x8a, 0x73, 0xb7, 0x56, 0xd9, 0xbf },
  { 0xcb, 0xcb, 0xb7, 0xc8, 0x97, 0xef, 0xf7, 0x19, 0x01, 0x73, 0xca, 0xc4, 0x55, 0x35, 0xd6, 0xc3 },
  { 0xde, 0x54, 0xf0, 0x4b, 0xb6, 0x61, 0xee, 0xee, 0x97, 0x93, 0x56, 0x4b, 0x51, 0xdd, 0x3c, 0xff },
  { 0xd2, 0x1c, 0xeb, 0x6a, 0xaa, 0x90, 0xdf, 0x1a, 0x6c, 0x4d, 0x04, 0xc6, 0x16, 0xbe, 0xeb, 0x00 },
  { 0xf4, 0xaa, 0xde, 0xb6, 0x5f, 0x20, 0xac, 0x5f, 0x0b, 0xc1, 0x6c, 0x58, 0x0d, 0x16, 0x99, 0x60 },
  { 0xa9, 0xeb, 0x05, 0x73, 0xc6, 0xf1, 0xf6, 0xfb, 0x43, 0xd7, 0xe0, 0xb6, 0x0a, 0xb9, 0x56, 0xfe },
  { 0xd6, 0x88, 0x9b, 0x37, 0x90, 0x03, 0x6e, 0xb5, 0x10, 0x55, 0x47, 0xf8, 0xfb, 0x94, 0xc7, 0x9e },
  { 0x84, 0x63, 0x47, 0x17, 0xa5, 0xf8, 0x2f, 0x1f, 0x09, 0xca, 0x25, 0x18, 0xb8, 0x4d, 0xd3, 0x36 },
  { 0x78, 0xea, 0x95, 0xbb, 0xb9, 0xb9, 0x39, 0xf2, 0x9f, 0x33, 0xcc, 0x12, 0x42, 0xf8, 0x97, 0x7f },
  { 0xe7, 0x9d, 0x48, 0x6c, 0x35, 0x71, 0x50, 0x34, 0x28, 0xfc, 0x74, 0xc1, 0xa5, 0x0f, 0x91, 0xf0 },
  { 0x87, 0xfb, 0xfb, 0x2c, 0x5e, 0x23, 0xab, 0xea, 0xc9, 0xea, 0xd7, 0xa0, 0x4c, 0x6a, 0xc1, 0x2a },
  { 0x81, 0xf0, 0x08, 0x24, 0xee, 0x88, 0x5b, 0x9e, 0x33, 0x63, 0xf6, 0x51, 0xab, 0x12, 0x08, 0x9e },
  { 0xc4, 0xcd, 0xe3, 0xbc, 0x4a, 0x39, 0x2c, 0x81, 0x2e, 0xc4, 0xda, 0x12, 0x6a, 0xf4, 0x31, 0x06 },
  { 0x9a, 0x44, 0x19, 0xde, 0xc8, 0x1e, 0x5e, 0x2d, 0xd4, 0x7f, 0xd1, 0x27, 0xec, 0x53, 0x01, 0xce },
  { 0x2d, 0xe7, 0x75, 0x3e, 0x14, 0xb5, 0x49, 0x3a, 0x86, 0xd0, 0x88, 0x30, 0xa5, 0x6d, 0x34, 0xea },
  { 0x6e, 0x31, 0x97, 0xd4, 0x1d, 0xb9, 0xfb, 0x41, 0x9d, 0x55, 0xe5, 0x03, 0x60, 0xda, 0xf1, 0x1e },
  { 0x51, 0xf7, 0x3c, 0x0c, 0xf8, 0xcd, 0x79, 0x4e, 0xbd, 0xf4, 0xe6, 0x82, 0xb9, 0x19, 0x21, 0x6c },
  { 0x86, 0xfa, 0x7d, 0x9c, 0x1d, 0xc5, 0x0c, 0x9c, 0x2b, 0x76, 0xd2, 0xd4, 0x99, 0xcc, 0xd5, 0xaa },
  { 0x0c, 0x0f, 0xd3, 0xf2, 0x86, 0x3d, 0xd8, 0x93, 0x63, 0x47, 0x6f, 0x8b, 0x09, 0xc8, 0xe8, 0x0f },
  { 0x5e, 0x9b, 0x4b, 0x6b, 0xef, 0x91, 0x5c, 0x58, 0x58, 0x68, 0xf5, 0x9d, 0x3e, 0xb6, 0x93, 0x11 },
  { 0xd9, 0x81, 0xb2, 0xbb, 0x00, 0x61, 0x98, 0x4d, 0xd5, 0x9e, 0x8c, 0x93, 0xb7, 0xde, 0x16, 0x33 },
  { 0x0e, 0x4d, 0xe3, 0xef, 0x35, 0x62, 0xb1, 0x3b, 0x50, 0x3f, 0x11, 0xe0, 0x25, 0x67, 0x6a, 0x87 },
  { 0xc6, 0xa6, 0xa7, 0xc2, 0x0d, 0x2b, 0x42, 0xcc, 0xc4, 0xac, 0xd6, 0x88, 0x63, 0x80, 0xd5, 0x65 },
  { 0x63, 0x4a, 0x58, 0xb3, 0xc0, 0x5e, 0x43, 0x61, 0xb6, 0xc8, 0xe2, 0xa0, 0xea, 0x77, 0xe7, 0x5f },
  { 0xfe, 0x2a, 0xb5, 0x1e, 0x65, 0x36, 0xc4, 0x20, 0x1c, 0x9e, 0xe8, 0xff, 0x34, 0xd8, 0x9a, 0x8f },
  { 0xde, 0x7a, 0xf3, 0xbc, 0x23, 0x2f, 0x12, 0x34, 0xc2, 0xa5, 0xd3, 0x7f, 0xdd, 0x75, 0x5e, 0x16 },
  { 0xef, 0xe6, 0xa4, 0xd9, 0x46, 0x25, 0x67, 0x3e, 0x1c, 0x72, 0x9f, 0x10, 0x2e, 0x9f, 0x19, 0x4a },
  { 0xff, 0x03, 0x4d, 0x68, 0xe2, 0x19, 0x22, 0x50, 0x0c, 0x79, 0xfa, 0xf1, 0x99, 0xf6, 0x99, 0x89 },
  { 0xbe, 0x39, 0xa7, 0xc0, 0xd6, 0x0e, 0x66, 0x53, 0x08, 0x70, 0x7b, 0x07, 0xaf, 0x7e, 0xaa, 0xff },
  { 0x44, 0xb7, 0x1a, 0x27, 0x63, 0x60, 0x5a, 0x12, 0xc2, 0x08, 0xfd, 0x3c, 0xa8, 0xe8, 0x07, 0x7d },
  { 0xa4, 0x1b, 0x38, 0x6a, 0x3a, 0xe1, 0x60, 0x6b, 0x85, 0x83, 0xcf, 0x83, 0xd8, 0x83, 0xcc, 0x97 },
  { 0xa5, 0xad, 0xb5, 0xb3, 0xfb, 0x22, 0xe7, 0xed, 0xb3, 0x11, 0x80, 0x6c, 0xd1, 0xa3, 0xb7, 0x18 },
  { 0x97, 0x98, 0xac, 0x29, 0x82, 0x7e, 0xf6, 0xe5, 0x6a, 0x76, 0x15, 0xe4, 0xfe, 0xf9, 0x8f, 0x50 },
  { 0x93, 0xe2, 0x4c, 0xce, 0x84, 0xda, 0x46, 0x28, 0x94, 0x21, 0xd7, 0x65, 0x71, 0x0c, 0x72, 0x0b },
  { 0x18, 0x71, 0xaf, 0x53, 0x9b, 0xf1, 0x16, 0x88, 0xdb, 0xd8, 0xc1, 0x53, 0x74, 0xc7, 0x60, 0x5d },
  { 0x49, 0x5f, 0xca, 0x1e, 0x7e, 0x1c, 0x5c, 0xb6, 0x3d, 0xdc, 0xf7, 0x28, 0xba, 0x79, 0xbf, 0xa2 },
  { 0x9d, 0x38, 0x49, 0x3d, 0xbe, 0x71, 0x3f, 0x93, 0x46, 0x31, 0xb7, 0x99, 0x67, 0x26, 0xd8, 0xc6 }
};

static const uint8_t aLoxPatchedMd5 [16] =
{
  0x58, 0xc1, 0x4c, 0x59, 0x2d, 0x47, 0xca, 0x22, 0xcc, 0xf8, 0x34, 0xcd, 0x63, 0x97, 0x50, 0x70,
};

const char *aLoxSubtitledCue[] =
{
  "FILE \"%s (%s) (Track 01).wav\" WAVE\n"
  "  TRACK 01 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 02).iso\" BINARY\n"
  "  TRACK 02 MODE1/2048\n"
  "    PREGAP 00:03:00\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 03).wav\" WAVE\n"
  "  TRACK 03 AUDIO\n"
  "    PREGAP 00:02:00\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 04).wav\" WAVE\n"
  "  TRACK 04 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 05).wav\" WAVE\n"
  "  TRACK 05 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 06).wav\" WAVE\n"
  "  TRACK 06 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 07).wav\" WAVE\n"
  "  TRACK 07 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 08).wav\" WAVE\n"
  "  TRACK 08 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 09).wav\" WAVE\n"
  "  TRACK 09 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 10).wav\" WAVE\n"
  "  TRACK 10 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 11).wav\" WAVE\n"
  "  TRACK 11 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 12).wav\" WAVE\n"
  "  TRACK 12 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 13).wav\" WAVE\n"
  "  TRACK 13 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 14).wav\" WAVE\n"
  "  TRACK 14 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 15).wav\" WAVE\n"
  "  TRACK 15 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 16).wav\" WAVE\n"
  "  TRACK 16 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 17).wav\" WAVE\n"
  "  TRACK 17 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 18).wav\" WAVE\n"
  "  TRACK 18 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 19).wav\" WAVE\n"
  "  TRACK 19 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 20).wav\" WAVE\n"
  "  TRACK 20 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 21).wav\" WAVE\n"
  "  TRACK 21 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 22).wav\" WAVE\n"
  "  TRACK 22 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 23).wav\" WAVE\n"
  "  TRACK 23 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 24).wav\" WAVE\n"
  "  TRACK 24 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 25).wav\" WAVE\n"
  "  TRACK 25 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 26).wav\" WAVE\n"
  "  TRACK 26 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 27).wav\" WAVE\n"
  "  TRACK 27 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 28).wav\" WAVE\n"
  "  TRACK 28 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 29).wav\" WAVE\n"
  "  TRACK 29 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 30).wav\" WAVE\n"
  "  TRACK 30 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 31).wav\" WAVE\n"
  "  TRACK 31 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 32).wav\" WAVE\n"
  "  TRACK 32 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 33).wav\" WAVE\n"
  "  TRACK 33 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 34).wav\" WAVE\n"
  "  TRACK 34 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 35).wav\" WAVE\n"
  "  TRACK 35 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 36).wav\" WAVE\n"
  "  TRACK 36 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 37).wav\" WAVE\n"
  "  TRACK 37 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 38).wav\" WAVE\n"
  "  TRACK 38 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 39).wav\" WAVE\n"
  "  TRACK 39 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 40).wav\" WAVE\n"
  "  TRACK 40 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 41).wav\" WAVE\n"
  "  TRACK 41 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 42).wav\" WAVE\n"
  "  TRACK 42 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 43).wav\" WAVE\n"
  "  TRACK 43 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 44).wav\" WAVE\n"
  "  TRACK 44 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 45).wav\" WAVE\n"
  "  TRACK 45 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 46).wav\" WAVE\n"
  "  TRACK 46 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 47).wav\" WAVE\n"
  "  TRACK 47 AUDIO\n"
  "    INDEX 01 00:00:00\n",
  "FILE \"%s (%s) (Track 02).iso\" BINARY\n"
  "  TRACK 02 MODE1/2048\n"
  "    PREGAP 00:03:00\n"
  "    INDEX 01 00:00:00\n",
  NULL
};

#endif

int redump_to_isowav(
  const char* pTitle, const char* pRedumpLanguage, const char* pIsoWavLanguage,
  unsigned uNumTracks, const unsigned* pLenTracks )
{
  int iErrorCode = -1;

  MAPPEDFILE_T cBinMapping;

  FILE * pFile = NULL;
  const char ** ppLine;

  unsigned  uTrack;
  uint8_t * pIsoTrack;
  uint8_t * pWavTrack;
  size_t    uWavTrack;
  uint8_t   aMd5 [16];

  char aFileName [256];

  static uint8_t aWavHeader [] = {
    0x52, 0x49, 0x46, 0x46,
    0, 0, 0, 0,
    0x57, 0x41, 0x56, 0x45,
    0x66, 0x6D, 0x74, 0x20,
    0x10, 0x00, 0x00, 0x00,
    0x01, 0x00,
    0x02, 0x00,
    0x44, 0xAC, 0x00, 0x00,
    0x10, 0xB1, 0x02, 0x00,
    0x04, 0x00,
    0x10, 0x00,
    0x64, 0x61, 0x74, 0x61,
    0, 0, 0, 0,
  };

  // Convert every track in the REDUMP image, except for the last track, which
  // is just a copy of the 2nd track with a few less blank sectors at the end.

  for (uTrack = 1; uTrack < uNumTracks; ++uTrack)
  {
    // Open up the REDUMP track as a memory-mapped file.

    memset( &cBinMapping, 0, sizeof(cBinMapping) );

    sprintf( aFileName, "%s (%s)/%s (%s) (Track %02u).bin", pTitle, pRedumpLanguage, pTitle, pRedumpLanguage, uTrack );

    if (!OpenMemoryMappedFile( &cBinMapping, aFileName, true ))
    {
      printf( "Failed to open file \"%s\"!\n\n", aFileName );

      printf( "Please copy the game's REDUMP image .CUE and .BIN files to the \"%s (%s)/\" directory.\n\n", pTitle, pRedumpLanguage );
      goto errorExit;
    }

    if (cBinMapping.m_uViewSize != pLenTracks[uTrack])
    {
      printf( "REDUMP file \"%s\" is the wrong size!\n\n", aFileName );
      goto errorExit;
    }

    // Verify that the track is good.

    md5_memory( cBinMapping.m_pViewAddr, cBinMapping.m_uViewSize, aMd5 );

    if (memcmp( aMd5, aLoxRedumpMd5[ uTrack - 1 ], 16 ) == 0)
    {
      printf( "REDUMP file \"%s\" MD5 checksum verified correct.\n\n", aFileName );
    }
    else
    {
      printf( "REDUMP file \"%s\" MD5 checksum is incorrect!\n\n", aFileName );
      goto errorExit;
    }

    // Output this as a ".iso" or ".wav" track?

    if (uTrack == 2)
    {
      // Copy the track's data sectors to the Japanese .ISO file.

      sprintf( aFileName, "%s (%s)/%s (%s) (Track %02u).iso", pTitle, pIsoWavLanguage, pTitle, pRedumpLanguage, uTrack );

      printf( "Converting REDUMP track %2u to \"%s\".\n\n", uTrack, aFileName );

      pIsoTrack = cBinMapping.m_pViewAddr + (3 * 75 * 2352);
    
      if ((pFile = fopen( aFileName, "wb" )) == NULL)
      {
        printf( "Failed to open Japanese .ISO file \"%s\"!\n\n", aFileName );
        goto errorExit;
      }
      while (pIsoTrack < (cBinMapping.m_pViewAddr + cBinMapping.m_uViewSize))
      {
        if (fwrite( pIsoTrack + 16, 1, 2048, pFile ) != 2048)
        {
          printf( "Failed to write Japanese .ISO file \"%s\"!\n\n", aFileName );
          goto errorExit;
        }
        pIsoTrack += 2352;
      }
      fclose( pFile );
      pFile = NULL;
    
      // Copy the track's data sectors to the translated .ISO file.

      sprintf( aFileName, "%s (%s)/%s (%s) (Track %02u).iso", pTitle, pIsoWavLanguage, pTitle, pIsoWavLanguage, uTrack );

      printf( "Converting REDUMP track %2u to \"%s\".\n\n", uTrack, aFileName );
    
      pIsoTrack = cBinMapping.m_pViewAddr + (3 * 75 * 2352);
    
      if ((pFile = fopen( aFileName, "wb" )) == NULL)
      {
        printf( "Failed to open %s .ISO file \"%s\"!\n\n", pIsoWavLanguage, aFileName );
        goto errorExit;
      }
      while (pIsoTrack < (cBinMapping.m_pViewAddr + cBinMapping.m_uViewSize))
      {
        if (fwrite( pIsoTrack + 16, 1, 2048, pFile ) != 2048)
        {
          printf( "Failed to write %s .ISO file \"%s\"!\n\n", pIsoWavLanguage, aFileName );
          goto errorExit;
        }
        pIsoTrack += 2352;
      }
      fclose( pFile );
      pFile = NULL;
    }
    else
    {
      // Copy the track's data sectors a .WAV file.

      sprintf( aFileName, "%s (%s)/%s (%s) (Track %02u).wav", pTitle, pIsoWavLanguage, pTitle, pIsoWavLanguage, uTrack );

      printf( "Converting REDUMP track %2u to \"%s\".\n\n", uTrack, aFileName );

      pWavTrack = cBinMapping.m_pViewAddr;
      uWavTrack = cBinMapping.m_uViewSize;

      if (uTrack == 3)
      {
        pWavTrack += (2 * 75 * 2352);
        uWavTrack -= (2 * 75 * 2352);
      }

      aWavHeader[4] = ((uWavTrack + 36) >>  0) & 255;
      aWavHeader[5] = ((uWavTrack + 36) >>  8) & 255;
      aWavHeader[6] = ((uWavTrack + 36) >> 16) & 255;
      aWavHeader[7] = ((uWavTrack + 36) >> 24) & 255;

      aWavHeader[40] = (uWavTrack >>  0) & 255;
      aWavHeader[41] = (uWavTrack >>  8) & 255;
      aWavHeader[42] = (uWavTrack >> 16) & 255;
      aWavHeader[43] = (uWavTrack >> 24) & 255;

      if ((pFile = fopen( aFileName, "wb" )) == NULL)
      {
        printf( "Failed to open %s .WAV file \"%s\"!\n\n", pIsoWavLanguage, aFileName );
        goto errorExit;
      }
      if (fwrite( aWavHeader, 1, 44, pFile ) != 44)
      {
        printf( "Failed to write %s .WAV file header \"%s\"!\n\n", pIsoWavLanguage, aFileName );
        goto errorExit;
      }
      if (fwrite( pWavTrack, 1, uWavTrack, pFile ) != uWavTrack)
      {
        printf( "Failed to write %s .WAV file data \"%s\"!\n\n", pIsoWavLanguage, aFileName );
        goto errorExit;
      }

      fclose( pFile );
      pFile = NULL;
    }

    CloseMemoryMappedFile( &cBinMapping );
  }

  //
  // Write the translation's new .CUE file.
  //

  sprintf( aFileName, "%s (%s)/%s (%s).cue", pTitle, pIsoWavLanguage, pTitle, pIsoWavLanguage );

  printf( "Writing file \"%s\".\n\n", aFileName );

  if ((pFile = fopen( aFileName, "wb" )) == NULL)
  {
    printf( "Failed to open %s .CUE file \"%s\"!\n\n", pIsoWavLanguage, aFileName );
    goto errorExit;
  }

#if 0
  if (fwrite( aLoxSubtitledCue, 1, strlen(aLoxSubtitledCue), pFile ) != strlen(aLoxSubtitledCue))
  {
    printf( "Failed to write %s .CUE file data!\n\n", pIsoWavLanguage );
    goto errorExit;
  }
#else

  for (ppLine = aLoxSubtitledCue; *ppLine != NULL; ++ppLine)
  {
    char aLine [256];
    sprintf( aLine, *ppLine, pTitle, pIsoWavLanguage );
    if (fwrite( aLine, 1, strlen(aLine), pFile ) != strlen(aLine))
    {
      printf( "Failed to write %s .CUE file data!\n\n", pIsoWavLanguage );
      goto errorExit;
    }
  }

#endif

  fclose( pFile );
  pFile = NULL;

  //
  // All Done.
  //

  iErrorCode = 0;

  //
  //
  //

  errorExit:

    if (pFile != NULL) fclose(pFile);

    CloseMemoryMappedFile( &cBinMapping );

    return iErrorCode;
}



// ****************************************************************************
// ****************************************************************************
//
// xdelta_patch_iso() - Patch the ISO using xdelta3 files.
//

int xdelta_patch_iso( const char* pPureIsoName, const char* pHackIsoName, const char* pLanguage )
{
  int iErrorCode = -1;

  MAPPEDFILE_T cPureMapping;
  MAPPEDFILE_T cHackMapping;

  uint8_t * pXdeltaBuffer = NULL;
  unsigned  uXdeltaLength = 0;

  usize_t uOutputLength;

  META_BLOCK_LOCATION * pMetaBlockList;

  int iResult;

  char aFileName [256];

  // Open the input and output as memory-mapped files.

  memset( &cPureMapping, 0, sizeof(cPureMapping) );
  memset( &cHackMapping, 0, sizeof(cHackMapping) );

  if (!OpenMemoryMappedFile( &cPureMapping, pPureIsoName, true ))
  {
    printf( "Failed to open file \"%s\"!\n", pPureIsoName );
    goto errorExit;
  }

  if (!OpenMemoryMappedFile( &cHackMapping, pHackIsoName, false ))
  {
    printf( "Failed to open file \"%s\"!\n", pHackIsoName );
    goto errorExit;
  }

  // Sanity check!

  if ( cHackMapping.m_uViewSize != cPureMapping.m_uViewSize )
  {
    printf( "\nThe input and output .iso files are different sizes!\n\n" );
    goto errorExit;
  }

  // Completely reset the output .iso from the source .iso.

  memcpy( cHackMapping.m_pViewAddr, cPureMapping.m_pViewAddr, cPureMapping.m_uViewSize );

  // Read all of the changes to the main executable files from an xdelta3 file.

  #if IS_XANADU1
  sprintf( aFileName, "patches/xdelta-lox1-%s/lox1-code-patch.xd3", pLanguage );
  #else
  sprintf( aFileName, "patches/xdelta-lox2-%s/lox2-code-patch.xd3", pLanguage );
  #endif
  if (!read_binary_file( aFileName, &pXdeltaBuffer, &uXdeltaLength ))
    goto errorExit;

  if (uXdeltaLength == 0)
    goto errorExit;

  iResult = xd3_decode_memory(
    pXdeltaBuffer, uXdeltaLength,
    cPureMapping.m_pViewAddr, cPureMapping.m_uViewSize,
    cHackMapping.m_pViewAddr, &uOutputLength, cHackMapping.m_uViewSize, 
    0 );

  if (pXdeltaBuffer) {
    free( pXdeltaBuffer );
    pXdeltaBuffer = NULL;
  }

  if (iResult != 0)
  {
    printf( "\nCannot xdelta3 decode the .ISO because \"%s\"!\n\n", xd3_strerror( iResult ) );
    goto errorExit;
  }

  if (uOutputLength != cHackMapping.m_uViewSize)
  {
    printf( "\nPatched .ISO is the wrong size!\n\n" );
    goto errorExit;
  }

  //
  // Locate the reorganized CD directory so that we can modify META-BLOCK file
  // lengths and positions.
  //

#if IS_XANADU1

  // XANADU 1 - Hacked CD directory information in the boot sectors

  uint8_t * pHackBank86 = cHackMapping.m_pViewAddr + 0x002800;

  uint8_t * pDirFileNameLo = pHackBank86 + (0xdd00 - 0xc000);
  uint8_t * pDirFileNameHi = pHackBank86 + (0xdd80 - 0xc000);
  uint8_t * pDirFileAddrLo = pHackBank86 + (0xde00 - 0xc000);
  uint8_t * pDirFileAddrHi = pHackBank86 + (0xde80 - 0xc000);
  uint8_t * pDirFileSizeLo = pHackBank86 + (0xdf00 - 0xc000);

#else

  // XANADU 2 - Hacked CD directory information in the boot sectors

  uint8_t * pHackBank86 = cHackMapping.m_pViewAddr +  0x002800;

  uint8_t * pDirFileNameLo = pHackBank86 + (0xdc90 - 0xc000);
  uint8_t * pDirFileNameHi = pHackBank86 + (0xdd40 - 0xc000);
  uint8_t * pDirFileAddrLo = pHackBank86 + (0xddf0 - 0xc000);
  uint8_t * pDirFileAddrHi = pHackBank86 + (0xdea0 - 0xc000);
  uint8_t * pDirFileSizeLo = pHackBank86 + (0xdf50 - 0xc000);

#endif

  //
  // Extract/Insert scripts in the META_BLOCK fles.
  //

  for (pMetaBlockList = aMetaBlocks; pMetaBlockList->m_uMetaBlock1st != 0; pMetaBlockList++)
  {
    // Unpack the META_BLOCK into its constituent DATA_CHUNKs.

    uint8_t * pMetaBlockAddr = cPureMapping.m_pViewAddr + pMetaBlockList->m_uMetaBlock1st;
    uint8_t * pMetaBlockStop = cPureMapping.m_pViewAddr + pMetaBlockList->m_uMetaBlockEnd;

    uint8_t * pSrcEnd = unpack_meta_block( pMetaBlockAddr, pMetaBlockList );

    if (pSrcEnd == NULL) goto errorExit;

    // Read all of the changes to the META-BLOCK from an xdelta3 file.

    #if IS_XANADU1
      sprintf( aFileName, "patches/xdelta-lox1-%s/lox1-data-patch-%s.xd3", pLanguage, pMetaBlockList->m_pDirectoryName );
    #else
      sprintf( aFileName, "patches/xdelta-lox2-%s/lox2-data-patch-%s.xd3", pLanguage, pMetaBlockList->m_pDirectoryName );
    #endif

    if (read_binary_file( aFileName, &pXdeltaBuffer, &uXdeltaLength ))
    {
      if (uXdeltaLength)
      {
        iResult = xd3_decode_memory(
          pXdeltaBuffer, uXdeltaLength,
          (uint8_t *) g_aMetaBlockSource, sizeof(g_aMetaBlockSource),
          (uint8_t *) g_aMetaBlockTarget, &uOutputLength, sizeof(g_aMetaBlockTarget), 
          0 );
      
        if (iResult != 0)
        {
          printf( "\nCannot xdelta3 patch META-BLOCK file %s because \"%s\"!\n\n", pMetaBlockList->m_pDirectoryName, xd3_strerror( iResult ) );
          goto errorExit;
        }

        if (uOutputLength != sizeof(g_aMetaBlockTarget))
        {
          printf( "\nPatched META-BLOCK file %s is the wrong size!\n\n", pMetaBlockList->m_pDirectoryName );
          goto errorExit;
        }
      }

      if (pXdeltaBuffer) {
        free( pXdeltaBuffer );
        pXdeltaBuffer = NULL;
      }
    }

    // Pack all the DATA_CHUNKs into a new META_BLOCK.

    pack_meta_block( pMetaBlockList->m_uMetaBlock1st, g_uMetaBlockChunks,
      g_aMetaBlockChunks, g_aDataChunkLength, g_aDataChunkOrigin,
      g_aMetaBlockExtras, g_aExtraDataLength, g_aExtraDataOrigin,
#if IS_XANADU1
      0 );
#else
      pMetaBlockList->m_uPauseMenuChunk );
#endif

    unsigned uMetaBlockLength = (unsigned) (g_pDstMetaBlockEnd - g_aDstMetaBlock1st);

    // Overwrite the old META_BLOCK with the new META_BLOCK.

    pMetaBlockAddr = cHackMapping.m_pViewAddr + pMetaBlockList->m_uMetaBlock1st;
    pMetaBlockStop = cHackMapping.m_pViewAddr + pMetaBlockList->m_uMetaBlockEnd;

    uint32_t uMetaBlockOffset = pMetaBlockList->m_uMetaStartAdd;

    memcpy( pMetaBlockAddr + uMetaBlockOffset, g_aDstMetaBlock1st, uMetaBlockLength );

    unsigned uMetaBlockSectors = (uMetaBlockLength + 2047) / 2048;

    if (pMetaBlockList->m_uMetaBlockMax)
    {
#if !HACK_FOR_JAPAN
#if IS_XANADU1
      // Increase Xanadu1 boss meta-block file length to read up to $84:B7FF

      if (memcmp("z3", pMetaBlockList->m_pDirectoryName, 2) == 0)
        uMetaBlockSectors = (pMetaBlockList->m_uMetaBlockMax / 2048) - 1;
#else
      // Increase Xanadu2 boss meta-block file length to read up to $82:BFFF.

      if (memcmp("za", pMetaBlockList->m_pDirectoryName, 2) == 0)
        uMetaBlockSectors = (pMetaBlockList->m_uMetaBlockMax / 2048);
#endif
#endif // !HACK_FOR_JAPAN
    } else {
      // Wipe the rest of the sector after the META_BLOCK.

      memset( pMetaBlockAddr + uMetaBlockOffset + uMetaBlockLength, 0, 2048 - (uMetaBlockLength & 2047) );
    }

    // Fixup the directory entry on the CD.

    const char * pFileName = pMetaBlockList->m_pDirectoryName + strlen(pMetaBlockList->m_pDirectoryName) - 3;

    uint8_t uFileNameLo = pFileName[2];
    if (uFileNameLo >= 'a') uFileNameLo -= 32;
    uFileNameLo -= (uFileNameLo >= 'A') ? ('A' - 10) : ('0');

    uint8_t uFileNameHi = pFileName[1];
    if (uFileNameHi >= 'a') uFileNameHi -= 32;
    uFileNameHi -= (uFileNameHi >= 'A') ? ('A' - 10) : ('0');

    uFileNameHi = (uFileNameHi << 4) + uFileNameLo;

    uFileNameLo = pFileName[0];
    if (uFileNameLo >= 'a') uFileNameLo -= 32;

    bool fFoundEntry = false;

    for (unsigned uDirEntry = 0; pDirFileNameLo[uDirEntry] != 0; ++uDirEntry)
    {
      if ((pDirFileNameLo[uDirEntry] == uFileNameLo) &&
          (pDirFileNameHi[uDirEntry] == uFileNameHi))
      {
        printf( "Patched and recompressed data file \"%c%02X\", was %3dKB, now %3dKB.\n",
          uFileNameLo, uFileNameHi,
          pDirFileSizeLo[uDirEntry] * 2, (uMetaBlockLength + 1023) / 1024);

        if (uMetaBlockSectors > 255)
        {
          printf( "META_BLOCK is too big (510KB max size)! Aborting!\n" );
          goto errorExit;
        }

        if (pDirFileSizeLo[uDirEntry] < ((uMetaBlockLength + 2047) / 2048))
        {
          printf( "META_BLOCK is bigger than original! Aborting!\n" );
          goto errorExit;
        }

        // Update the file's starting sector (if desired).
        uint8_t uSector = pDirFileAddrLo[uDirEntry];
        pDirFileAddrLo[uDirEntry] += (uMetaBlockOffset / 2048);
        if (pDirFileAddrLo[uDirEntry] < uSector)
          ++pDirFileAddrHi[uDirEntry];

        // Update the file's length.
        pDirFileSizeLo[uDirEntry] = uMetaBlockSectors;

        fFoundEntry = true;

        break;
      }
    }

    if (!fFoundEntry)
    {
      printf( "Could not find directory entry for META_BLOCK \"%c%02X\" $%08x!\n",
        uFileNameLo, uFileNameHi, pMetaBlockList->m_uMetaBlock1st );
      goto errorExit;
    }
  }

  //
  // Verify the MD5
  //

  uint8_t aMD5[16];
  unsigned i;

  md5_memory( cHackMapping.m_pViewAddr, cHackMapping.m_uViewSize, aMD5 );
  
  printf( "\nThe MD5 for the patched ISO is \"" );
  for (i = 0; i < 16; ++i) 
    printf( "%02x", aMD5[i] );
  printf( "\".\n" );

  if (memcmp( aMD5, aLoxPatchedMd5, 16 ) != 0)
  {
    printf( "That is not what is expected for the translation, something has gone wrong!\n" );
    goto errorExit;
  }
  else
    printf( "That correctly matches the MD5 that is expected for the translation.\n" );

  //
  // All Done.
  //

  iErrorCode = 0;

  //
  //
  //

  errorExit:

    if (pXdeltaBuffer != NULL) free(pXdeltaBuffer);

    CloseMemoryMappedFile( &cHackMapping );
    CloseMemoryMappedFile( &cPureMapping );

    return iErrorCode;
}



// ****************************************************************************
// ****************************************************************************
//
//
//

int main(int argc, char * argv[])
{
  int iErrorCode = -1;
  int i;

#if IS_XANADU1
  static const char * pTitle = "Legend of Xanadu - Kaze no Densetsu Xanadu";
  static const char * pRedumpLanguage = "Japan";
#else
  static const char * pTitle = "Legend of Xanadu - Kaze no Densetsu Xanadu II";
  static const char * pRedumpLanguage = "Japan";
#endif

#ifdef DEFAULT_FRANCAIS
  const char * pXdeltaLanguage = "francais";
#else
#ifdef DEFAULT_ESPANOL
  const char * pXdeltaLanguage = "espanol";
#else
  const char * pXdeltaLanguage = "english";
#endif
#endif

  char aSrcTrack[256];
  char aDstTrack[256];
  char aCueTrack[256];
  char aIsoWavLanguage[256];

  printf( "\n\"%s (%s)\" Xdelta3 Patcher (" __DATE__ ")\n\n", pTitle, pRedumpLanguage );

  // Really crappy parameter handling.

  for (i = 1; i < argc; i++)
  {
    char * pArgument = argv[i];

    if ((strcasecmp( pArgument, "-h" )     == 0) ||
        (strcasecmp( pArgument, "--help" ) == 0))
    {
      goto display_help;
    }

    if (strcasecmp( pArgument, "--english" ) == 0)
    {
      pXdeltaLanguage = "english";
      continue;
    }

    if (strcasecmp( pArgument, "--francais" ) == 0)
    {
      pXdeltaLanguage = "francais";
      continue;
    }

    if (strcasecmp( pArgument, "--espanol" ) == 0)
    {
      pXdeltaLanguage = "espanol";
      continue;
    }

    printf( "Unknown option \"%s\"!\n\n", pArgument );

    display_help:

    return -1;
  }

  // The aIsoWavLanguage name starts with an upper-case letter, for no great reason.

  strcpy( aIsoWavLanguage, pXdeltaLanguage);
  aIsoWavLanguage[0] = toupper( (unsigned char) aIsoWavLanguage[0] );

  // Construct the names of the .ISO files to process.

  sprintf( aSrcTrack, "%s (%s)/%s (%s) (Track 02).iso", pTitle, aIsoWavLanguage, pTitle, pRedumpLanguage );
  sprintf( aDstTrack, "%s (%s)/%s (%s) (Track 02).iso", pTitle, aIsoWavLanguage, pTitle, aIsoWavLanguage );
  sprintf( aCueTrack, "%s (%s)/%s (%s).cue", pTitle, aIsoWavLanguage, pTitle, aIsoWavLanguage );

  // If any of the files do not exist, then convert the REDUMP rip.

  if (!FileExists( aSrcTrack ) || !FileExists( aDstTrack ) || !FileExists( aCueTrack ))
  {
    // Convert the REDUMP binary rip into the more-usable .ISO/.WAV format.

    iErrorCode = redump_to_isowav(
      pTitle,
      pRedumpLanguage,
      aIsoWavLanguage,
      sizeof( aLoxRedumpSizes ) / sizeof( aLoxRedumpSizes[0] ),
      aLoxRedumpSizes);

    if (iErrorCode == 0)
      printf( "\nREDUMP image fully converted to .WAV and .ISO format and ready for patching.\n\n" );
    else
      exit( iErrorCode );
  }

  // Finally, patch the ISO.

  iErrorCode = xdelta_patch_iso( aSrcTrack, aDstTrack, pXdeltaLanguage );

  // Report the result.

  if (iErrorCode == 0)
  {
#if REMOVE_SRCTRACK
    remove( aSrcTrack );
#endif
    printf( "\n\"%s (%s)\" translation successful!\n\nWe hope that you enjoy the game!\n\n", pTitle, aIsoWavLanguage );
  }

  // All Done!

  return iErrorCode;
}
