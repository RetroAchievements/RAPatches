# legend-of-xanadu1-english

![LoX1 english logo](https://gitlab.com/legend-of-xanadu-translation/legend-of-xanadu1-english/-/wikis/home/images/lox1-panorama-with-logo.png)


## Table of Contents
--------------------

- [What is this project?](#what-is-this-project)
- [Where can you get more information about the game?](#where-can-you-get-more-information-about-the-game)
- [Who can use these patches?](#who-can-use-these-patches)
- [How do you patch your game into English?](#how-do-you-patch-your-game-into-english)
- [What do you end up with?](#what-do-you-end-up-with)
- [What can you do with the translated game?](#what-can-you-do-with-the-translated-game)


## What is this project?
------------------------

This project contains a set of xdelta3 patches that convert Falcom's 1994 Japanese game "Kaze no Densetsu Xanadu" (aka "The Legend of Xanadu") into the English language.

The game itself was written for the [PC Engine](https://en.wikipedia.org/wiki/TurboGrafx-16) videogame console in Japan, and the translated version will only run on the PC Engine or TurboGrafx-16 consoles.

**THIS REPOSITORY CONTAINS NONE OF FALCOM'S COPYRIGHTED CODE OR DATA!**

It contains only the data changes and new code that are required to make the game fully playable in English, together with a program that decompresses Falcom's files, applies the changes, and then finally recompresses the entire game using a more-efficient compression method so that the translated game still fits within the limited memory available on the PC Engine console.

**This project uses no AI-translated English text or AI-generated code.** Instead it is the product of years of hard work, a passion for the original game created by Yoshio Kiya and his team at Falcom, and lots and lots of coffee.


## Where can you get more information about the game?
-----------------------------------------------------

Please see the project's wiki [[here|home]].


## Who can use these patches?
-----------------------------

In order to legally use the patches and the patching program, you must own the original PC Engine game CD-ROM.

The patching program needs you to put a copy of a redump-compatible rip of the original game CD-ROM into the _"Legend of Xanadu - Kaze no Densetsu Xanadu (Japan)/"_ folder.

If you are not familiar with the work of the Redump project, you can read about it [here](https://wiki.redump.info/Redump).

If you need to know how to make a redump-compatible rip of your original game CD-ROM, then you can read their guide [here](https://wiki.redump.info/Disc_Dumping_Guide_(MPF)).

If you want to know what the list of the ripped files should look like, you can see the redump project's information about the Japanese "Kaze no Densetsu Xanadu" CD-ROM [here](https://redump.info/disc/36269).

If you own the original game, but do not have the specific computer hardware that is needed to make a redump-compatible rip of your CD-ROM, then you could feel that there must be somwhere on the internet where you can download an archive of the original game rip in the correct format.

You might very well think that. We couldn't possibly comment.


## How do you patch your game into English?
-------------------------------------------

If you are running a macOS operating system, then you must first install either Apple's _Xcode_, or the smaller _Command Line Tools for Xcode_ in order to compile the patching program. If you use either Homebrew or MacPorts, then either of these programs will have already installed the software that you need. If not, then please see Apple's instructions [here](https://developer.apple.com/documentation/xcode/installing-the-command-line-tools).

If you are running an Ubuntu or Debian linux operating system, then you must first install the "build-essential" package in order to compile the patching program. To do that open up a terminal window and enter `sudo apt update` then `sudo apt install build-essential`.

If you are running a Windows operating system, then Gitlab has built a Windows version of the patcher that you can run on any version of Windows back to the old 32-bit Windows 7 operating system.

- Download the latest translation release [here](https://gitlab.com/legend-of-xanadu-translation/legend-of-xanadu1-english/-/releases).
- Extract the files to your computer's drive, and you should see a _"legend-of-xanadu1-english/"_ folder.
- Copy the redump-compatible files from your rip of the original CD-ROM to the _"legend-of-xanadu1-english/Legend of Xanadu - Kaze no Densetsu Xanadu (Japan)/"_ folder.
- Open a terminal/command window in the _"legend-of-xanadu1-english/"_ folder.
- On Windows, enter the command `xdelta-patch-lox1`, on other platforms enter the command `make`.
- You should see a lot of text output, followed by a message telling you that the translation succeeded.
- That is all, you're done!


## What do you end up with?
---------------------------

When the conversion process has finished, you should end up with a set of files in the _"Legend of Xanadu - Kaze no Densetsu Xanadu (English)/"_ folder that you can burn to a CD-R disc and play in your PC Engine console. The new image can also be use with modern PC Engine emulator programs such as MesenCE, Geargrafx, etc, or on modern PC Engine hardware-emulation platforms such as the MiSTer.


## What can you do with the translated game?
--------------------------------------------

Enjoy playing it, we hope!

The original game is copyright 1993 by Falcom. These patches contain English-language text and program code that is copyright 2026 by the authors of this project.

The translation patches are licensed to users under the [CC BY-NC-SA license](https://creativecommons.org/licenses/by-nc-sa/4.0/) for non-commercial use only. **That specifically means that this translation should not be used for the manufacturing or sale of English-language reproduction CD-ROMs of Falcom's copyrighted game.**

The patching program that applies the patches to a copy of the CD-ROM files is separately licensed to users under the [Apache 2.0 license](https://www.apache.org/licenses/LICENSE-2.0) because of its inclusion of Josh MacDonald's xdelta3 library code.
