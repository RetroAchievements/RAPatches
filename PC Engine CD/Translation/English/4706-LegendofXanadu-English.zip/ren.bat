@echo off
setlocal EnableDelayedExpansion
for %%F in ("*(English)*") do (
    if not exist "%%~fF\" (
        set "name=%%~nxF"
        ren "%%F" "!name:(English)=(Japan) (En) (1.0) (John Brandwood & Samuel Innes)!"
    )
)