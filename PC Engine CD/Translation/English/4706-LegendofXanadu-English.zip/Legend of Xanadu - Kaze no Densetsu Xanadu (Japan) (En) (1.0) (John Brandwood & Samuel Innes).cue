FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 01).wav" WAVE
  TRACK 01 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 02).iso" BINARY
  TRACK 02 MODE1/2048
    PREGAP 00:03:00
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 03).wav" WAVE
  TRACK 03 AUDIO
    PREGAP 00:02:00
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 04).wav" WAVE
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 05).wav" WAVE
  TRACK 05 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 06).wav" WAVE
  TRACK 06 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 07).wav" WAVE
  TRACK 07 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 08).wav" WAVE
  TRACK 08 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 09).wav" WAVE
  TRACK 09 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 10).wav" WAVE
  TRACK 10 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 11).wav" WAVE
  TRACK 11 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 12).wav" WAVE
  TRACK 12 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 13).wav" WAVE
  TRACK 13 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 14).wav" WAVE
  TRACK 14 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 15).wav" WAVE
  TRACK 15 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 16).wav" WAVE
  TRACK 16 AUDIO
    INDEX 01 00:00:00
FILE "Legend of Xanadu - Kaze no Densetsu Xanadu (Japan) (En) (1.0) (John Brandwood & Samuel Innes) (Track 02).iso" BINARY
  TRACK 17 MODE1/2048
    PREGAP 00:03:00
    INDEX 01 00:00:00
