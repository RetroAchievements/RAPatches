Use with:

(Redump)
File:               Bazar de Gozarre no Game de Gozarre (Japan) (Track 02).bin
BitSize:            32 Mbit
Size (Bytes):       4238304
CRC32:              B94ED469
MD5:                0D1CF7F122311978FCDA66CE2FBDA964
SHA1:               6F3405324CC47B46C562603CB77AC0EB5D4A5B52
SHA256:             32BF245F30B5768DC650340023921F7AB906C2B9424EB8C7B0CD29DD470435C4