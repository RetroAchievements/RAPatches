Patch must be applied to "Emerald Dragon (Japan) (Rev 1)"

http://redump.org/disc/32497/



Instructions:

1. Copy/extract the .cue and 31 .bins to the patch directory
2. Drag "Emerald Dragon (Japan) (Rev 1)).cue" onto "ed_rev1_patcher.bat"
3. That's it!