@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\Ys4Merged.bin
set delta_file=%CD%\patch\Ys IV - The Dawn of Ys (Japan) (En) (v0.95) (NightWolve).xdelta
set output_file=%CD%\Ys IV - The Dawn of Ys (Japan) (En) (v0.95) (NightWolve).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Ys IV - The Dawn of Ys (Japan) (Rev 3)\Ys IV - The Dawn of Ys (Japan) (Rev 3).cue" "%CD%\Ys4Merged"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\Ys4Merged.bin"
DEL "%CD%\Ys4Merged.cue"

pause
