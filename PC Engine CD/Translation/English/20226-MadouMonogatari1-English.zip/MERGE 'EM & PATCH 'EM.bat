@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\MadouMerge.bin
set delta_file=%CD%\patch\Madou Monogatari I - Honoo no Sotsuenji (Japan) (En) (v1.0) (LIPEMCO! Translations).xdelta
set output_file=%CD%\Madou Monogatari I - Honoo no Sotsuenji (Japan) (En) (v1.0) (LIPEMCO! Translations).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Madou Monogatari I - Honoo no Sotsuenji (Japan)\Madou Monogatari I - Honoo no Sotsuenji (Japan).cue" "%CD%\MadouMerge"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\MadouMerge.bin"
DEL "%CD%\MadouMerge.cue"

pause
