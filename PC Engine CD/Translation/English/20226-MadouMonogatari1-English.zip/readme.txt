﻿********************************************************************************
*            Madou Monogatari I: Honoo no Sotsuenji (PC-Engine CD)             *
*                          English Translation Patch                           *
*                           by LIPEMCO! Translations                           *
*                              v1.0 (13 Dec 2020)                              *
*                                                                              *
*                               Supper -- Hacking                              *
*                        TheMajinZenki -- Translation                          *
*                               cccmar -- Editing and Testing                  *
*                             Xanathis -- Testing                              *
********************************************************************************

Sorcery Kindergarten has very strict requirements for graduation. Indeed, this 
year, only one person even qualified to take the final exam at all: six-year-old 
Arle Nadja, who now faces the daunting task of climbing the monster-infested 
Magic Tower and retrieving the three Magic Orbs hidden within in order to 
graduate. What trials await Arle inside the Tower? Can she pass the test, or 
will she be doomed to another year of kindergarten?

Madou Monogatari I: Honoo no Sotsuenji (Sorcery Saga I: The Fiery Kindergarten 
Graduation) is a 1996 dungeon crawler for the PC-Engine Super CD-ROM² system. 
It's a remake of the first game in the Madou Monogatari series, originally 
developed by Compile for the MSX2 computer and subsequently ported to several 
other platforms. The various ports differ wildly from each other, sometimes to 
the point of being almost completely different games; though the PC-Engine 
version is based on the original home computer editions, it adds high-quality 
cutscenes, CD audio, near-full voice acting, and many extra events, monsters, 
and items.

Released in limited quantities at the very, very end of the PC-Engine's 
lifespan, the game is somewhat notorious for its rarity, often fetching the 
equivalent of $400+ in Japanese auctions on the rare occasion it's sold at all.

This patch fully translates the game into English. In addition to translating 
the text, subtitles have been added to cutscenes which were originally 
voice-only.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Additional Features
  IV.   Authors' Comments
  V.    Special Thanks
  VI.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard extensions used in this 
section, or use them differently from normal, which makes things very confusing. 
Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distribution 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent the Redump disc image, just split up into its 
component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

Note that regardless of how you patch, the translated disc image will be 
somewhat smaller than the original. This is normal and intended; the original 
game makes use of a PC-Engine CD BIOS feature that allows a redundant copy of 
the game data to be stored on the disc and automatically used if the primary 
version gets damaged. (Actually, the game doesn't set it up correctly and so it 
probably doesn't work at all, but it's the principle of the thing.) This is not 
important in the context of a translation patch – emulated discs should never 
get "damaged", and if you're playing on real hardware and manage to corrupt the 
disc, then you can presumably burn another copy at your leisure. So we decided 
to save ourselves the hassle and you the hard drive space by just getting rid of 
the redundant data.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches the 
verified "good" image as listed on Redump.org, and if all the tracks on the disc 
are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  Redump name: Madou Monogatari I: Honoo no Sotsuenji
  CRC32:       c9725820
  MD5:         59c01f94b3c991c3509620430cf95c0a
  SHA-1:       8e583b2c38736871aa44ba842291f257f9b5af34

See Redump for full details: http://redump.org/disc/37150/

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with one of the CUE files 
provided in the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch file in the "redump_patch" folder.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the patch to 
the BIN or IMG file. If you get an error, you'll need to try one of the other 
patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Madou Monogatari I - Honoo no Sotsuenji EN [v1.0] Redump.cue". Rename your 
patched disc image so it has *exactly* the same name as the CUE, except with a 
.bin extension instead of .cue.
     Important: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc image, but splits it up into separate tracks instead of 
combining them into a single file. It's easily recognized by the presence of 32 
separate BIN files and a single CUE.
  
  Before patching: 
  
  - Make sure that your disc's CUE file has a name like "Madou Monogatari I - 
Honoo no Sotsuenji (Japan).cue".
  
  - Make sure that the BIN files are named in the format "Madou Monogatari I - 
Honoo no Sotsuenji (Japan) (Track 01).bin", "Madou Monogatari I - Honoo no 
Sotsuenji (Japan) (Track 02).bin", etc., up through "Madou Monogatari I - Honoo 
no Sotsuenji (Japan) (Track 32).bin".
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch.bat".
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump dump, or you otherwise couldn't get method 
A to work, it may still be possible to patch it. If your disc is in BIN+CUE 
format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"madou1.bin" and "madou1.cue", or "madou1.img" and "madou1.cue"). Note that if 
you rename the BIN file, you will need to open your CUE in a text editor and 
make the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat".
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up (which, misleadingly, tells you that you need an Arcade Card to 
play). Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

Just to add an extra layer of madness, this game also requires an additional 
peripheral to run: the Arcade Card, an add-on that provides extra RAM. 
Fortunately, the Arcade Card doesn't require any extra BIOS images; assuming 
your emulator supports it in the first place, it's probably enabled by default, 
and you shouldn't have to worry about it. If you're trying to play on a real 
console... well, good luck navigating the gigantic mess that the PC-Engine's 
hardware revisions are.

Finally, make sure to run the game in two-button Control Pad mode. The PC-Engine 
was originally released with controllers that had two buttons, but later had 
upgraded controllers released with six buttons. The six-button controllers use a 
different protocol from the two-button controllers, meaning that games that 
weren't specifically designed to support them – including this one – will have 
"glitchy" input unless the controller is put in two-button compatibility mode. 
Emulators will generally default to two-button mode, but if you have problems 
with the game pressing buttons on its own, check your emulator's settings.

                    ****************************************
                    *       III. Additional Features       *
                    ****************************************

In addition to the translation, this patch makes one small but very important 
change: in the original game, it's impossible to skip voice clips. If voice 
samples are turned on in the options, you're obliged to listen to every single 
one, in full, every time it plays, and can't continue the game until it 
finishes. This makes for a very, very bad combination with the game's near-full 
voice acting; consider the fact that you have to listen to a lengthy voice clip 
every time you look at the map, view an item's description, purchase something 
in a shop...

Since the voice acting is one of the game's central attractions, and it's really 
a shame that poor design encourages players to turn it off, we've taken the 
liberty of modifying the game so that voice clips can be cut off by pressing any 
button while they're playing, making for much smoother and less 
headache-inducing gameplay. Hope no one feels they're missing out by not being 
able to experience the agony of having to constantly wait for Arle to finish 
informing you that THIS IS THE THIRD FLOOR OF THE MAGIC TOWER before you can 
close the map.

During the course of this project, we also discovered that the game was intended 
to have cheat codes to view its cutscenes from the title screen (a common 
feature for PCECD games). While these cheat codes were fully programmed and are 
active in the released game, due to a bug, using them will just display a 
loading screen and then crash the game. Since that's kind of a shame, we also 
fixed the codes up to work properly:
  * To view the cutscene that plays before the final boss, hold Button I and 
press Run at the title screen.
  * To view the ending scene and credits, hold Button II and press Run at the 
title screen.
  
                    ****************************************
                    *        IV. Authors' Comments         *
                    ****************************************

  -------------------
  -- TheMajinZenki --
  -------------------

  LIPEMCO! *Another Madou Monogatari translation appeared!*
Honestly I've become very charmed by this series, with its lighthearted tone and 
the small scale adventure (Arle isn't out to save the world, at least not in 
these games).
Most of the non-story text is shared between the games, so it was mostly a 
matter of touching up the differences and translating the script. This version 
of the game add some conversation with both recurring characters from the other 
versions and some new ones as well. The hardest part from a translation 
perspective, as usual, was conveying some of the word puns that are ubiquitous 
in Japan. Some of the monsters unique to this version especially have names that 
have multiple layers of puns, from what they look like, what they're doing, and 
what they're called... it's like three puns in one.
At any rate, I hope you enjoy this version of Madou Monogatari I!

  ------------
  -- cccmar --
  ------------

  Madou Monogatari PCE-CD is a very late PCE-CD dungeon crawler and the final 
port of the MSX original, released around 6-7 years earlier. This game is 
actually much simpler than its Mega Drive counterpart when it comes to gameplay 
itself. It’s a much more basic turn-based dungeon crawler, in which Arle must 
get through the entire tower to graduate. Pretty much all of the characters are 
different in this one, except for the teacher, and there are many new enemies to 
battle as well. The puzzles themselves also differ a lot from the ones found in 
the Mega Drive title. In general, this game’s theme is the most 
“Buddhist/Shinto” out of the Madou Monogatari games we worked on. What’s more, 
it’s also the most punny game out of the bunch. Some examples include a 
character named Hattari (“bluff” – you’ll see why when you play the game), a few 
‘misheard’ words, references to Japanese commercials and enemy names which are 
puns themselves (Penny-Pinching Turnip for example was originally a 
lobster/turnip/stocks pun – all in one monster name). Overall, I’d say it’s a 
shorter and easier game than the Mega Drive port, but it has the usual PCE-CD 
voice acting. Hope you enjoy it and compare the game to the other ports, to see 
how many things are different!
  
  ------------
  -- Supper --
  ------------

  "In addition to translating the text, subtitles have been added to cutscenes 
which were originally voice-only." Oh, it sounds so simple when you just write 
it out like that...
  
  Well, here we are with Madou Monogatari I, again, but actually it's a totally 
different game from the Mega Drive version that we translated earlier this year, 
because this series makes no damn sense. Seriously, even though the Mega Drive 
and PC-Engine versions came out the same year and are supposedly remaking the 
same game, they have only passing similarities: "Oh, there's a puzzle where you 
have to make walls to proceed," or "Oh, this monster was in the other version 
too." This port hews closer to the original MSX2 game, but it's still a 
radically different experience from that or any other version of the game.
  
  This being... what, the fifth time?... that I've worked on a Madou Monogatari 
game, I'd like to think I know a thing or two about the series at this point. 
Personally, I think this port is a bit meh, especially compared to the 
extravagantly enhanced Mega Drive version. The visuals are slick, the remixed 
music is nice, and the full voice acting is neat (they even got Kotono 
Mitsuishi, best known as the voice of Sailor Moon, as Arle)... but the gameplay 
just isn't polished. Most battles are nothing more than "hit the enemy with 
their weakness twice to beat them". Bosses are few and far between. The new 
characters and events are generally bland and forgettable, and occasionally 
creepy in all the wrong ways. And don't even get me started on the unskippable 
voice clips, which were so torturous that the very first thing I hacked in, 
before touching anything else, was the ability to skip them...
  
  But it's still Madou Monogatari, and considering we got our translation 
group's name from the series, we're pretty committed at this point. So we 
translated it, and I desperately hope someone out there will appreciate the work 
that went into it. You know that scene in the opening where the camera slowly 
pans down the Magic Tower as Arle narrates? That sequence alone took me upward 
of 10 hours to add subtitles to. I think I've figured out why pretty much 
everyone else who's ever translated a PCECD game opted to do a dub instead. (In 
fact, from a glance at the bare handful of PCECD fan translations that even 
exist, it seems we may actually have been the first to sub a game instead of 
dubbing it...)
  
  After compressing and inserting the translated text into the game, I 
discovered I had almost an entire RAM bank free to play around with, so I 
decided to go all-out and use it to convert the text box from three lines to 
four, and implement fully in-engine dynamic word wrapping (only the second time 
I've bothered, after those damn Bahamut Senki advisor messages where I had no 
choice). Honestly, it's probably better than the game deserves, but I do think 
the results look pretty nice. I finally even got to reuse the painstakingly 
crafted font from the Mega Drive version!
  
  Anyway, don't let my griping scare you off. Hope you enjoy this weird version 
of a weird game, even if it wasn't my cup of (skeleton) tea. It's certainly not 
a bad game, just a strange one. And it's got the melting zombie kids in it, 
which I'm sure will please someone.
  
  And to that one person who's going to demand an explanation for the Pokemon 
reference: it was originally a tagline from a Japanese detergent commercial. 
We're aware the replacement is slightly anachronistic. We tried.

                    ****************************************
                    *          V. Special Thanks           *
                    ****************************************

Thanks to 喜楽ミズ for making Japanese transcriptions of the game's voice-only 
cutscenes, which can be found here: 
http://okiraku06.lolipop.jp/okiraku/de-tama.htm

Thanks to elmer for providing immensely helpful resources and support for 
PC-Engine hacking, including a special bugfixed Windows binary of bchunk that's 
used in the patching process.

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *         VI. Version History          *
                    ****************************************

v1.0 (13 Dec 2020): Initial release.
