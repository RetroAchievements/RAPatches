@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\PrivateMerge.bin
set delta_file=%CD%\patch\Private Eye Dol (Japan) (En) (v1.0) (Supper).xdelta
set output_file=%CD%\Private Eye Dol (Japan) (En) (v1.0) (Supper).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Private Eye dol (Japan)\Private Eye dol (Japan).cue" "%CD%\PrivateMerge"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\PrivateMerge.bin"
DEL "%CD%\PrivateMerge.cue"

pause
