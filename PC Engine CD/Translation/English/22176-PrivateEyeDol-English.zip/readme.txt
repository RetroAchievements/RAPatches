﻿********************************************************************************
*                               Private Eye Dol                                *
*                          English Translation Patch                           *
*                              v1.0 (12 Jan 2023)                              *
*                                                                              *
*                               Supper -- Hacking and Translation              *
*                               cccmar -- Testing                              *
*                             Xanathis -- Testing                              *
********************************************************************************

Up-and-coming teen actress May Star thought the filming for her latest TV 
special would be a chance to enjoy some time with her friend Ayaka and new 
prototype AI partner Navi. Instead, it unexpectedly erupts into mystery and 
tragedy, leaving May the only one who can solve a baffling crime. Good thing 
she's a detective's daughter! But this proves to be only the beginning of a 
tangled saga, as May finds herself inexorably drawn into a web of incidents 
involving lies, corruption, and her own father's mysterious suicide five years 
ago. Can May and her friends catch the culprits – or will this be their last 
shoot?

Private Eye Dol (also known as "Private Eyedol", with many variations in 
capitalization) is a 1995 detective adventure game developed by HuneX and 
published by NEC Home Electronics for the PC-Engine Super CD-ROM² system. 
Released late in the PC-Engine's lifespan, it showcases a highly polished 
presentation that often makes it feel more like a next-generation game, with 
large and detailed graphics, full voice acting, and features such as text 
scaling that are rarely seen on the console. Perhaps its biggest distinguishing 
element is its RPG-like overworld, which provides a higher degree of freedom 
compared to traditional menu-driven Japanese detective games.

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Known Issues
  IV.   FAQ
  V.    Cheat Codes
  VI.   Bonuses and Easter Eggs
  VII.  Author's Comments
  VIII. Special Thanks
  IX.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image 
format it reasonably can. Though the Redump-verified disc image is a definite 
plus, options are provided to patch pretty much any image so long as it has the 
correct data track. If you don't have the Redump image, just go ahead and try to 
patch whatever you have using whichever of the options below applies to it.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches the 
verified "good" image as listed on Redump.org, and if all the tracks on the disc 
are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  Redump name: Private Eye dol
  CRC32:       80d5f718
  MD5:         b8d7b3de039fe5dcaf3149b3da0ae654
  SHA-1:       5502081d84ce4b036b81b35471b56a6cd510c80a

Consult Redump for full details: http://redump.org/disc/37189/

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch file in the "redump_patch" folder.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the patch to 
the BIN or IMG file. If you get an error, you'll need to try one of the other 
patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Private Eye Dol EN [v1.0] Redump.cue". Rename your patched disc image so it has 
*exactly* the same name as the CUE, except with a .bin extension instead of 
.cue.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc image, but splits it up into separate tracks instead of 
combining them into a single file. This is easily recognized by the presence of 
25 separate BIN files and a single CUE.
  
  Before patching:
  
  - Make sure that your disc's CUE file has a name like "Private Eye dol 
(Japan).cue".
  
  - Make sure that the BIN files are named like this:
      Private Eye dol (Japan) (Track 01).bin
      Private Eye dol (Japan) (Track 02).bin
      …
      Private Eye dol (Japan) (Track 25).bin.
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch.bat".
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump dump, or you otherwise couldn't get method 
A to work, it may still be possible to patch it. If your disc is in BIN+CUE 
format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"pidol.bin" and "pidol.cue", or "pidol.img" and "pidol.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat".
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patch in the "auto_patch" directory to 
the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do this 
is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

** NOTE: This patch was developed and tested using two forks of v1.29.0 of the 
Mednafen emulator: the mainline version that you'll find if you search for 
"Mednafen", and the "pceDev" fork that has improved PC-Engine features and 
accuracy (https://github.com/pceDev16/mednafenPceDev/). Currently, playing the 
unpatched version of this game on mainline Mednafen will cause it to hang during 
an early cutscene due to inaccurate disc seek timing. While the translation 
contains extra code to prevent this from happening, I strongly recommend using 
the pceDev fork to play if possible; its improved accuracy means the cutscene 
visuals will properly synchronize with the audio, unlike in standard Mednafen.



If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up. Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

Additionally, make sure to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with the game not accepting input or pressing buttons on its 
own, check your emulator's settings.

                    ****************************************
                    *          III. Known Issues           *
                    ****************************************

- The "Private Talk" voice actor commentary that can be accessed using the 
"Green Room" code isn't translated, because I had to draw the line somewhere and 
"subtitling 15 minutes of irrelevant voice actor chatter" was where I put it. 
Sorry if you're dying to understand every word of Sakura Tange's press statement 
or whatever, but I had no desire to increase my subtitling load by half again 
over a minor bonus feature most people will never see. I did everything else in 
this rather long game by myself; please give me this!

- I've attempted to translate the Backup Utility accessible from the title 
screen, and as far as I can tell, all the resources should be translated and 
show up when they're supposed to. However, because most of the utility's 
functionality requires the Memory Base 128 peripheral, which the emulator used 
for development doesn't support, it's largely untested. If you try it out and 
find a problem, feel free to report it, but until it's properly emulated, I may 
not be able to do much to fix it.

                    ****************************************
                    *               IV. FAQ                *
                    ****************************************
  
Q. How come the game will only let me save to the first save slot, the "White 
Script"?

A. Because the game's save files are very large (one save takes up over a third 
of the built-in backup memory), the developers decided to only allow you to use 
one save file by default. To use save slots other than the first, you must have 
an extra peripheral, the Memory Base 128, which contains additional save memory. 
(Deliberately designing an inefficient save system to incentivize buying more 
hardware? Oh, surely not!)

    Note that as of this writing, the Memory Base 128 is not widely emulated, so 
depending on your setup, you may be stuck with just the one slot.

Q. This game is supposed to be "Arcade Card compatible." What does that mean?

A. With no Arcade Card plugged in, the full-size character portraits shown 
during conversations have to be read from the disc every time they're used, 
resulting in a considerable loading delay (~1-2 seconds) every time the portrait 
changes. This will be further exacerbated if voice acting is enabled due to the 
game having to seek between different parts of the disc for the graphics and 
sound. That's why both of these features can be disabled in the options, and 
it's probably a good idea to turn off at least one of them if you don't have an 
Arcade Card.

   If you have an Arcade Card plugged in, however, the game will preload all the 
portraits to it at the start of each Scene (case), allowing them to be displayed 
almost instantly. This means there will be a loading screen when you first start 
the game or move to a new scenario, but given the drastic speed improvements 
during gameplay, it's well worth it.

Q. I'm stuck! What do I do next!?

A. Well, if you're not the type to look things up from a playthrough video, here 
are a few more or less spoiler-free tips for common sticking points. If you're 
in need of a complete walkthrough, please learn Japanese, then consult PC Engine 
Fan's August 1995 edition (Volume 8, Issue 8), pp. 60–63. Seriously, it's the 
only guide I've found in any language.

  -----------
  - Scene 1 -
  -----------
  
  - Make sure to check all the rooms. If at any point nothing seems to be 
happening, just walk around and check them again. Easy as that.

  -------------------
  - Scene 2, Part I -
  -------------------
  
  - If things aren't moving forward, try asking important people about their 
keys again.
  - Check the bathroom in Cabin 1.

  --------------------
  - Scene 2, Part II -
  --------------------
  
  - When in doubt, try the substation or Tengu Rock.

  -----------
  - Scene 3 -
  -----------
  
  - Go downtown and check the surroundings, carefully.
  - Try to go into the old apartments, and be sure to check the surroundings 
carefully afterwards.
  - Check Sonoki's apartment again.
  - Go downtown and see if anyone you recognize is at MAGSAX.
  - See who's at Sun Dance.
  - Check Kinoshita's apartment again.
  - If you get into the parking garage but can't seem to do anything there, try 
going to Sun Dance again.

Q. What's the correct spelling of the game's title?

A. Game logo: "Private eye dol". Credits: "Private eyedol". Art gallery: 
"PRIVATE EYEDOL". User manual: プライベート・アイ・ドル. Rolfee: プライベートアイドル. Redump: 
"Private Eye dol". In short: no one knows, including the people who made it, so 
I'm going with "Private Eye Dol" because that's how capitalization is supposed 
to work. I would personally prefer "Private Eyedol", but what few 
English-language resources for the game exist already use the three-word 
spelling, and there's not much point in further confounding the issue.

                    ****************************************
                    *            V. Cheat Codes            *
                    ****************************************

This game has several cheat codes for accessing bonus features. The codes have 
been known almost as long as the game's been out (see PC Engine Fan's coverage) 
and are pretty much the only aspect of the game that's already documented in 
English, but in the interest of collecting as much information about this 
obscure game as possible in one place, I'm listing them here.

If nothing else, you absolutely must check out the art gallery once you've 
beaten the main game. You haven't really finished until you've cleared it!
  
  - Art Gallery: Hold Button I while booting the game until the title menu 
appears (the intro will not appear at all if this is done correctly). Then press 
Up, Down, Left, Right, Up, Down, Select, Button II. This will take you to a 
special playable bonus area. In addition to the advertised cutscene viewer and 
music player, it also has a hidden "sidequest" of sorts – check out the gap on 
the right side of Yoh's room, at the very back of the area. Note that once 
you've started this "quest", you can get hints for it by pressing Button II.

  - Green Room: At the title menu, while holding Select and Right, choose the 
"Start" option. Contrary to what most cheat sites claim, you don't need to hold 
Button I while booting the game for this to work. A menu will appear allowing 
you to listen to extensive voice actor commentary (not translated, sorry) and 
view a karaoke sequence of the theme song, with or without vocals.
  
  - Scenario Select: As with the Art Gallery, hold Button I as the game boots 
until the title menu appears. Now, like with the Green Room, hold Select and a 
direction on the D-Pad while selecting the "Start" option to begin the game from 
a particular scenario:
    - Select + Up: Scene 2, Part I
    - Select + Down: Scene 2, Part II
    - Select + Left: Scene 3

                    ****************************************
                    *     VI. Bonuses and Easter Eggs      *
                    ****************************************



** WARNING: This section contains some spoilers! You probably shouldn't read it 
until you've beaten the game.



Due to this game's undeserved obscurity, it's hard to find much information 
about it in Japanese, much less English. This makes it very easy to miss out on 
some interesting content, so I've decided to collect all the hard-to-find stuff 
that I know of in this section to make it a little more accessible.

  -----------
  - Scene 1 -
  -----------

  - After questioning Motoko about Kanna's disappearance, leave Motoko's room 
and walk down the hall. Navi will remark about Ayaka not being back yet. At this 
point, you can go back to Motoko and ask her to tell Ayaka to wait in her room 
if she comes back. If you do, when Motoko gets up and leaves her room after a 
while (this is based on a real-time timer), she'll put a note on the door to 
May's room. None of this ultimately has any bearing on the plot, but it's easy 
to miss since the game never makes any mention of it and you're locked out of it 
after a few minutes.

  - Immediately after the first "case review" with Navi, when regular gameplay 
resumes in May's room, Yuuko will be taking a shower downstairs. Predictably, if 
you go there, you're given the option to peep on her. You can no longer do this 
once you take the much more logical action of talking to Motoko, making it easy 
to overlook (probably on purpose).
  
  - After finding the sleeping pill on the pedestal, leave and head towards 
May's room without investigating anything else. Yuuko will be standing next to 
Ayaka in May's room, and will leave and return to her own room as you approach. 
The significance of this is never actually explained, so you'll have to come up 
with your own interpretation.
  
  - During the climax, most players will just take one of the obvious escape 
routes, but there are some interesting outcomes if you take less intuitive 
actions:
    - You can't lose on the first move, and there's different dialogue for every 
possible action (moving in any of the four directions or doing nothing).
    - Several routes result in extra dialogue:
      - Down, Down, Right (pinned in the corner, game over)
      - Down, Right, Left (successful escape; most people would never try this 
because it involves moving straight toward the attacker, which is a game over in 
almost every other situation)
      - Down, Left, Up (game over)

  -------------------
  - Scene 2, Part I -
  -------------------

  - Talking to the person you've set as the culprit yields unique dialogue. You 
can usually do it twice to get different lines.
  
  - When searching for the ring, set the navigator as the culprit and examine 
the anchor chain at the bow.

  --------------------
  - Scene 2, Part II -
  --------------------

  - Once you unlock the "Beach" location, instead of putting it in its proper 
location, place it on one of the shore tiles on the west side of the map. If you 
then try to go there, you'll get a small bonus scene. You can't do this once 
you've put it in the correct position, or once Motoko has left.
  
  - After investigating the crime scene at the Noctilucent Cave, when you're 
supposed to talk to Watabe and Sakaki in the hotel lobby, ignore them and go to 
the third floor for a small gag involving Kihara.
  
  - The morning after the incident, immediately leave the hotel and go to the 
Noctilucent Cave to find the old woman standing outside.
  
  - After the old woman screams at Watabe at the substation, she can be found at 
the harbor.

  -----------
  - Scene 3 -
  -----------

  - When ordering at Sun Dance, the game accepts a number of unlisted passwords. 
It's not terribly exciting, though; they have no effect beyond the owner going 
through the same "fetching an order" animation as for any other valid entry that 
isn't the "real" password. There's unused text indicating it was originally 
supposed to be possible to place orders at MAGSAX, so these entries may actually 
be a leftover from that. Whatever the case, here they are:
      - カフェオレ (CAFE AU LAIT)
      - ココア (COCOA)
      - メロンソーダ (MELON SODA)
      - コーラ (COLA)
      - メイスター (MAY STAR)

  - After the shooting, return to District 2 and, disregarding Navi's warnings, 
attempt to reenter Sun Dance to get a unique game over.

  - At the end of the credits is a copyright message. Waiting for several 
minutes on this screen will cause a series of messages to appear, eventually 
resulting in the game giving you the code to access the "Green Room" described 
above.

                    ****************************************
                    *        VII. Author's Comments        *
                    ****************************************
  
  I've been doing this fan translation thing for a good five years or so now, 
and in all that time, I don't think I've ever come across a game quite so 
thoroughly and undeservedly forgotten as Private Eye Dol.
  
  Let's start with how I discovered the game. Was it on a game recommendations 
list? Nope. A "gee, I wish someone would translate this for me" plug in some 
forum post or chat message? No, not that I'm generally paying much attention to 
those anyway. One of those green-label "good game" listings on the Game Catalog 
@Wiki? A remarkably canny guess, but nope! Just a random offhand mention 
somewhere or another? No, no, no, I never heard a whisper about this game 
anywhere. I found it only when I was going through the entire list of PC-Engine 
games and checking out the ones with interesting titles (my holding pattern 
whenever I run out of translation projects to work on).
  
  So I boot up this game I've never heard of, with absolutely no idea what to 
expect, and start playing. Okay, it's an adventure game, one of the Japanese 
ones that's all menus. I've played more Galaxy Fraulein Yuna than anyone ever 
should, I'm cool with that, I'll go till it gets boring. Click through the 
character intros, get to the next area, nice spooky mansion. Click through more 
dialogue. Maybe the "Move" menu will be opening up soon to let me go inside? 
Then suddenly lightning strikes and thunder crashes and I've been transported 
into an RPG Maker adventure game, and it turns out that that's the REAL game. 
It's probably completely unintentional, but it's an amazing fake-out if you 
don't know what's coming.
  
  Anyway, I was hooked after that, and I went through the game as fast as I 
could. (Which would have been faster if things didn't abruptly grind to a halt 
an hour in while I worked out a way to keep Mednafen from freezing on the second 
cutscene – this furthers my theory that absolutely no one else has played this 
game.) I was utterly blown away by the quality of what I was experiencing. Going 
through basically random games the way I was, you'll find some trash, you'll 
find a lot of mediocre-to-decent titles, but it's very rare to pull up some 
no-name game and find unqualified excellence.
  
  My comment at the time was that this game often feels more like it's on the 
PlayStation than the PC-Engine, and working on it for this project has only 
furthered the impression. Character movement uses the wall-pushing mechanic seen 
in games like Lunar for more fluid navigation. Every single line of dialogue is 
voiced. Text is outlined, colored, even scaled! On the PC-Engine! A 10-hour 
mystery story. The obligatory animated cutscenes. New gimmicks every case. A 
surprise vocal song at the end. Hell, it's even fun, too.
  
  Thus enamored, I looked the game up after I'd finished, thinking something 
this good must be famous somewhere and I'd just missed all discussion of it 
somehow…but no. You might think it'd come up in Japanese net circles, but it's a 
rare topic even there. You'll find plenty about comparable contemporaries like 
the esteemed Yuna series, but Private Eye Dol is just a footnote.
  
  As for the West? Well, here's the PC Engine Software Bible's entry on the 
game, in its entirety: "Girlie digital comic." That's about as much information 
as I could find about it in English anywhere. (Sorry to pick on you, paul, but 
please get a little further into the game before you jump to conclusions!)
  
  With that, it was pretty obvious what I had to do next. So I did a bunch of 
disassembly work, made a decoding table for the text, and then in typical 
fashion proceeded to forget about the game for months. I finally remembered it 
later in the year and said, "You know, I should probably do something with 
this," then got to work for real.
  
  This wasn't an easy game to work on. It was a fun one…as translation hacks go, 
anyway…but it was a heavy workload for a one-person project. Text was compressed 
and had to be decoded for translation, and then a new compression had to be 
implemented so the translated text would fit back in the game. The original 
three-line text box wasn't going to cut it, so I redid large swaths of the 
printing system to make it four lines instead (while maintaining a working 
three-line mode for use in menus). The text scaling algorithm – whose programmer 
was very VERY proud of their work, judging by how often it's used – had to be 
almost totally redone to work with a variable-width font. Subtitles had to be 
added not only to two different types of cutscenes, but several in-game 
sequences as well. And let me tell you, that password screen in the last case 
was fun…
  
  Oh yeah, and I had to translate some 150,000+ characters of text plus over 
half an hour of audio, which worked out to be over three times longer than 
anything I'd ever done before. The final translated script was a bit more than 
60,000 words, which sounds almost insultingly short – not even novel length!? – 
for the scale of the game and the effort it took to make it happen. But perhaps 
that's the nature of operating solo – all the different aspects of the project 
get rolled up into one giant and seemingly neverending problem, and looking at 
any one of them by itself afterward leaves you surprised at how small it 
actually is. …Or maybe that's just me. Most people aren't dumb enough to try to 
do this alone, so I don't have much to compare to.
  
  In any case, it was a hard road, but I'm happy with the results. I suffer no 
delusions that my work or passion will do anything to change the game's status 
as a forgotten also-ran, but I've done the best I can to at least give the rest 
of the world a chance to evaluate it. It's definitely more than the "bishoujo 
game" that most seem to have dismissed it as. If you play it, I hope you'll get 
the same pleasant surprise I did.
  
  P.S. If you loved the game and have now imported a PC-FX and copy of Anime 
Freak FX volumes 1–3 at great expense just to watch the OVA, uh, please don't 
hold your breath for me to translate that too.
  
                    ****************************************
                    *         VIII. Special Thanks         *
                    ****************************************

Thanks to elmer for providing resources and documentation for the PC-Engine that 
were very extensively referenced during the production of this patch, and for 
the special bugfixed Windows binary of bchunk that's used in the patching 
process. And for helpfully pointing out that the letter "t" in the font really 
ought not to be quite as tall as a full-height character, advice which in my 
usual way I immediately rejected before realizing weeks later that almost every 
single font in existence does it that way. I still think the font designers have 
this wrong and it really should be taller, but fighting against centuries of 
convention is probably a losing battle.

Thanks to contributors at MobyGames for providing kanji readings for the names 
of the staff members in the credits; I had no desire to play "guess the reading" 
for all 100+ people who worked on the game, so I sure hope they got them right.

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *         IX. Version History          *
                    ****************************************

v1.0 (12 Jan 2023): Initial release.
