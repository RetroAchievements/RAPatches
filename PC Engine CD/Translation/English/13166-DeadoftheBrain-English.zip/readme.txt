Use with:

(Redump)
File:               Dead of the Brain 1&2 (Japan) (Track 02).bin
BitSize:            183 Mbit
Size (Bytes):       24100944
CRC32:              92F26DB6
MD5:                936948015FA327ED56BB2DC19B6FB16D
SHA1:               9AC8AC828BDD7915B9B65D074482026B4F85B218
SHA256:             F3F3FC923E86E83510F27826DB9D11479BBC5FAAC38AEE0AAE8F57AEC239544F