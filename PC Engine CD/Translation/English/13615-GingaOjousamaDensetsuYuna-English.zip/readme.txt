﻿********************************************************************************
*             Ginga Ojousama Densetsu Yuna (Galaxy Fraulein Yuna)              *
*                          English Translation Patch                           *
*                              v1.3 (12 Dec 2023)                              *
*                                                                              *
*                             Mafoo343 -- Translation                          *
*                               Supper -- Hacking                              *
*          Cargodin, Weedeater, Athena,                                        *
*             Momochi, HeirTransparent,                                        *
*           SilverLupin, TheMajinZenki -- Translation Support                  *
*           cccmar, Cargodin, Xanathis -- Testing                              *
********************************************************************************

Yuna Kagurazaka was just your ordinary high school girl in the year 2299 – a bit 
carefree and more than a little absent-minded, but nothing special…until she won 
the Galaxy Fraulein Contest and rocketed to idol stardom! But when her fellow 
contestants begin disappearing one by one only to turn up wearing power armor 
and trying to kill her, she discovers her true destiny: she is the Savior of 
Light, protector of the galaxy, and must fight to keep the forces of darkness 
from conquering the universe! Can Yuna take down the evil Thirteen Frauleins of 
Darkness, or will hinging the fate of the cosmos on the whims of a flighty 
teenage girl prove a colossal mistake?…Possibly both.

Ginga Ojousama Densetsu Yuna, officially translated as Galaxy Fraulein Yuna, is 
a 1992 adventure game (visual novel/digicomic) by Red Company and Will for the 
PC-Engine Super CD-ROM² system, and the first entry in the Galaxy Fraulein Yuna 
series. Originally inspired by a series of illustrations of Gundam mecha 
anthropomorphized as cute girls, the concept was reworked into an original video 
game property and eventually achieved considerable success amidst Japan's 
mid-to-late-'90s galge boom, becoming the basis for a string of games, several 
albums, multiple art CDs, and two OVA series – out of which only the OVAs ever 
saw release outside Japan.

This patch fully translates the game into English. It translates all text, 
subtitles the 60+ minutes of animated cutscenes, and adds full karaoke 
subtitling (transliteration and translation) to in-game songs. A translation of 
the instruction manual is also provided (though be warned – it contains blatant 
spoilers!); if it wasn't already included in the download, it can be viewed at 
http://stargood.org/trans/yuna_manual/manual.php.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Additional Features
  IV.   About Galaxy Fraulein Yuna
  V.    Debug and Unused Stuff
  VI.   Authors' Comments
  VII.  Special Thanks
  VIII. Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

There are two known editions of this game: the original version, and a later 
rerelease that included a separate HuVIDEO CD containing various bonus 
materials. Both editions are completely identical in terms of game content, but 
the CD tracks are laid out in a slightly different way between the two, meaning 
the discs aren't quite compatible for patching purposes. As such, separate 
patches are provided for the original and rerelease versions.

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches a verified 
"good" image as listed on Redump.org, and if all the tracks on the disc are 
combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches one of the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  ORIGINAL EDITION: http://redump.org/disc/31791/
    Redump name: Ginga Ojousama Densetsu Yuna
                 ("Original" edition, serial HCD2031)
    CRC32:       e3a941bb
    MD5:         aacda3875c8bb1cbcf8769349f3738c8
    SHA-1:       a380e89fa45909b6a31790426a7c3bda26d20e58

  RERELEASE EDITION: http://redump.org/disc/29922/
    Redump name: Ginga Ojousama Densetsu Yuna
                 ("Rerelease" edition, serial HCD5078)
    CRC32:       bb333162
    MD5:         7e8a3a0813ce6c3f4943a58452909a32
    SHA-1:       143e67da58982437b287ab577f8047fbe5ca991b

Consult the Redump links for full details.

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch files in the "redump_patch" folder. Pick the 
.xdelta file whose version label matches your disc: "[v1.2-original]" for the 
original release, or "[v1.2-rerelease]" for the rerelease.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the 
appropriate patch to the BIN or IMG file. If you get an error, you'll need to 
try one of the other patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Ginga Ojousama Densetsu Yuna EN [v1.2] Redump.cue". Rename your patched disc 
image so it has *exactly* the same name as the CUE, except with a .bin extension 
instead of .cue. Note that at this point, it doesn't matter which version you 
patched – the output disc image will always be the same, regardless of which 
version you started with.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc images, but splits them up into separate tracks instead of 
combining them into a single file. These are easily recognized by the presence 
of 10 separate BIN files and a single CUE.
  
  Before patching: 
  
  - Make sure that your disc's CUE file has a name like "Ginga Ojousama Densetsu 
Yuna (Japan) (FAAT, FABT, FACT).cue.cue" (original release) or "Ginga Ojousama 
Densetsu Yuna (Japan) (FAFT).cue" (rerelease).
  
  - Make sure that the BIN files are named in the format "Ginga Ojousama 
Densetsu Yuna (Japan) (FAAT, FABT, FACT).cue (Track 01).bin", "Ginga Ojousama 
Densetsu Yuna (Japan) (FAAT, FABT, FACT).cue (Track 02).bin", etc., up through 
"Ginga Ojousama Densetsu Yuna (Japan) (FAAT, FABT, FACT).cue (Track 10).bin". If 
patching the rerelease, the code at the end should be "(FAFT)" instead of 
"(FAAT, FABT, FACT)".
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch_original.bat" (if patching 
original release) or "binpatch_rerelease.bat" (if patching rerelease).
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match one of the Redump dumps, or you otherwise couldn't 
get method A to work, it may still be possible to patch it. If your disc is in 
BIN+CUE format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"yuna.bin" and "yuna.cue", or "yuna.img" and "yuna.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch_original.bat" (if patching 
original release) or "binpatch_rerelease.bat" (if patching rerelease).
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch_original.bat" (if 
patching original release) or "isopatch_rerelease.bat" (if patching rerelease).
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

** NOTE: This translation was developed and tested on the most recent release of 
Mednafen as of this writing, version 1.27.1. Currently, it has the most accurate 
PC-Engine emulation in existence, and it's your best bet for playing this 
translation. Older Mednafen releases may have less accurate timing, resulting in 
the subtitles not quite syncing to the visuals as intended. Other emulators? 
Cross your fingers.

If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up. Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

Additionally, make sure to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with the game not accepting input or pressing buttons on its 
own, check your emulator's settings.

                    ****************************************
                    *       III. Additional Features       *
                    ****************************************

In addition to the translation, this patch makes some small but important 
changes aimed at eliminating needless frustrations and annoying bugs:

  - Voiced lines can now be skipped. Like many of its contemporaries from the 
era when voice acting in video games was still a novelty, the original game 
forces voiced lines to be listened to in full every time they play and provides 
no option to turn them off, a design decision which swiftly wears out its 
welcome for the modern player.
  
  - Fast-forwarding text has been made easier. The original game will only 
advance to the next text box if Button I is pressed with no other buttons held. 
Since Button II is used to fast-forward text, skipping multiple boxes in a row 
requires an awkward pattern of pressing Button II to fast-forward, waiting for 
the text to finish printing, pressing Button I to clear the box, pressing Button 
II again to fast-forward, and so on. The translation remedies this by advancing 
to the next box when Button I is pressed regardless of whether other buttons are 
held, allowing Button II to be held down to continuously fast-forward.
  
  - A bug which caused the opening song to desynchronize from the visuals under 
certain circumstances was fixed. Due to an obscure sound driver initialization 
issue, skipping the intro sequence during the opening text ("This is a story…") 
and then starting a new game would cause the game to lag slightly more than 
usual throughout the opening song, leading to the visuals falling progressively 
further behind the audio. While so subtle as to be practically unnoticeable in 
the original game, this would have completely ruined the subtitle 
synchronization in the translation, so fixing it was a must.

For the record, minor errors from the original game have been left intact, such 
as dialogue lines with the wrong portrait and lip flaps that don't start/end in 
sync with the voices. Don't pin every mistake on the translation!

                    ****************************************
                    *    IV. About Galaxy Fraulein Yuna    *
                    ****************************************

(originally written by Mafoo343 for a game guide, presented here in slightly 
edited form)

Galaxy Fraulein Yuna was originally conceived in the early '90s by Mika Akitaka, 
an artist known for his mecha designs in anime series including Zeta Gundam, ZZ 
Gundam, Gundam 0080: War in the Pocket, Gundam 0083: Stardust Memory, and more 
recently Gundam The Origin. Aside from his work on Universal Century–era Gundam 
series, Akitaka also redrew many Gundam designs as cute girls wearing power 
armor, known as "MS Girls." One such design in particular, his rendition of 
Gundam F91, caught the attention of video game studios Red Company and Hudson 
Soft, who wanted to turn the character into an original video game IP. The end 
result of this was the Galaxy Fraulein Yuna franchise.

Galaxy Fraulein Yuna was initially conceived as a shoot-'em-up for the NEC 
PC-Engine. However, as time went on, the game was ultimately reworked into a 
visual novel – or "digital comic," as they were sometimes referred to back in 
the day. The first entry in the series was released on October 23, 1992 for the 
NEC PC-Engine Super CD-ROM² add-on. It would then see a re-release in 1995 with 
a newly included HuVIDEO disc containing an animated commercial and concept art 
as part of a promotion for the release of Galaxy Fraulein Yuna 2: Princess of 
Eternity.

Eventually, Hudson Soft would, in fact, get back with Mika Akitaka in late 1995 
to produce a shoot-'em-up as originally intended: Galaxy Policewoman Legend 
Sapphire. This went on to become one of the rarest video games of all time, 
currently fetching prices well above $1,000 on the secondhand market, making it 
the crown "jewel" of many a PC-Engine collector.

Though none of the Yuna games ever saw release outside Japan, the character did 
manage to make one appearance in an officially localized title: In Saturn 
Bomberman, Yuna, along with other Hudson Soft characters, is unlockable for use 
in the game's multiplayer mode. Conversely, Bomberman makes a cameo of his own 
in the original Galaxy Fraulein Yuna, acting as a judge in a swimsuit 
competition.

Westerners who've heard of Yuna at all most likely encountered it through its 
OVA series, which received a somewhat improbable international release through 
A.D. Vision. There are two OVA series based on the games, comprising a total of 
five episodes. The second series was notably directed by the same individual 
that would go on to make the well-regarded Madoka Magica franchise.

Galaxy Fraulein Yuna features the talent of Japanese voice actress Chisa 
Yokoyama, who has worked on a number of roles in various anime and video game 
series, including Sasami (Tenchi Muyo!), Lt. Noin (Gundam Wing), Milk (NG Knight 
Lamune & 40), Servbots (Mega Man Legends) and Sakura Shinguji (Sakura Wars). As 
it happens, Red Company, aside from working on the Galaxy Fraulein Yuna 
franchise, also co-developed most of the Sakura Wars games with Sega, bringing 
back Chisa Yokoyama as the lead for much of that series as well.

The Yuna series ran strong through the late '90s, eventually culminating in its 
best-known and best-regarded game: 1997's Galaxy Fraulein Yuna 3: Lightning 
Angel for the Saturn, ported to the PlayStation the following year as Galaxy 
Fraulein Yuna: Final Edition. The franchise petered out soon after, with little 
activity since aside from sporadic re-releases of existing material, but it 
remains a fond memory for many.

                    ****************************************
                    *      V. Debug and Unused Stuff       *
                    ****************************************

(Written by Supper, who cares too much about these kinds of things. If for some 
reason you're reading this without having played the game, note that there may 
be mild spoilers.)

Galaxy Fraulein Yuna was the first console game that Will ever developed, which 
is probably one of the reasons it contains reams and reams of unused content. 
It's a real goldmine for people who obsess over these things like I do, so I 
figured I'd write up all the unused materials I encountered in the course of 
working on the translation for the benefit of interested parties (which is 
probably no one, but w/e). I wouldn't be surprised if there's more unused stuff 
lying around on the disc – I really wasn't even looking that hard and found all 
this.

  +------------+
  | Debug Menu |
  +------------+

In the course of extracting the game text for translation, I noticed there was a 
bunch of text for a debug menu. While Athena had previously spotted this and 
documented it on TCRF, and the sequel had a known debug menu accessible through 
a button code, no such code was available for this game. But after disassembling 
the title screen logic, it turns out that this one, too, has a fully…well, okay, 
*mostly* functional debug menu accessible via a button code. At the title 
screen, enter the following sequence of button presses:

  - Hold Right, press Button II
  - Hold Left, press Button I
  - Hold Right, press Button II
  - Hold Left, press Button I
  - Hold Left, press Button II
  - Hold Right, press Button I
  - Hold Left, press Button II
  - Hold Right, press Button I

There's a sort of pattern to it that you'll understand if you give it a try.

Doing this loads up a debug menu that provides a number of useful features. 
We've fully translated it for this patch – it was, in fact, extremely useful for 
debugging the translation. Thanks for thinking of us, Will!

  * イベント (Events): A cutscene viewer. Selecting an event will play it, then 
return to the debug menu. Mostly functions as advertised, though several events 
on the last page are mislabeled, and a few are placeholders that don't exist and 
just crash the game if selected.

  * コースデータ (Course Data): A "level select," so far as a visual novel can have 
one. Allows the game to be started from various points in the story. Note that 
the game doesn't always set up all the flags correctly to allow it to be 
properly played from that point – you may find yourself suddenly getting kicked 
back to earlier in the story once you reach a new area because the game doesn't 
register that it's supposed to already be complete.

  * 音楽 (Music): A fully functional sound test for the PSG music tracks. Most of 
the game's music is there, though the Bomberman theme is notably absent.

  * 絵 (Images): An *extremely* rough and buggy image viewer. The game first 
prompts for the ID number of an image to view, then attempts to show it. 
Sometimes, this works as intended, but more often results in an 
improperly-displayed picture, garbled glitch image, freeze, or (sometimes 
seizure-inducing) crash. Selecting certain images may also seem to do nothing, 
but cause the game to freeze when trying to exit the image viewer. Also, the 
selectable range of image IDs doesn't even cover the entire game. The broken 
state of this thing is probably the biggest reason this game's debug code never 
got released like the sequel's apparently did.

  * バトル (Battle): A battle test. This menu lists every possible battle in the 
game, including those for Yuna's various fusions; selecting one starts it as 
normal, with the game jumping back to the debug menu once the player wins or 
loses (not neglecting to display the post-battle titillation scene if the player 
wins, of course). Oddly, selecting the Yuna VS Alephtina battle results in a 
nasty red error message claiming it's unfinished and can't be played, but it 
proceeds to run normally anyway.

  +---------------------+
  | Unused Jungle Scene |
  +---------------------+

There's an interesting mostly-finished but unused event on Loureezus. It appears 
that originally, it was supposed to be possible to get to Loureezus without 
freeing Gina, in which case Yuna could attempt to trek through the jungle on her 
own before eventually getting overwhelmed by the heat and having to turn back. 
The event is mostly programmed, albeit with several obvious errors like 
Alephtina's violin screeching sounds playing in place of one of Elner's lines. 
It even has a number of unique unused images (some unfinished) and unused voice 
clips.

This event can be accessed through memory editing: Use the debug menu to start 
the game from the beginning of Loureezus (it *won't* work if you start directly 
from the jungle), then set the byte at logical memory address $2998 to 0x00 to 
make the game think Gina isn't in the party. Beat Shiori as usual – note that 
the game correctly recognizes that you don't have Gina and won't allow you to 
fuse with her – then try to go to the jungle.

We actually translated this event for the patch, so you can experience it in 
English if you're so inclined. (Hey, I told you I care too much about these 
things.)

  +-----------------+
  | Unused Graphics |
  +-----------------+

The image viewer, despite its barely-functional state, allows access to a number 
of interesting unused graphics:
  
  * Image 185 is an unused variation on the "split-screen" image of Yuna and 
Mari in the cruiser.
  * Image 203 is an unfinished (no background) picture of a confused Yuna poring 
over a large book. This same book is prominently visible in the background of 
one of the interior shots of Yuna's cruiser; it was probably meant to be the 
cruiser's manual, with Yuna realizing after trying to read it that she's not 
going to be able to fly the ship. Note that image 204 is a simple placeholder 
graphic, probably reserved for a second image in this set.
  * Images ~268-277 depict Yuna having an encounter with the green-haired guard 
on Flint, normally only encountered outside the restricted area, in the 
underground elevator room.
  * Images 307 and 311 show unused facial expressions for Yuna and the Rock 
Princess during their encounter in the elevator.
  * Images 568-571 are a seemingly finished but unused sequence depicting Yuna 
being overcome by the heat in the city on Loureezus. While there's no shortage 
of dialogue of Yuna complaining about the heat, the game ultimately doesn't use 
any special graphics for it.
  * Image 582 shows Shiori smiling. This matches better with her expression 
after transforming, and was probably meant to be shown before it occurred.
  * Image 687 displays a used sprite of Lia, but over a placeholder background.

It's quite likely there are more unused images on the disc that just aren't 
accessible due to the image viewer's incomplete state. I leave searching for 
them to future generations of people with too much damn time on their hands.

  +---------------------+
  | Sound Test Oddities |
  +---------------------+

The sound test contains a few interesting entries. In addition to the used 
entrance jingles for the Thirteen Frauleins of Darkness, there are two unused 
jingles in a similar style to the others: one labeled 乗馬のシェラ (Shera the 
Horserider), and another labeled ターニャ (Tanya). No such characters appear in the 
game. It's also worth nothing that the label for Emily's theme refers to her as 
エリーゼ (Elize), possibly an early name.

  +-----------+
  | Unused Ad |
  +-----------+

Cutscene 0x17 is an unused screen probably left over from a demo version. It 
shows an image advertising the game for release on October 23rd (the game did 
indeed come out on that day in 1992), then jumps to program 0x06, an unused and 
more primitive title screen. Pressing Run will start a new game as normal, while 
idling for a few seconds will cause the game to jump to the cutscene shown after 
the Ryudia battle – this was probably something more sensible such as an intro 
sequence in earlier versions.

To see this, set an execution breakpoint on $3800, start any event via the debug 
menu, then when the breakpoint triggers, set $3803 to 0x17 before resuming.

  +---------------------+
  | Final Battle Mockup |
  +---------------------+

The game has five different battle "modes." Of them, modes 0 and 2–4 are used, 
but mode 1 is a non-interactive mockup of the final battle, with placeholder 
text for HUD elements and sound effects. The quickest way to view it is to use a 
debugging emulator to set an execution breakpoint on address $3800. Then go to 
the battle debug menu and select the エルラインＶＳ闇 (El-Line VS Darkness) option, and 
when the breakpoint triggers, write the value 0x01 to address $3803 before 
resuming execution.

Note that we didn't translate this. Even I have my limits.

  +----------------------+
  | After-Battle Scripts |
  +----------------------+

Almost all of the short post-battle events, which are normally special 
voice-only cutscenes, also have unused text versions programmed in the normal 
game engine. These include additional narration describing events that are 
directly depicted in the cutscenes, like the enemy's body disappearing. The 
full-screen events may have been a later addition, replacing these original text 
versions.

For some reason, the only character whose event doesn't have corresponding text 
is Yoshika, though there are a bunch of blank lines at the point in the script 
where it should appear that indicate it was deleted for some reason (ran out of 
space and had to free some up?).

  The second battle against Mai is the only one in the game that actually uses 
this text, with the cutscene itself containing no audio whatsoever. My 
speculation is that they had to do this due to not recording voice acting for 
all the lines in the conversation that follows, but who knows.

  +---------------+
  | Draft Scripts |
  +---------------+

The game's scripts are organized into "blocks" that each cover a set of related 
game areas. For some reason, directly following the blocks for the final area of 
the game are several lengthy blocks of completely unused text and scripting data 
which appear to be very early drafts of various sections of the game. These were 
most likely used to test out the flow of the game and refine the design before 
the voice acting and other money-intensive work was done.

Here's a list of draft script blocks:
  * Block 26 (disc sectors 0x86BA+): encounter with Alephtina in the jungle
  * Block 27 (disc sectors 0x86C2+): encounter with the blue-haired guard 
outside the restricted area on Flint
  * Block 28 (disc sectors 0x86CA+): second visit to the Undersea Temple, 
encounter with Luminaev
  * Block 30 (disc sectors 0x86DA+): encounter with Sayuka, events on the ghost 
planet

Though some of these are somewhat "playable," most of them are broken in various 
ways and will freeze the game either immediately upon being loaded or after 
trying to access invalid resources. Those that do work use the same graphical 
assets as the finished game.

While the draft scripts generally follow the same basic flow of events as in the 
final game, the writing is vastly different, often bearing only a vague 
resemblance to the final product. The drafts are generally much wordier than 
what ultimately went into the game, and often include additional gags and 
references – Alephtina's "Latern Festival dance tune" is identified as the 
ホラえもん音頭 (Horaemon Song) in reference to Doraemon, a lengthy paragraph speculates 
that being defeated by Luminaev would have sullied Yuna with BDSM associations 
and destroyed her career, and so on.

Since they're unused and broken and long as hell, we didn't translate these. But 
they're there in the dumped script, so if you pull that up in the source code 
that I've probably put on Github or somewhere, you can have a look at the text 
if you're interested.

                    ****************************************
                    *        VI. Authors' Comments         *
                    ****************************************
  
  --------------
  -- Mafoo343 --
  --------------

  How I came to translate Galaxy Fraulein Yuna is a pretty interesting story 
actually. Just two years ago if you had asked me, I wouldn't even have known 
about the franchise, let alone what a PC Engine was. It all started in early 
2020 when I got the itch to try to get into translation again. My previous 
efforts on an unrelated project had fallen through and I was looking for 
something a little more manageable, but still challenging, to work on. One day, 
I was listening to some J-Pop in an automatic playlist on YouTube and then the 
song {Lightning Heart} came on. I thought the tune sounded interesting, so it 
got me curious as to where it came from.

  It turned out, that the tune was the opening theme to the second Galaxy 
Fraulein Yuna OVA, which was an anime adaptation of a series of visual novels. 
This got me morbidly curious in the games themselves, though I didn't pull the 
trigger on working on them right away. A few weeks later, I stopped by my local 
videogame store and oddly enough, they had a complete copy of Galaxy Fraulein 
Yuna 2 in near mint condition for dirt cheap. I was fairly surprised, 
considering I live in a relatively small town; you wouldn't normally expect to 
see imports in a place like that.

  Anyways, I bought the game and had a chance to try it out, and from that point 
on I was hooked. My positive experience with the game made me want to go back to 
the original and translate it. At first, I started off translating the Sega 
Saturn Remix, which is a remake of the PC Engine original. This sounded like a 
good idea on paper since an entirely 2D game should stand to benefit from the 
Saturn's superior hardware capabilities. Unfortunately, the Remix proved to be 
mostly inferior to the original in regards to visual presentation. If I had to 
guess, RED Company was probably short-staffed at the time, since they were also 
developing Sakura Wars, Yuna FX and Yuna 3 around that point.

  Whatever the reason, the remake ended up looking like most of its backgrounds 
were done in MS Paint. On top of that, a lot of elements that were animated in 
the original were presented completely static in the remake. Around the point 
Yuna arrives at her cruiser is where I decided to switch gears and focus on the 
original instead. Thankfully, the developers were pretty lazy and more or less 
copy-pasted the script of the original as-is into the remake. This made the 
whole transition process relatively easy for me.

  Right around New Year's 2021, Supper approached me about making the 
translation into a romhack, and eight months later, here we are! It took me 
fifteen months, but I've finally finished my first translation project. What's 
more, I have a confession to make, I only just finished playing through the game 
for the first time when I completed the translation's initial draft. In order to 
keep things interesting, I translated the game as I was progressing though it so 
that everything was new and fresh for me. I briefly skimmed through a let's play 
on YouTube so that I had a rough idea of what I was getting into, but otherwise, 
I pretty much got to experience the game as I translated it. This means that it 
literally took me fifteen months to beat a game that can be completed in around 
only eight hours XD

  With that being said, I had an absolute blast translating the game. It was a 
learning experience, and the fun I had along the way made it all worthwhile. My 
thanks goes to everyone that took the time to pitch in and help out, I couldn't 
have done this without you. Additionally, my thanks also goes to anyone that 
showed their support for this project, I appreciate your encouragement. Thank 
you for downloading the patch, I hope you enjoy :)
  
  ------------
  -- Supper --
  ------------

  One of the unfortunate aspects of translating games is that when you do your 
work right, no one actually notices it. The language just turns into a natural 
part of the experience: as long as everything is consistent and flows together, 
most people zone out and take it for granted. Which of course is exactly what we 
want, but it also means pretty much no one appreciates how much work it takes to 
make it happen. If you've actually read this far, maybe you're one of the few I 
can plead my case to.
  
  I first became aware of this project when Mafoo posted some of his early work 
on the ROMhacking.net forums last year. Initially, I was too busy to take on 
another project, but after wrapping up the PCE version of Madou Monogatari I in 
December, I was in the mood for another project on the system and played through 
Yuna to see if it suited my fancy. (Verdict: it's more "galge" than my usual 
tastes, but its charm won me over in the end.) One thing turned into another, 
and ultimately I'd disassembled the game, dumped the text, and built the script 
inserter before I actually contacted Mafoo about the possibility of working on 
it. Luckily, no one else had jumped in to hack it ahead of me. (This is a nice 
perk of doing work on consoles nobody cares about.)
  
  So, that had the text side of things sorted out from the get-go. Took maybe 
2–3 weeks, all told? Pretty ho-hum by PCECD standards, really. Then, now that I 
was fully committed and it was too late to turn back, I had no choice but to 
figure out something for the dozens of long, voice-only cutscenes.
  
  As far as I know, I'm the only person to date who's ever been dumb enough to 
attempt to subtitle a PC-Engine game, having done it for both my previous 
translation projects on the console, and at this point I could probably write a 
book on how profoundly ill-suited a machine it is for it. It has one layer of 
background and one layer of sprites, and that's it. You want to overlay 
subtitles over arbitrary content, they're going to have to be made of sprites. 
If the PCE didn't have the most fantastically overpowered sprite hardware 
imaginable in 1987, it would be completely impossible. As it is, it's just 
extremely improbable.
  
  My previous projects both had no more than ten minutes of scenes requiring 
subtitling, so I took the direct route of hacking in prerendered graphics for 
each line and modifying the game scripts to display them as needed. Yuna, on the 
other hand, has over an hour of scenes plus multiple songs, including an 
elaborate opening sequence which consumes almost all of the available memory 
with compressed graphics. The straightforward approach just wasn't going to work 
here.
  
  So I made into reality an idea I'd been turning over in my head after spending 
a few too many hours on my old projects tediously tinkering with scripts to try 
to get the subtitles correctly timed: why not leave the existing cutscene code 
alone, and instead generate and overlay the subtitles asynchronously using the 
VSync handler? Well, when I actually tried it, it turned out there were a 
million reasons it couldn't and probably shouldn't have worked.
  
  But by pure luck, this game is set up in such a way that it's actually 
feasible, and let me tell you, I could not be happier about it. Because of this 
innovation, all I had to do was go through every single cutscene, time it, add a 
sync point at the start of each voice clip, write out a script to display 
everything, carefully manage VRAM usage so the subtitles don't overwrite or get 
overwritten by existing graphics, add background tile patches to conceal 
subtitle-induced sprite overflow, throttle subtitle processing speed during 
VBlank-intensive scenes to avoid visual artifacts, etc. etc. etc.…Okay, so it 
was still a ton of work, but it was immeasurably less than what the naive 
approach would have entailed. This system made the process of subtitling about 
as straightforward as it could possibly be within the inherent constraints of 
the PC-Engine.
  
  Anyway, once the subtitle system was in place, the project was basically just 
slow but steady translation combined with periodic headaches over unexpected 
bugs and particularly troublesome cutscenes. It took a tremendous effort – one 
far disproportionate, I expect, to the actual potential audience for this patch 
– but in the end, things somehow worked out. I still can't quite believe it, but 
here we are.
  
  So enjoy the translation. I hope we made it look easy. It was anything but. 
But hey, I had fun, and isn't that what's really important here?…No?
  
  P.S. Could someone please inform VNDB that this game is not its sequel? 
Thanks.

                    ****************************************
                    *         VII. Special Thanks          *
                    ****************************************

Special thanks to all the following people for contributing to this translation, 
directly or indirectly:
  * Cargodin – Created the original transcript/translation of the game's intro 
sequence, and helped test the patch
  * Weedeater – Created OP/ED theme transcription
  * Athena/悠里マヤ (Yuri Maya) – Made a Japanese transcript of the audio of the 
game's hidden message in track 1
  * Momochi – Misc. translation assistance
  * HeirTransparent – Misc. translation assistance
  * SilverLupin – Misc. translation assistance
  * TheMajinZenki – Misc. translation assistance

Thanks to the members of LIPEMCO! Translations (other than that useless git 
Supper) for their support throughout development and assistance in testing the 
translation.

Thanks to Elner…I mean, elmer for providing resources and documentation for the 
PC-Engine that were very extensively referenced during the production of this 
patch, and for the special bugfixed Windows binary of bchunk that's used in the 
patching process.

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *        VIII. Version History         *
                    ****************************************

v1.0 (25 Aug 2021): Initial release.



v1.1 (03 Feb 2022): Small update with a few minor changes and fixes.
  
  - Fixed the Redump link in the readme for the original edition of the game. 
Thanks to xelement5x on the PC Engine Fans forum for spotting this.

  - Mafoo343 was able to dig up the (strangely obscure) official lyrics to Dream 
Girl and Show Me; previously, we had to rely on fan transcriptions. While those 
were mostly correct, a few bits of Dream Girl were slightly off, most notably 
"daiuchuu" being misheard as "daisuki" (in all fairness, it's a pretty 
nonsensical line). The transcriptions and translations have been updated to 
match the official lyrics.
  
  - The capitalization convention for song lyric translations has been changed 
to match Yuna 2 -- previously, every line was capitalized, but now only new 
sentences are capitalized. Given that these are prose translations rather than 
anything actually meant to be sung, this is probably less disingenuous.
  
  - The translation of the title logo during the opening sequence has been moved 
from the bottom to the top of the screen, again to match with the Yuna 2 
translation (and typical subtitling conventions).
    
  - And for even more consistency with Yuna 2, instances of an ellipsis followed 
by a heart mark are now separated by a space. Why do I inevitably find myself 
getting sucked into this kind of excruciating minutae on these projects?
  
  - Some minor translation goofs have been fixed:
  
    - Intro: "500 planets" -> "500 star systems". This was entirely my fault; 
Cargodin had it right to begin with. Sorry for doubting you!
    
    - Professor Murakami's enka performance: "She's like a completely different 
teacher" -> "What an odd teacher". Again, the initial translation was correct 
and I was 100% responsible for screwing it up :(
    
    - Looking behind the gym for the second time: "That shadow over there by the 
gym" -> "Over in the shadow of the gym".
    
    - In Kaede's intro: "The Apostle of Light, Elner of Wisdom" -> "Elner of 
Wisdom, Apostle of Light". Though this title is rarely used, other dialogue 
indicates that it refers to all the robot members of the Matrix of Light, not 
just Elner -- they're all "apostles" of Yuna, the "savior".
    
    - Flint intro cutscene: "The warp was..." -> "Warps and me don't mi...". 
(Yuna is starting to explain that she doesn't handle warps well before getting 
cut off.)
    
    - Returning to Yoshika after refusing her offer of tea: "My apologies" -> 
"Sorry to keep bothering you".
    
    - Mariana intro cutscene: "human life" -> "humanoid life".
    
    - Yuna's beloved jumbo parfait special: "If you buy a meal, you get another 
one free" -> "If you eat an entire one, you get another free". The phrasing used 
in this game is a bit vague, but in the sequel, a more detailed explanation is 
given that makes the intent here clear.
    
    - Just before the first Mai battle: "There's one weensy little thing I 
didn't tell you" -> "I've been told to keep this quiet".
    
    - In the most significant change, the dialogue with Mai in the cutscene 
after her first battle has been rewritten. The original translation made it 
sound like she was begging for forgiveness, while the actual tone is more like 
"I hope you go embarrass yourself" (which is much more in line with all her 
subsequent appearances).
    
    - Elner's comments on the Undersea Temple mural: "a fraulein's power can 
influence the cosmos" -> "the power of frauleins is what governs the cosmos".
    
    - Talking to Lia after the Luminaev battle: "imperial guard" -> "elite 
guard". The same term is used in Yuna 2, albeit referring to something 
different, and I translated it as "elite guard" there because I mistakenly 
thought that's what it was here. Given that there's no empire involved, "elite" 
really makes more sense anyway. (Also, this is yet another case where the 
initial translation was fine and I screwed it up...)
    
    - Emily's quiz: "That's not math" -> "Isn't that science".
    
    - In the Emily battle: "How sweet" -> "Aren't you precious" (this is an 
idiom that was mistakenly translated literally).
    
    - A few instances of characters being referred to as "women" have been 
changed to "girl" where it would be more fitting (specifically Yoshika, Remi, 
and Emily, who are all 15 or 16). The original Japanese used vague terms that 
could be translated either way, and since I didn't actually know their ages when 
I was first editing, sometimes I had to guess, and naturally got it wrong.



v1.2 (08 May 2023): Minor update to coincide with the release of the Yuna 3 
translation. Makes the following text changes:

  - Various places: "To do as one pleases" -> "Every which way". Mafoo asked for 
the translation of this running gag to be changed so it would work better with 
how it's used in Yuna 3.

  - Yuna: "My daddy" -> "My papa". Consistency with the rest of the game (and 
series).

Additionally, Redump has updated their database with another variant of the 
game, "FAAT", which is content-identical to the previously-listed FABT and FACT 
releases. The patching instructions have been modified to reflect this.



v1.3 (12 Dec 2023): Originally a bugfix update focused on issues that occurred 
when playing on real hardware, this ended up turning into a full script review, 
translation update, and general cleanup as well. This was actually mostly done 
back in September, but a lengthy series of improbable occurrences resulted in it 
getting delayed until after the release of the Tengai Makyou translation.

** Bug Fixes **

  - On real PC-Engine hardware and emulators with accurate CD seek delays such 
as the pceDev fork of Mednafen, the subtitles for the title screen music did not 
synchronize correctly with the lyrics due to lacking the proper code to align 
their start with the beginning of the CD audio. This has been fixed. Other parts 
of the game that use CD audio already had the necessary synchronization code, so 
they were unaffected. Thank you very much to Alcahest for alerting me to this 
issue.

  - In the course of fixing the above problem, I realized that I had not 
correctly set up the subtitle synchronization code for the ADPCM voice clips 
used in cutscenes: subtitles were being started as soon as the game requested 
sound playback from the BIOS rather than when the sound actually began playing. 
This worked fine on most emulators because they don't emulate CD drive seek 
delays properly, but on real hardware, there is often a substantial wait between 
an ADPCM sound being triggered and actually starting to play. As a result, the 
subtitles were almost never properly synchronized on real hardware. The code has 
been adjusted and the cutscene synchronization points have been retimed so that 
this should no longer be an issue.

  - A bug introduced by the subtitle code that could cause the paging registers 
to get stuck in an unintended state if a vertical sync interrupt occurred at 
certain times, potentially leading to a crash during cutscenes, has been fixed. 
I find it hard to believe this bug could have existed throughout all previous 
releases while never causing any issues, but by all indications, it did.
  
  - In the cutscene where Yuna first gets to space and Elner tells her she needs 
to pick where to go, the final subtitle was timed to disappear very, very close 
to the end of the scene. This worked fine on the emulator used during 
development, but on more accurate software (and probably real hardware), the 
scene would actually end before the subtitle went away. This caused all the 
sprites on screen to get "stuck" while the game loaded the next scene. That 
subtitle now disappears a few frames sooner to avoid this issue.

  - An oversight in one of the newly added variable-width printing routines 
meant that if a glyph more than 8 pixels wide was aligned with the background 
patterns in a certain way, it would get corrupted with the contents of the 
characters that followed it. By coincidence, this pattern alignment never 
occurred in older releases, but the font update changed some characters' widths 
and caused this bug to occur in at least one place. In any case, it's been 
fixed.
  
  - A bug in the original game that caused a sound effect not to play correctly 
in the Dark World has been fixed. In the scene where Gina, Marina, and Erina fly 
across the screen, the game tries to play a "whoosh" sound effect but 
incorrectly specifies part of the settings, causing playback to begin from near 
the middle of the ADPCM buffer instead of at the beginning. This meant that what 
actually played was mostly a fragment of the existing contents of the buffer 
(one of Yuna's previous lines). In previous releases, I figured this wasn't my 
problem and left it as it was, but this time I decided it was worth cleaning up.

** Text Updates **

- The fonts were updated based on the revised versions I made for Private Eye 
Dol. I really didn't want to do this because it basically obliges me to update 
Yuna 2 in the same way, but the old fonts have several tacky-looking characters 
that I just couldn't stand to look at anymore. The changes aren't huge: removing 
the needless "flag" hanging from the top of the "f", narrowing the "j" to make 
its curve less exaggerated, shortening the "t" to be properly proportional to 
the other characters, dropping the serif-like protrusion from the top of the "l" 
in the subtitle font, and maybe one or two other minor alterations. I'm sure 
this will just prompt somebody to complain that they liked the old version 
better, but you know, I can't please everyone.

- A couple of lines of text in the battle script were apparently left 
untranslated in previous versions...except I'm not sure they're actually used. 
The messages in question are not-quite-exact duplicates of other battle lines, 
and it's not clear if the text blocks they appear in are ones that actually show 
up in-game -- there is an incredible amount of duplication in the battle text, 
which is how I overlooked this in the first place.  So this may have fixed 
Yuna's "Iyaaah!" (Shiori battle) and "Don't make fun of meeee!" (Alephtina 
battle) messages under some circumstance, or may have achieved nothing. I tried.

- I didn't intend to make any changes other than bug fixes, but somehow ended up 
reviewing the entire damn script like I did with the last revision of Yuna 2, 
resulting in some dozens of (mostly minor) translation corrections and 
touch-ups. It's my fervent hope that the translations for the various games in 
the series are now at parity with each other and  everything is as good as it's 
going to get. (I wouldn't bet on it, though.) Here's a full list of changes:

  ** Main Script Changes **

  - Elner: "collateral damage on this scale will be unacceptable" -> "it will 
make this level of damage seem like a trifle"
  
  - Yuna: "So as a bonus prize, I'm getting a cruiser" -> "The cruiser I got as 
a bonus prize is here"
  
  - Airport information desk woman: "So you are Miss Kagurazaka?" -> "Miss 
Kagurazaka, was it?". By my reading, she's simply confirming the name Yuna just 
told her rather than actually recognizing her.
  
  - Yuna at airport information desk: "Why not?" -> "There's really no way?". 
どうしても, not どうして.
  
  - Elner: "from here on, you're going to face more and more battles" -> "the 
battle is finally beginning"
  
  - Yuna: "It's in my textbook that I always keep in my desk." -> "I always 
leave my textbooks behind inside my desk, so..."
  
  - Elner: "The galaxy's top fraulein idol was defeated in a karaoke contest by 
a high school teacher...?" -> "So the galaxy's top fraulein idol lost to a 
karaoke-obsessed high school teacher..."
  
  - Yuna: "I wonder who could be there" -> "I wonder if someone's there". 
Misread 誰か as 誰が.
  
  - Yuna's remarks about her pseudo-delinquent friend(s) have been changed from 
plural to singular, which seems the more likely interpretation to me, and had 
some additional corrections made (I misinterpreted カッコ as "cool" when it's 
actually supposed to be 格好, "appearance").
  
  - Kansai dialect delinquent: "Instead of that swimsuit, I think you oughta 
wear something else. Why don't we get you changed up? Girls―strip her." -> "If 
yer gonna wear a swimsuit like THIS, you might as well not wear anything at all, 
yeah? Strip 'er."
  
  - Yuna: "Oh, that director―I do know him." -> "Oh, that director―I know him."
  
  - Pushy drama director: "our ratings will shoot up by 600%" -> "we'll have a 
600% audience share, guaranteed". No, it doesn't actually make sense, which I'm 
pretty sure is the joke.
  
  - Kaede, if Yuna loses to her: "Now do you understand my true strength? 
Resistance is futile, so render your lowly life unto me." -> "Now do you 
understand the limit of your strength? Live your plebian life as you will."
  
  - Yuna: "How could you say something so cruel at a time like this?" -> "Don't 
be so cruel when things are like THIS!"
  
  - Yuna: "What in the heck was all that about? I'm so confused." -> "What in 
the heck was all THAT about?". The original text is one sentence, and I think it 
only makes sense to keep it that way.
  
  - Narration: "hidden behind the roses are truly malicious flowers" -> "hidden 
behind the roses are truly nasty flowers"
  
  - Mari: "is the beauty of these flowers insufficient for you" -> "are you 
satisfied with the beauty of these flowers"
  
  - Elner: "it means they're REALLY bad, REALLY strong people" -> "it means 
she's a REALLY bad, REALLY strong person". This line seems to be referring to 
Mari rather than the Frauleins of Darkness as a whole, and Yuna's reaction 
supports this.
  
  - Yuna: "I guess I'll just have to beat them" -> "I'm gonna beat her". Changed 
in accordance with the previous line.
  
  - If you choose to fight Mari, Yuna and Elner have a short dialogue where 
Elner praises Yuna. It seemed so banal that I became convinced it couldn't mean 
what it appeared to say, and I ended up turning it into a weird grammar joke. 
Upon reflection, no, I was massively overthinking it and it's just stupid 
dialogue. You'd think I'd know better, considering the series we're talking 
about here. Anyway, that exchange should now be less completely wrong.
  
  - Mari: "You couldn't possibly understand my tastes" -> "How could you not 
understand these sensibilities...?"
  
  - Mari: "Try again if you like, though." -> "Do give it another try!"
  
  - Yuna: "Why do we have to go somewhere so dangerous" -> "Why are we going 
somewhere dangerous on PURPOSE"
  
  - Yuna: "MY school just went to Kyushu" -> "OUR school just went to Kyushu"
  
  - Narration: "A man with a face that's half machine is squatting in the area 
that's sheltered from the rain" -> "The places that are sheltered from the rain 
have guys with half-machine faces squatting in them". Plural makes more sense 
here.
  
  - Yuna: "It's supposed to be pretty classy" -> "It's pretty classy stuff"
  
  - Yoshika: "Well, how was it?" -> "Is something the matter?"
  
  - Yuna: "I was just getting to that!" -> "C'mon, don't worry about that!". I 
got confused here because Yuna's 「いいじゃない　別に」 seems to parrot Elner's question of 
「いいじゃないですか」, but on a closer reading, that's just a coincidence and Yuna is 
simply trying to deflect attention from her obvious lie about suspecting Yoshika 
from the beginning.
  
  - Narration: "A female mannequin clad in a swimsuit gazes this way with a 
smile" -> "A woman modeling a swimsuit gazes this way with a smile". Here's your 
Japanese trivia for today: the word "mannequin" can be used to refer to actual 
people who model items for a store, not just display dummies.
  
  - Mai: "Yannow if anything, like, interesting's happened lately" -> "Yannow 
anywhere that's been, like, interesting lately"
  
  - Mai: "This bar was all ancient Greek, and they had all these pyramids and 
stuff" -> "They said this place was like, an ancient Greek style bar, and it had 
all these pyramids and stuff"
  
  - Yuna: "Really? And what university was that?" -> "Really? Where'd you go to 
college?". Changed to better reflect that Mai has, supposedly, not actually 
graduated from university yet. I say "supposedly" because the in-game dialogue 
absolutely makes it sound like she has -- seriously, she brags about how her 
"professors" (教授) doted on her and she "graduated" (卒業しちゃった), and then Yuna asks 
her "What was your university?" (大学どこだったんですか？) in past tense! -- but all sources 
outside the game claim she's currently attending school, and in the sequel she's 
a "student teacher". So I guess she must be bragging about graduating high 
school (where she was taught by professors for some reason), and Yuna's actually 
asking her where she STARTED college after that. Or she graduated college once 
but is actually still attending it for some reason. Or she's just outright 
bullshitting (actually, this may be the most likely possibility). Sheesh.
  
  - Mai: "are you, like, whining about me or something" -> "you like, got a 
problem with me or something"
  
  - Mai: "Only natural since I'm in the industry" -> "That's right, I'M the one 
in the industry here"
  
  - Narration: "Somehow, they seem to have wound up back at the entrance" -> "It 
seems they've wound up back at the entrance"
  
  - Narration: "The girl's tone suddenly sparks Yuna to anger" -> "Yuna suddenly 
rounds on the girl in a rather prim tone". This actually still isn't an accurate 
translation, but the original text remarks that Yuna is expressing her anger in 
an "onee-san tone", referring to a feminine speech style often seen in Japanese 
fiction. It's not really a translatable concept.
  
  - Yuna: "It's just that I thought you shouldn't look so sloppy or talk like 
that. I'm sorry about what I just said, okay?" -> "I just said it because I 
thought you shouldn't look so sloppy or talk that way. I'm sorry, okay?"
  
  - Yuna: "...I've...folk danced..." -> "...I've held hands...at a folk dance." 
Mai's response was slightly changed to match.
  
  - Mai: "you're the type that thinks 'we can be good friends, but there's no 
way we can be lovers'" -> "you're the 'we can be friends, but I'd never think 
about you THAT way' type"
  
  - Mai: "You were just part of a friend group?" -> "You just went on group 
dates for singles?"
  
  - Mai: "You don't have even the slimmest sliver of charm as a 'woman'" -> "You 
don't have even the slimmest sliver of charm as a woman". The quotes are part of 
the Japanese script, but in English, this really isn't an appropriate place for 
them.
  
  - Narration: "Yuna simply falls flat on the road without a word" -> "Yuna just 
shakes her head without saying anything". It's a particularly dumb mistake...but 
this line isn't actually used, which is why I wasn't checking it too closely in 
the first place.
  
  - Alephtina: "It seems you lack the beautiful heart to appreciate art" -> "You 
don't even have so much as a beautiful, art-loving heart"
  
  - Narration: "The girl raises her violin and strikes it with all her soul" -> 
"Touched, the girl readies her violin"
  
  - Alephtina: "I've lost" -> "I give up"
  
  - Yuna: "Should we be afraid...?" -> "Maybe they won't be scary...?"
  
  - Gina: "'Should we be afraid?' Yuna asks..." -> "'Maybe they won't be 
scary...?' ...Yuna."
  
  - CD store worker: "she'd up and left" -> "she'd up and disappeared". Looking 
at this again, I think it's talking about the library worker found at the park, 
not Emily as I initially assumed. The sentence is so vaguely phrased that you 
could really take it either way.
  
  - CD store worker: "I thought you were special, but you're really just another 
idol, huh!?" -> "Think you're hot stuff, huh!? Well, you're just another idol!"
  
  - Narration: "The girl is staring at Yuna" -> "The girl is glaring at Yuna"
  
  - Emily: "Perhaps there's more to you than meets the eye" -> "You might even 
be on the level of a cat". This is a direct translation of the original text, 
and more obviously an insult, which works better with the dialogue that follows. 
It also parallels the other dialogue branch, where she says Yuna is dumber than 
a fish.
  
  - Yuna: "What, you can't think of anything either, Elner?" -> "Geez, even 
Elner didn't plan for this."
  
  - Lia: "A contest of words means nothing" -> "Enough fighting with empty 
words"
  
  - Lia: "Even if...you're this kind...I WILL defeat you and become the galaxy's 
number one fraulein..." -> "But...if you're that kind to me...Then beating you 
and becoming the galaxy's number one fraulein is...". This line is somewhat 
vaguely phrased, but I'm quite confident that the previous translation 
interpreted it wrongly.
  
  - Sayuka: "which is, alone, the prerequisite of being a fraulein" -> "which is 
the prerequisite of being a fraulein". "Alone" is rather overdoing it for こそ 
here.
  
  - Yuna's reponse to Sayuka's battle taunt: "Oh, come on..." -> "No way..."
  
  - Yuna: "I know I said something mean about you, but...those words just came 
out on their own somehow" -> "I didn't say that because I hate you, just...those 
words came out on their own somehow"
  
  - Yuna: "Even YOU should know that you can't just do bad things!" -> "You know 
full well you can't just do bad things, don't you!?"
  
  - Sayuka: "Do you understand my true strength?" -> "Do you now comprehend the 
limits of your strength?"

  ** Cutscene Changes **
  
  - Elner, after Yoshika battle: "What's important here is that the darkness' 
influence has reached this place" -> "What's important here is that the forces 
of darkness have reached this place". This is more consistent with the 
translation of 闇の勢力 elsewhere. In a subsequent line which refers back to this 
one, "it" was changed to "they" to accommodate.
  
  - Mai, after being defeated: "the ancient 'Savior of Light'" -> "the ancient 
Savior of Light". The quotes are technically part of the script (the 
after-battle "cutscenes" almost all have unused text transcriptions in the game 
because they were originally just part of the regular adventure mode), but they 
really aren't adding anything here.
  
  - Lia, after defeating Luminaev: "All just as I predicted" -> "I DID see 
promise in you"
  
  - Elner, after Ryudia battle: "Erina, can you tell us the positions of the 
Dark Nebula and the cloud planet?" -> "Erina, can you display the positions of 
the Dark Nebula and the cloud planet?"
  
  - Lia, after beating Yuna: "Well, would you look at that? I'm the galaxy's top 
fraulein after all!" -> "Now, behold! Yes, I AM the galaxy's top fraulein!"
  
  - Flint intro: "It now plays the role of a mineral supply base to a human 
cultural sphere, which is centered on the artificial planet Flint" -> "It now 
plays the role of a mineral supply base, centered on the artificial planet 
Flint, to the human cultural sphere"
  
  - Loureezus intro: "Almost the entire planet is covered in an ever-evolving 
jungle of diverse vegetation, and it is host to abundant life" -> "Almost the 
entire planet is covered by a jungle comprised of fern-derived plants, and it is 
also host to abundant fauna"
  
  - Black hole intro: "The star is forced to grow infinitely smaller until its 
size is infinitesimal" -> "Its size shrinks to near-infinitesimality, and its 
mass grows to near-infinity"
  
  - Black hole intro: "A black hole's spherical surface is surrounded by what we 
call an event horizon. All light particles become distorted as they draw nearer 
to the gravitational singularity." -> "Around a black hole exists a spherical 
surface called an event horizon, and all light and particles within it will be 
distorted toward a singularity."
  
  - Dark Nebula intro: "Within its extent, even the dimmest of lights does not 
exist" -> "Within it, there is nothing but a dark space where light does not 
exist"
  
  - Flint asteroid belt intro: The end of one of Yuna's lines ("Right, Elner?") 
was accidentally treated as the first part of the next character's line. This 
has been corrected.
  
  - Yuna, preparing to open the Dark Gate: "join in with me" -> "join in with 
us"
  
  - Yuna, preparing to recite the chant to open the Dark Gate: "Ready as I'm 
gonna get!" -> no change. I note this because the Japanese transcription for 
this line was wrong and has been corrected but, after giving it some thought, I 
decided that the existing translation was actually a pretty good approximation 
of the sense of もうやるっきゃないよ (literally "we've just gotta do this") for the given 
context.
  
  - Yuna, entering the Dark Gate: "What's going on?" -> "What's that noise?"
  
  - Yuna, comforting the defeated Lia: "Don't worry about a thing" -> no change. 
Once again, the Japanese transcription was wrong (in fact, it wasn't even 
complete) but the guesslation was coincidentally passable anyway.
  
  - After the asteroid is destroyed: "What are WE supposed to do?" -> "What's 
the point in going?" (please don't ask me which of the robots is actually saying 
this line, they don't have lip flaps and I can't keep track of their voices)
  
  - Sayuka: "My apologies. Please do forgive my presumptuousness." -> "I'm 
sorry. Please do allow me a moment to laugh." Don't ask me how I managed to miss 
this one, considering she immediately follows it up with an extra-haughty 
ojou-sama laugh.
  
  - Yuna during Marina's awakening: "No fair suddenly changing the subject!" -> 
"No fair asking questions all the sudden!". For some reason, the last part of 
this dialogue had its volume lowered almost to the point of inaudibility, making 
a critical word of the sentence hard to make out. I ended up pulling the audio 
from a demo version of the game, which had the line at normal volume instead, 
and eventually figured it out. Incidentally, with this, I now have Yuna saying 
"all the sudden" at some point in all three games. Multiple people specifically 
complained to me that they didn't like this phrasing, and I have roundly ignored 
all of them because I think Yuna is too dumb to know or care. Mission complete!
  
  - Yuna after Marina's awakening: "Come on, now, quit it!" -> "Aw, don't worry 
about it."
  
  - Yuna during Erina's awakening: "My body doesn't seem to feel as heavy as it 
did before" -> "My body doesn't feel heavy like it did earlier"
  
  - Yuna during Erina's awakening: "I can be a bit careless" -> "I can be a bit 
scatterbrained sometimes"
  
  - Lia after fighting Queen of Darkness: "I...despise her..." -> "I...couldn't 
stand it..."
  
  - Yuna in intro: "Up 'til now, I was nothing special. I was just your average 
high school girl, until..." -> "Up 'til now, I was just your average, 
run-of-the-mill high school girl, but...". The first clause was incorrectly 
transcribed, resulting in this being erroneously split up into two sentences.
  
  - Yuna in ending: "Don't go" -> no change. I'd mostly just like to acknowledge 
that the Japanese transcription for this line, which is rather hard to 
understand due to using a heavy echo effect, was corrected based off of the 
transcript by nemesislivezx on the following page: 
https://w.atwiki.jp/opedmiroor/pages/723.html Ultimately, this didn't matter as 
far as the translation goes, but I feel a bit more satisfied having the right 
transcription in the script.
  
  - Lia in ending: "You ever try this nice thing we call 'exhaling'?" -> "Next 
thing you know, they'll be calling you 'Puffy-Wuffy Yuna.'" Yeah, sorry, this 
was a pretty stupid flub. I think by this point in the game, everyone involved 
in the translation was ready to be done...
