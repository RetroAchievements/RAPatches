CATALOG 0000000000000
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 01).bin" BINARY
  TRACK 01 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 02).bin" BINARY
  TRACK 02 MODE1/2352
    INDEX 00 00:00:00
    INDEX 01 00:03:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 03).bin" BINARY
  TRACK 03 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 04).bin" BINARY
  TRACK 04 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 05).bin" BINARY
  TRACK 05 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 06).bin" BINARY
  TRACK 06 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 07).bin" BINARY
  TRACK 07 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 08).bin" BINARY
  TRACK 08 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 09).bin" BINARY
  TRACK 09 AUDIO
    INDEX 01 00:00:00
FILE "Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper) (Track 10).bin" BINARY
  TRACK 10 MODE1/2352
    INDEX 00 00:00:00
    INDEX 01 00:03:00
