@echo off
set xdelta_exe=%CD%\app\xdelta.exe
set original_file=%CD%\GODY-Merged.bin
set delta_file=%CD%\patch\Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper).xdelta
set output_file=%CD%\Ginga Ojousama Densetsu Yuna (Japan) (En) (v1.3) (Supper).bin

echo Merging files...
"%CD%\app\binmerge.exe" "%CD%\Ginga Ojousama Densetsu Yuna (Japan) (FAFT)\Ginga Ojousama Densetsu Yuna (Japan) (FAFT).cue" "%CD%\GODY-Merged"

if %errorlevel% equ 0 (
    echo Merging successful. Patching...
"%xdelta_exe%" -d -s "%original_file%" "%delta_file%" "%output_file%"
    echo Patching complete.
) else (
    echo Merging failed.
)

DEL "%CD%\GODY-Merged.bin"
DEL "%CD%\GODY-Merged.cue"

pause
