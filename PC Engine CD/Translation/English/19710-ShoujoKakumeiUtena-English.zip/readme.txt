Use with:

(Redump)
File:               Shoujo Kakumei Utena - Itsuka Kakumei Sareru Monogatari (Japan) (Disc 1) (Track 1).bin
Size (Bytes):       455191968
CRC32:              d09bb820
MD5:                4bafc62317927b6f4fd928ed91c0fe1e
SHA1:               02e80bf640c50da94633cd46a71ed856cd58468f

(Redump)
File:               Shoujo Kakumei Utena - Itsuka Kakumei Sareru Monogatari (Japan) (Disc 2) (Track 1).bin
Size (Bytes):       568266720
CRC32:              ea84b5c1
MD5:                e1868e827dca16686d781334a2f5b702
SHA1:               7dee85e47594bd621f7dcdf284afc582476c0e5c