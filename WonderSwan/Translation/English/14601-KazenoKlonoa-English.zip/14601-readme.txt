Use with:

(No Intro)
Kaze no Klonoa - Moonlight Museum (Japan).ws
5e907dd88b3cfb2855a18fb1bf689860
80c6ef12