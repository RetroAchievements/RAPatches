Use with:

(No Intro)
File:               Digimon Adventure 02 - Tag Tamers (Japan) (Rev 1).ws
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6EDEDAF8
MD5:                2CB264BA76B88452D7576992F2B90DBF
SHA1:               44A5502B70EA75926B87377E3F634C8093BC574A
SHA256:             81C0ADF1390C8E9F72D42DE898392180C6445C594EB31FB66DA62A8ADC08072C