Use with:

(No Intro)
Chocobo no Fushigi na Dungeon for WonderSwan (Japan) (Rev 2).ws
edbc77ab0d585447d927318a6eb66c9b
ccaa4853