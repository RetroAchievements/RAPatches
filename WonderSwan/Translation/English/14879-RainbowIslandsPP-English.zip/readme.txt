Use with:

(No Intro)
File:               Rainbow Islands - Putty's Party (Japan).ws
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8F8608AD
MD5:                854BD4105D726BF7E76FEF8393D6EAD0