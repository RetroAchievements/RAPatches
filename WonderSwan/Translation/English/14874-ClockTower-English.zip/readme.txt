Use with:

(No Intro)
File:               Clock Tower for WonderSwan (Japan) (Rev 1).ws
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              4E8909D1
MD5:                8F0BA3401662A40E8DA5EBCFE7B85E81
SHA1:               DB9B3308336B59AEFF7BD173D687953A37739381
SHA256:             DBD2162F783A77453AC85416ABE0A289F79A04A4C6C909CBB6408158740B2CDE