Wizardry (WonderGate Unlock)
----------------------------

If you've played this game before, you'll have noticed a big WONDERGATE option on the main menu. The WonderGate offered a small handful of typical features such as uploading your survival score and a rotating shop, but biggest benefit of this feature was the DOWNLOAD function.
DOWNLOAD allowed you hit up there server and "download" new maps to play, exclusive to this version of the game, which had many new remixed monster types, and a bevy of exclusive gear, that was all quite powerful.
These new maps would become available on a weekly basis after release, and they put out 10 new maps in total. This was likely a way to curb possible trade-ins as well as the used market right around launch.

If you didn't have a WonderGate (or your in the present time where the service is defunct), you could link up with a friend to download the maps to your save, but these days, there's not a ton of people who still have these on their original carts, and carts with the save on it go for a nifty penny in the Japanese market.

What are you gonna do about it?
-------------------------------
This hack, in short, enables all these maps for you. No need to go to the WonderGate menu, set up a save file, or anything like that. Even if your SRAM is totally dead, they'll just all be accessible from the appropriate menu when you load it up.
So yeah, you weren't really downloading anything. Anything that would have meant more than a handful of bytes would most likely have been unfeasible, even on fancy 2000s Japanese Internet cell phones.

Install
-------
It's IPS format, so just use something like Lunar.
This is a very simple patch in one place (it really only needs 3 bytes, but the original instruction was 5), and should be compatible with other patches going forward.
As always, go with No-Intro, and I would anticipate this would fail to install over trimmed romsets from eras past.
It's also compatible with Hengki Kusuma Adi's English Translation Enhancement patch:
https://www.romhacking.net/translations/5829/

Use
---
After install:
1. Select START
2. Load up your party at the Tavern
3. Back out to the Edge of Town
4. Select Special
5. Select New Maze
6. Then just pick the map you want. 

They're all pretty tough, so you'll want to level up and make progress in the game first.
Works on real hardware from my testing.

Notes:
------
You can check out some details and a bit of a walkthough on the maps here, such as how to get the new items, etc.:
http://multix.jp/wizardry/extra.html

The original page for the WonderGate features of this game is still up as of this writing. You can see who had the best survival rankings back in the day:
http://www.sting.co.jp/games/wiz/wondergate.htm


Bonus:
------
If you own a real cart, you can pretty easily unlock these levels for yourself by editing a save file, and either transferring the save using a cart dumper, or by using a second WonderSwan and a FlashMasta or similar flash cart.

In your save file, you need to write 0x3FF into address: 0x40F2. You can do this by Hex editing the save file and inputting 0xFF at 0x40F2, and 0x03 at 0x40F3. 
Alternatively, you can load up an emulator like Mednafen or StoicGoose and live edit the SRAM at 0x140F2 in the same way as mentioned above.