Use with:

(No Intro)
File:               Digimon Adventure 02 - D1 Tamers (Japan).wsc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              4D28637E
MD5:                833BD00F18FAC9B03392A1D2CEC17A54
SHA1:               18D3DFE25D82964AB7BB61AF363D368FD12F4D4B
SHA256:             AAB36FC2E67E394123B103560D062DF1C5726D7933F29CD198DC342AFCEF0352