Use with:

(No Intro)
File:               Neon Genesis Evangelion - Shito Ikusei (Japan).ws
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              BF8D9212
MD5:                0215C4B8A395F6FCF8F5B07605EAE08B