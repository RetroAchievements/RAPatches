Use with:

(Redump + RAPatches)
md5: 8c831f55fde0779e0e12f89f0c894404
crc: A4DA0F8A