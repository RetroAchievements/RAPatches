This game normally consists of five tracks, but needs to be merged for
the patch to work.

The easiest way to do this is with binmerge: https://github.com/putnam/binmerge


Redump - Original Tracks (md5 + filename)
f3c602776cef3435cae753c9006b8507 *Farland Story FX (Japan) (Track 1).bin
1bb6ea320d1df6086eabf4c41ed56f9e *Farland Story FX (Japan) (Track 2).bin
8069a0b48b3cd5a742c415a86bedeab0 *Farland Story FX (Japan) (Track 3).bin
f2037fa1c694c084cb5769067bd5f5c5 *Farland Story FX (Japan) (Track 4).bin
fb456a281ffe37718adbe6b0b0f8eb45 *Farland Story FX (Japan) (Track 5).bin

Redump - Merged Tracks (md5 + filename):
4e9a0fc6cdd1204597a7a83f3af9002c *Farland Story FX (Japan).bin


V1 Patch Download:
https://drive.google.com/file/d/12-s1-un8l-aWie3sLBEQKrxV1rzt-9t2/view?usp=share_link

V2 Patch Download:
https://drive.google.com/file/d/1gwanrUBZhG7zCXQ3KFgdpaGTUksMMU1E/view?usp=share_link