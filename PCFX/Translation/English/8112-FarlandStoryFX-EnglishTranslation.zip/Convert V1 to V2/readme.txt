Use with:

(Redump + RAPatches)
md5: 0774adf390880c3f3aaa1f25461e718c
crc: 53093C68