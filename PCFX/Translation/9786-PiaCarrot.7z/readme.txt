Use with:
[Redump]
Pia Carrot e Youkoso!! We've Been Waiting for You (Japan) (Track 2).bin
b2b566d753dccc365cac70921462e257
37d0b393