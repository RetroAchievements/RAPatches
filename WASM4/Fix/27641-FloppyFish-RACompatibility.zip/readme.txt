Use with:

(Lost Level Archive)
File:               Floppy Fish (World) (Chris Breece).wasm
BitSize:            117 Kbit
Size (Bytes):       15093
CRC32:              9DED1195
MD5:                B0D2811B4AADB20B750C91E23AB19F29
SHA1:               A7540E7EFD1D2B689D0AFE244A9D4D7E71A57FE3
SHA256:             2FD2CF234FDE51D641744E61E78BD4AA41574562A863C9701677B6680996216B

or

https://wasm4.org/play/floppy-fish/
https://gitlab.com/betothebopgames/floppy_fish
