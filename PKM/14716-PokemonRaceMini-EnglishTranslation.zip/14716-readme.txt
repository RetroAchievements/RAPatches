Use with:

Pokemon Race Mini (Japan).min (No-Intro)
8b50be4cf91a6a3268f5be5e67120056
F8C842B5
