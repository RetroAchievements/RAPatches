Use with:

Pokemon Puzzle Collection Vol. 2 (Japan).min (No-Intro)
66809741517a2f0809cacd6acdd77b27
76A1BBF8
