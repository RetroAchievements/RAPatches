Use with:

(No Intro)
File:               Doom (Europe).32x
BitSize:            24 Mbit
Size (Bytes):       3145728
CRC32:              53734E3A
MD5:                1ABE8B9B1855B1B101CB7F1D86395C22