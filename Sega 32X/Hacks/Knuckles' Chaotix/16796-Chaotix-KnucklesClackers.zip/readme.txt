Use with:

(No-Intro)
File:               Knuckles' Chaotix (Japan, USA) (En).32x
Size (Bytes):       3145728
CRC32:              d0b0b842
MD5:                47b1095e68b053125cd2cd5b1ac4eb50
SHA1:               0c2fff7bc79ed26507c08ac47464c3af19f7ced7