Get started

1. Install Undertale. If you have already played the game prior, you will need to move or delete your existing save files. This file is located in C:\Users\{username}\AppData\Local\UNDERTALE. This entire folder should be empty before you proceed to the next step.
2. Put the RA_parameters.dll in the folder listed above.
3. Locate the data.win file belonging to Undertale. If you're playing on Steam, you can right-click Undertale in your library, select the manage option, and select "browse local game files". If you are playing on GOG, click the option icon next to play, then select manage installation, and select "show folder".
4. Apply the xdelta patch belonging to the storefront you are playing on (RELEASESTEAM for Steam, RELEASEGOG for GOG). Delta Patcher (https://www.romhacking.net/utilities/704/) is required for this. Once you have it installed and opened up, press the first folder icon to locate the data.win file, and the second folder icon to choose the .xdelta patch file. Finally, press "APPLY PATCH".

After following all steps above, booting up Undertale should greet you with a connection screen where you can input your credentials, and select whether you would like your unlocks to be in Casual or Hardcore mode. In-game, you can view your achievements by opening the menu and selecting the "ACH." tab.

Troubleshooting

The game goes straight to the intro.
This means you did not apply the .xdelta patch to the data.win file. Check out steps 3 and 4.

There is a "hash invalid" error.
This means you did not put the RA_parameters dll in the right place (step 1/2), or attempted to modify the game file in a way that is not allowed.

When I try to load a save, I get a dancing dog.
This means an old save file is still present in the UNDERTALE folder. Check out step 1 to remove it. Regular Undertale saves are not compatible with RetroAchievements.