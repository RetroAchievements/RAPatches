Use with:

(No Intro)
File:               Tsumi to Batsu - Hoshi no Keishousha (Japan).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              CA2E5E49
MD5:                A0657BC99E169153FD46AECCFDE748F3
SHA1:               581297B9D5C3A4C33169AE0AAE218C742CD9CBCF
SHA256:             750C67C56762678D44260831DC15206F50B1A5589FFCD7F6AAAD85BEAFA7D5BA