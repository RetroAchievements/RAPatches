Use with:

(Redump)
File:               Doshin the Giant (Europe) (En,Fr,De,Es,It).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              10F7328A
MD5:                749B736EFD4B7A6C495AE543C371FB65
SHA1:               85ADED0068DE903F3727726F36C67426883E9101
SHA256:             D96ED6DF644AF61E8969EAF0F946EAE72C977B55266DEA055887662FBEB2688B