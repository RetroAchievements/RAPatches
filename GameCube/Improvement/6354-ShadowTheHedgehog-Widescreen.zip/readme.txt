Use with:

1)
REDUMP
Shadow the Hedgehog (Europe) (En,Ja,Fr,De,Es,It).iso
MD5: c93225c1a4f1fa4aad5d1dd330293c1a
CRC32: db7d8cd9
RA Checksum: ced5659aced94ebdeb6c4e0a975e9913

2)
REDUMP
Shadow the Hedgehog (Europe) [Subset - 326 Endings].iso
MD5: 1ec439fe3860af5924c3d8c9c5dc234a
CRC32: 14279262
RA Checksum: 00537ed1b0057f837f2018eb3699a1fd