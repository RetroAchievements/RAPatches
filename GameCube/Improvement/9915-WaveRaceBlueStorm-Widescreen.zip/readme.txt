Use with:

(Redump)
File:               Wave Race: Blue Storm (USA)
Size (Bytes):       1459978240
CRC32:              d2ee9ccd
MD5:                dff711fc30af8010da68502e62e03827
SHA1:               389ce9dc75074a1ca43097c7a105815c7d20ee2c