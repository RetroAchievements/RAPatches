Use with:

Redump
Super Mario Sunshine (Japan) (Rev 1).iso
MD5: d23c79fcb8f7cb978f4363e9393a92ea
CRC-32: 11f48191