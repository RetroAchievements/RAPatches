Use with:

(Lost Level Archive)
File:               Pikmin 2 - Pikmin 1^2 (v1.1) (PikHacker).iso
BitSize:            10 Gbit
Size (Bytes):       1408532480
CRC32:              DE2B5629
MD5:                BFB3752412C9827732B53F6590CCB408
SHA1:               753AF1B8024D0E43D1D0047D65B4BE67143FD22E
SHA256:             03E41E148DC1596E2E04CA5255BFAC99E6C4711F9DCC25091AFF2B12B0B1A870