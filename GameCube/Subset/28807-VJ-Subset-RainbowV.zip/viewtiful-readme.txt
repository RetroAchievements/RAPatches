Use with:

(Redump)
Viewtiful Joe (USA).iso
5137df30cb87ee7987bebab8c19cb994
121A9A8E