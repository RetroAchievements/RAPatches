Use with:

(LLA)
File:               Super Smash Bros. Melee - The Akaneia Build (v1.0.1) (Team Akaneia).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              F42C9A24
MD5:                63EA8E113E451C9369F17F7A49012412
SHA1:               66EACA53BB33824118345378B32CB56516D0308F
SHA256:             B1B60A188421C8D0E564FA276A4762FE67E8DE271AC2E131C20F70EE715AF6CD