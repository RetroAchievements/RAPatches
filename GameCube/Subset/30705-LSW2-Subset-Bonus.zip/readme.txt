Use with:

Redump
LEGO Star Wars II - The Original Trilogy (USA).iso
MD5: 12be79c1b0b1c16a8239cc428328b61d
CRC-32: cea162cd