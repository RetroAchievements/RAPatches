Use with:

(Redump)
File:               Pokemon XD - Gale of Darkness (Europe) (En,Fr,De,Es,It).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              0850DDB9
MD5:                F36D14BEBF8FEA6A046404BFF6ADB7E6
SHA1:               2B7E287DF4264DDD07824D316A9D6E063D96AEC5
SHA256:             1CC438ED60E542991B8F1ABEA4617E67880F2568ACEB513602051CA6F310E8C1