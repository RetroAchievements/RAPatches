Use with:

(Redump)
File:               Kururin Squash! (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              8BE76FA2
MD5:                B6768B74AB521063420A8AA8B957E599
SHA1:               F1E5E50751CEE4FA654182E0904F7F6EF721E5CC
SHA256:             8583A8872C3E786D0DA717439899789C8DEFC14BA576D8BB8E56765B86545C60

------------------------------------------------------------------------------------

(Redump + RAPatches)
File:               Kururin Squash! (Japan) (En) (v2.0.1) (NewGBAXL).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              0969CA6B
MD5:                0EFCEE11B7A33E54B84E670487FF1531
SHA1:               C514919681A0A9F161AB8B96C916FFADD0EA71E8
SHA256:             31C1728DF64768688945F8EE889B5742C60741EC8D2BA1C286D398E86D18EC17