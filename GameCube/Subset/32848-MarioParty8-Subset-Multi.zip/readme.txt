Use with:

(Redump)
Mario Party 7 (USA) (Rev 1).iso
MD5: bd367c67fca5d93e581a43d1f61f4514
CRC-32: 8582361b

(Redump)
Mario Party 7 (Japan).iso
MD5: ee9f181b20a8c1f79d70b109d4372367
CRC-32: 78c91bb8

(Redump)
Mario Party 7 (Europe) (En,Fr,De,Es,It).iso
MD5: b82a9ddaf4265c53062cb8cda7129312
CRC-32: a543adbc