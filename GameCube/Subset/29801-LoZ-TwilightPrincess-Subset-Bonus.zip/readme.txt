Use with:

(Redump)
Legend of Zelda, The - Twilight Princess (USA).iso
41deff9b1fd2831f48fbfa2dd1054e4d
0AB54D43

Legend of Zelda, The - Twilight Princess (USA) (Pt) (v1.0) (lucjedi).iso
9415128e3ba61c13f84630312da86307
2B8C0BFD