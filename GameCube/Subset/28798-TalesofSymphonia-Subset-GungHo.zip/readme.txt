Use with:

(Redump)
Tales of Symphonia (USA) (Disc 1).iso
a427c43797ab0ad5c024014142d1c3e1
7FE3B9F7

Tales of Symphonia (USA) (Disc 2).iso
1078706dc88043ba6e7ab1a9aa708b32
A65645EB