Use with:

(Redump)
Metroid Prime (Europe) (En,Fr,De,Es,It).iso
b1379c44e0ebc521e18215de3e5dbeea
AED8BC02

Metroid Prime (USA) (Rev 2).iso
fdfc41b8414dd7d24834c800f567c0f8
61592372