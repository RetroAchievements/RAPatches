Use with:

REDUMP
Shadow the Hedgehog (Europe) (En,Ja,Fr,De,Es,It).iso
MD5: c93225c1a4f1fa4aad5d1dd330293c1a
CRC32: db7d8cd9
RA Checksum: ced5659aced94ebdeb6c4e0a975e9913