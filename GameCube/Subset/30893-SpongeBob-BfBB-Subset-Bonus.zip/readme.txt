Use with:

(Redump)
File:  Nickelodeon SpongeBob SquarePants - Battle for Bikini Bottom (USA).iso
CRC32: 658F36BC
MD5:   9e18f9a0032c4f3092945dc38a6517d3