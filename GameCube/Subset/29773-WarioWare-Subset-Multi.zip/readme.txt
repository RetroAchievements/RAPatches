Use with:

(No Intro)
WarioWare, Inc. - Mega Party Game$! (USA).iso
556075718d1b65fe04a9386722fcec8a
673E9CE1