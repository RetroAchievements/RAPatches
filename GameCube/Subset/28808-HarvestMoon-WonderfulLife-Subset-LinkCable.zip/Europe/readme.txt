Use with:

Redump
Harvest Moon - A Wonderful Life (Europe).iso
MD5: 9e9b1d087aef6e2993c7bbd9e7b2fcc9
CRC-32: 877aeb09