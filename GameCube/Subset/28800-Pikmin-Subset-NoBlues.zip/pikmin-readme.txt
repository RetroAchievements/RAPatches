Use with:

(Redump)
Pikmin (USA) (Rev 1).iso
a249b6aac02b24223b0156fc2eaf8853
5C680247