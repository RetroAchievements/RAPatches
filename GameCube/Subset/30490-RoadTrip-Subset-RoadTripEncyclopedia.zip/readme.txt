Use with:

(Redump)
File: 		Road Trip - The Arcade Edition (USA).iso
RA Checksum: 	403b82be469bfedaf27b3392aeac0f44
MD5: 		297d13cd9485baab035df30b289a1bcd
CRC-32: 	550d6fe7