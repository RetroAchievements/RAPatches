Use with:

(Redump)
Final Fantasy Crystal Chronicles (USA).iso
a6d6064396b20c0d0d836afad97d3a4c
141AEAC0