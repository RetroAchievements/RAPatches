Use with:

(Redump)
Legend of Zelda, The - Ocarina of Time & Master Quest (USA).iso
29d3c366bf3143b251986e99a0964cdb
C1719A28