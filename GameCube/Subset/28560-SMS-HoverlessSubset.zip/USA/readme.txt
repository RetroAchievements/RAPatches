Use with:

Redump
Super Mario Sunshine (USA).iso
MD5: 0c6d2edae9fdf40dfc410ff1623e4119
CRC-32: 771ad977