Use with:

Redump
Super Mario Sunshine (Europe) (En,Fr,De,Es,It).iso
MD5: 72c4860d8555d5e790628e348abc244d
CRC-32: 4c1d3641