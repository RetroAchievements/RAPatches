Use with:

(Redump + RAPatches)
File:               Super Smash Bros. Melee (USA) (Rev 2) (C-Stick in Single Player).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              2A0B7783
MD5:                2C9C2EA7FCFA202132CC47CB36D79E49
SHA1:               CF39EF635FD54BADEF1060FD649040612781B46D
SHA256:             629070E08F868F4E8A6028BB703E88391032F0CD0DAE127F8F638DAB9A40961E