Use with:

(Redump)
Legend of Zelda, The - Twilight Princess (USA).iso
41deff9b1fd2831f48fbfa2dd1054e4d
0AB54D43