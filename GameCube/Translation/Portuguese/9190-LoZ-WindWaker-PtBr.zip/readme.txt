Use with:

(Redump)
File:               Legend of Zelda, The - The Wind Waker (Europe) (En,Fr,De,Es,It).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              61FC5423
MD5:                9841CC876FB7BE6C61EAD51DEEABF280