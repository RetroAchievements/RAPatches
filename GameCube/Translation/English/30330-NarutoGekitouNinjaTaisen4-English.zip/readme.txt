Use with:

(Redump)
File: Naruto - Gekitou Ninja Taisen! 4 (Japan).iso
MD5:  20cdb87874ce4f2db4717fb43682e026
CRC:  60AEFA3E