Use with:

(Redump)
File:               Konjiki no Gashbell!! Go! Go! Mamono Fight!! (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              06FA3328
MD5:                6D67BBEFB1C1283B248BE402EB9A615D
SHA1:               AE56218A47939E900357372E8E2B4851E2EED7E4
SHA256:             956747DCB95C7FBAD5A91CD0D619802F8C7E5B7AA559C6E0A07BFCF09CEE08CF