Use with:

(Redump)
File:               Metal Gear Solid - The Twin Snakes - Special Disc (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              7697E706
MD5:                8433B28379D8533ECD3D09DD864D078E
SHA1:               7DEB1F25832A40D3DB234122ED675294CC4C3CF6
SHA256:             42940BA759BB3FD7DC1FE0BD421061D4B266E4760D04C5ADB86034E9337BBB64