Use with:

(Redump)
File:               Donkey Konga 3 - Tabehoudai! Haru Mogitate 50-kyoku (Japan).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              27C4E790
MD5:                815684C4B43466B7DB847B633D37AE96
SHA1:               877022ACC53A3EB97A4290C45F69BE345DEFA0E0
SHA256:             207979320E66D6895372D99CD238735318A8AC07448FF818D641853A589D4858