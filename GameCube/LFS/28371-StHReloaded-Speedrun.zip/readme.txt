Use with:

(Redump + Patches or Lost Level)
File: Shadow the Hedgehog - Reloaded (v1.2) (LimblessVector,dreamsyntax) (Widescreen).iso
md5:  db6dba6df2067a7b6384440401754934
crc:  608B69C4