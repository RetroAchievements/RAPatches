Use with:

(Redump)
File:               Nickelodeon SpongeBob SquarePants - Battle for Bikini Bottom (USA).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              658F36BC
MD5:                9E18F9A0032C4F3092945DC38A6517D3
SHA1:               9E13B75E3C045956FD5117821F53F7FCE098C3FD
SHA256:             19B2FCD161C801EFB61CFCD201580C37326145784E04C114E7A1C5735459C3DD