Use with:

(Lost Level Archive)
File:               SpongeBob and the Pit of 100 Trials (v2.0) (Gravity).iso
BitSize:            9 Gbit
Size (Bytes):       1229651968
CRC32:              E50C60B0
MD5:                E0EFF2FE5419DCABFB0DD9CCCEEF7F83
SHA1:               B32E39226E8BA18F9B359AE5B4F42F4A7F836155
SHA256:             5AAFD43EA32A484906E91479A46677E38AF097B16FD7E3E3565A920B98018090