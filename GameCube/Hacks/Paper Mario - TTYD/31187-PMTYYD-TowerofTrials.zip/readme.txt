Use with:

(Redump)
File:               Paper Mario - The Thousand-Year Door (USA).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              5A682160
MD5:                DB9A997A617EE03BBC32336D6945EC02
SHA1:               8E403C1CB6A51967698B0BFEAFDAF2A4FA96A61F
SHA256:             991EC0779B2CFD861BBECA6B3E4CB13B22C6106F26B3429B6C1714170BA1027F