Use with:

(Redump)
File: Pikmin 2 (USA).iso
CRC:  3541416B
MD5:  66f8d886afa0742cd9901d1bfe3b114f