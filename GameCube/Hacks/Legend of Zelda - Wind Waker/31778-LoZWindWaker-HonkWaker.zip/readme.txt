Use with:

(Redump)
File:               Legend of Zelda, The - The Wind Waker (USA, Canada).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              AD21C2BA
MD5:                D8E4D45AF2032A081A0F446384E9261B
SHA1:               6B5F06C10D50EBB4099CDED88217EB71E5BFBB4A
SHA256:             EC2D4EE790F48BEE3D4C10FEED166370DF895F474E8DB3F9AF3B16EE001436DF