Use with:

(Redump)
File: 		Pikmin 2 (USA).iso
RA Checksum: 	3876a058fdf7ee82565f9a4439237b1f
MD5: 		66f8d886afa0742cd9901d1bfe3b114f
CRC-32: 	3541416b