Use with:

(Redump)
File:               Luigi's Mansion (Europe) (En,Fr,De,Es,It) (Rev 1).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              9A75E03A
MD5:                109274D9078B5AECF3BFA9AF1D10688C
SHA1:               3F742BF1DB42BD3B24EC50BC66320F762B043752
SHA256:             8AAD63BF047CBA66210717C1FBB9E506A8FE7CEF8D38DF6981E0D57917761F24