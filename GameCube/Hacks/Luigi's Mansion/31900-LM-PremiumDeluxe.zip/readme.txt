Use with:

(Redump)
File:               Luigi's Mansion (USA).iso
Size (Bytes):       1459978240
CRC32:              0b0c339d
MD5:                6e3d9ae0ed2fbd2f77fa1ca09a60c494
SHA1:               96a7d2e6b6e0a355f6e57ef76bd37f6ee837ed25