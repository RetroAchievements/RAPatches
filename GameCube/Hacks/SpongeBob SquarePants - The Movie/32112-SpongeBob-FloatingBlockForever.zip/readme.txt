Use with:

(Redump)
File:               Nickelodeon The SpongeBob SquarePants Movie (USA) (Rev 1).iso
BitSize:            10 Gbit
Size (Bytes):       1459978240
CRC32:              77BE3CC6
MD5:                9FBAD7186B2168190082A54FA20D63B7
SHA1:               2AEA159B1E98A220A6E4534F0F017B8722CE4CAA
SHA256:             F6691501E3529577658FD22431B1C31DA79882A38EF815F64C132279958B4B0B