Use with:

(Redump)
File: Metroid Prime (USA).iso
CRC:  852B658C
MD5:  eeacd0ced8e2bae491eca14f141a4b7c