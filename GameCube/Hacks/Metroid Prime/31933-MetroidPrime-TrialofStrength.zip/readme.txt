Use with:

(Redump)
File: Metroid Prime (USA).iso
MD5:  eeacd0ced8e2bae491eca14f141a4b7c
CRC:  852B658C