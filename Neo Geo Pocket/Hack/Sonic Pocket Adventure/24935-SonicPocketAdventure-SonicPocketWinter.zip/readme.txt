Use with:

(No Intro)
File:               Sonic The Hedgehog - Pocket Adventure (World) (En,Ja).ngc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8BD22145
MD5:                6123E8A783B146BDCDC6A9FA95ABB0BD
SHA1:               5A881D8124D902B4A98D76362AD62566A86F0ABA
SHA256:             EAD73B11039667FE0DAB8A4619605BACC5C5D7C708F083C29F5090FE96C6A091