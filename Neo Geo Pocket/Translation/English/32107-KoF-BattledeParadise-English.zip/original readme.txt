================================================

      KING OF FIGHTERS: BATTLE DE PARADISE
	        ENGLISH TRANSLATION v1.0
           by xenophile127 & marc_max

================================================

The King of Fighters: Battle De Paradise is an exclusive Neo Geo Pocket Color
game released only in Japan in 2000.

It's a Mario Party-style board game featuring characters from The King of
Fighters series, packed with minigames, references, jokes, and puns drawn
straight from the KOF universe.

It is also probably one of the best games on the Neo Geo Pocket Color, it's easy
to learn, very enjoyable and full of charm. The minigames are a blast, and the
dialogues are simply hilarious.

For more than 25 years, the game remained untranslated... until now! We're
excited to finally bring you the chance to experience Battle de Paradise in
English for the first time.

The translation process was a real challenge, with over a thousand lines of text
dialogues, plus the console's technical limitations and the lack of
documentation and debugging tools. Still, we've tried to deliver the best
possible result, aiming to make it feel just like an official release from back
in the day.



HOW TO CONTRIBUTE
-----------------
While the game is now fully playable, there are still 30+ untranslated
dialogues remaining.

These are dialogues that contain potential jokes and/or references to the King
of Fighters series, that was impossible.

Also, some of the already translated dialogues could be improved by players who
have a deep knowledge of the KOF universe.

For that reason, we've put this online tool that will allow anyone to help
add or update the translation:

https://www.marcrobledo.com/king-of-fighters-battle-de-paradise-translation/



PATCHING INFORMATION
--------------------
You must provide the original King of Fighters, The - Battle de Paradise (Japan) ROM:

King of Fighters, The - Battle de Paradise (Japan).ngc
CRC32: 77e37bac
MD5:   362e9c04ec255225eeb0a9dee8fcac1b
SHA-1: 8aabdd45ba2b9e24bdcd8e51f6653736257d4644
 
Apply the patch here: https://www.romhacking.net/patch/



CHANGELOG
---------
v1.0 (2025-10-28)
- first version



CREDITS
-------
xenophile - translation
kensuyjin33 - pixel art logo
marc_max - translation, reverse engineering & hacking



DISCLAIMER
----------
This is a fan created translation, no copyright or trademark infringement is intended.
The King of Fighters is a trademark � of SNK. We are not affiliated nor endorsed by SNK.