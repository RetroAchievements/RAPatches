Use with:

(No Intro)
File:               King of Fighters, The - Battle de Paradise (Japan).ngc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              77E37BAC
MD5:                362E9C04EC255225EEB0A9DEE8FCAC1B
SHA1:               8AABDD45BA2B9E24BDCD8E51F6653736257D4644
SHA256:             1B188C99E4FC6F6E5FC55748A32DD7CDC82DDA9335DC99DEEE45528FD6083780