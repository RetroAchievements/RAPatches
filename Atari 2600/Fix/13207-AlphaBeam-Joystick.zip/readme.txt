Use with:

(No Intro)
File:               Alpha Beam with Ernie (Japan, USA) (En).a26
BitSize:            64 Kbit
Size (Bytes):       8192
CRC32:              27C6B897
MD5:                9E01F7F95CB8596765E03B9A36E8E33C
SHA1:               A1F660827CE291F19719A5672F2C5D277D903B03
SHA256:             5A8ED1AAA54C2A4634D50B09FF708E888124B136715B1BEC0F13B35317DA40B1