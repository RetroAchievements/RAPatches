FILE "Doctor Hauzer (Japan) (En) (v1.2.1) (SnowyAria).bin" BINARY
  TRACK 01 MODE1/2048
    INDEX 01 00:00:00
