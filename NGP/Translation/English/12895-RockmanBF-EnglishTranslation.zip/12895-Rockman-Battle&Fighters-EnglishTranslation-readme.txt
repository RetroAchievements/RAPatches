Use with:

Rockman - Battle & Fighters (Japan).ngc (No-Intro)
c71af75c76778b8a2d32a0c6f170736e
9C861E49
