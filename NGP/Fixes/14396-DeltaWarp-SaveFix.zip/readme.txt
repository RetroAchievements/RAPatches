Use with:

Delta Warp (Japan) (En,Ja).ngc
d4651757a3db5a8e5a5a64c337c6002f
ADD4FDFF