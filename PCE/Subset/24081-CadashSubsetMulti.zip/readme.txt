Use with:

(No Intro)
File:               Cadash (USA).pce
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              BB0B3AEF
MD5:                617A4254C05E88145110718951039E61