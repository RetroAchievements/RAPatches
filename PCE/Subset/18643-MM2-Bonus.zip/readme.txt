Use with:

Mega Man 2 (USA) (Unl).pce

NonGood equivalent: Mega Man II (US).pce
MD5: e68b97f12b236e7b827dc77f98d29cd5
CRC: 64C67A8F


Resulting ROM shares checksum of megaman2_ver087.pce (NonGood)