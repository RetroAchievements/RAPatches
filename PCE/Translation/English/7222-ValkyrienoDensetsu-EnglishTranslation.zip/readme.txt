Use with:

(No Intro)
Valkyrie no Densetsu (Japan).pce
f08a37d37a69315652e1a0ec8dbba650
A3303978