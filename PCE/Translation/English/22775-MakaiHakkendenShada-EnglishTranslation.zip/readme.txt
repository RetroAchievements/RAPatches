Use with:

(No Intro)
File:               Makai Hakkenden Shada (Japan).pce
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              BE62EEF5
MD5:                06C9C65E0E1C0669BE28CC99ACE61F54