Use with:

Shiryou Sensen (Japan).pce (No-Intro)
cfd7fc43a9664979685b8e4358e4555f
469A0FDF
