Use with:

Dragon's Curse (USA).pce (No-Intro)
55153240fe1d0076c4f759b82f2d7e3e
7D2C4B09
