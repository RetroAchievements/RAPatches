Use with:

(No Intro)
File:               James Bond Jr (USA).sfc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              69C2F850
MD5:                40BC3A750D8ADEAAF15ABDAAA6DB9EE0