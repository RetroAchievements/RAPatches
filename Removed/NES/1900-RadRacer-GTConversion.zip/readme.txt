Use with:

Rad Racer (USA).nes (No Intro)
V14-/V15+ RA Checksum: fa0688fd15c7851878997b0c61b109e9
ROM Checksum: 1f0014742b957f323599f5109f7fad73
CRC32 Checksum: 595DAA35