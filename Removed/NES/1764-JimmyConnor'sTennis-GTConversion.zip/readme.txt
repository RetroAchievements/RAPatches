Use with:

Jimmy Connors Tennis (USA).nes (No Intro)
V14-/V15+ RA Checksum: 1bddc3b9473d6bd1e5cad34a805845de
ROM Checksum: e3f903e2a4ee6a8939081ebc4f69b5af
CRC32 Checksum: C31E3754