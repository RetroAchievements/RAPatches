Use with:

Soccer (World).nes (No Intro)
RA Checksum: c432b613606c41bafa4a09470d75e75f
ROM Checksum: d0f9c6cbf039416dad98230bced05892
CRC32 Checksum: 820D62AB