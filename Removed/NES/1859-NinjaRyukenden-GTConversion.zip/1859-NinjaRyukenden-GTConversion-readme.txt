Use with:

Ninja Ryuuken Den (Japan).nes (No-Intro)
b0430c155e39e89cbba8f3d143027387
BA7818A1
