Use with:

Shadow Warriors (Europe).nes (No-Intro)
60e2600fa999530ea5b3964d1048e143
1D2FB2B7
