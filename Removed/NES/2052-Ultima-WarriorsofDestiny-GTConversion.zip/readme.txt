Use with:

Ultima - Warriors of Destiny (USA).nes (No Intro)
RA Checksum: 65dd13bba2feeb90e13567be72f8795c
ROM Checksum: deac2a37fb35d44af259f4621cc10a29
CRC32 Checksum: 2D8C2829