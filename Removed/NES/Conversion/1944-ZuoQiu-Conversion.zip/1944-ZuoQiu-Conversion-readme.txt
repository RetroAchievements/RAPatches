Use with:

Side Pocket (USA).nes (No-Intro)
b2e9418c80a3561cb182bfcd13174edb
1FBACF06
