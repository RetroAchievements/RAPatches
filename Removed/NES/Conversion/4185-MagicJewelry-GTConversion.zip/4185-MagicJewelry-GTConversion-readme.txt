Use with:

Magic Jewelry (Asia) (Unl).nes (No-Intro)
f2cfa49312bd4de3624ac24618dcd55b
C3940BF2
