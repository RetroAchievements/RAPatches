Use with:

Jackal (USA).nes (No-Intro)
c6c17bf18a51718859f9bd6aacb7ef58
2E52D091
