Use with:

(No Intro)
File:               Castlevania (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              AE0FA667
MD5:                379DE955AF1C8F3AE231783831793B8A
Headerless Data:
CRC32:              0AC1AA8F
MD5:                756170BA1E06FA26C60D10114DC6A5AE


(No Intro)
File:               Castlevania (USA) (Rev 1).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              12A6CB14
MD5:                A1B849F232781D0E929435DF447822B5

Headerless Data:
CRC32:              B668C7FC
MD5:                728E05F245AB8B7FE61083F6919DC485