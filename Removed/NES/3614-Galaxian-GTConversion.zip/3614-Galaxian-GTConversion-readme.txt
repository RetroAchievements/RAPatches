Use with:

Galaxian (Japan).nes (No-Intro)
01c1f123f436943527f50eb585025b99
084F61CD
