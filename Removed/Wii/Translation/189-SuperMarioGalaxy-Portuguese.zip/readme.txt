Use with:

(Redump)
File: Super Mario Galaxy (USA) (En,Fr,Es).wbfs
CRC:  554C4520
MD5:  b2f195d72c0e159fee288114edb4c9ea