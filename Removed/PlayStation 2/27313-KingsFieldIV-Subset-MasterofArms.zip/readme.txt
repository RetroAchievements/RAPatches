Use with:

(Redump)
King's Field - The Ancient City (USA).iso
MD5: e4c7bc4021db07893580f70e66cff3f6
CRC: 879215A7