Use
Monster Hunter G (Japan) [Subset - Town Quests].xdelta
with:

(Redump)
File:               Monster Hunter G (Japan).iso
BitSize:            31 Gbit
Size (Bytes):       4206362624
CRC32:              55A6318A
MD5:                33E84667478B7545AE96D6E9789CFAB6
SHA1:               FD63BA943F6A2B3862EAF148CCC36C6B1BEE2372
SHA256:             1F42874C47CBAC732AD1DF85F82E6072E191A43DC2D553E2A163E924D04784F8

Use
Monster Hunter G (Japan) (En) (Remix v13) (Amaillo) [Subset - Town Quests].xdelta
with:

File:               Monster Hunter G (Japan) (En) (Remix v13) (Amaillo).iso
BitSize:            31 Gbit
Size (Bytes):       4206362624
CRC32:              0AE6D003
MD5:                09CE31E4B140C0056E0DB584BF570983
SHA1:               F78EAD9B3A2AC6CB6DF84A930F3C8B5E542AFE04
SHA256:             F436D0948352E03C53CA0209FBF5C521873A764E1D605EB8DEC1A530BFA9DB61

Use
Monster Hunter G (Japan) (En) (Remix v13) (Amaillo) (MHGPlus) (vFinal QuestFix2) (Yuzucchi) [Subset - Town Quests].xdelta
with:

File:               Monster Hunter G (Japan) (En) (Remix v13) (Amaillo) (MHGPlus) (vFinal QuestFix2) (Yuzucchi).iso
BitSize:            31 Gbit
Size (Bytes):       4206362624
CRC32:              02A52335
MD5:                3A4082ED6EA7A04EC2C902D56C8373AC
SHA1:               6A7CAAE7F63C2F2DD3EA13F30F20680B05E80B38
SHA256:             8CECEC9FB1DBBCBFA75721CA03A53D7F9F799BC92021C6A5545B871C2A213084