Use with:

(TOSEC + RAPatches)
File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 1).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              1DA7B4CA
MD5:                7BA941B04BFDFBAAC43FDD83C7A80942
SHA1:               475FD7261C660A0FB22BC2AC6D8F13623E9DECB5
SHA256:             8BCF5D548DAC76BE1F50F3E81853F305F4878EC206DF0790484717FA53E1C1FC

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              2490A3DB
MD5:                C618F19A7285659146764257C4F79090
SHA1:               BA38317AB8D0F21B52BB800EF7CDEF569720A1D0
SHA256:             E655C7935A1EA71D69DC7D86FB1823004FBDB05DE292CDEAFF07BDE218384976

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              DC691B46
MD5:                5824767DA22E2A9E5A04201738B0E948
SHA1:               C6A5E12078494D4F281FC122C3BC1845E95BAF41
SHA256:             079BADC94C63DB18CA86CE4041B55717F689C95CBD271B58FC2BDB3C9F454E5C

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 4).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              B92F2FB2
MD5:                79CF4631CE1E93AFD9390E0D24DDD75F
SHA1:               A50503623B9040FF727092A880FCF3EE319D0A98
SHA256:             E1FEBCC1EF10178757B172ED43C242BDAD9FE08B2A407F16A6F7A00357704A99

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 5).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              766D43E6
MD5:                FC68D417C66616DE5C51005A05741C49
SHA1:               BF40D2404849E41E0084E950E5C36CB5B5CDD254
SHA256:             86B40127796156F496EA254378679755CA8BED2F1BAA0EA49AFFC1C6CFB82BDD

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 6).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              3AB55228
MD5:                457AF8D3B5A6082C9C08E705256CC044
SHA1:               DFB2A415DA453164F4EAFD619E534AEADC0B022E
SHA256:             9D7D35E83D97E17E5EF1ABED44B2F6261E2A1937367EB54EC7301A606D3D5E35

File:               Princess Maker (1992) (Micro Cabin) (En) (v1.0) (Teo Lopez Del Castillo) (Disk 7).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              2D2670A3
MD5:                E78728C594ABD9A5ABB05A9833079285
SHA1:               E96973C3FC72E2F0BE22543623CBF3869A3A578E
SHA256:             4AF563D6EECCBB1B8CF7BB4E88DA71A1DBA2CB13E5816346317242D72043EF25

