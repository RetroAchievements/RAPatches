Use with:

(No Intro)
Metal Gear (Japan).rom
12e302954fa9b23c11ce7c8f5770b82a
FAFE1303