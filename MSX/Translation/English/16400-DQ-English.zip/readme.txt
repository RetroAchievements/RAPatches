Use with:

(No Intro)
File:               Dragon Quest (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              7729E7A9
MD5:                B6A39A89FB0DF0BE5DFF7D64F5FE8900