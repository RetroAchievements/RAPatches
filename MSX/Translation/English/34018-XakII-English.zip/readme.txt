Use with:

(TOSEC)
File:               Xak II - The Rising of the Red Moon (1990)(Micro Cabin)(JP)(Disk 1 of 6)(Opening Disk)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              6ABBA413
MD5:                616D050D2515F6F83DCB40C7DF208008
SHA1:               A4981DA3AAEAEE5A5FB65A5C63331094369557D2
SHA256:             2228B4C03B0E35E3071F31E7E9B281C06BA1DAF6FB9778035D7209145669ED16

File:               Xak II - The Rising of the Red Moon (1990)(Micro Cabin)(JP)(Disk 2 of 6)(Game Disk 1)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              AE57BC79
MD5:                273BCF6F7E375F085CDD02964ADC6F6A
SHA1:               0E7764B421A15BFC2B321B093A8724E0ED564573
SHA256:             17BF30CDA123DB24E46004DDECD91DD5453E68A165C59117CB62B9099ED67D25

File:               Xak II - The Rising of the Red Moon (1990)(Micro Cabin)(JP)(Disk 3 of 6)(Game Disk 2)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              BBBB87A5
MD5:                57F18122C24F59BA3422BB1641435221
SHA1:               5E1A654527BD03789064F9A9B4ED04F634236238
SHA256:             3137CA05E05AC03D092D7F7A56246238FFCD60F2764196CCF3032354739A7708

File:               Xak II - The Rising of the Red Moon (1990)(Micro Cabin)(JP)(Disk 4 of 6)(Game Disk 3)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              33A6F59B
MD5:                7C045DE8EC0E73688FD52892508F107C
SHA1:               7310143250E695FCCA2458FEBC81236F40E59CFA
SHA256:             9F747A94173B93B982D95AEDB2C2F46B91570C8DD7EFEDC755BCE3C95461F306

File:               Xak II - The Rising of the Red Moon (1990)(Micro Cabin)(JP)(Disk 5 of 6)(Game Disk 4)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              9FF8E365
MD5:                A1AE01277248218D0516DE67F6D06D71
SHA1:               0E931895B6569C1E364AC9D9DF0F5B0BA8E38833
SHA256:             C5384F42229B2D4400C52FEA2713C52A6D15ED711BB6161111F5B4FA6BA32F6E
