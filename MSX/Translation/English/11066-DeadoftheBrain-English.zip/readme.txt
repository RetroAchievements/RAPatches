Use with:

(TOSEC)
File:               Dead of the Brain - Day of the Living Dead (1992)(Fairytale)(JP)(Disk 1 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              9F92F165
MD5:                4F5B73C1A06826C0FADE506A91C7C128
SHA1:               B07072CA1EC75B03707ED5D16D05F0821698C9C6
SHA256:             1B77943FC768EDB2F35B71A604A6C9B4433D9BAD7A2F2C1D926ED1F594BA07FD

File:               Dead of the Brain - Day of the Living Dead (1992)(Fairytale)(JP)(Disk 2 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              57883240
MD5:                123705481B66D40ACD7039724E2943CE
SHA1:               9E887F4211D6B68F09DA9B5E7593B740A99CBF07
SHA256:             B4EE49950F7D22B918678A14D2803E36BE762A33C071307CC593F0C178FC8792

File:               Dead of the Brain - Day of the Living Dead (1992)(Fairytale)(JP)(Disk 3 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              08FB12DE
MD5:                6F389E6CF51D7A950B270CAB65FAD150
SHA1:               2014F2557F89A81896002EE62A7832BB16532358
SHA256:             96988985327FED054A7251B49140115ECCB6B53945666A864C25FF36FB0BC90E
