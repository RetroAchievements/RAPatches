Use with:

(No Intro)
File:               Stone of Wisdom, The (Japan).rom
BitSize:            256 Kbit
Size (Bytes):       32768
CRC32:              8C7A7435
MD5:                C5B05F12E6C3BFE8F8391E949508EFF7
SHA1:               3950F22265139A84CF57F3C0936E7927173F3D7A
SHA256:             823911EC562B4EE2EB8237A31253FE7853746A02D4DD27057CF535D0BFBD06B1