Use with:

(No Intro)
File:               Dragon Slayer Jr. - Romancia (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              17F9EE7F
MD5:                560544F37BF6F806B200D5DB3D562E26