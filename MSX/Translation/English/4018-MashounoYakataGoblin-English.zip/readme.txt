Use with:

(No Intro)
File:               Mashou no Tachi Goblin (Japan).rom
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              D34D74F7
MD5:                65F4DE7E2DAD263973DAD54B70A79F74