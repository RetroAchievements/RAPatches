Use with:

(No Intro)
File:               AshGuine - Densetsu no Seisenshi (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              3CB34EFB
MD5:                851ACA1E5D3F0E8D9B1CBEC2E8451831
SHA1:               F57B46154CF0711E3F5218E00F67C375D95D1D5D
SHA256:             3668E0EC34B2E69C5A84EE6082E277466D60E99807936C06BC79A8A87B23D850