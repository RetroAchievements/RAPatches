Use with:

(No Intro)
File:               Shiryou Sensen - War of the Dead (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              39E1C37A
MD5:                89DB61D03A72AEDE925D79E02706F666
SHA1:               3194153A9C93AA24B37804A764F112BDEF091BF8
SHA256:             BC621C8BDB5D9A721989DCF3A77158229869CA73FBBDCB796C43E98E2D27D084