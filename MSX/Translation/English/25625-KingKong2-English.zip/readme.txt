Use with:

(No Intro)
File:               King Kong 2 - Yomigaeru Densetsu (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              23B78A2D
MD5:                A7BC0525D6367FE9B32EB568A14133E7
SHA1:               FE4BD35E87DD50FDDD255172129B9BEC38691188
SHA256:             9C42A0B4D4219176E0E894C434DEB0B479CDE3CE9EDBD9E99395A8BAAE6C01D6