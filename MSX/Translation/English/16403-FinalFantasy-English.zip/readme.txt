Use the one of the bps patches on the following file:

(TOSEC)
Final Fantasy (1989)(Micro Cabin)(JP)(Disk 1 of 2)(Game Disk)[a3].dsk
RA Checksum: 636370BA2BBD18F94168D93D82988848
CRC32 Checksum: DF6C730F

To save the game, you must create a .m3u file that lists the patched file and your user disk.

NOTE: Due to a bug with how data is stored with the English patch, a bug can occur if you start a new game with the performance patch that
causes Garland to not spawn in the Chaos Shrine, leaving the game unbeatable.
To fix this, start a new game on the unpatched version (or the English patched version without Performance) and save by sleeping at an inn.
After that, you can use the performance patched version without issue.

Additionally, the performance patch causes problems for the User Disk creation process.
Feel free to use the provided user disk to skip the creation process.
Or, if you want to make one yourself, use either the unpatched or non-performance patch until you format it in-game.