Use with:

(No Intro)
File:               Malaya no Hibou (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              F7A9591D
MD5:                8153CC9023D0E38D7DA0B359C47DF5E8