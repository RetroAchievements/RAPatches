Use with:

(No Intro)
Penguin-kun Wars 2 (Japan).rom
3db77573e81184156486fe743b828e58
B1B24DA1