Use with:

(No Intro)
File:               Ganbare Goemon! - Karakuri Douchuu (Japan) (Wii U Virtual Console).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              40E53EA3
MD5:                44C47AE77D38EE95D311F90204ED4AC5
SHA1:               FD71DF03B0E9F3CAF701ECFC6D5232060CAB3B13
SHA256:             A436ADDC241D977BA38081463322E7E611D6BAB4D10CD06305FE5A71F02A549C