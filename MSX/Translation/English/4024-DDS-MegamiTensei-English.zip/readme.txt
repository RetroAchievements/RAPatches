Use with:

(No Intro)
File:               Digital Devil Monogatari Megami Tensei (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              25FC11FA
MD5:                5FAAA5AB88E24224584577C4C43EFC40
SHA1:               7DC7F7E3966943280F34836656A7D1BD3ACE67CD
SHA256:             803C8486DD54E3316140531590B4D725F038A776F56041FF954D3717CEC6FF7B