Use with:

(No Intro)
File:               Hinotori - Houou Hen (Japan) (Alt).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              D95116B0
MD5:                C35D87613BC6C7F5C03BFB8FA220A3F6
SHA1:               612C18616BC800D9EB69B9DA3CD29ECA31F50C1C
SHA256:             D4D443C18203F1A463B4D0B356A95C5DC578E24E47E5EA596C773B63AD20FBA0