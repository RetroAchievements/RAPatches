Use with:

(No Intro)
File:               Golvellius (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              5EAC55DF
MD5:                AB0FE259831647DA8F6E8DCF24FB0B45