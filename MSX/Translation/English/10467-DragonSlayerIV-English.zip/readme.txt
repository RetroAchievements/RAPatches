Use with:

(No Intro)
File:               Dragon Slayer IV - Drasle Family (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              98095852
MD5:                38209DD384CA5A791E97FFC6C68097A2