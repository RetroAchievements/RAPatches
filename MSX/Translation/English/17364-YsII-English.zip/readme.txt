Use with:

(TOSEC)
File:               Ancient Ys Vanished II - The Final Chapter (1988)(Falcom)(JP)(Disk 1 of 2)(Game Disk)[a2].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              D7D8E9EA
MD5:                3C6DCE5438EF82689A1C23465596E318
SHA1:               B7E599FAEAFC9735E2F73933EC0589771616FFF0
SHA256:             B2E3F93FFA04BB00DBFD7B279838FC746CEB880244E90176B0FDC48CB686BCC9

File:               Ancient Ys Vanished II - The Final Chapter (1988)(Falcom)(JP)(Disk 2 of 2)(Data Disk)[a].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              73C23B9E
MD5:                28B348C771D677F4446CC6A5DFF8080B
SHA1:               1710CB95CCFA8138C7732A4FD5AE92D8C37B491B
SHA256:             23361308F26B62F73B66A9F17EB74D853A6F7CF8DF5571E0E6B922503CDD6AC7
