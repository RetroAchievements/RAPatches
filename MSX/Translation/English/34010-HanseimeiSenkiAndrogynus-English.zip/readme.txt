Use with:

(No Intro)
File:               Han Seimei Senki Andorogynus (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              C6F74489
MD5:                65ED7FCE763E5E7EC60306E86FFF872F
SHA1:               55183B7B7DF66950DBB65EF1065D7D987E0FDF5A
SHA256:             F298DB966471BD45851FE50A22926087D1D9CEBB98C7BCEAA68EE266FA3D5934