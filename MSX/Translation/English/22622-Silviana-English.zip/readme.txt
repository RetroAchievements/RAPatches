Use with:

(TOSEC)
File:               Silviana (1989)(Pack In Video)(JP).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              E9993ECA
MD5:                FBDA461B65B6D4F7EDC18C04A38DD1ED