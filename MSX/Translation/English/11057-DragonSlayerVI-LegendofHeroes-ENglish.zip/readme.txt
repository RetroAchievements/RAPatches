Use with:

(TOSEC)
File:               Dragon Slayer 6 - The Legend of Heroes (1990)(Falcom)(Disk 1 of 5)(Game Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              EB942948
MD5:                E9CE6D341813C57A0DD049A03F3A501F
SHA1:               87A4570AB486E87B81016D9BA18040ADA41041FA
SHA256:             562A0259C79EFB8C6698431CB3C1312E2D08517AB261975021444383B5D38827

File:               Dragon Slayer 6 - The Legend of Heroes (1990)(Falcom)(Disk 2 of 5)(Scenario 1 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              A61150E1
MD5:                12C5F1D0E56CC682EB7A23260BB06AB0
SHA1:               86D4E55B0467925C1C49A056B62A3ACA16A3A7E4
SHA256:             A67833B794CE563F76445F07006A8F7ADBCD4929D27021D9E977B622043AD1DF

File:               Dragon Slayer 6 - The Legend of Heroes (1990)(Falcom)(Disk 3 of 5)(Scenario 2 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              175E7262
MD5:                202EF61831204D807EBC36FCED323A0A
SHA1:               30A812A98388ED90DA1494DA00AE19C916081347
SHA256:             FDE334555E6191145A4CE031A797A6BE430E43B83E4B68704BABCEF19744DA7F

File:               Dragon Slayer 6 - The Legend of Heroes (1990)(Falcom)(Disk 4 of 5)(Scenario 3 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              FA685A65
MD5:                66A91F85FA747F32C5EA4B784D55F9DE
SHA1:               7E5C6172B803D89D7B503F6DB8D8FDBF6AEF0C54
SHA256:             494E6F67BB9455A255BB0F5AAA9DCF0924182E45DEEE7E10CBB815A65A48D2AC
