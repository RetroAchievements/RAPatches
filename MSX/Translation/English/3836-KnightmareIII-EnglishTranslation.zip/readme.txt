Use with:

(No Intro)
File:               Knightmare III - Shalom (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              CF60FA7D
MD5:                355F48B2A181880E60314F69752F9084