Use with:

(No Intro)
File:               AshGuine Story II - Kokuu no Gajou (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              47A82D74
MD5:                3B191BA16E7C5DEF2F1E9FEBC1FB92E5
SHA1:               EFDF63F01293251DC593163A42F31556FD042282
SHA256:             25556813DF44C5062A22174978F8919D341D7BA6088878E5EC2AC52D100D6048