Use with:

(No Intro)
File:               AshGuine Story III - Fukushuu no Honoo (Japan).rom
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              353382CE
MD5:                F582DF437DDE65D958EEC72260801B32
SHA1:               6FD90E7573ABDB5A7BD6E4E8DC44DB80FC163E30
SHA256:             3639D50B155FCC59D508311FB29AF19E6152ABF6DB258548BEFDC53776EDF42F