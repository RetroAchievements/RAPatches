Use with:

(TOSEC)
File:               Dragon Slayer 5 - Sorcerian (1987)(Falcom)(JP)(Disk 1 of 5)(Game Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              2E78DEA6
MD5:                D5A70FCDDA8963FAB885BDDBDA7AB122
SHA1:               D61B45D5C9ACD4AB956A96CD29F8CD193FF7BE08
SHA256:             C3BC0A2A49A7B0B7451E21E11ED8536B3818964B6FC4581070F9F4B8D710E451

File:               Dragon Slayer 5 - Sorcerian (1987)(Falcom)(JP)(Disk 2 of 5)(Scenario 1 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              A672D57F
MD5:                7803F87CD99E4BD507B8EA986EC8C7BE
SHA1:               B04522B146DA995231B6D3D824689BC26948A320
SHA256:             8D53E039666553B5B25B6158BE7A3B646D103ADB50FD268D4483084BE821B2A1

File:               Dragon Slayer 5 - Sorcerian (1987)(Falcom)(JP)(Disk 3 of 5)(Scenario 2 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              593EC54E
MD5:                4815B29ABDF64AE52135D36B8B1A8650
SHA1:               B612FD891215534B03E80ADDC342B84C03C5A369
SHA256:             9D6BB0F19B7254FA614F410E6FF01519D4186AC717F8E570A6C24407AB3098BE

File:               Dragon Slayer 5 - Sorcerian (1987)(Falcom)(JP)(Disk 4 of 5)(Scenario 3 Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              C31FF24B
MD5:                391FAFCD00ABCD5861223ECD7005665A
SHA1:               160C12350C97A213D1C92E978A243DA4A3A4EA34
SHA256:             2CC1989FB412207A3D7E772B75A11396F7F5C174EB57AE781E3A51E6996B967A
