Use with:

(TOSEC)
File:               Fray - In Magical Adventure (Japan) (En) (v1.0) (Oasis) (Disk 1) (Opening Disk 1).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              735F01C2
MD5:                0EC43432F8D84ECAF9C5EC8D67625575
SHA1:               A0BD6D35C89FBF5EDC438FAC72B626C1F7D5983E
SHA256:             F2451F5030906422FB116AB144683B7AFEC558131A757CD0AC1AD87DF0F81FEF

File:               Fray - In Magical Adventure (Japan) (En) (v1.0) (Oasis) (Disk 2) (Opening Disk 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              34BCA240
MD5:                BFBF24692B0A61E7A7BD1EAA2FD1C860
SHA1:               0ADCFCA1ADE6CE66EA3AD655F949D9940D181CAD
SHA256:             257A77E209DDCCF966DA0CE179A9F5C3DF0D3D993B1557C7FED7B12A5F89E05C

File:               Fray - In Magical Adventure (Japan) (En) (v1.0) (Oasis) (Disk 3) (Game Disk 1).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              A7047634
MD5:                23DA96BA182C8081FD49FAC5B9DCF0E4
SHA1:               C6BDFBC94C460F8964985D61285BFD1E559BBCB3
SHA256:             148713E7280440DD830E3D26AD898158672C94F976E8FAAA200AE430C2F1AE0F

File:               Fray - In Magical Adventure (Japan) (En) (v1.0) (Oasis) (Disk 4) (Game Disk 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              C7D675E6
MD5:                90526F294C8C34A4C6788697DEED412E
SHA1:               EA55D4FEEA9C1E45CC63FFB1B4F0AEB551ACDBF3
SHA256:             A0976A405C292547DDF6A17303BAA6DE48E859A040CFD8BBAE99F6DD30CC850D
