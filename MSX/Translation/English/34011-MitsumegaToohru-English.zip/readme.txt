Use with:

(No Intro)
File:               Mitsumega Toohru - Three-Eyed One Comes Here, The (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              4FACCAE0
MD5:                2D2F5B2EA8BEA2F6DAA765EFFFCF6A4B
SHA1:               176EC8E65A9FDBF59EDC245B9E8388CC94195DB9
SHA256:             8B08BA9F9B3E13CE4CCF36731D722D231477B5DDF45107949ABB89DD4A5A0168