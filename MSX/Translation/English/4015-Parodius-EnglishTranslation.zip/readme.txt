Use with:

(No Intro)
File:               Parodius (Japan) (Alt).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              CA21CDE4
MD5:                E753BB6637DD811F1E9B41747A1D3C58