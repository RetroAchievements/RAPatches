Use with:

(TOSEC)
File:               Shiryou Sensen 2. War of the Dead 2 (1990)(Victor)(JP)(Disk 1 of 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              BBE61F63
MD5:                50680AC1F866DB69210A303E107C85CC
SHA1:               FD9AA0EB8E5451FD0CB51A8296CB1004692DC727
SHA256:             5311240951CB71F1AAFA6C661DFD732B520CF072D9F641858ACA8778B5DBE2D6

File:               Shiryou Sensen 2. War of the Dead 2 (1990)(Victor)(JP)(Disk 2 of 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              84628411
MD5:                9D28564DABC83BD16C8EA5F2A1F3C7AA
SHA1:               28B5BE7124FD6B0223136BCFACB2FAC1B9E1F6E4
SHA256:             93933502489751BA79D0FDA5DE1F8DD997C7A3B3546F890AD2457B741E19378F
