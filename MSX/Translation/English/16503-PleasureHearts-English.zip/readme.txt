Use with:

File:               PLEASURE.DSK
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              BF81E259
MD5:                CC86D3600BF2994A7A65852A225A2893
SHA1:               83646E9E2BD7451F2B45B9C8CBC15531DAD51CB2
SHA256:             276496B13C64857F5ABDDBD891E3239AEBD9A3F580D5159B4E725F1B0F6F4A10

https://www.msx.org/downloads/games/shoot-em/pleasure-hearts