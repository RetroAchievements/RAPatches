Use with:

(No Intro)
File:               Borfesu (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              E040E8A1
MD5:                9E98015A26D7615DB9DEA90F6D97B4B9