Use with:

(No Intro)
File:               Gekitotsu Pennant Race 2 (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              C44C6330
MD5:                AF91306740FF42FFD25F0F75D3E4FCA8
SHA1:               93B07E3CD5AE2F00B36824A74F83A3EF0D65D0D5
SHA256:             E013DB9EFCE513E993DC8FB77CA08AA486C1284E1DB36C388C01F8426D736461