Use with:

(TOSEC + RAPatch)
File:               Adventure of Randar (Japan) (Clean).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              09EACCC6
MD5:                C87B75029BEC477A114354177346BCBD
SHA1:               6884817CCFCABEFF1F13DBE5D857CF07890F95AB
SHA256:             8524B0CFA78D8B6631C7E9CC848972F3A5C1133B745E191F770635A63E3BE259