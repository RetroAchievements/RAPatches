In order for this game to work with RA, the save data must be cleared.

Included in this directory is "Adventure of Randar (Japan) (Clean).bps" 
which must be used on the TOSEC-verified dump detailed below.

Use with:
(TOSEC)
File:               Randar (1989)(Compile)(JP).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              4BAEA838
MD5:                227A4A048C676ED602D2BCD2F7A2954F
SHA1:               F01EA5B68A82EC06435520055C2F57562B66F053
SHA256:             C2FB5FE3F57C8A1930CD7907618E13715452CF59925D4A8A66B59441C81A1E08



Once patched, you can play the game in Japanese or use the patch in the
"TOSEC (Clean) Base" directory to play in English.