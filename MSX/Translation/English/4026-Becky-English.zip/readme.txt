Use with:

(No Intro)
File:               Becky (Japan).rom
BitSize:            128 Kbit
Size (Bytes):       16384
CRC32:              A580B72A
MD5:                C47B53B72C6C3588EA5B881C0FCDBA2B