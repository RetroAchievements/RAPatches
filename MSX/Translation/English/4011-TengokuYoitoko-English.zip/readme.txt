Use with:

(No Intro)
File:               Tengoku Yoitoko (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              7E637801
MD5:                88E940BB5C15D201BF1779821C10D923