Use with:

(No Intro)
File:               Nyorols (Japan).rom
BitSize:            128 Kbit
Size (Bytes):       16384
CRC32:              6D81D863
MD5:                E83E8D43C8CA5E6FEC21996D47A619ED