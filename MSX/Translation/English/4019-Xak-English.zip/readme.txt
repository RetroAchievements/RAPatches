Use with:

(TOSEC)
File:               Xak - The Art of Visual Stage (1989)(Micro Cabin)(JP)(Disk 1 of 3)(Opening Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              32F044B3
MD5:                BC1CD40D59F11D69CB2C55A1CC55B598
SHA1:               3B491035B2B85C6619D1133F0C31E9A973EA8C1E
SHA256:             8183C29D40E30665852F86F81FB8D3C293A766D4FC1E73FE968D1519252173A7

File:               Xak - The Art of Visual Stage (1989)(Micro Cabin)(JP)(Disk 2 of 3)(Game Disk 1).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              1AB66C77
MD5:                B5C0E183409E57565ED7D982CD81D989
SHA1:               FFB30C79DBDFB344E76FA4A13C59A667F0342CCD
SHA256:             E5CF0D9880F825D34596F011D9AB608E1841B78A77A18A603019B0D35FAB46D0

File:               Xak - The Art of Visual Stage (1989)(Micro Cabin)(JP)(Disk 3 of 3)(Game Disk 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              94E02E04
MD5:                3FE8D98EE3258EE3EEB125A16B9FB615
SHA1:               86179A4F22B6E792637E281CE17650429E2C4465
SHA256:             5137C3DA24B105912538F721C03FAC45E0B4974FE20FDCB9085609DB7E03C57E
