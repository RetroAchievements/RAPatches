Use with:

(TOSEC)
File:               Xak III - The Tower of Gazzel (1991)(Micro Cabin)(Disk 1 of 4)(Opening Disk).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              405160C0
MD5:                75336135466D17B1BEA87BB43ECD0F77
SHA1:               06042CE12D2B4C16357EA6385335C232698D02D1
SHA256:             1ACB9BE1F87B04E7E7F3675B499D1D3B8DFE36C7F54192BCB7B65662F3AE1CC6

File:               Xak III - The Tower of Gazzel (1991)(Micro Cabin)(Disk 2 of 4)(Cabin Times).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              4437D318
MD5:                B14B88F3D45F58EAFF26F7DCC49BF901
SHA1:               6DAEAAF7AFC74A09CEB51ADC39AC9390C18BD456
SHA256:             90429FDDAD2431E9CFE7F68F2AF1FB0E8E2CF39FC17FF76B795532D47744E707

File:               Xak III - The Tower of Gazzel (1991)(Micro Cabin)(Disk 3 of 4)(Game Disk 1).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              1006EB21
MD5:                A704AAF68C26C68FB97F51AB83882CEF
SHA1:               E20DE4CDDB47C22C1E2446877ED88CEE53D19557
SHA256:             1DD280CDB3AF880ED5DED3736748D510E1E511A11255DBF2747E1B0BD24A98BA

File:               Xak III - The Tower of Gazzel (1991)(Micro Cabin)(Disk 4 of 4)(Game Disk 2).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              0D427EDD
MD5:                D3BE49916C452017BD6024C402796875
SHA1:               418425B63D5924309D580488002C881B9B174A21
SHA256:             F48CA3D0A27B4AF9BCAA47EAFC336E7AFE61CCA7BE82CC423C6311F73E0CD920
