Use with:

(No Intro)
File:               M36 - A Life Planet (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              FA8F9BBC
MD5:                EE9FE57E172B4E734847B95CDB57E9D5