Use with:

(No Intro)
File:               Super Deform Snatcher (1990)(Konami)(Disk 1 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              83DBE06F
MD5:                EB58AA6C3AD17511C3446AD674D53BA0
SHA1:               8134D72F38380C5FF4D01A693096CB2A52FDFBF7
SHA256:             D88F770E1EC1F50AFB931F9091BE97E956C5C4E53242236A8B722EA5D3BD05FD
-------------------------------------------------------------------

File:               Super Deform Snatcher (1990)(Konami)(Disk 2 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              4E4AAA7D
MD5:                28C4A4C3B5E9ABEA6941AD5DAB20BD68
SHA1:               231153E21CB8D36C3E4A8F2C01B74D6442E8DB63
SHA256:             9D200009994AB4E538F15AFA9C29ECE1E24614BBE43CE7E9BF3A1641DF1DDDD8
-------------------------------------------------------------------

File:               Super Deform Snatcher (1990)(Konami)(Disk 3 of 3).dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              51D1199A
MD5:                2CD4AE28421533F766C435AB48EB5AE1
SHA1:               3383A02B01D04F88FF707B878C9B75C76DBD873B
SHA256:             4E81CBC7B47624BC8DC07AF9600F435C960C80848C4977DDA7BA15EB3F54E773
-------------------------------------------------------------------
