Use with:

(No Intro)
File:               Super Deform Snatcher (1990)(Konami)(JP)(Disk 1 of 3)[SCC+].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              EC0ECD55
MD5:                5268389961BA615384688DF611C172CE
SHA1:               1E8334AA3CB826CC45A3E3D0B46B9CDC228725D6
SHA256:             67813A6136950794CA6EF6554F2457D0AF5B1B5FB443158E9FD943E8AD190CBF
-------------------------------------------------------------------

File:               Super Deform Snatcher (1990)(Konami)(JP)(Disk 2 of 3)[SCC+].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              930E06B3
MD5:                AB9290F7FB6063A2F0356876124BF049
SHA1:               1156F6C4D9332FDC6CDA05558AC3E3102A2764FE
SHA256:             C1C406DEB1217C202F2A450CBD76A5B1EA06FAEAD381A2B160A647CC5CC4890D
-------------------------------------------------------------------

File:               Super Deform Snatcher (1990)(Konami)(JP)(Disk 3 of 3)[SCC+].dsk
BitSize:            5 Mbit
Size (Bytes):       737280
CRC32:              0547BB3A
MD5:                585CAF83583815CDAF6FA11578879674
SHA1:               E4B1B5F8B7EA4532551C103164860C8802151131
SHA256:             7DF3804C957879886567F68312AF08625E5BAD3F9BA84B66E452771EA7D71F9C
-------------------------------------------------------------------