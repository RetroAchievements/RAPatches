Use with:

(No Intro)
Metal Gear 2 - Solid Snake (Japan).rom
9f50d92d35e19d5de37d75a36a410588
18B1F34B