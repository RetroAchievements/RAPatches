Use with:

(No Intro)
File:               Metal Gear 2 - Solid Snake (Japan).rom
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              18B1F34B
MD5:                9F50D92D35E19D5DE37D75A36A410588
SHA1:               AF567EA6E27912D6D5BF1C8E9BC18E9B393FD1AB
SHA256:             43B7FAB533ABEB87313919EC1FC7BC732D7B0EBFACEDE1E4F89D8295160384F2