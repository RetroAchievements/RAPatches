Use with:

(No Intro)
File:               Metal Gear 2 - Solid Snake (Japan).rom
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              18B1F34B
MD5:                9F50D92D35E19D5DE37D75A36A410588