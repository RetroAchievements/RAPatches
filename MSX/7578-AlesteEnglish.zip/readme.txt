Use with:

(Tosec)
Aleste (Japan).dsk
28427cfe955f65c6ec8ef2bdd35ff6a7
73AED1B4