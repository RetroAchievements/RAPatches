Use with:

(No Intro)
File:               Super Boy 3 (Korea) (Unl).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              9195C34C
MD5:                CA1E0E7BDD2A0BE70129B1DE97746E40