Use with:

(No Intro)
File:               Metal Gear (Japan).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              FAFE1303
MD5:                12E302954FA9B23C11CE7C8F5770B82A