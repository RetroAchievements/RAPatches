Use with:

(No Intro)
File:               Vampire Killer (Japan, Europe) (Alt).rom
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              0AEDEA40
MD5:                51D021AF50C3A48124331A9FBC738B97