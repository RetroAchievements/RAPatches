Use with:

(No Intro)
File:               Kekkyoku Nankyoku Dai Bouken (Japan) (Wii U Virtual Console).rom
BitSize:            128 Kbit
Size (Bytes):       16384
CRC32:              AAE7028B
MD5:                97EE96F00FAC07A5D70A3801D8A9805A