Use with:

(No Intro)
File:               Inazuma Eleven 2 - Tormenta de Fuego (Spain).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              207DF617
MD5:                B7E14BC0DC17536DFCF95DA36E1CCBE1
SHA1:               D5332D94137E5378A548F7BB3A7B8431F353743A
SHA256:             B13C10E9D7758DFD304BED36C4FC5724C7F6912758A9BB6CF5F83F4869A6FFC8