Use with:

(No Intro)
File:               Inazuma Eleven 2 - Firestorm (Europe).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              C32471B6
MD5:                CB15824882AEFC201A3FDE17F161F10D
SHA1:               E4FC850FB5E574D5CCE7B33EA333A4851EAEA061
SHA256:             90CA081913F329072EA10B5BAF75E28C2CD8A93C00CDA917840B26DA6FDC15E8