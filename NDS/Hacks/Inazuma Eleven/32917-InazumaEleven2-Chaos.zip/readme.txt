Use with:

(No Intro)
File:               Inazuma Eleven 2 - Blizzard (Europe).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              391E1B3C
MD5:                610B521DE0F1E98588335279FC775899
SHA1:               18F2EFD017F9E17779DBBB2C6834FD5E46B7459C
SHA256:             C166041B1C8B1375AC175ED39A7F04DF79DD84318D89A25C1FBAF20EB1EDEFE0