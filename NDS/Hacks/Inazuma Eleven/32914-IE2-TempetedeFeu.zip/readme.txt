Use with:

(No Intro)
File:               Inazuma Eleven 2 - Tempete de Feu (France).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              B574D31B
MD5:                B1E149B7FFBF183B8499D41AD6094CFA
SHA1:               233487CC3526194A40CC0F83E6B69B771C48EB31
SHA256:             EAC6593227E02A78E69A0954A3FA1B22C8E7BAC400891E4EAC8341FAF78E8968