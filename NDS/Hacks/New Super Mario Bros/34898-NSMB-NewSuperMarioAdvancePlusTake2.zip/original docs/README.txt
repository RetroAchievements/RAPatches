New Super Mario Advance + Take 2: Version 1.1
-A NSMB Hack by MarioFanatic64-

Originally released January 1, 2015.
Version 1.1 released May 15, 2015.
Version 1.2 released June 14, 2015.

DISCLAIMER: PIRACY IS A CRIME. I ACCEPT NO RESPONSIBILITY FOR ANY PENALTIES FACED FROM ILLEGAL PIRACY. IF YOU DO NOT OWN LEGITIMATE COPIES OF NEW SUPER MARIO BROS. AND A NINTENDO DS SYSTEM, DO NOT PLAY THIS MOD AND DO NOT DOWNLOAD A NEW SUPER MARIO BROS. DS ROM.

--Introduction--

Thank you for downloading this full-length modification for New Super Mario Bros. DS! This hack is a remake of the classic NES game Super Mario Bros. 2, remade in the game engine for New Super Mario Bros., incorporating more traditional Mario gameplay but retaining the same classic levels and visual art direction. The hack also includes enhanced levels from my very first hack, rebuilt in the same style as Super Mario Bros. 2. Originally, my first hack was released in two different versions- one version with unmodified New Super Mario Bros. graphics and the other having graphics ripped from the SNES port of Super Mario Bros. 2- known as the "Doki Doki Panic! Edition". When the hack failed miserably, I promised to fix the hack up to make it of a higher quality. Almost five full years later, the full remake "New Super Mario Bros. 2: Take 2" is finally ready to be re-released in a much better light. Of course, expect to see some original content in this hack as well! There are many new inclusions, such as seasons which can change how levels play. These levels are confined to Worlds 4 and 7 so they can be easily skipped if people don't want to play a similar level more than once.

This is my fourth full-length hack to reach a final release, following New Super Mario Bros. 2: Doki Doki Panic! Edition, New Super Mario Bros. 5: Clone Tag Team and New Super Mario Bros. 5: Clone Tag Team 2. Also coming in the future is a ground-breaking new hack to be named Super Mario: Endless Earth, so if you haven't played any of these hacks or are interested, be sure to look them up!

Oh, and be sure to support Nintendo in their tough times and make sure you've purchased a legitimate copy of New Super Mario Bros. DS and the proper Nintendo DS/DS Lite/DSi/DSiXL/3DS/3DSXL/2DS/New3DS/New3DSXL hardware!

--Installation--
These hacks run from the original New Super Mario Bros. DS ROM (The USA version). This means that if you wish to play these mods, you'll need to aqcuire the ROM for New Super Mario Bros. DS from the internet. Due to legal reasons, a direct link to a ROM file cannot be provided, so you'll have to search for it yourself.

You'll know if you have the right file if it is named "0434 - New Super Mario Bros. (U).nds", or something similar.\

Once you have obtained the ROM, you'll also need to acquire an .xdelta patcher. For this tutorial the patching program described will be "xdeltaUI.exe" You'll also need the patch files for the mod, which is contained in this .zip file. There are three patches in this package, each containing a different playable character. You can choose between Mario, Luigi and Toad. You'll want to extract these patches from the .zip file so you can use it with your patching program.

Once you have all this, here are your instructions. Note that you'll have to patch each file individually. In this tutorial, we will be using "NSMA_MARIO.xdelta":
-Extract one of the .xdelta patches from the .zip folder.
-Run xdeltaUI.exe and for "Source File", select your NSMBDS ROM.
-For "Patch File", select "NSMA_MARIO.xdelta" from the directory you placed it in.
-For "Output File", select an appropriate directory and name your file. The file extension MUST be ".nds", so for now just name it something simple like "New Super Mario Advance - Mario Edition.nds"
-Click "Patch".
-Your output file should now be modified to play the New Super Mario Advance + Take 2! You'll be able to play it using an emulator (such as No$GBA for low-end computers and DeSmuME for high-end computers) or using a Nintendo DS/3DS flashcart like R4DS or Supercard DSTWO.

--Updating your ROM for Bugfixes--
Every now and then, bugfix patches may be released to correct some issues people are having with the game. You can apply these new patches to a new ROM or your existing modified ROM, it should all work fine. The current version packed in with this release is v1.0, but be sure to check around to see if there's a more recent patch.

v1.0 was released as of January 1st, 2015.
v1.1 was released as of May 15th, 2015.
v1.2 was released as of June 14, 2016.

--Changelog--

-Version 1.0
Initial Release

-Version 1.1
Added Custom Music:
-Title Screen
-Overworld
-Underground
-Boss
-Game Over
Altered graphics:
-Door Texture
-Fuzzies
Minor Changes:
-Slightly retouched
-Music changed in certain areas

-Version 1.2:
Added Custom Music:
-Desert
-Beach
-Ending
Toad as a Playable Character:
-Mario head model replaced (Toad head by Ray and Freeze)
-Mario body retextured (Textures by Ray and Freeze)
-"MARIO CLEAR" text changed to "TOAD CLEAR"
-Mario Head Icon replaced with Toad Head Icon
-Toad Voice Clips (Clips by Ray and Freeze)
Removed "Mario vs. Luigi", "Minigames" and "Options" from the title screen.

-Known Issues
Some particular areas of the hack are missing background music and certain sound effects. Due to the level design of Super Mario Bros. 2 often requiring many different visual environments per level, exploits had to be made of the New Super Mario Bros. game engine to keep the level design faithful. The downside to this exploit is that there may be some rooms and areas that lack sound effects. I have tried to keep this to a minimum, so there are very few areas where this happens and the rooms where it does take effect are brief enough to be ignored.

If a Fuzzy is located in a level, Buzzy Beetles don't have a walking animation. Fuzzies replace Spike Tops in this hack, and Spike Tops and Buzzy Beetles share a walking animation, so Buzzy Beetles won't load their own individual animation if the game believes the Spike Top animation is already loaded. Because Fuzzies slide along walls there is no walking animation. In levels where there are no Fuzzies Buzzy Beetles have walking animations as intended.

--Troubleshooting--

-What is a ROM?
A ROM file contains a game- it's the file in the cartridges that your Nintendo DS console runs whenever you play a game. These can be ripped and uploaded to the internet, and there are various ways to run them as they are. You'll be able to play ROMs using an emulator (such as No$GBA for low-end computers and DeSmuME for high-end computers) or using a Nintendo DS/3DS flashcart like R4DS or Supercard DSTWO.

-It's not working. What am I doing wrong?
If you don't know what you're supposed to be doing, patching and playing New Super Mario Advance + Take 2 may be difficult. If you need more information about ROMs, emulators or flashcarts there is a lot of information to read on Google.

-I found an error. What do I do?
Don't worry, errors happen. Every now and then, you might encounter something weird in the hack like missing sound effects, or something that doesn't seem to be working right. If you want something done about it, feel free to report the error at the official Discussion Thread of New Super Mario Advance + Take 2 at the New Super Mario Bros. Hacking Domain. Alternatively, you could also report the error at the Discussion Thread at GBATemp or at DSHack.org.

If errors are fixed, a new revision of the mod will be released. Just check for an update at http://nsmbhd.net/ every now and then to keep up with the latest fixes.

-Is this a virus/some sort of scam?
Don't worry, this isn't harmful. You may have to be cautious of the websites where you download the New Super Mario Bros. DS ROM, but this hack itself is perfectly fine and risk free. It's 100% free to play and download, so if you did pay money to download this file you have been scammed and I urge you to do something about it! Remember, you should only have downloaded this hack from the OFFICIAL SOURCES such as File Trip, MediaFire, romhacking.net and the New Super Mario Bros. Hacking Domain.

-Can I get in legal trouble if I play this hack?
As long as you currently own a legitimate copy of New Super Mario Bros. DS and a Nintendo DS system, you should have nothing to worry about. I do not condone Video Game Piracy, this is a not-for-profit fanmade project. However, use this at your own risk as this is a legal grey area and laws are subjective depending on your region.

And with that note, I hope that you enjoy this hack and look forward to my future projects. Currently, one more NSMB Hacking Project is in development, titled Super Mario: Endless Earth. You can subscribe to my channel on YouTube to keep up with the latest updates on Endless Earth, as well as the latest revisions of my hacks.

--Credits--

-Level Design
Kensuke Tanabe
Hideki Konno
Hiroshi Yamauchi
MarioFanatic64
Masayuki Uemura
Satoru Iwata
Shigeru Miyamoto
Shigeyuki Asuke
Toshiaki Susuki
Yasuhisu Yamamura
Yoichi Yamada
with edits by MarioFanatic64
(World 8-Tower from Super Mario Advance 4: Super Mario Bros. 3 - "Corocoro Castle")

-Graphics
Artie
Aya Oyama
Carlytoon
Bormorgin
Freeze
Hiroyuki Kimura
Kanae Kobata
Mariko Sanefuji
Masaaki Ishikawa
MarioFanatic64
Mitsuko Okada
Ray
SaturnYoshi
TRS
Tsuyoshi Watanabe
Yo Ohnishi
with edits by MarioFanatic64

-NSMB Editor 5.2
Dirbaio
Piranhaplant
Treeki

-Special Thanks
The users of the New Super Mario Bros. Hacking Domain

'Till next time,
-MarioFanatic64