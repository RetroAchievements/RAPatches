Use with:

(No Intro)
File:               Pokemon - SoulSilver Version (USA, Australia).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              D8EA6090
MD5:                8A6C8888BED9E1DCE952F840351B73F2
SHA1:               F8DC38EA20C17541A43B58C5E6D18C1732C7E582
SHA256:             51D0F94A16AF7D77C067B4CB7D821BA890A13203A2E2C76049623332C0582E20