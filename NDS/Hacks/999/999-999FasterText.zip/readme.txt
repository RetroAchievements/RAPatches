Use with:

(No Intro)
Nine Hours, Nine Persons, Nine Doors (USA).nds
MD5: 6f15eb27d6724dc424abb66264ef7468
CRC: D7F85F15
RAHash: 7ade38ca60377a283d9f99884bc03bdc