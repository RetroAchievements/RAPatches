Use with:

(No Intro)
File:               Pokemon Conquest (USA, Australia) (NDSi Enhanced).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              0989A8A1
MD5:                E428CCBA832B9E78193C6B673DD63407
SHA1:               CB52F4F8131D790D4D4E805F975E6BD47492EF6D
SHA256:             2F2F932DFF012B551EB02634E1C29D3CAF9C2F707D7C7A92A2C1987E0F1CE030