Use with:

(No Intro)
File:               Pokemon Mystery Dungeon - Explorers of Sky (Europe) (En,Fr,De,Es,It).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              5D2537E9
MD5:                6735749E060E002EFD88E61560E45567
SHA1:               C838A5ADF1ED32D2DA8454976E5B1A1AA189C139
SHA256:             1FA39D35873B58E02F3623438414C334AD93B840651A8A9AC13EE3C789F170C1