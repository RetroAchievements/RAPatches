Use with:

Pokemon Mystery Dungeon - Explorers of Sky (USA).nds (No Intro)
fbd30735438e31cb1600656163b2224b