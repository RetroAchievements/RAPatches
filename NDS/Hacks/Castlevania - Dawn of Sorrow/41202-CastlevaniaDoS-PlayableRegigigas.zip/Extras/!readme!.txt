With the Boss Balore no longer in the Castle, your main target is Aguni, which resides in The Pinnacle. Defeating this boss will unlock the double set of doors which lead into the Mines of Judgement.

It's an alternative way of keeping progression, since removing Balore would normally softlock a save!