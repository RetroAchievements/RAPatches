Use with:

(No Intro)
File:               Pokemon - Black Version 2 (USA, Europe) (NDSi Enhanced).nds
BitSize:            4 Gbit
Size (Bytes):       536870912
CRC32:              D4427FD1
MD5:                4C65A32989C78B8070751765592B0EA6
SHA1:               E51E6DFB8678A3D19DCD2A10691B96A569CA0ABB
SHA256:             2E6B2415354AA41471BC7617068DCE059A59931BF5C4348A264F8043F297683A