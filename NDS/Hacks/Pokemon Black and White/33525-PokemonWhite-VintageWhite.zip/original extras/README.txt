If you are reading this, then you are probably intending to play my ROM hack,
Pokemon Vintage White. Before you begin, I want to cover a few things. 

Difficulty:

First off, this hack is meant to be nuzlocked. All of the fights in the game
(with the exception of a select few that don't matter) have been revamped. This
means that all boss trainers (i.e. gym leaders, E4, etc.) have teams that present
far more of a challenge than in most games. Additionally, all of the regular trainers
have teams that can be extremely difficult as well. To accomadate for this, I have
included a document titled VW Trainer Docs that I would encourage you to use. This game
is not easy and you will probably wipe multiple times if you plan on using harder nuzlocke
rules. 

Pinwheel Clause:

For those of you that feel that doing Pinwheel Clause isn't a viable thing to do, you're in 
luck. Outer Pinwheel Forest has now been aptly changed to Not Pinwheel Forest and the met
location reflects this.

Available Pokemon:

Only Pokemon available in Gens 1-3 (and their gen 4 evolutions) are available in the main game of the hack.
For those of you who wish to go further, the postgame includes the remainder of the Gen 4 Pokemon and all
of the Gen 5 Pokemon as well as revamped boss fights, a whole new Elite 4, and a lot of trainers to fight.

Starter Pokemon:

When you begin your adventure and you get to the screen where you choose your starter Pokemon, worry not,
the images don't actually reflect the Pokemon that you will recieve. Your starter will be a Hoenn starter
that corresponds to the starter type that you choose and the text associated with them will reflect that.

Level Curve:

The level curve is extremely steep in this hack and with Gen 5 exp gain, grinding would be a massive pain. 
I would encourage you to hack in Rare Candies (either via PKHaX or an AR Code) so that you don't spend most
of your time grinding. 

Where's the Weather?:

Weather, as a mechanic, is extraordinarily busted. Permanent Weather is even more busted. Therefore, I have
removed all access to permananet weather abilities from the player. The AI will still have access to these
abilities, but the player will have access to the Weather TMs to counteract this.

Anyways, good luck and have fun