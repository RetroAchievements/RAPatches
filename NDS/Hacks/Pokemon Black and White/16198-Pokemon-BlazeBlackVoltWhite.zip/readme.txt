Use with:

(No Intro)
File:               Pokemon - Black Version (USA, Europe) (NDSi Enhanced).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              4F6E5580
MD5:                37BFF1431EDA9B3A525737C7F59A432D
SHA1:               26AD0B9967AA279C4A266EE69F52B9B2332399A5
SHA256:             B9979189D299A0231D01C8885C0D054B706976FFC75427CA59D84E0CE1493034

File:               Pokemon - White Version (USA, Europe) (NDSi Enhanced).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              B552501C
MD5:                77C34BA77F8FA44E7CAF04F695DB0560
SHA1:               BC696A0DFB448C7B3A8A206F0F8214411A039208
SHA256:             B288BB061FD646894F5059F55CD0A1EFB13B4F0CFD3D9E06E9E42A5BD9431AC6
