Use with:

(No Intro)
File:               Castlevania - Order of Ecclesia (Europe) (En,Fr,De,Es,It).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              F7B9390D
MD5:                2B9DC9B44CCE2E786FDF1FF8D45D667C
SHA1:               B62E2D0CD63BDB16E32F2D4A1D0AC90A242C8481
SHA256:             49A7590E8D20A78D5743DE56333BC512A205A8BA5CD7A8C35D1780708C74B79F