Use with:

1456 - Legend of Zelda, The - Phantom Hourglass (USA) (En,Fr,Es).nds (No-Intro)
e727e333ba706ac1f67352a287c419a3
8B431C41
