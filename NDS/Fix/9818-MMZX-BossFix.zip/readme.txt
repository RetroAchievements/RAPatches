Use with:

(No Intro)
File:               Mega Man ZX (Europe) (En,Ja,Fr,De,Es,It).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              7A37B5FC
MD5:                E8A4C5894E1120F1128B32A5853E0784