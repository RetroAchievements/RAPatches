Use with:

0121 - Castlevania - Dawn of Sorrow (USA).nds (No-Intro)
02b82366dce96b554440fd0b39b491d3
135737F6
