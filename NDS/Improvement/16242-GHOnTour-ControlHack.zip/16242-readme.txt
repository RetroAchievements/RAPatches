Use with:

2380 - Guitar Hero - On Tour (USA) (En,Fr).nds (No-Intro)
28b23cdfc7c4e47f1ebd7e6846183ffb
EF72CED6
