Use with:

(No Intro)
File:               Pokemon - Platinum Version (USA) (Rev 1).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              69D628E8
MD5:                AB828B0D13F09469A71460A34D0DE51B
SHA1:               0862EC35B24DE5C7E2DCB88C9EEA0873110D755C
SHA256:             FBCE4C4DEF0C7797F8DD238A3D7A5E48B4A7E3ABD86890AC65F6321CEF781BDB