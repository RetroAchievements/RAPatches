Use with:

(No Intro)
File:               Dragon Quest IV - Chapters of the Chosen (USA) (En,Fr,Es).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              C433DB29
MD5:                A850803F31D480290902F51E70C11922
SHA1:               B9132B77597BFEB8F4162B4EE51D87B4F92EDC41
SHA256:             7F25B79CF9E8FECA0AACF6F12F3DDD9AE5B7F4B00ED01D2173853D33869BD24F