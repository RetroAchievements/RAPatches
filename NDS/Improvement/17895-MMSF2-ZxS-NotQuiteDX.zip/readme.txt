Use with:

(No Intro)
File:               Mega Man Star Force 2 - Zerker x Saurian (USA).nds
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              1E6C4B77
MD5:                907EECE95D49379E6F3B95C17BCA4344
SHA1:               494171C0FC19823BEB5FCC7C0D61F028C97898CA
SHA256:             D10E3933CAFCD7DB1A45BBBD8BE3864349F76B2D1145494AA1E599C752877208