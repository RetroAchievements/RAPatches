Use with:

(No Intro)
File:               Pokemon - HeartGold Version (USA).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              C180A0E9
MD5:                258CEA3A62AC0D6EB04B5A0FD764D788

File:               Pokemon - SoulSilver Version (USA, Australia).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              D8EA6090
MD5:                8A6C8888BED9E1DCE952F840351B73F2