Use with:

Learn with Pokemon - Typing Adventure (Europe).nds (No Intro)
114fd7dcc0922e0c75c2b899243635e7