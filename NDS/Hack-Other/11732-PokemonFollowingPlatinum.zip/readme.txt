Use with:

Pokemon - Platinum Version (USA).nds (No Intro)
361e825aa24fc471a317c510130bf4c3