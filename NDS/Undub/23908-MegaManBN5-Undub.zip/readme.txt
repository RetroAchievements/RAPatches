Use With:

Mega Man Battle Network 5 - Double Team DS (USA) [nointro]
hash: e52b6d43d524ee11a89095f88f8d3425
CRC32: 16F03F13