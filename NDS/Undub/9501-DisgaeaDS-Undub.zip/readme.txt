Use with:

(No Intro)
File:               Inazuma Eleven 3 - Sekai e no Chousen!! - The Ogre (Japan).nds
BitSize:            4 Gbit
Size (Bytes):       536870912
CRC32:              A9754AEA
MD5:                DE2690E8035A695BB65334599AFFEB7C
SHA1:               9380F1D7EE75E7C6EF24F1B76C88ECDC85088957
SHA256:             1429C7B99CA8E7A18C49B6C2A9F61D43314B771C2C9A34C1E555BB0566C4CFE0