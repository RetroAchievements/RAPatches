Use with:

(No Intro)
Castlevania - Portrait of Ruin (USA).nds 
2edd57540cae45842fbd19c45a4214f9
96df4c4d