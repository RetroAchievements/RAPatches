Use with:

(No Intro)
File:               Castlevania - Portrait of Ruin (USA).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              96DF4C4D
MD5:                2EDD57540CAE45842FBD19C45A4214F9
SHA1:               382602E3615B2282EEAD584014125E71B5B0F033
SHA256:             1174A36FD91F79E95E90B76AA1268AF8FC09F69C04CC8E5B4FF791E872254ABD