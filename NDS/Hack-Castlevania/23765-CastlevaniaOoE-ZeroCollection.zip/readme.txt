Use with:

(No Intro)
File:               Castlevania - Order of Ecclesia (USA) (En,Fr).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              A7612D61
MD5:                E13BDCF706989486DF939556EEB42ECE
SHA1:               F9EBF006A489B8C9391E8D1FD05EC6B9CEF6FD7B
SHA256:             9525838929F3D11F34E52FDB7AE3CCDDAFDAF00995170117DA963124522A28D4