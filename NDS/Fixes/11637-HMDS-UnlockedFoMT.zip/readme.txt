Use with

(No Intro)
Harvest Moon DS (USA) (Rev 1).nds
0b943fd4bdca48ca8556615a592fd16e
CEA0FDCD