Use with:

(No Intro)
Radiant Historia (USA).nds
52cf5d4f0fd4e39cfe69bc1ba78b9d54
7B1BB37D