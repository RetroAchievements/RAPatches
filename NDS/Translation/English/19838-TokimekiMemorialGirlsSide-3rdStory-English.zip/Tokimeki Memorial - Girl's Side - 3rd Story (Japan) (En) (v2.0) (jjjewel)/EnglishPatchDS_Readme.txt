Tokimeki Memorial Girl's Side 3rd Story (DS)
English patch by jjjewel

Credits:

    Translation: jjjewel
    Spot translation: AmuletCross
    Programming/Hacking: jjjewel
    Graphic editing: jjjewel
    Editing: chocobikies, jjjewel, xMimii
    Beta-testing: chocobikies, jinny-jin, xMimii
    Special thanks: Azpirin for the Light Patcher program.

Version History:

2.00 Released Jun, 2015. First public released. Complete translation patch.
1.00 Released Feb, 2014. Complete translation patch. Private released.
0.90 Released Jan, 2013. Beta test patch with full translation.
0.10 Released Nov, 2012. Beta test patch with partial translation.
0.05 Released Sep, 2012. Beta test patch with partial translation.

Patching Instructions:

* Run TMGS3_20150614_patcher.exe and then drag and drop your clean ROM
  on the program window. Wait until you see the pop-up window informing
  that patching is done. Your English patched will be in the same folder
  as your clean ROM.

  For detailed instructions, please check this page;
  https://sites.google.com/site/otomeundercover/patching-instructions
  
* Save files from the original Japanese game should work with this patch.
However, it is a precaution to backup your save files.

* Please visit my Google site for project updates.
https://sites.google.com/site/otomeundercover/otome-projects/tmgs3-ds

~Thank you~

