Use with:

(No Intro)
File:               Tokimeki Memorial Girl's Side - 3rd Story (Japan).nds
BitSize:            4 Gbit
Size (Bytes):       536870912
CRC32:              2B796C86
MD5:                ECE1EFBA16D654B6EC111989C9BE75C3
SHA1:               70F3A98F7A356AF4C50C864CE9D3DC41160D434C
SHA256:             12836E03752EDCE2C6672B406EA75D5051A33318B48F09828DC90B2B9FA9EA38