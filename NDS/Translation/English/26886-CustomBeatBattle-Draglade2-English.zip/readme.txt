Use with:

(No Intro)
File:               Custom Beat Battle - Draglade 2 (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              C041AC94
MD5:                F0785E7F58EBBBDDE837EA3E713BB365
SHA1:               29828E97A344FC9D08C4A0399E75B8AF875ABCBE
SHA256:             815083541AE48E061FE079D9E8257DA2918BE16FE7764DB7BAADBB0FC4966876