Use with:

(No Intro)
File:               Ookami to Koushinryou - Umi o Wataru Kaze (Japan).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              B2EA6D73
MD5:                ECE63390068D708A5E56D0E471D11FE7
SHA1:               58F307C0E69D08924A95CEDCFFF6F6EB0B875F44
SHA256:             ED5575BDD52ADFE5C515562AD45989FD58A5F1529A59F0D8953B3F6E30ACB466