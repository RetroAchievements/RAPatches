Use with:

(No Intro)
File:               MapleStory DS (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              18194D7A
MD5:                4094A2831B0D812CB1CEA8D749391DCC