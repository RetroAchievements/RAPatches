Use with:

(No Intro)
File:               Ookami to Koushinryou - Boku to Holo no Ichinen (Japan).nds
CRC32:              9e4800e2
MD5:                45e06c981de5653e122d9b5afc72f1fa
