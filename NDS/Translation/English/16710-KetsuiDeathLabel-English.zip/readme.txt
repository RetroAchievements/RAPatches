Use with:

(No Intro)
File:               Ketsui Death Label - Kizuna Jigoku-tachi (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              8A4C33CB
MD5:                7DBBEFCA112049A71F1E0F056CA7A72F
SHA1:               7E85E25BAD13FC5A7B37187473DB554E80482B90
SHA256:             BE755C20488DBD72811DBC49431FCDDC18B62B4FE7BF27B34C46AB2FC74B6B75