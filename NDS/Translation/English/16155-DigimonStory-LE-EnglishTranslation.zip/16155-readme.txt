Use with:

(No Intro)
File:               Digimon Story - Lost Evolution (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              83878137
MD5:                D994FF42E80827FD4546BB64FFD8D2EA
SHA1:               F180146F517712C177D6497125A24F35B0D6102F
SHA256:             6F74958BCE94F9ACDFFD75F0EFA1F85E7D07664D8AC7D6C926A556B17939AF37