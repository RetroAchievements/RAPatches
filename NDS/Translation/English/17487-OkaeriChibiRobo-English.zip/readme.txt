Use with:

(No-Intro)
File:               Okaeri! Chibi-Robo! - Happy Rich Oosouji! (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              30DEDCA9
MD5:                B951A52B1A9E1FE4EA2B9BE9E41989FF
SHA1:               D8A33D9757C25C54764EF9611B49CC16F82B55FE
SHA256:             001A003CAD85F67947688166ECFB0437370C933CE92FFAD0059AED1BF4A14D25