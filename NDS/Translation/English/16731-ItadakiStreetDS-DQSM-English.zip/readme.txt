Use with:

(No Intro)
File:               Itadaki Street DS - Dragon Quest Super Mario (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              DA820B40
MD5:                931928E36FC34D3EF334F6CFC0C1D332
SHA1:               CDD5A4A407A1C9FEA5F88697A8D45F575E131F36
SHA256:             3E2C7A4D4E19BDB56E53579FD427448362ED01D950E6E3C2013A43E5E335B7E6