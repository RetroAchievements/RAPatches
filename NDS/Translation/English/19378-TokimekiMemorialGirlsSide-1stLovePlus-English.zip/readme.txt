Use with:

(No Intro)
File:               Tokimeki Memorial Girl's Side - 1st Love Plus (Japan) [b].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              668D41BE
MD5:                470FCAFCD3E2D34F89F7D1786726696C
SHA1:               C726186F04E608D0DC9067C73BD3D31BEF573522
SHA256:             676DBE3D65DACD35FFC0CC7CBFEA773EC947A1EF76C4FD3F7BCE64FEB39D129F