Use with:

(No Intro)
File:               Meitantei Conan & Kindaichi Shounen no Jikenbo - Meguriau Futari no Meitantei (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              2C0870E9
MD5:                5C9FF4CD984B130E0CC58134F9FC89B2
SHA1:               D1DA59D1283ACAD430CC199A2AEF77E91E0F5A5F
SHA256:             D9FF492E473D385C67E4FF98E891A5A8CE08543A73818D99D63CF91D80744FDF