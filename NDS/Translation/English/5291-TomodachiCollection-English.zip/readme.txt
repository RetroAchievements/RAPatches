Use with:

(No Intro)
File:               Tomodachi Collection (Japan) (Rev 1).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              60C49745
MD5:                7AB6ACD97168F6D70E953A9C8057337C