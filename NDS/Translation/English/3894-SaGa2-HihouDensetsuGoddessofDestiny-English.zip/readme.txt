Use with:

(No Intro)
File:               SaGa 2 - Hihou Densetsu - Goddess of Destiny (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              F47920FB
MD5:                CB70E35F95FD09B1247B151FD117A126
SHA1:               AB732FB3AEDEB11CD932842106FC9D17784D6CF8
SHA256:             A896E7596B0B5CC4EB3740DD566D32B75C0FF943129F55B67885DD95B9F703C3