Use with:

4606 - Coropata (Japan).nds (No Intro)
4181a16ae96d3d503cd24286d5f1b106
6904973A