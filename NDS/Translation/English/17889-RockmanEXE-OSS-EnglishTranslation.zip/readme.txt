Use with:

No Intro
Rockman EXE - Operate Shooting Star (Japan).nds
0a1ba456028f7d9a59d5c0f25fcccbb5 
06441e8b