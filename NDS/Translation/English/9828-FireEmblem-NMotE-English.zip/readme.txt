Use with:

(No Intro)
File:               Fire Emblem - Shin Monshou no Nazo - Hikari to Kage no Eiyuu (Japan) (Rev 1) (NDSi Enhanced).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              2DA8A814
MD5:                76A346E915E2BAE57432B166CA7B74E6
SHA1:               C724754FB09800833E9ACEB2022FA100475B4369
SHA256:             5FE1360FD8448E9DBEB08DC23941921DF89E8BB7E1565568ED39BF0C8D60DF89