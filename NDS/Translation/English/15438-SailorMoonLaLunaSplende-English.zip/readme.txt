Use with:

(No Intro)
File:               Sailor Moon - La Luna Splende (Italy).nds
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              463FB1F5
MD5:                E5E1E6E7FE9A89F91BC90DDBFE203E4D
SHA1:               0D40769232CE43FB47134D921AF3D62779C878E7
SHA256:             322EE3B38FF6A9A80FBC4BA373091EF058C2C4CE616722F88D615E11FEDF5918