Use with:

(No Intro)
File:               Culdcept DS (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              CF759637
MD5:                0E23E1A070998D3F3B16D6BFD16CF63E
SHA1:               0EA2B3C4FF913139A7786C2E8F561A49958C8E57
SHA256:             B1D54F39D7DA60A96CCFE83B763EE2349E41CB81072E0DB1A569B6FA10488C0A

or

(Caravan)
File:               Culdcept DS (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              A4F03D74
MD5:                18958F52BFC6977600E73A3CAA21BFD2
SHA1:               C1D476009DB48CFFE52346605B0097C19172A3D7
SHA256:             48836AB70C98DB929081D89EA7D6C2BD79B902400507DAF3B9E4C3CDE8B65C05


Original Patch:
https://www.romhacking.net/translations/2579/