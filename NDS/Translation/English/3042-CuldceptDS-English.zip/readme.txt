Use with:

(No Intro)
File:               Culdcept DS (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              CF759637
MD5:                0E23E1A070998D3F3B16D6BFD16CF63E
SHA1:               0EA2B3C4FF913139A7786C2E8F561A49958C8E57
SHA256:             B1D54F39D7DA60A96CCFE83B763EE2349E41CB81072E0DB1A569B6FA10488C0A

Original Patch:
https://www.romhacking.net/translations/2579/