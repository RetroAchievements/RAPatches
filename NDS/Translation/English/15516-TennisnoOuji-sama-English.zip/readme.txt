Use with:

(No Intro)
File:               Tennis no Ouji-sama - Motto Gakuensai no Ouji-sama - More Sweet Edition (Japan) [b].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              303301B1
MD5:                7D0B3FFE2B9A1C43EEB86A8541DC6618
SHA1:               05BE451E97127A887362BEF389D94A913C82C41F
SHA256:             14EADEC0871FAD406476967E0AE4F196D996719C76470BE924A9269F37F2A091