Use with:

4085 - Blood of Bahamut (Japan).nds (No-Intro)
4f61232e8bbe47536bee6bfb31e50275
1306A2ED
