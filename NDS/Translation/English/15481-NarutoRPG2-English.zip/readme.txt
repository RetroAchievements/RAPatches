Use with:

(No Intro)
File:               Naruto RPG 2 - Chidori vs Rasengan (Japan).nds
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              73913B7B
MD5:                353A2EE41A6812E3740933B1029E57AD
SHA1:               10C86618D24B3E33E710D11A798A8397BE4D6F61
SHA256:             2AC129A624B282294A1BAF07EB27C46DF6BFC0BFE3DD400CF9D610A840F3A9B3