Use with:

(No Intro)
File:               Nanashi no Geemu (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              057D0B3F
MD5:                EE9BCF9A65F7A01BDABBA79053280922