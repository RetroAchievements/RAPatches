Use with:

(No Intro)
File:               Tokimeki Memorial Girl's Side - 2nd Season (Japan).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              8455FD93
MD5:                B8442AD4A4279F874BD0F827E338FD0F
SHA1:               6997ABE5BBECF4C6BD267E522224D226CFE14944
SHA256:             B5A9804EF0E2706B9C0DF9DFA747944954A6F798286A273E0EA19EF54A5642F6