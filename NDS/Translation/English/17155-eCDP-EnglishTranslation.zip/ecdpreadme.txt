Use with:

(No Intro)
File:               Kurutore eCDP (Japan) (Not for Resale).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              088CEA8F
MD5:                C421495142CAA1C4BEC8BA115A05D415
SHA1:               136AACC9D3D7C8567381CD4E735FF3C004A018D0
SHA256:             34F39417949CBE3ECAF7510D8EE5A30E57F2FFAEF08997646A678DAE79DE11FD