Use with:

(No Intro)
File:               Cid to Chocobo no Fushigi na Dungeon - Toki Wasure no Meikyuu DS+ (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              E82764F2
MD5:                97F8E08589ADC30F4F026B64B88B5D48
SHA1:               15CBCB823AD85E586554EEBF1B648327BE1EC051
SHA256:             187F794866C235DAC9B9C53D4DBAB9A5CE03A956EC10B584AFD25280ADE3A311