Use with:

(No Intro)
File:               5134 - Metal Max 3 (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              03440034
MD5:                36CDCC2A5319144E149420D30B91FDF1