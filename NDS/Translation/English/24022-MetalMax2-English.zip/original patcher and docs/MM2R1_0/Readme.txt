Metal Max 2 Reloaded English Translation v1.0 20211208
====================================

Application Instructions
------------------------

This patch should be applied to:

    No-Intro:   5925 - Metal Max 2 - Reloaded (J).nds
    MD5:             c34945237a362c7ebc03c37c48df00f2
    CRC32:                                   4416e3ec
    SHA-1:   7a04340c8ca4913014baf1ee1ba247d15931afd3
    Size:                                    67108864
    Serial:                                      TMXJ

Not sure which ROM you have? You can check using ROMhacking.net's Online ROM
Hasher here:

https://www.romhacking.net/hash/

For Windows users:
* Run the included "Patcher.exe" and click "Apply patch"
* Select your Metal Max 2 Reloaded ROM
* The patch will be applied automatically and appear in the same folder
  as your ROM.


*For non Windows users the xdelta file will be avaliable on MetalDreamers github page for download.*

For MacOS users we recommend MultiPatch available at:

https://projects.sappharad.com/tools/multipatch.html

or

https://www.romhacking.net/utilities/746/

For everyone else, you're probably comfortable with the xdelta3 CLI.



Supported Ways to Play
----------------------

Emulators:
* MelonDS
* Desmume
* no$GBA  (Has some visual issues)
* Drastic (Android)


Original Hardware:
* TwiLight++
* R4i 3DS Plus Gold

"Lost" Passwords
--------------

Throughout the game you will encounter chests guarded by keypad passwords.
There is no in-game means to discover these passwords, as they were included
as promotional items across various magazines and websites including Famitsu,
Amagami's official website, and Weekly Shounen Jump. As such we've included
the passwords in our patcher this time just clic "Lost password" option.




v1.0: 20211208
Initial release

Credits:
MetalFan...............Project Lead, Assembly Modifications, Graphics Editing
meunierd.........................................Programming(Script inserter)
Colmines92...............Programming, Assembly Modifications,Graphics Editing
FlashPV......................................................Graphics Editing
Pleonex.......................................Programming(NITRO FORMAT TOOLS)
Sai..........................................................Translation Lead
Toyoch.............................................Script Editing/Translation
cccmar.............................................Script Editing/Translation
gamebunny......................................................Script Editing
Sidier............................................................Translation
Kzinssie..........................................................Translation
Kzenolog...............................................Patcher Background Art
robertsonsondohjr................................................Patcher icon
JaMpocalypse..........................................................Testing

Comments:

-MetalFan-
Well, it seems that we are at the end of the road, it has been a wonderful trip,
full of moments of joy, and of course of stumbling, it has been 1 year and nine
months of work since March 2020, but finally (I can’t believe it yet :) we are
ready to release our translation of the Metal Metal 2 Reloaded for NDS.
This patch would not have been possible without the great contribution of a
great group of people who I have enjoyed working with and from whom I have also
learned a lot. For this project we have the special help of Sai who translated
the entire script with excellent quality at an incredible speed.
Also with Colmines92 who, although he joined later, was instrumental in solving
problems of all kinds with his amazing hacking skills.
We hope you enjoy the translation. 
Who knows, maybe there are surprises for the future;)

-meunierd-
It brings me joy to see that this translation is finished and released.
I'm proud to have played a part its construction.
Many thanks to MetalFan for his passion and dedication to get this finished.
Metal Max 2R is a high watermark for the series. Have fun.

-cccmar-
Well, here we are – this is Metal Max 2 Reloaded, the remake of the original
Metal Max 2 released in the early 90s. This game adds a lot of new stuff into
the mix, such as more WANTED, quests, all of the QoL improvements from the earlier
game (Metal Max 3) and a lot of other good stuff. I’ve been involved in the project
as one of proofreader, so hopefully most of it looks presentable! The main translator
of this project was Sai, thanks to him this translation was possible at all, so
huge kudos to him for his peerless work and dedication. We had a discussion
regarding some terms, like some names, punny descriptions etc. and we managed to
come up with good replacements for most of the untranslateable bits.
Overall, the story in this case is rather straightforward,
like in most Metal Max games – it’s all the side activities/quests you do
that matter the most, rather than the main plot.
So, I hope you guys enjoy the fruits of our labour, and see you some other time!


Special Thanks
--------------
*StorMyu.....................................Help with Assembly Modifications
*IcySon55.............................................................Tooling
*Efriim......................Help with ingame Jukebox/drinks/snacks locations

