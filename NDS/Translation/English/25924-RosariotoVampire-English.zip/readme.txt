Use with:

(No Intro)
File:               Rosario to Vampire - Tanabata no Miss Youkai Gakuen (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              BBBF7A37
MD5:                517755FCDCE54FF807F09D44FFCD91A4
SHA1:               BE453232C9DFD96846BEC06006C3F78C6E038178
SHA256:             671B4F50F5B74D256BC70663931F8C37AB27CB376EA6B5334E7661D668EFB6D8