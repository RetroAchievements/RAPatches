Use with:

(No-Intro)
File:               Puzzle Series Vol. 5 - Slither Link (Japan).nds
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              BBD2266B
MD5:                7FA2FBE18042814392F6F6EB702D2EC8
SHA1:               D2111B32ADD11205D9E41005614FB3447B8D8B0B
SHA256:             5E55B8C3E1538C17BE14C3A8C504366528F63BF8EEBB6323BDA9C824D058EBEA