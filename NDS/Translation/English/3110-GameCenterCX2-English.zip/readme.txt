Use with:

(No Intro)
File:               Game Center CX - Arino no Chousenjou 2 (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              0E54B5B8
MD5:                AD0FA1DEFAD5A3E278D224F8A48F8FEF
SHA1:               E9899E7F6BDB31153AFEAC692A4F380AF19A3512
SHA256:             B7C773450FBAA880FEE14429000D1080B7996E21A2C391CC1FAD9AA5FB15938E