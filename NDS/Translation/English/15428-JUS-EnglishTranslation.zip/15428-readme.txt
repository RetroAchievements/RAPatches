Use with:

0696 - Jump Ultimate Stars (Japan).nds (No-Intro)
a478e6f6ef25b21ae8e640d88f37bdfc
2023075D
