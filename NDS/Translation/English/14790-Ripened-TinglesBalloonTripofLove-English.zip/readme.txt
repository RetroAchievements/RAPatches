Use with:

(No Intro)
File:               Irozuki Tingle no Koi no Balloon Trip (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              C7A78A3E
MD5:                608525CFA0819175EEF7F7877B9F06AA
SHA1:               560C0A0AB940CB957A37FEAB650904F5BE089967
SHA256:             C40EB53FDECFCA31FC3D66C9F2A44E8C0C9FBA458C192CB86BE39FCB73374201