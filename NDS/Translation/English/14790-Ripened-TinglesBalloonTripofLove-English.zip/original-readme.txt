Ripened Tingle's Balloon Trip of Love English translation patch v1.1
--------------------------------------------------------------------

This patch translates the game into English.

Any bugs/errors should be reported on our blog:
https://www.tingletranslation.blogspot.com



1) How to use the patch
-----------------------

If you want to play on an actual DS/3DS/2DS, you will need a flashcart compatible with your console.
Otherwise, you will need an emulator.
You will also need a ROM of the game. This can be dumped from a cartridge using a DS Lite or 3DS.
*We do not condone the sharing of illegal ROMs. Do not ask us where to find them or mention them on our website.

To apply the patch to your ROM:

Windows: Use DeltaPatcher (http://www.romhacking.net/utilities/704/)
Mac: Use MultiPatch (https://www.romhacking.net/utilities/746/)
Linux: Use xDelta for Linux, or run DeltaPatcher in wine.


***A NOTE ABOUT ROM COMPATIBILITY***
One of the most commonly circulated ROMs of this game on the internet is a bad dump. 
Our patch is designed to work with a 100% correctly dumped ROM. 
If your ROM is a bad dump, you can try to apply the "CRC Fix.xdelta" patch BEFORE applying the v1.1 translation patch.

There is an application available on our website in the "Releases" section that checks if your ROM is a bad dump.


2) General Information
----------------------

- The translation patch is completely free. If you paid for it, you have been scammed and should demand your money back. 
- Do not share the translated ROM online *anywhere*, and DEFINITELY do not share it on our website.


3) Patch Information
--------------------
- The credits are not completely localized; the cinematic that plays alongside them is translated, 
  but the actual credits (i.e. the names of the development staff) remain in Japanese.

- There is one VERY SMALL, insignificant piece of Japanese text that remains untranslated due to technical reasons. It appears near the end of the game, and translates to "Double Tap!".



4) Credits
----------

Translators:
DaVince
waldrumpus

Graphics Editors:
joesteve1914
masterofzoroark
reinamoon
Rimbamboo
Zell0s

ROM Hackers:
joesteve1914


Special Thanks:
DarthNemesis (script editing program)
Normmatt (helped with font problem)
Auryn (Misc hacking help)
Kelebek (Misc hacking help)
FAST6191 (Misc hacking help)
FShadow (English title logo)
IcySon55 and FTI



5) Changelog
------------

1.1
- Crash that occurred at the end of Page 12, Chapter 2 fixed.
- Source ROM now based on correct dump of the game.
- Some minor issues with the font were corrected.
- Some typos were corrected.

1.0
- Initial patch release