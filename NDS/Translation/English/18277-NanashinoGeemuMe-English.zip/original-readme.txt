 English Title: The Nameless Game: Eye
Japanese Title: Nanashi no Game: Me
       Version: v1.13
      Released: August 28th, 2015

--- RELEASE LOG ---
v1.0: Initial release.
v1.1: Includes AP patch that improves compatibility with some cards.
v1.11: Translated banner text.
v1.12: Fixed a small bug in one of the endings where it said the player's name when it should've said the girlfriend's name.
v1.13: Fixed some hardcoded NPC names.


--- NOTICE ---
This is a completely free patch. You've been ripped off if you had to pay for it.

We are not liable for any damage arising from the use of this patch or the patcher.


--- ROM Info ---
Original ROM info:
If your ROM does not match then it is not a clean dump and might not work.
(Data from http://datomatic.no-intro.org/index.php?page=show_record&s=28&n=4133)
Filename: ind-ngme.nds
    Size: 67108864 bytes
   CRC32: 930C4A47
     MD5: A9B1E6D1648C9419B687A8705AC4D541
   SHA-1: 8A354A0EE8878AED582DE5EA20C3A79A81A5FF34

Output patched ROM info:
Filename: The_Nameless_Game_Eye.nds
    Size: 63459956 bytes
   CRC32: 8321A8CA
     MD5: 2C8FD83C44860B27FDC8B4C991962E37
   SHA-1: 2EB2EBA44D54FB0E0091E57311BF49231DABF817

xdelta will automatically verify the MD5 checksum before patching and will error if it does not match.


--- Instructions ---
Patch instructions for Windows:

1) Run xdeltaUI.exe
2) Under "Patch", click "Open..." and select The_Nameless_Game_Eye.xdelta
3) Under "Source File", click "Open..." and select the ROM you would like to patch
3) Under "Output File", click "..." and choose a place to save the patched ROM



Patch instructions for other operating systems:
For Mac OS X only: http://www.romhacking.net/utilities/746/

For Mac OS X and *nix systems:
1) Open a terminal
2) Extract "The_Nameless_Game_Eye.xdelta" to the same directory as the .nds file
3) Use the "cd" command to change directories to where the .nds file is located
4) Type "xdelta -dfs (original unpatched .nds file) The_Nameless_Game_Me.xdelta" (without quotes).
Replace (.nds file) with the file you want to patch. For example, "xdelta -dfs ind-nngm.nds The_Nameless_Game_Me.xdelta"
This should output a file named The_Nameless_Game_Eye.nds in the same directory.

If that doesn't work:
Check your distro's repository and install the xdelta package if it is available. Or you can download the source code and compile it yourself: http://xdelta.org/


--- Credits ---
Rat		- Main Translator
Nagato		- Programmer, Translator
Vodka		- Image Editor

Special thanks:
Ryusui		- Image Editor from Nanashi no Game whose images were reused
Niggurath	- For creating the LP series of Nanashi no Game: Me that eventually turned into this patch (See below for link to channel and original LP thread)
Panzer		- For making this release possible by approaching me when the LP started and acting as the middleman between me and the team working on the LP
NikolaMiljevic	- Tester
bobmcjr		- Tester

Niggurath's Youtube channel containing the original LP series can be found here: https://www.youtube.com/channel/UCZmxSkjDVGugKlbRn4uXUcg
You can find the Let's Play Nanashi no Game Me playlist here: https://www.youtube.com/playlist?list=PLuoM6YEhavdwQi254teAEGQO1GA7FJ9DH
The original LP thread is here, but you need a SomethingAwful account to see it: http://forums.somethingawful.com/showthread.php?threadid=3701391