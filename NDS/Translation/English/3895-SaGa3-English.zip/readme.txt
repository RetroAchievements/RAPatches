Use with:

(No Intro)
File:               SaGa 3 - Jikuu no Hasha - Shadow or Light (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              D0C79AE7
MD5:                8EDB0033AA3B0F5E02F3D1424F2663DC
SHA1:               4569D24295FCC37EFA3F6F9C98C4AAFEF40625B8
SHA256:             02942885C9ACFF95FB7B958864D8F304DE509B497AADD5932ECD9050EFFDAF1C