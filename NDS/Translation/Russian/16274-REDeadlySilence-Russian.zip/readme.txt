Use with:

(No Intro)
File:               Resident Evil - Deadly Silence (USA).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              DE3E278C
MD5:                3C2BED30E73D5F31E2335557256DBA85
SHA1:               B7DEE8C12078D347ED28D85F095AB3BDD0E4D87F
SHA256:             E72A5F9180592DDE1973150E0FA785BE07D4D5CDA911999D9E1A90DE52C772F3