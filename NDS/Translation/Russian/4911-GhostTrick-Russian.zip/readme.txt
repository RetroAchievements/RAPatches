Use with:

File:               Ghost Trick - Phantom Detective (USA) (En,Fr,De,Es,It).nds (nointro)
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              5CD93FE5
MD5:                E61D75F376B0733B5479AE869F744855