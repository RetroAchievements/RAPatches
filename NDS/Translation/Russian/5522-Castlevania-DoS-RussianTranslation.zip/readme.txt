Use with:

(No Intro)
Castlevania - Dawn of Sorrow (USA).nds
cc0f25b8783fb83cb4588d1c111bdc18
135737F6