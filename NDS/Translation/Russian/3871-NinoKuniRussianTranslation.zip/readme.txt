Use with:

(No Intro)
File:               Ni no Kuni - Shikkoku no Madoushi (Japan).nds
BitSize:            4 Gbit
Size (Bytes):       536870912
CRC32:              68B796B1
MD5:                F0E3027B9E97618732B4F2D4298AD0CF
SHA1:               DFAAA4DC03BBB59F010B9146A720B24CFC7738EB
SHA256:             7C78318AE93BD5639E592BE98B22114E2160C54397F7BFFF5E1BFE61B54A4F3C