Use with:

(No Intro)
File:               Wish Room - Tenshi no Kioku (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              F717E806
MD5:                AB66995F4093C877D0CAC3A49C1F7AF8
SHA1:               98BFC31C0CC165CDC41F79820CD96940A84F8860
SHA256:             43DEDA107D82E0683078F7A121DE7C765F7B2EF0C3C06D789AA5159D322775B7