Use with:

(No Intro)
Gyakuten Kenji 2 (Japan).nds
MD5: 2d02ffe1f6cc97fb291e28f350877938
CRC: 04D1A557