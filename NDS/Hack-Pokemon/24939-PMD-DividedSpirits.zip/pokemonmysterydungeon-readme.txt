Use with:

(No Intro)
File:               Pokemon Mystery Dungeon - Explorers of Sky (USA).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              22DDE080
MD5:                10AF6A1A4D90FFB48BFB6C444324F7FD