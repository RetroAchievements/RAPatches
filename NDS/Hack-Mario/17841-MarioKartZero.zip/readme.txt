Use with:

(No Intro)
Mario Kart DS (USA, Australia) (En,Fr,De,Es,It).nds
8cbf438d5a7c0d9acbe56a9b627ca6c5
D47555BE