Use with:

(No Intro)
Super Mario 64 DS (USA).nds
82ea4525a39dc2f484a054cff3f1b834
E6321562