Use with:

(No Intro)
Super Mario 64 DS (Europe) (En,Fr,De,Es,It).nds
867b3d17ad268e10357c9754a77147e5
29715DEC