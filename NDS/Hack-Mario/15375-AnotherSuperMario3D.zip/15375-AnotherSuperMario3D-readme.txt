Use with:

0037 - Super Mario 64 DS (USA).nds (No-Intro)
3f39c39315c8d23e6d55841e3143d320
E6321562
