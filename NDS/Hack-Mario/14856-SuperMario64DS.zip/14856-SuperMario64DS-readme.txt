Use with:

0022 - Super Mario 64 DS (Europe) (En,Fr,De,Es,It).nds (No-Intro)
ba3c4052e00c5cc31df5d5534c39de1b
29715DEC
