Use with:

(No Intro)
File:               Pokemon Ranger - Guardian Signs (Europe) (En,Fr,De,Es,It).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              10DF0E03
MD5:                73D61CCC128DCEEBBB7EE394FC0D664D
SHA1:               18CC346F32989E619B473D5D9DE4A414CBF93B38
SHA256:             815E727B25C57F92197A592DF8C1272C0F20D8190BD0A5ADFC688B445C1C406F