----------------------------------------------------------------------------------------

File:               Pokemon - SoulSilver Version (USA).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              D8EA6090
MD5:                8A6C8888BED9E1DCE952F840351B73F2
SHA1:               F8DC38EA20C17541A43B58C5E6D18C1732C7E582
SHA256:             51D0F94A16AF7D77C067B4CB7D821BA890A13203A2E2C76049623332C0582E20

----------------------------------------------------------------------------------------

File:               Pokemon - SoulSilver Version (USA)[Uncapped Framerate].nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              3F506BC8
MD5:                BB768CD344EA0F47C28825E91CA5BE90
SHA1:               1AB12DAE95A3F71C5E188FBB23F5C7F21ACE3616
SHA256:             0874A3BCD8301F9BBB7BE94901A29D443A7678C00B8F5F97C27AE4B849B0F642

----------------------------------------------------------------------------------------

File:               Pokemon - SoulSilver Version (Europe).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              968CDE08
MD5:                706A77BB5183A22B8436A46E38F2DD32
SHA1:               27A25C23AA1C0ECABE48A30A004B96C9DBC97730
SHA256:             94AD298C32BBCC623D042CA20F46CFCAA399A8E814260CC5645DFE5F4C167C17

----------------------------------------------------------------------------------------

File:               Pokemon - Versione Argento SoulSilver (Italy).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              0041AE66
MD5:                84E670608D8D70DA372A89C3A50F0ECD
SHA1:               E137ACF711E0B14C297ABF0254E5B4A9263338E7
SHA256:             DEAE3FA3FFC4456AAF922B5DFE4B238A15D36A821C1F79C9AFDCE8A7BE58E85E

----------------------------------------------------------------------------------------

File:               Pokemon - Version Argent SoulSilver (France).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              36D0A539
MD5:                7AEE270F3CE81CCF897BADC2307B88A9
SHA1:               BA78F6FFF3FC1E32AFF8FCC4707A2DA1EC996F7C
SHA256:             BD224AB12E954C6469ABCAD66415A3DBEDA68CEBB14F66DB4E29F4460F7502CA

----------------------------------------------------------------------------------------

File:               Pokemon - Silberne Edition SoulSilver (Germany).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              94E4A5B5
MD5:                7F128163A5AFF6E67C67A8EC39242166
SHA1:               576CDB7EEC728C49AED85B9DD7E1E084BA1F08F9
SHA256:             7D3B9AFFA155D4A899BDB65DEB36D927B733CC5B7CEFA0F2064EFDA90938FD63

----------------------------------------------------------------------------------------
