Use with:

(No Intro)
File:               Tales of Innocence (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              AFA9C467
MD5:                B3081E0785DC4A738A5A24E7D498C3FD
SHA1:               409E441C803660F3FD9E51CDDE53528004578C7C
SHA256:             864B2AB1EEB8C13C57CFBC80BB03D98C58D90AD038ADCDFC1A81E59CBB1F74E5

(No Intro + English Patch)
File:               Tales of Innocence (Japan) (En) (v1.0) (Absolute Zero) (Anti-Cheat) (Bartis1989).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              335DEA82
MD5:                DB86C29CF8613E93E617B9283711F6C5
SHA1:               D4880E51A2348E6FEC804AA054CC96C50C7F42C2
SHA256:             F7E0A532FC7F92736236E8724D8D64AD01D38E107A1AD0E2586A45E0BDC09FFF