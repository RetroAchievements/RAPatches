Use with: 

(No Intro)
Pokemon - Black Version (USA, Europe) (NDSi Enhanced).nds
RA Checksum: bd562276c75b98cbd185231c1b1d016e
ROM Checksum: 37bff1431eda9b3a525737c7f59a432d
CRC Checksum: 4F6E5580