Use with:

(No Intro)
File:               Mario & Luigi - Partners in Time (Europe) (En,Fr,De,Es,It).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              3184FBC4
MD5:                F9E031C8D3AACEA6306BBAC41BF577F5
SHA1:               BA4EC2F99B4F2E0047601552BCCF00AA73E28701
SHA256:             8B16B1F1F0ACA4A78DAE540BE56A219ADBDE6EE3F1CD33D3F0FBA777DE01D6A3