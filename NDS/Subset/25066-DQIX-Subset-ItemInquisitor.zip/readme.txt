Use with:

[No Intro]
Dragon Quest IX - Sentinels of the Starry Skies (Europe) (En,Fr,De,Es,It).nds
MD5: 3a63438fff7db282fa3133e8fd020e85
CRC: FE8EC0E8

Note: Save files can be loaded on any Subset as well as the Core set. 
Just adjust the file name accordingly -- Make sure you back it up before applying any changes!