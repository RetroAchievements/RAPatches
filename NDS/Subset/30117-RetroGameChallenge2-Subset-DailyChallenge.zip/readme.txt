Use with:

(No Intro)
File:               Game Center CX - Arino no Chousenjou 2 (Japan).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              0E54B5B8
MD5:                AD0FA1DEFAD5A3E278D224F8A48F8FEF
SHA1:               E9899E7F6BDB31153AFEAC692A4F380AF19A3512
SHA256:             B7C773450FBAA880FEE14429000D1080B7996E21A2C391CC1FAD9AA5FB15938E

[No Intro + RAPatches]
File:               Game Center CX - Arino no Chousenjou 2 (Japan) (En) (v1.51) (Aaron Tokunaga-Chmielowiec).nds
BitSize:            449 Mbit
Size (Bytes):       58872016
CRC32:              D8EC931B
MD5:                72736AFC13EF85A0AA73D5BED03C796C
SHA1:               794258D07B9AC6374AC99A55A8EDC0FF94517437
SHA256:             1ABB8EF246799093A7E2E3EFFFC9FFE866BBB028349D061DF538A0EE031F9337