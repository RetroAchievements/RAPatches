Use with:

(No Intro)
File:               Dragon Quest - The Chapters of the Chosen (Europe) (En,Fr,De,Es,It).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              AC5B7BD9
MD5:                2AEBA340C3727410B5CBF5708329C59F