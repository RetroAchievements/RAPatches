Use with 

(No Intro)
All Kamen Rider - Rider Generation (Japan).nds
RA Hash: 654fb79d03b8d8a5461e40ba7391c084
MD5: ADC87F72D8F315BFF1024635D4681F08
CRC: 986B74F0