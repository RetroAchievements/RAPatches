Use with:

(No Intro)
File:               Contra 4 (USA).nds
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              B9DF4B8E
MD5:                74BDE12741469D1A266EC0C60672464D