Use with:

File:               2673 - Dragon Quest IV - Chapters of the Chosen (USA) (En,Fr,Es).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              c433db29
MD5:                a850803f31d480290902f51e70c11922
RA Checksum:        fef0aa768a5a6ab490674476f04fae50

OR

File:               2642 - Dragon Quest - The Chapters of the Chosen (Europe) (En,Fr,De,Es,It).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              ac5b7bd9
MD5:                2aeba340c3727410b5cbf5708329c59f
RA Checksum:        0bfd0fc908b0e7c8479d53e4cad82b28

---

To play Title Tracker Subset (with Party Chat):
1. Download the party chat patch (dq4-party-chat-v1.2.xdelta) from https://www.romhacking.net/hacks/7382/
2. First, apply the party chat patch to the USA ROM.
3. Second, apply the title tracker with party chat patch.

OR

To play Title Tracker Subset (no Party Chat):
1a. Apply the USA title tracker patch to the USA ROM.
OR
1b. Apply the Europe title tracker patch to the Europe ROM.