Use with:

(No Intro)
Guitar Hero - On Tour (USA) (En,Fr).nds
748d06f1c40bd91f1c33bdd6e59ff706
ef72ced6
