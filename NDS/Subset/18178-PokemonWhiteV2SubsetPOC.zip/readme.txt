Use with:

(No Intro)
Pokemon - White Version 2 (USA, Europe) (NDSi Enhanced).nds
RA Checksum: b24b5463d801b87fac81381238667315
md5: 0afc7974c393265d8cf23379be232a1c
CRC: 777EB04F