Use with:

(No Intro)
File:               Pokemon - White Version (USA, Europe) (NDSi Enhanced).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              B552501C
MD5:                77C34BA77F8FA44E7CAF04F695DB0560