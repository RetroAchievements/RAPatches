Use with:

(No Intro)
File:               Pokemon - White Version 2 (USA, Europe) (NDSi Enhanced).nds
BitSize:            4 Gbit
Size (Bytes):       536870912
CRC32:              777EB04F
MD5:                0AFC7974C393265D8CF23379BE232A1C
SHA1:               B5D7490BE7B415B8F1E672A53E978A9CC667E56A
SHA256:             3E50AEC3DB401332175A5D2B5FE2A68AC1A05EC63995DBA9D1506B1B51837446