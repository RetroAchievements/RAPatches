Use with:

(No Intro)
File:               Lufia - Curse of the Sinistrals (USA).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              CAC43A4E
MD5:                33C5B4F9580C8A8AB48E15B04C925A6A
SHA1:               019908480071470B8549885A87A88B17B2330CD5
SHA256:             051333D74FA1A7D56FBF4EAA7B39A1EBA423D34131ECC292BFC8C186F3F7A74B