Use with:

(No Intro)
File:               Suikoden - Tierkreis (Europe) (En,Fr,De,Es,It).nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              9AD09ADA
MD5:                FEE1EE35AE1FF7B98520F64F6394157A