Use with:

(No Intro)
Bakugan - Battle Brawlers (Europe) (En,Fr,De,Es,It,Nl,Sv) (B6RP).nds
MD5: BBC72FFF53ADC04D27AB2F844DB99469
CRC: 9B12E0DD