Use with:

(No Intro)
File:               Hoshi no Kirby Ultra Super Deluxe (Japan).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              46342D80
MD5:                1816473B04E54F0BB925BE36C51301B3
SHA1:               7B15F266F7D1C0D23295AEA6B490D1F54EAAC9F1
SHA256:             D88C3EEFC9949BEA19FC619B33386A5D5719340EFAD0CE54AF3013D08225FCE6