Use with:

No Intro
Izuna 2 - The Unemployed Ninja Returns (USA).nds
RA Checksum: 2dfe9d9d24cff87ecb7aa730b5b04c9e
CRC32 Checksum: D98F38E6

