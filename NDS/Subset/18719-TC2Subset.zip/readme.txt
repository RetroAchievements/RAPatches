Use with 

(No Intro)
Trauma Center - Under the Knife 2 (USA).nds
RA Hash: 537af33ba04149e096bc5875ec838ef2
MD5: c3245d475b8258b3546cd9593aaa6e82
CRC: 1497600D