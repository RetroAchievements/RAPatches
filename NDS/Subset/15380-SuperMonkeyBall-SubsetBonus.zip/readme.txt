Use with:

(No Intro)
File:               Super Monkey Ball - Touch & Roll (Europe) (En,Fr,De,Es,It).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              7394B0C2
MD5:                C2D25D78EDCD97C0D32A2DC3780EED85