----------------------------------------------------------------------------------------

(No Intro)
File:               Inazuma Eleven (Europe) [Subset - 100% Player Recruitment].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              7EF233D6
MD5:                873CE1DBD20673BDAFC1C58AE6BD5C5B
SHA1:               29DC9FB6A3ACD23994CE1520C44ED38A20B1AB40
SHA256:             30A775144CE539BFD1594D9C57B224357ABA902E2C57C55A1E25F1D0B037EBDF

----------------------------------------------------------------------------------------

(No Intro)
File:               Inazuma Eleven (France) [Subset - 100% Player Recruitment].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              5590258A
MD5:                17D46B3DC3A7D89955635F5C7202ADBD
SHA1:               3F1CD2B1D60D67B92DB098317F663E6C1D7EC6CC
SHA256:             957AFFB79E7733BE1FC60100CC98481DC8DF9C73FEF6B7D59DAF26A7FA8440A6

----------------------------------------------------------------------------------------

(No Intro)
File:               Inazuma Eleven (Germany) [Subset - 100% Player Recruitment].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              62D1FF49
MD5:                221D4D2D4D9BC6999AFDE4C55A009E37
SHA1:               DAC35C30A24541A8789DFDFC805BFDB840F33F48
SHA256:             E041B43B80383739303EBF216B903A63C210F8529AAA121F2C18CDFBF5DD8232

----------------------------------------------------------------------------------------

(No Intro)
File:               Inazuma Eleven (Italy) [Subset - 100% Player Recruitment].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              0F50F706
MD5:                62EB27476DFCB6FE2F74068479BDA3A6
SHA1:               0582D206F8F9446B534CB09522F6015810D2941C
SHA256:             07DA39992E2EDC04E9ADA96465AC9C505D79619CF12BC4CAFE5945AC245DB5D7

----------------------------------------------------------------------------------------

(No Intro)
File:               Inazuma Eleven (Spain) [Subset - 100% Player Recruitment].nds
BitSize:            2 Gbit
Size (Bytes):       268435456
CRC32:              B42C459C
MD5:                DEC2CCC5053CC4A93B4CDF0C1E889B39
SHA1:               4D345105F382A8BAE6DDD315FE4DC1D17A8CA1A0
SHA256:             68F71949BDA807BDC9EE02665280C8682AB93C22ABCD356638CC137B6F039B8D

----------------------------------------------------------------------------------------