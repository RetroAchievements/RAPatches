Use with:

(No Intro)
Professor Layton and the Spectre's Call (Europe).nds
95e908922aa5699a9a18be3921e10f1c
AE4A3FD5

(No Intro)
Professeur Layton et l'Appel du Spectre (France).nds
2f11499caf8dcb5bb2f1d666fc54d8c6
1C71FEC8

(No Intro)
Professor Layton und der Ruf des Phantoms (Germany).nds
8db8815b3cf6f36d5d72be0209e2b8e4
12E582A0

(No Intro)
Profesor Layton y la Llamada del Espectro, El (Spain).nds
1a6a90642a569ba2c28665d28d258d8b
1838CF57

(No Intro)
Professor Layton e il Richiamo dello Spettro, Il (Italy).nds
422029001d1d0a2b9af6dd1176da9542
DE4AC4BA

(No Intro)
Professor Layton en de Melodie van het Spook (Netherlands).nds
ad507fe8c4ca5c64a0e0e751bdf547c3
AB14DB24