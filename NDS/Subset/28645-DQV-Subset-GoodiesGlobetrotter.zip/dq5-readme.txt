Use with:

(No Intro)
File:               Dragon Quest - The Hand of the Heavenly Bride (Europe) (En,Fr,De,Es,It).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              214C3931
MD5:                87215D7DDF71304F80AFBBFD7B8A8455
SHA1:               2B9C82283776026D931075DE8B87994CD0EE948E
SHA256:             15AC0888FBCDA0FCFEF0623DDBB47630ED8D8BB5968D2F2E563C3D9243362BE7