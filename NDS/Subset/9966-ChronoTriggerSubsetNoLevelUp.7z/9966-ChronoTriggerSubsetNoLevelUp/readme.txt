Use with:

(No Intro)
Chrono Trigger (Europe) (En,Fr).nds
md5: 4f3e02394f359aa0b9b4cf680d00e49f
crc: 82B3787C