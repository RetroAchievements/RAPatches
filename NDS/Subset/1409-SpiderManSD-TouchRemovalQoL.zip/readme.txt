Use with:

No-Intro
File:               Spider-Man - Shattered Dimensions (Europe) (En,Fr,De,Es,It).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              1D82AEEF
MD5:                64F6C3D017FC5F61EB3740CE2FD8A2A7
SHA1:               B09B7540E93292C8A7BDCC7E45A6B945470F34A3
SHA256:             EFD23252D760D6E77D52D04A6244444E7A9E58167A9FCFF9F5A7F8B0829483E8