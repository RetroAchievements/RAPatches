Use with:

(No Intro)
File:               Dragon Quest VI - Realms of Revelation (USA) (En,Fr,Es).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              75085C1A
MD5:                F5DD2364B69034439F79245849BEE633
SHA1:               015395649E69EA122A1CA79E108E386382360555
SHA256:             66B9F6D3C7EB1F2BBBF09B3004D46B86B08F87D3C1674A37F8246D2D544A3F33