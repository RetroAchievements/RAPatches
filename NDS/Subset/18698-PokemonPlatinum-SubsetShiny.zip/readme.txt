Use with:

(No Intro)
Pokemon - Platinum Version (USA).nds
d66ad7a2a0068b5d46e0781ca4953ae9
9253921d
