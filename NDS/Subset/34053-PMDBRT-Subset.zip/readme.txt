Use with:

(nointro)
File:               0668 - Pokemon Mystery Dungeon - Blue Rescue Team (Europe) (En,Fr,De,Es,It).nds
Size (Bytes):       33554432
CRC32:              A28B5A7A
MD5:                51360A97F1B601EA7DE88CF33AB2FF49
SHA1:               6F01887356268DE39085DF01490347BBCC3AA330
SHA256:             2540966E1E9CD722BF2AE401069DF10B81875AF03F0618D413B9D32511C14B05