Use with:

(No Intro)
File:               Pokemon - HeartGold Version (USA).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              C180A0E9
MD5:                258CEA3A62AC0D6EB04B5A0FD764D788
SHA1:               4FCDED0E2713DC03929845DE631D0932EA2B5A37

File:               Pokemon - HeartGold Version (Europe).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              B64A5EFB
MD5:                80C1024A03AA2C1E3D66BA168DB97739

File:               Pokemon - Edicion Oro HeartGold (Spain).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              0E3670CD
MD5:                B101936AD60A33E3C06B72C6EA15A99A

File:               Pokemon - Goldene Edition HeartGold (Germany).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              0A994C0C
MD5:                5582A09AF4FC2A9873712497C9CD425B

File:               Pokemon - Version Or HeartGold (France).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              533A6E55
MD5:                1F937C6376A25FF36358CA5819C83F5A

File:               Pokemon - Versione Oro HeartGold (Italy).nds
BitSize:            1 Gbit
Size (Bytes):       134217728
CRC32:              2646AE79
MD5:                7AAE450618F86F8D9E6F43ACA52AC919