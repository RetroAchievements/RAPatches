Use with:

(No Intro)
File:               Harvest Moon DS Cute (USA).nds
CRC32:              BA6B3F95
MD5:                0F391F2EDDB2A7E3B082FA036BB2878C

----------

The sprite change only affects Claire (the player character from Friends of Mineral Town).

In the introduction, choose the following answers:
1. Game Boy Advance
2. Love it
3. Not really
4. Mineral Town character

----------

Patch originally by unx on Romhacking.net
(https://www.romhacking.net/hacks/3781/)