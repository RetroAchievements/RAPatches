Use with:

(No Intro)
File:               Rock n' Bolt (Japan).sg
BitSize:            256 Kbit
Size (Bytes):       32768
CRC32:              0FFDD03D
MD5:                108FFE4BA5C2C8C5E0459CB7F0CFAC0E