Use with:

(No Intro)
File:               Loretta no Shouzou - Sherlock Holmes (Japan).sms
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              323F357F
MD5:                8DCDD83E58BE634A3735911A1AF05BB3
SHA1:               0DDD7448F5BD437D0D33B85A44F2BCC2BF2EA05E
SHA256:             5C8C32AFBA787F0983082B475EAFC382CD3EB33C582704A0DDA96D15861C4EBD

Make sure you change the extension from .sms to .sg