Use with:

(No Intro)
File:               Wizardry Scenario 1 - Proving Grounds of the Mad Overlord (Japan).wsc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              15E55706
MD5:                F0BA64CD7B88EAB7ADD0F7AF02080072