Use with:

(No Intro)
File:               Final Fantasy II (Japan).wsc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              F09E752F
MD5:                E03E666452651E82EB5734A9D684802A