Use with:

(No Intro)
Rockman & Forte - Mirai Kara no Chousensha (Japan).ws
523004d48e9d606e1557c2c57af6790b
cd206a9e
