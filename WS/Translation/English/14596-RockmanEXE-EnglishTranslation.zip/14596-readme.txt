Use with:

(No Intro)
Rockman EXE WS (Japan).wsc
a66390da2c2defcf092eb107edaf4fa0
658c4b98