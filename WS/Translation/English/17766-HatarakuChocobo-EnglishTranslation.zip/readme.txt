Use with:

(No Intro)
File:               Hataraku Chocobo (Japan).ws
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7A29E9A6
MD5:                EBAB0F1F4148D54437834971D9756431