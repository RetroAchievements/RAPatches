Use with:

(No Intro)
File:               Final Fantasy (Japan).wsc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              B7243E88
MD5:                E36650AC50DF69D1832A0D496C165DB2