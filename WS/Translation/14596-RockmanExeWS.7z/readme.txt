Use with:

Rockman EXE WS (Japan).wsc	(No-Intro)
a66390da2c2defcf092eb107edaf4fa0
658C4B98
