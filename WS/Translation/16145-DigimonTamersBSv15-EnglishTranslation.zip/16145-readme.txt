Use with:

(No Intro)
Digimon Tamers - Battle Spirit Ver. 1.5 (Japan).wsc
7e1be9ec064d8e1e92f26668c8a74326
6caad4a2