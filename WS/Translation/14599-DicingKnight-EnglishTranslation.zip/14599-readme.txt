Use with:

(No Intro)
Dicing Knight. (Japan).wsc
098b747bf9d88f651735b45197e393e1
1887389c