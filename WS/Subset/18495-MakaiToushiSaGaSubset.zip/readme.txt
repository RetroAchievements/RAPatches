Use with:

(No Intro)
Makai Toushi Sa-Ga (Japan).wsc
957137e7d5249c02fecff063e0c86e87
1B6F5F30

(No Intro)
Makai Toushi Sa-Ga (Japan).wsc + 1.2 Translation patch https://www.romhacking.net/translations/1614/
f1d130f871a4440be635322c73662049
a4308378