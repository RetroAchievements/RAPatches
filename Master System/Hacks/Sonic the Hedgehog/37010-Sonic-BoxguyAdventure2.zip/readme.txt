Use with:

(No Intro)
File:               Sonic The Hedgehog (USA, Europe, Brazil) (En).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              B519E833
MD5:                DC13A61EAFE75C13C15B5ECE419AC57B
SHA1:               6B9677E4A9ABB37765D6DB4658F4324251807E07
SHA256:             6AD738965ECE231427EE046B9905CFEE470D5C01220AFDD934DA4673E4A2458B