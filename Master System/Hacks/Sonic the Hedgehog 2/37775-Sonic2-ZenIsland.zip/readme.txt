Use with:

(No Intro)
File:               Sonic The Hedgehog 2 (Europe, Brazil) (En).sms
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              5B3B922C
MD5:                BF3B7A41E7DA9DE23416473A33C6AC2B
SHA1:               ACDB0B5E8BF9C1E9C9D1A8AC6D282CB8017D091C
SHA256:             402B1C89B120A23C6057CAF3D014F0E3074732264353C4A0E725D245B522E561