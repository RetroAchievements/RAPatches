Use with:

(No Intro)
File:               Alex Kidd in Miracle World (USA, Europe, Brazil) (En) (Rev 1).sms
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              AED9AAC4
MD5:                F43E74FFEC58DDF62F0B8667D31F22C0