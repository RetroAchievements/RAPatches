Use with:

(No-Intro)
File:               Alex Kidd in Miracle World (USA, Europe, Brazil) (En) (Rev 1).sms
Size (Bytes):       131072
CRC32:              aed9aac4
MD5:                f43e74ffec58ddf62f0b8667d31f22c0
SHA1:               6d052e0cca3f2712434efd856f733c03011be41c