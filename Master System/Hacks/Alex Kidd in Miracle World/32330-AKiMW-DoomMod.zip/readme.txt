Use with:

(No Intro)
File:               Alex Kidd in Miracle World (USA, Europe, Brazil) (En) (Rev 1).sms
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              AED9AAC4
MD5:                F43E74FFEC58DDF62F0B8667D31F22C0
SHA1:               6D052E0CCA3F2712434EFD856F733C03011BE41C
SHA256:             6667E133818E36A214C81003E543F2C4C3AB5FA018CA313E3AC222A5A6E361C5