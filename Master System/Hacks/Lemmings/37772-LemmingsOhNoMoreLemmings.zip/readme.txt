Use with:

(No Intro)
File:               Lemmings (Europe, Brazil) (En).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              F369B2D8
MD5:                B190F17A46BA9CC66676E7174209C24E
SHA1:               F3A853CCE1249A0848BFC0344F3EE2DB6EFA4C01
SHA256:             0B7E8F3ECD357C8129A214EA9B5723C4191B9550A0E94B120F70954FD668AD0C