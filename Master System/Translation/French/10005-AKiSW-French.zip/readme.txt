Use with:

Alex Kidd in Shinobi World (USA, Europe, Brazil).sms (No Intro)
d62b631506913712a2103f54912458a5