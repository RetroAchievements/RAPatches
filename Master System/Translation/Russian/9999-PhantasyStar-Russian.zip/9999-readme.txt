Use with:

(No Intro)
Phantasy Star (USA, Europe).sms
5ba9114edea5deb5282fd9ad7d4b2d62
E4A65E79

or

(No Intro)
Phantasy Star (USA, Europe) (Rev A).sms
1110938df80f4e44c8213d7f85cfb5e6
00BEF1D7