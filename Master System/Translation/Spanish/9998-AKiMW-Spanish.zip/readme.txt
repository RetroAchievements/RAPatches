NonGoodSMS Equivalent: Alex Kidd in Miracle World (UE) (V1.1) [T+ESP].sms
Base ROM: Alex Kidd in Miracle World (USA, Europe, Brazil) (Rev 1).sms (No Intro)
RA Checksum: 8d3df8d20e5beb5682c44bc2e2da16fa
CRC32 Checksum: C4F6B99D