Use with:

(No Intro)
File:               Aladdin (Europe, Brazil) (En).sms
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              C8718D40
MD5:                E3F60072028EB6F02C2B0558804AED83