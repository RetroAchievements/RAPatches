Use with:

(No Intro)
File:               Final Bubble Bobble (Japan).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              3EBB7457
MD5:                3573A65921B0506F7124F1F9FFB30974
SHA1:               AB585612FDDB90B5285E2804F63FD7FB7BA02900
SHA256:             DF74DD5AE77443E3B605F34698B7DCAADE2B26F21303DB3738C6ECB33DCB5AA4