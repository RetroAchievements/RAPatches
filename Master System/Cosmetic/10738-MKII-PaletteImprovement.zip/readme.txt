Use with:

(Redump)
File:               Mortal Kombat II (Europe, Brazil) (En).sms
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              2663BF18
MD5:                C60F62F13A60BC585822BFD2D68BA75C
SHA1:               12BD887EFB87F410D3B65BF9E6DFE2745B345539
SHA256:             CA8EB9142B42E55C8B8EDB54A5AAD0C4F62B98CAEDE3C5E489E62D504F11073D