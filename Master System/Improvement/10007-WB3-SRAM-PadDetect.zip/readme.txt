Use with:

(No Intro)
File:               Wonder Boy III - The Dragon's Trap (USA, Europe).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              679E1676
MD5:                E7F86C049E4BD8B26844FF62BD067D57