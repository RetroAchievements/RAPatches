Use with:

Sonic The Hedgehog (USA, Europe, Brazil).sms (No Intro)
dc13a61eafe75c13c15b5ece419ac57b