Use with:

(No Intro)
File:               Altered Beast (USA, Europe, Brazil) (Arcade Voices) (v1.2) (Maxim).sms
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              69FB5775
MD5:                3592D7A8B2EBF31004D057991462BFE6
SHA1:               5DE64F968C70BC3DC2C87C43A1FC3CCDFDEC70B7
SHA256:             21FE11F76ECD93214AE776CBCA5186EF6E3B45BC8940AAA0E9C42F3C19763C51