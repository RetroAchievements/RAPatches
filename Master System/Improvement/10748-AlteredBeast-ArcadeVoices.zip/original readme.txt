Altered Beast Arcade Voices patch
=================================

This patch replaces the voice samples in Altered Beast with data taken from the original arcade game, played using high-quality pcmenc data. It also adds in the missing "Rise from your grave", "Never give up" and "Welcome to your doom" samples, and the different beast roars.

Source is available at https://github.com/maxim-zhao/sms-hq-samples

v1.0 - initial release
v1.1 - boosted loudness of samples, fixed incorrect animal sounds on levels 3 and 4
v1.2 - corrected a bug which might make voices not sound right sometimes
