Use with:

(Final Burn Neo)
dkong.zip
d57b26931fc953933ee2458a9552541e
E9335A18