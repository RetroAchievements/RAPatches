Use with:

(Final Burn Neo)
dkong.zip
d57b26931fc953933ee2458a9552541e
E9335A18

To play the 1.06 version, the dkongbp.zip and dkong.zip are required. To play the 1.07 version, the dkongbp1.zip and dkong.zip are required.