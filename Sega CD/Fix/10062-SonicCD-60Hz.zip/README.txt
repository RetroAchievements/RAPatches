Sonic CD - PAL to NTSC 60Hz Full Patch V1
================By RoberMC===============

This patch is for people in love with Sonic CD as they originally played it in their "PAL" territory.

Until now if you wanted to play the original European release of Sonic CD for the Mega CD at 60 Hz, 
with its glorious Euro/Jap soundtrack, you had to use the "generic" Sega/Mega CD region change patches
which made the game run at 60 Hz, but full motion videos were skipping and playing back incorrectly,
another alternative was playing the Japanese release of the game which has some differences with the 
European release and some Japanese text in some places. You could also play the USA Betas, which had the
original Jap/Eur soundtrack but were not the final game. Or just surrender and play the USA version 
with its awful soundtrack... Well, until now!

This patch makes your Sonic CD European release to play flawlessly at 60 Hz. It has been worked on 
the European release so nothing changes, the game is the exact same European release but playing
correctly at 60 Hz, FMV decoding has been fixed and everything else.

This patch has been tested in the real hardware and in emulators. To play at 60 Hz you need to run the
game with the Sega CD USA bios, or any Region-free bios. European Region-Free Bios for extra nostalgia
recommended.

You can also apply Sonic CD ++ hack on top of this patch, just tell the SCD++ patcher you are using the
European iso as source as you would normally.

Two patches are included depending on which dump of the game you have, ISO or BIN format.

Included in this package:

DeltaPatcherLite.exe: Tool to apply the patch. It is allowed by the author to include it in the package.

SonicCD_PAL_to_NTSC_v1_BIN.xdelta: Patch file to use with "Redump" release of the European Sonic CD
				   in BIN+CUE format, apply the patch to the first track
				   "Sonic CD (Europe).bin" with file size of 129.590.496 bytes

SonicCD_PAL_to_NTSC_v1_ISO.xdelta: Patch file to use with ISO+CUE releases of the European Sonic CD
				   apply the patch to the first track "Sonic CD (E).iso", this should
				   work on any iso release as long as it is correctly extracted.

Readme.txt: This stupid file.

Note, You only have to apply one of the two included patches, NOT THE TWO, depending on which kind of dump of the
game you have, ISO or BIN format.

Enjoy!