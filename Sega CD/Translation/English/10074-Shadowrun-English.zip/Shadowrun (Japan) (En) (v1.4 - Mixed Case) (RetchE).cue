FILE "Shadowrun (Japan) (En) (v1.4 - Mixed Case) (RetchE) (Track 1).bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
FILE "Shadowrun (Japan) (En) (v1.4 - Mixed Case) (RetchE) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Shadowrun (Japan) (En) (v1.4 - Mixed Case) (RetchE) (Track 3).bin" BINARY
  TRACK 03 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
