Use with:
Meitantei Conan - Kigantou Hihou Densetsu (Japan) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
f5325eaf1ecbf7cd6e1e561a3b5d77f7
E620FAE2