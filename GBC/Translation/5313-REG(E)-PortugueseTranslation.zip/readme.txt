Use with:
Resident Evil Gaiden (Europe) (En,Fr,De,Es,It).gbc (No-Intro)
8a7f483857e251d56a16594ca84d1a7e
F85C3F2C