Use with:
Meitantei Conan - Karakuri Jiin Satsujin Jiken (Japan) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
3a3e92c106a8674642e0ee3c0c793a9f
3B5F24FC