Use with:

(No Intro)
Mobile Golf (Japan).gbc
fbf1ffe76883dffcca299228c81f171f
35FC5B32