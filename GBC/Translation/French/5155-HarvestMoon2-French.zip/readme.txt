Use with:
Harvest Moon 2 GBC (USA) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
a539a7a02639395ad8d7723199c81eae
08906220