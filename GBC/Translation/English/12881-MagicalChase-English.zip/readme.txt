Use with:

(No Intro)
File:               Magical Chase GB - Minarai Mahoutsukai Kenja no Tani e (Japan).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              15E5D499
MD5:                F722B68C0F532ED567397A3E53909CCF
SHA1:               3B13FC974D68A8B057AB8133A0BA7E3FBAC23F11
SHA256:             DF6D6B3E1998E2D00CDA82C9B2E6F80837D890A384B7C3B1A87E9A8DBCA300BF