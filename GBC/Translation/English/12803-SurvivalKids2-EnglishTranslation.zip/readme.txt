Use with:

(No Intro)
File:               Survival Kids 2 - Dasshutsu!! Futago-Jima! (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              AB8B25D8
MD5:                9D2F7E1AC30A46456A841C264963E5EA
SHA1:               8FD720D5B035939B553910A3EC45C1BD052484EB
SHA256:             3BFF03275CC5407C4746DE40B351E791B319E3C6C1DA11382FBE2DE4F9BA2160