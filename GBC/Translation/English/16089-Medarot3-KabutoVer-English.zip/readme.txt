Use with:

(No Intro)
File:               Medarot 3 - Kabuto Version (Japan).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              E655632C
MD5:                CBC55F3BB98F8C0443917AE477E56E51
SHA1:               5478069C840B5B13E2413771F35FDC844D1974F1
SHA256:             4BDF7D059350C69229EA72AA885DC81AC62BB3466E5DA000E8C880528D7ED650