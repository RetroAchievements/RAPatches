Use with:

(No Intro)
File:               Super Robot Pinball (Japan).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6E330FCD
MD5:                6C7DC7CE74088A9E42A6FB8D98A67714