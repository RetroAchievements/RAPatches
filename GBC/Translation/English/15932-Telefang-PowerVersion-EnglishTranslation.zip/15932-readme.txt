Use with:

Keitai Denjuu Telefang - Power Version (Japan) (GB Compatible).gbc (No-Intro)
04f7ea139fef2bc2e3f70b2c23933d2e
8B61CFCC
