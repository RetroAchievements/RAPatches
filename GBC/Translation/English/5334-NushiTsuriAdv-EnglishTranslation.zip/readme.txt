Use with:

(No Intro)
File:               Nushi Tsuri Adventure - Kite no Bouken (Japan) (Rumble Version).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              AC52F6EF
MD5:                5B40590960C204EFD6303B2E89A0CC10