Use with:

(No Intro)
File:               Marie no Atelier GB (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6144FC66
MD5:                FE97E6BB194BD38E5BAEB889B4C8E251
SHA1:               F2B175DA93054372531BC7D839BDBF3192C6A5EB
SHA256:             12C844AD512D2B210FB61847161606BA0E8A7349C27A2B0F896D687F4D6FBA8E