Use with:

(No Intro)
File:               Pokemon Picross (Japan) (Proto).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              CF647F4B
MD5:                35D2E7924408A3460E5C1A770ACF3A8A