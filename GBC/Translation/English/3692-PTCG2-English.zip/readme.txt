Use with:
Pokemon Card GB 2 - GR Dan Sanjou! (Japan).gbc (No-Intro)
1134862e84110443190df460351d4575
6C933A14