Use with:

(No Intro)
File:    Shin Megami Tensei Devil Children - Aka no Sho (Japan) (SGB Enhanced) (GB Compatible).gbc
Size:    2097152
CRC32:   f90c4977
MD5:     3d04e5c70919118ef6e7cb69dae14b10
SHA-1:   b15cbd01a21048d0fd022f0e023ab5d91faaf442
SHA-256: 6c70743e13f41738b80aa393ab20cd1d35f87e47cb50454a235fee5ba062dd0a