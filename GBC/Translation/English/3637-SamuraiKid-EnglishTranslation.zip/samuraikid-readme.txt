Use with:

(No Intro)
File:               Samurai Kid (Japan).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              44A9DDFB
MD5:                7EE095116F1733DC6BA2B2DE3F28F5EF