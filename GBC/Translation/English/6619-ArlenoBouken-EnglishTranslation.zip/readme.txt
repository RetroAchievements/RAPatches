Use with:

(No Intro)
File:               Arle no Bouken - Mahou no Jewel (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              8EE043EA
MD5:                9ABAF0DFEB58B76D6B5CCE4B42756C8E
SHA1:               FB781637DDAC30CEBB1865BA939F49BB2B0B5146
SHA256:             DCDFE0DD3C27E8DA2EAC40B7B1F692E16CBF5FF414476D7B05BDB958659B2BCD