Use with:

(No Intro)
File:               Yu-Gi-Oh! - Monster Capsule GB (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              1371E872
MD5:                B980DA92693762BD3A7A4791FE08766E
SHA1:               4ED5607DD83EBE7975C492B08D36870F8DD6E302
SHA256:             DAF4055A1E873944130B0E3E4A61ED9991831FB66A7C91AE52FCA7DA0E2D61DB