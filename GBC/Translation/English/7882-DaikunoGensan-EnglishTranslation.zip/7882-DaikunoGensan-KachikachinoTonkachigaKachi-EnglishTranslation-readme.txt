

Use with:

Daiku no Gen-san - Kachikachi no Tonkachi ga Kachi (Japan) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
7455ea4fb9bc8ac752b4e43fd6864b7f
E2071293
