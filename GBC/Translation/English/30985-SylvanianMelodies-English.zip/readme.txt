Use with:

(No Intro)
File:               Sylvanian Melodies - Mori no Nakama to Odori Masho! (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              6DD8AC91
MD5:                08130CB33FE270321D04D056B85D2037
SHA1:               55230E865958F7301076A4354B6B8B083A494BAE
SHA256:             82A54C80816DCB3C89F9FAC6EC7C39974D8FCBBEFD7E4AFBD47DBE13A2E857C9