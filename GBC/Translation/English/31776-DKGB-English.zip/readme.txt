Use with:

(No Intro)
File:               Donkey Kong GB - Dinky Kong & Dixie Kong (Japan).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              28D7E8D3
MD5:                22AFE691095C65F34AEABA3C283B2A9C
SHA1:               55B133B739A5472D477336647CB9EC97B7FA85A2
SHA256:             8DB7DBA17A4D84D31F8CC80C5095571C52101C7384D69D8E6FDBC0C8D6E777FA