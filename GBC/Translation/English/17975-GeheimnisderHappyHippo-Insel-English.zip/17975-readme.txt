Use with:

(No Intro)
File:               Geheimnis der Happy Hippo-Insel, Das (Germany).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              25B480C3
MD5:                3BC2DB27BAFF012307501C31D49922AC