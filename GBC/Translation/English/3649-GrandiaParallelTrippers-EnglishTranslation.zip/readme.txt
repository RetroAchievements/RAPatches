Use with:

(No Intro)
File:               Grandia - Parallel Trippers (Japan).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              23223670
MD5:                5679DE3C41C63C6B9DC9432C7ED1105A
SHA1:               647B7CC5FA415EF7081AA37CD787EB41D2A3E574
SHA256:             4C4397870B96A88E3232F7437945BA122AB2E951B3FE2BB7775D99843D1D6AA5