Use with:

(No Intro)
File:               Sutte Hakkun GB (Japan) (Proto) (SGB Enhanced) (GB Compatible).gbc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              E0386F84
MD5:                243B2B6151D41D8E111E98AC49BA9AB4
SHA1:               6EFD637F039D4F3A2240640921724A69A2844CC7
SHA256:             5551D4F76225447EA9E0F316A8710638CDE8A9F6997FE5FA0C627F0351BA023E