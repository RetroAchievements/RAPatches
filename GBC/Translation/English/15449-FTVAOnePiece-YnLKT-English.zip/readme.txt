Use with:

(No Intro)
File:               From TV Animation One Piece - Yume no Luffy Kaizokudan Tanjou! (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              C693AA37
MD5:                DA5586315CA857071D557A8FDE26C108
SHA1:               459F1AE41F6C5C6464745A23EA42BBBA5385A83B
SHA256:             6680858CFDCC658E4B1E10D49F48B0F4ABFDBA10CD52007CDE64744036EADFF4