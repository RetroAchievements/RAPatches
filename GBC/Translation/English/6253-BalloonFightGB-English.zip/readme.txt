Use with:

(No Intro)
File:               Balloon Fight GB (Japan) (SGB Enhanced, GB Compatible) (NP).gbc
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              D2AF64CE
MD5:                F94F61E6BEAEC6222E0D35229E2E271E
SHA1:               DBAA1BF9061DE0F052704D6A33892341A38F2152
SHA256:             FB6E3BF85C7F54A1C6EBC3772FD941AF6E0D53703E24518492BC9B2F5EDC8D7E