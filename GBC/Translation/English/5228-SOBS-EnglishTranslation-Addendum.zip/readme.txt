Use with:

(No Intro)
Star Ocean - Blue Sphere (Japan) (SGB Enhanced) (GB Compatible).gbc
MD5: 820e0a19275fabc03fe619c42db47179
CRC: 8c7ddbda