Use with:

(No Intro)
File:               Hello Kitty no Magical Museum (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F6768930
MD5:                B868FA9F3CECFA2D39DF43A5D1B13B60