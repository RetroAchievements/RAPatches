Use with:

(No Intro)
File:               Tales of Phantasia - Narikiri Dungeon (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              725CF31C
MD5:                A3C65D746E0E171843E9013E8D8E1021
SHA1:               EF322F4160CEEBD8DA67758EBD73225190AF6D23
SHA256:             E3853A07E50B8894C6E8F0FFAB94354128F270914F60A40D726105021DB73A05