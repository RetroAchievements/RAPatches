Use with:

(No Intro)
File:               Wizardry Empire - Fukkatsu no Tsue (Japan).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              1A10552B
MD5:                FA8360094CAE37A838FABCFD333AE300