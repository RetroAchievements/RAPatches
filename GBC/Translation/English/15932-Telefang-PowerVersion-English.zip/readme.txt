Use with:

(No Intro)
File:               Keitai Denjuu Telefang - Power Version (Japan) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8B61CFCC
MD5:                04F7EA139FEF2BC2E3F70B2C23933D2E
SHA1:               BAAF7FB9F9958CA22982BA0600BC0CB8A7FC4764
SHA256:             594B148824E575EB7577A4111AEA80C5A7718EC43979A86E3A2D360C8040A99B