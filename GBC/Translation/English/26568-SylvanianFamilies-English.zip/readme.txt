Use with:

(No Intro)
File:               Sylvanian Families - Otogi no Kuni no Pendant (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              C6FE4497
MD5:                5B250AB006A50301F29E74551531BD7F
SHA1:               440D0010386F3F2D658740CC6584558F546482A6
SHA256:             446D18A00DDA7E50CD839AFD1F27BB91B864807CCCDF14B36C2188B6961DBCDF