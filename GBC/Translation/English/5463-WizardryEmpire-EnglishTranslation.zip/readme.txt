Use with:

(No Intro)
File:               Wizardry Empire (Japan) (Rev 1).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              FA82620F
MD5:                FCF910E4D2F27BAB40244EB7BF4AA2D3