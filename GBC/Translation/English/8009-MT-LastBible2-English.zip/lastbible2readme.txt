Use with:

(No Intro)
File:               Megami Tensei Gaiden - Last Bible II (Japan) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              9CAA00B5
MD5:                7E32DC8B60413CFAA24F941691E545D2