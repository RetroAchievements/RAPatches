Use with:

(No Intro)
File:               Medarot 3 - Kuwagata Version (Japan).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              BC617834
MD5:                DABFBDC9ABA5F2EDC21F884C52881E0D
SHA1:               5207698702D206046DD105B07E0C0BBDBC6ED39C
SHA256:             20E7EB282542D57FB17F11DBF87CF805F41BE0971877F7C28E3A40F4934A26BF