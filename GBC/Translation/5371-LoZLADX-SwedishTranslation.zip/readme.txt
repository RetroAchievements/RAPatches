Use with:
Legend of Zelda, The - Link's Awakening DX (USA, Europe) (Rev 2) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
7351daa3c0a91d8f6fe2fbcca6182478
06887A34