Use with:

(No Intro)
File:               Legend of Zelda, The - Link's Awakening DX (USA, Europe) (Rev 2) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              06887A34
MD5:                7351DAA3C0A91D8F6FE2FBCCA6182478
SHA1:               1C091225688D966928CC74336DBEF2E07D12A47C
SHA256:             5DEE5816ED9B46CFC4A2D94F275E555DD3C5080ECA00DED975A41A881A6D4C06
