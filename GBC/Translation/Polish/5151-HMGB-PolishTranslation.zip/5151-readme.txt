Use with:

Harvest Moon GB (USA) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
498c0a50a5e5cde16127617a97ad6162
AB5738A1
