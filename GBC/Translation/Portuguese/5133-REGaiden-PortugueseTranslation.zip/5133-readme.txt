Use with:

(No Intro)
File:               Resident Evil Gaiden (Europe) (En,Fr,De,Es,It).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              F85C3F2C
MD5:                8A7F483857E251D56A16594CA84D1A7E