Use with:

(No Intro)
File:               Survival Kids (USA) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C46ABA56
MD5:                07D4DF7A1C93F5BEF617E5A90B9EDEE2