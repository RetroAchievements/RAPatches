Use with:

(No Intro)
File:               Legend of Zelda, The - Link's Awakening DX (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              97822948
MD5:                07C211479386825042EFB4AD31BB525F

File:               Legend of Zelda, The - Link's Awakening DX (USA, Europe) (Rev 1) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              B38EB9DE
MD5:                CCBB56212E3DBAA9007D389A17E9D075

File:               Legend of Zelda, The - Link's Awakening DX (USA, Europe) (Rev 2) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              06887A34
MD5:                7351DAA3C0A91D8F6FE2FBCCA6182478