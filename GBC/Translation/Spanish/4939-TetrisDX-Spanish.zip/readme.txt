Use with:
Tetris DX (World) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
65973d7a1446346294f8ca9d2d1b7e66
69989152