Use with:

(No Intro)
File:               Pokemon Card GB 2 - GR Dan Sanjou! (Japan).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6C933A14
MD5:                1134862E84110443190DF460351D4575
SHA1:               A7E12BCC5F514E3AAD8DE570FD511AAB0A308822
SHA256:             0C26B4FEC983E1CE7EFEDB7C6B6DE997A26240F0390A7CAAB21888B819E3624A