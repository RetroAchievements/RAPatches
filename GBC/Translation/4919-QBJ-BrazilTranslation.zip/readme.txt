Use with:
Quest - Brian's Journey (USA) (GB Compatible).gbc (No-Intro)
93ff3f6b4bfe0a138d8a8897899e8cb0
9AC27645