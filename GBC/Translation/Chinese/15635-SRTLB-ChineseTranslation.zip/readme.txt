Use with:

No Intro
Super Robot Taisen - Link Battler (Japan) (SGB Enhanced) (GB Compatible).gbc
D710CD23E7E38023297D04E935DBEBAE
D24E592D
