Use with:

(No Intro)
File:               Terrifying 911 (Unl).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              188B06F8
MD5:                A7A2C27CB6FC2C6CF67EB8AF2B99C612