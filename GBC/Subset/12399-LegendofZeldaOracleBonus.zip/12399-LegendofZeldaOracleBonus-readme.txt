Use with:

Legend of Zelda, The - Oracle of Ages (Europe) (En,Fr,De,Es,It).gbc (No-Intro)
825de040ea4dff66661693f8712b1bdb
5933E3FA

Legend of Zelda, The - Oracle of Seasons (Europe) (En,Fr,De,Es,It).gbc (No-Intro)
4ca44cbdd4e05c9b3c22da96d3de6338
DBAC1357

