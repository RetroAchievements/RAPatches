Use with:

Pokemon - Crystal Version (USA, Europe).gbc (No-Intro)
9f2922b235a5eeb78d65594e82ef5dde
EE6F5188
