Use with:

(No Intro)
File:               Bomberman Max - Ain Version (Japan).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              545E0DA2
MD5:                54C8522C1D924A05BB05AC6673F023E6