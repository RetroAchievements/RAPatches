Use with:

(No Intro)
File:               Caterpillar Construction Zone (USA, Europe) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D20DC670
MD5:                046AF13647ED4777510AA86FCB753BF9