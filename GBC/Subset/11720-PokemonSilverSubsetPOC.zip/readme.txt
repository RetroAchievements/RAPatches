Use with:

(No Intro)
Pokemon - Silver Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
2ac166169354e84d0e2d7cf4cb40b312
8AD48636