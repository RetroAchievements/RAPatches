Use with:

(No-Intro + RAPatches)
File:               Pokemon Crystal - Crystal Clear (v2.6.0) (ShockSlayer).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              17617CDE
MD5:                51E834D984B192305E848A73EF100716
SHA1:               84D5C4924C3F1F3FC690669148B7E392948FB23D
SHA256:             C4585682D26C0BAE3EB424F064806739839EE8E537735A19A5E16703FA86E32A