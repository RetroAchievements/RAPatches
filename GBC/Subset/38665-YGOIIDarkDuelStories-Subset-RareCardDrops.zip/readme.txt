dUse with:

(No Intro)
File:               Yu-Gi-Oh! Duel Monsters II - Dark Duel Stories (Japan) (SGB Enhanced) (GB Compatible).gbc
Size (Bytes):       4194304
CRC32:              ba7182c3
MD5:                782b88b1bf9768a2b1b139177a0c1c33