Use with:

(No Intro)
Dragon Warrior III (USA).gbc
b74b6132326bafcd75e415ddcd9a2932
0FD9C59C