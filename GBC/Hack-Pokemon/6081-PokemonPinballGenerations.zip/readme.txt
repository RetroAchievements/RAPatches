Use with:

(No Intro)
File:               Pokemon Pinball (USA, Australia) (Rumble Version) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              03CE8D9A
MD5:                FBE20570C2E52C937A9395024069BA3C
SHA1:               9402014D14969432142ABFDE728C6F1A10EE4DAC
SHA256:             7672001D4710272009DF6A41E3CBADA65DECD56E0EB2F185CB3D59C08D33EA0E