Use with:

(No Intro)
File:               Pokemon Trading Card Game (USA, Australia) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              81069D53
MD5:                219B2CC64E5A052003015D4BD4C622CD