Use with:

Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc (No Intro)
MD5: 301899b8087289a6436b0a241fbbb474