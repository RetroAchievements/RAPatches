Use with:
Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc (No-Intro)
301899b8087289a6436b0a241fbbb474
3358E30A