Use with:
Revelations - The Demon Slayer (USA) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
86ed74283fe0071f8d3f05923051efab
D1A65D74