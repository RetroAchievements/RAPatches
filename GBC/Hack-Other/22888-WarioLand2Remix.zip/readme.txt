Use with:

(No Intro)
File:               Wario Land II (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              047BDF80
MD5:                B7598A51E0ACC0D74CA8F464826371ED
SHA1:               AE37915058035DF4CEEDD72D709F91EFB4878EFF
SHA256:             40F366CCD5BD6A9643DC317DB63A286F9104F164F9FC46FF037E548D5E83ED52