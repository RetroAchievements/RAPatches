use with:
Wario Land 3 (World) (En,Ja).gbc (No-Intro)
16BB3FB83E8CBBF2C4C510B9F50CF4EE
480D0259