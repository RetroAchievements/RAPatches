

Use with:

Shantae (USA).gbc (No-Intro)
028c4262dbb49f4fc462a6eb3e514d72
E994B59B
