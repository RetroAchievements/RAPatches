Use with:

(No Intro)
File:               Luke Yingxiong 2 - Zook Hero 2 (Taiwan) (Unl).gbc
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              59822B31
MD5:                C194C03C9D31EC629FD126551F7364FE
SHA1:               4BF85D9641E3B842A917474DCB49A8B7F282711B
SHA256:             3A6D8F713B369DA673BF903355A8894E7A763CB45408D2CF5CEC9FECC3CE616F