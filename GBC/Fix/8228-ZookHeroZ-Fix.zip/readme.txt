Use with:

(No Intro)
File:               Luke Yingxiong Z (Taiwan) (Unl).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              8CED0C21
MD5:                2DFCACFF86B06540D528447C21531B46
SHA1:               271097C99BE5F60FBDB561875D006A622093FE70
SHA256:             7B511DF10FACA5F4BBEDB87C761BD0581770C2DA23ECCC85BB80A56F60DE3AF7