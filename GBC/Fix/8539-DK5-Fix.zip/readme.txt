Use with:

(No Intro)
File:               Donkey Kong 5 - The Journey of Over Time and Space (Taiwan) (En) (Unl).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              1A369DD5
MD5:                0132A38451021C3C9E8F5532FC888343
SHA1:               1FF1AC88DEA7431866016970C4F4AE049302201B
SHA256:             70485A478C3156C57CA2FF6DC40C24E0EE74582DD8CEAB714AB587D7EFCAA6F7