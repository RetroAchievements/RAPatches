Use with:

(No Intro)
File:               Pokemon - Silver Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8AD48636
MD5:                2AC166169354E84D0E2D7CF4CB40B312