Use with:

(No Intro)
File:               Pokemon - Silver Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              8AD48636
MD5:                2AC166169354E84D0E2D7CF4CB40B312
SHA1:               49B163F7E57702BC939D642A18F591DE55D92DAE
SHA256:             72B190859A59623CBEF6C49D601F8DE52C1D2331B4F08A8D2ACC17274FC19A8C