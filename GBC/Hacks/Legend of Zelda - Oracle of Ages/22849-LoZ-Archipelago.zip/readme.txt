use with:
Legend of Zelda, The - Oracle of Ages (USA, Australia) (No-Intro)
C4639CC61C049E5A085526BB6CAC03BB
3800A387