Use with:

(No-Intro)
File:               Legend of Zelda, The - Oracle of Ages (USA, Australia).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              3800A387
MD5:                C4639CC61C049E5A085526BB6CAC03BB
SHA1:               880374FB978B18AF4AA529E2E32F7FFB4D7DD2F4
SHA256:             0B56B78A9E45452E98C33EDD111234931F1E034DC097F6F23082EB8DB6055474