Use with:

(No Intro)
File:               Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              3358E30A
MD5:                301899B8087289A6436B0A241FBBB474