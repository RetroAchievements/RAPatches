Use with:

(No-Intro)
File:               Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc
Size (Bytes):       2097152
CRC32:              3358e30a
MD5:                301899b8087289a6436b0a241fbbb474
SHA1:               f2f52230b536214ef7c9924f483392993e226cfb