patch with

no-intro
File:               Pokemon - Crystal Version (UE) (V1.0).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              EE6F5188
MD5:                9F2922B235A5EEB78D65594E82EF5DDE
SHA1:               F4CD194BDEE0D04CA4EAC29E09B8E4E9D818C133
SHA256:             D6702E353DCBE2D2C69183046C878EF13A0DAE4006E8CDFF521CCA83DD1582FE