Use with:

(No Intro)
File:               Pokemon - Crystal Version (USA, Europe) (Rev 1).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              3358E30A
MD5:                301899B8087289A6436B0A241FBBB474
SHA1:               F2F52230B536214EF7C9924F483392993E226CFB
SHA256:             FDCC3C8C43813CF8731FC037D2A6D191BAC75439C34B24BA1C27526E6ACDC8A2