Use with:

(No Intro)
File:               Pokemon - Gold Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            16 Mbit
Size (Bytes):       2097152
CRC32:              6BDE3C3E
MD5:                A6924CE1F9AD2228E1C6580779B23878
SHA1:               D8B8A3600A465308C9953DFA04F0081C05BDCB94
SHA256:             FB0016D27B1E5374E1EC9FCAD60E6628D8646103B5313CA683417F52B97E7E4E