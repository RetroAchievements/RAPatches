Use with:

(No Intro)
Pokemon - Gold Version (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
MD5 - a6924ce1f9ad2228e1c6580779b23878
CRC - 6BDE3C3E