Use with:

(No Intro)
File:               Dragon Warrior Monsters 2 - Cobi's Journey (USA) (SGB Enhanced) (GB Compatible).gbc
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              AB7BFDD5
MD5:                F71AC6AC4BB335F59BFD2B594D47AB49
SHA1:               76901B7E5CADF9611DD4FAC52E8501155C1E33A2
SHA256:             8E38A7420EF5239C7196AA4FD4B1499E65DB2823E875BBF8241BB2199E766D4E