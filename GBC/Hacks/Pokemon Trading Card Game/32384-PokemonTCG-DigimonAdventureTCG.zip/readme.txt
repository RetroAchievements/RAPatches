Use with:

(No Intro)
File:               Pokemon Trading Card Game (USA, Australia) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              81069D53
MD5:                219B2CC64E5A052003015D4BD4C622CD
SHA1:               0F8670A583255CFF3E5B7CA71B5D7454D928FC48
SHA256:             A54515BB6B3E364964D3C0226F5A6B0C8C0F7318C9296EF2E321DF0BBB8541CE