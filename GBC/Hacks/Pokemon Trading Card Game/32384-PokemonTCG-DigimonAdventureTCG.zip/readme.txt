Use with:

(No Intro)
File:               Pokemon Trading Card Game (USA, Australia) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              2144DF1C
MD5:                C777370C63F1BD0DFC6D9E507360995C
SHA1:               76082986107E55BCFB873FEB84199C3F6F0ED823
SHA256:             E134A22CA86CD78EDA7B66E88EC77721F0D05CDA3B39594EBCD1E761B2A122A7