Use with:

(No Intro)
Magi Nation (USA).gbc
MD5 - 1624f857098ca278b15629914f48352b
CRC32 - 5042450B