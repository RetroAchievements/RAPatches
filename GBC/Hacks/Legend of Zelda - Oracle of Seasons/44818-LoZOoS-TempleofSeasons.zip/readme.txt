Use with:

(No Intro)
File:               Legend of Zelda, The - Oracle of Seasons (USA, Australia).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D7E9F5D7
MD5:                F2DC6C4E093E4F8C6CBEA80E8DBD62CB
SHA1:               BA1268290FB2B1B70505D2D7B5825FC8A4816A4B
SHA256:             862A51368FB30539279D336B3FE193B43876D2CB15C87A36F5DA517804AB3971