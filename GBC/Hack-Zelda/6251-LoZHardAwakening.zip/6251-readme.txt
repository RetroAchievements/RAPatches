Use with:

(No Intro)
File:               Legend of Zelda, The - Link's Awakening DX (USA, Europe) (SGB Enhanced) (GB Compatible).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              97822948
MD5:                07C211479386825042EFB4AD31BB525F