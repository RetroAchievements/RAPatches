Use with:

Legend of Zelda, The - Link's Awakening DX (USA, Europe) (SGB Enhanced) (GB Compatible).gbc (No-Intro)
07c211479386825042efb4ad31bb525f
97822948
