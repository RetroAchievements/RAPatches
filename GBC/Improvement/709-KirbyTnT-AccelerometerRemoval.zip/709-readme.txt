Use with:

(No Intro)
File:               Kirby - Tilt 'n' Tumble (USA).gbc
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              E541ACF1
MD5:                F2E24776D93082362C9B435ABC167D89