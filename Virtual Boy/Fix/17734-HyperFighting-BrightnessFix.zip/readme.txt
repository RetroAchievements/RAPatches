Use with:

(No Intro)
File:               Hyper Fighting (World) (Aftermarket) (Unl).vb
BitSize:            32 Mbit
Size (Bytes):       4194304
CRC32:              3F2A6BA2
MD5:                C2047A94DCB0DB30794C8533BA625622
SHA1:               578355DE83822CE67522033DD7545631124A71AB
SHA256:             8F37F324550C9B60246C0A3EFEFA1B7F2400EF9F79B5D3CE2EF61699C68614B2