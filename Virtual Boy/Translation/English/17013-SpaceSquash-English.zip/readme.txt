Use with: 

(No Intro)
Space Squash (Japan).vb
md5: 09c5f3143c25d1d30a3470e571653e48
crc: 60895693 