Use with:

(No Intro)
File:               Niko-chan Battle (Japan) (Proto).vb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F3CD40DD
MD5:                D9A0215782DCACEE5A3C4CC83D1C5189
SHA1:               217CA062F65D4E8B2848085918AF5AC4B33B12D4
SHA256:             AE35CC583482187045307A326EDFC19887B8129C039166D80CD5C316524D89BF