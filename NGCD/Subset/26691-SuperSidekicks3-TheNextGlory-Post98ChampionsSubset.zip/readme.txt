Use with:

(Redump)
Tokuten-ou 3 - Eikou e no Chousen ~ Super Sidekicks 3 - The Next Glory (Japan, USA) (En,Ja,Fr,Es,It,Pt) (Track 01).bin
MD5: DB1372DEC6F64D6512284609DBCD58CD
CRC: 69CCAE9B