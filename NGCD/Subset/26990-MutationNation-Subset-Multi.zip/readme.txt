Use with:

(Redump)
File:               Mutation Nation (Japan) (En,Ja) (Track 01).bin
BitSize:            70 Mbit
Size (Bytes):       9273936
CRC32:              61EE4822
MD5:                041207E4E4F9AB70E8D0084F9E48D52C
SHA1:               C86046C7B15FD101F2B8D25BD3077744991A270C
SHA256:             0E60B6E2B3018EC7D68A774545937CE8612861703F3E571B38701754D16FC66F