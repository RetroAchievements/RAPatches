Use with:

(No Intro)
File:               Mario Artist - Paint Studio (Japan).ndd
BitSize:            495 Mbit
Size (Bytes):       64931840
CRC32:              B732C3AD
MD5:                8485643E5830CD67ED4C0A5FD49E2491
SHA1:               9997E6F118C72F265EB648F18FAA48C3A416FB3B
SHA256:             6B3C4FCD6C89370A9E7FFA0130282F20897F96F5ED5A1F634F82A546850B6C2A