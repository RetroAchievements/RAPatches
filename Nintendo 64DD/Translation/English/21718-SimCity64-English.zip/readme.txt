Use with:

(No Intro)
File:               SimCity 64 (Japan).ndd
BitSize:            495 Mbit
Size (Bytes):       64931840
CRC32:              163456CA
MD5:                EBBA03F20096FC2BC178FC3A1F4EC2B6