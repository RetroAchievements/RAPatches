Use with:

(No Intro)
File:               Mario Artist - Polygon Studio (Japan).ndd
BitSize:            495 Mbit
Size (Bytes):       64931840
CRC32:              AC304109
MD5:                DA23EE561578B7DAD77ED72728B46D30
SHA1:               4E4F267D2D063286BF4C1302386DAB8B1AB0D4C6
SHA256:             A601AE1A9CAEF9F60A81B343351EA222BD1270671E1BE546D6C4F4B680315F09