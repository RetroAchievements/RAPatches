Use with:

Kenseiden (USA, Europe).sms (No Intro)
6ae8f011701608ae8b765a26eb0b7ce1

