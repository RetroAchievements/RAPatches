Use with:

Sonic The Hedgehog 2 (Europe, Brazil) (Rev 1).sms (No Intro)
0ac157b6b7e839953fc8eba7538fb74a