Use with:

[BIOS] Sega Master System (USA, Europe) (v1.3).sms (No Intro)
840481177270d5642a14ca71ee72844c