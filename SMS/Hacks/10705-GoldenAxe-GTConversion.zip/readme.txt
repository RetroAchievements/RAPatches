Use with:

Golden Axe (USA, Europe).sms (No Intro)
b4911ad6a9d2ba56497cd5b01da3938a