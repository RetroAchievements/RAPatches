Use with:

(No Intro)
Sonic The Hedgehog - Triple Trouble (USA, Europe, Brazil) (En).gg
f0f7e4dfe2908f0030e64fd9ed843422
D23A2A93