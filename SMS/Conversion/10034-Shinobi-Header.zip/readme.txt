Use with:

Shinobi (USA, Europe).sms (No Intro)
3dd2c025185e19ac9bf1ed16b695c629