GoodSMS Equivalent: Alex Kidd in Miracle World (UEB) (V1.1) [T+Bra_CBT].sms
Base ROM: Alex Kidd in Miracle World (USA, Europe, Brazil) (Rev 1).sms (No Intro)
RA Checksum: ba4e6991da1b864b24089e2ea642cce6
CRC32 Checksum: 8938B5C8