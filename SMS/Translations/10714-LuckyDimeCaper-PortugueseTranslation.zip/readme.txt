Use with:

Lucky Dime Caper Starring Donald Duck, The (Europe, Brazil).sms (No Intro)
653f10042a5ee5854ccf971456641a4d