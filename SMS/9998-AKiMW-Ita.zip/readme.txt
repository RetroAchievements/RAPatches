GoodSMS Equivalent: Alex Kidd in Miracle World (UEB) (V1.1) [T+Ita1.0].sms
Base ROM: Alex Kidd in Miracle World (USA, Europe, Brazil) (Rev 1).sms (No Intro)
RA Checksum: e53f30ba87d1efeb8c5652e2d29737cb
CRC32 Checksum: 5BCD77ED
