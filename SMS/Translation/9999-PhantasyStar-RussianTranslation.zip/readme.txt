Use with:

Phantasy Star (USA, Europe) (Rev 1).sms (No Intro)
1110938df80f4e44c8213d7f85cfb5e6