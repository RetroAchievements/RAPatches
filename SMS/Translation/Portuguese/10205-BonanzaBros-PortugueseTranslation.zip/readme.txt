Use with:

(No Intro)
File:               Bonanza Bros. (Europe, Brazil).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              CAEA8002
MD5:                E58F6F374B3405FD2A5E5B80E639A980