Use with:

R-Type (World).sms (No Intro)
9e5507d51ac6f24c702a52a7abce0d3c