Use with:

Ayrton Senna's Super Monaco GP II (Europe, Brazil).sms (No Intro)
04abc524a3b7f7e2e96eb910490e77ec