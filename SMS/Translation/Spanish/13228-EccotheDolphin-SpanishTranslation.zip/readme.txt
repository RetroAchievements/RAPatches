Use with:

(No Intro)
File:               Ecco The Dolphin (Europe, Brazil) (En).sms
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              6687FAB9
MD5:                BEA00F9B73AC248BAFA7E406A5489B32
SHA1:               3BFDEF48F27F2E53E2C31CB9626606A1541889DD
SHA256:             577A4E14B5A15F0D9F0C0140F5E8DB5A7A06595570F3F4075229F0598C9A0869