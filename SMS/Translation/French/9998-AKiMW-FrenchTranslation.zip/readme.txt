GoodSMS Equivalent: Alex Kidd in Miracle World (UEB) (V1.1) [T+Fre].sms
Base ROM: Alex Kidd in Miracle World (USA, Europe, Brazil) (Rev 1).sms (No Intro)
RA Checksum: f69a7b54835381e7a91333c4d78a51f2
CRC32 Checksum: 944BED08