Use with:

Cyborg Hunter (USA, Europe, Brazil).sms (No Intro)
ac90d79743cac1afcd7049f7b4e73bc4