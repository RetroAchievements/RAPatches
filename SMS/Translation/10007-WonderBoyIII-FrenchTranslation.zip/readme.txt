Use with:

Wonder Boy III - The Dragon's Trap (USA, Europe).sms (No Intro)
e7f86c049e4bd8b26844ff62bd067d57