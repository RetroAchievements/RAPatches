Use with:

(No Intro)
File:               Ys - The Vanished Omens (USA, Europe, Brazil) (En).sms
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              B33E2827
MD5:                77D2FF054429F7970134E67800539A78