QUEST #010: It Takes Two
Goal: Develop two sets for games with another developer
Point of Contact: @SlashTangent#3722 & @SnowPin#2659 
1. Set must have a fair share of the work done by each dev - Sets like Animal Crossing DS would not be approved.
2. Must be a full set covering every aspect of the game
3. Set must contain at least 40 achievements
4. Achievements must make sense, no fluff to fulfill requirement. 
5. Must Follow Dev CoC as per usual.

DevQuest 11 - Happy Birthday RA!
On November 2nd, 2012 RAs first achievement was made
http://retroachievements.org/achievement/1
To celebrate this we are asking developers to make A Genesis set (no 32x, no CD, no Prototypes).
This quest is available year round



"A place for people who do actual work for RA to share their knowledge, thoughts, opinions, ask for help, etc."

"A place for people who are responsible for maintaining various aspects of RA.org to share their knowledge, thoughts, opinions, ask for help, etc."