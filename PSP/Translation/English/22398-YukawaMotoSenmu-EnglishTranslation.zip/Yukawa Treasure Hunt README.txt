###################################################################
Former Managing Director Yukawa's Treasure Hunt (April 2022)
###################################################################

## Intro ##
Former Managing Director Hidekazu Yukawa has lost his promotional Dreamcast
material that he can't possibly show to the public! It's up to you, unnamed
Sega fan, to help him and search for his missing items! For some unknown
reason, they've been split into six parts each, so here's a shovel and
good luck!!

Yukawa's Treasure Hunt was a promotional game near the Dreamcast's launch
where players who solved a weekly puzzle between March 20th, 1999 and
April 11th, 1999 could submit their victory online and be entered into a
raffle. That raffle has long ended, so the servers do not work, but the
game itself stands as an interesting piece of history.

## Translation Status ##
The game is 95% complete, including the VMU minigame. There are a few images
that are compressed and still need to be translated. To assist the player,
here are the menu options written out:

Main menu:
スタート   - Start
オプション - Option

Dialogue boxes:
次　へ - Next
は　い - Yes
いいえ - No
戻　る - Return

In game:
アクションポイント - Action Points


## Installation ##
This patch utilizes the Universal Dreamcast Patcher, which has been included in this distribution.
For more information on the patcher, view its README here:
https://github.com/DerekPascarella/UniversalDreamcastPatcher/blob/main/README.md

# Two Options for Play #
- "Yukawa Treasure Hunt English 1.0.dcp" will get you your regular puzzle-hunting
adventure, where you can download the VMU game to rack up points to spent for more
digging opportunities! Be as hard working as Yukawa!

- "Yukawa Treasure Hunt English 1.0 - Max VMU Score.dcp" instead comes with VMU game containing
a high score of 999, allowing you to copy the VMU game to your own card, then start digging
with 999 extra digs! Need a refill of points? Just redownload the VMU game and
get back out there! Yukawa's not sleeping in his bed if you don't find his keys!

# Instructions #
1. Inside the patcher folder, run "Universal Dreamcast Patcher.exe."
2. Click "Select GDI or CUE" and select your GDI image.
3. Click "Select Patch" then select either "Yukawa Treasure Hunt English 1.0.dcp" 
   or "Yukawa Treasure Hunt English 1.0 - Max VMU Score.dcp."
4. Click "Apply Patch."


## Tips ##
- You can earn more action points to dig with by playing the VMU mini game. Install it
  from the menu, then aim for the high score! Alternatively, install the Max VMU Score
  patch and get infinite points.
- If you use a time machine, you might win the contest!


## Credits ##
SnowyAria - Translation, game hacking
EsperKnight, Mr. Nobody - Game hacking


## Special Thanks ##
Derek Pascarella (ateam)


## Contact ##
Have any issues or run into any problems? Feel free to drop by our discord here:
*  https://discord.gg/bewGNtm

Alternatively, you can message ArcaneAria/SnowyAria on ROMhacking.net or on Twitter at @SnowyAria.