Planetarian ~ the dream of a little star ~
------------------------------------------

by ShinjiGR - ver. 1.0


This patch was made for the Japanese retail version of the game.
It works on all versions (Original release, The Best release, Tsunami Charity Edition).


Instructions
------------
1. Unpack the archive to a directory.
2. Copy the ISO of the game to the same directory and rename it to Planetarian.iso
3. Run the file "PlanetarianPSP English patch.bat"

Enjoy!