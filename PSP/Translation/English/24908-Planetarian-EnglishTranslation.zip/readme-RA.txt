Use with:

(Redump)
File:               Planetarian - Chiisa na Hoshi no Yume (Japan) (v1.00).iso
Size (Bytes):       283213824
CRC32:              BFC444A2
MD5:                756A33A6AF9B9583A1B4A7C337B05BD3