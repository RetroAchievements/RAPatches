Use with:

(No-Intro)
File:               AIR (Japan) (v1.02).iso
Size (Bytes):       1615888384
CRC32:              3D7534DA
MD5:                25F033D837C3F84748B96097B8B24895