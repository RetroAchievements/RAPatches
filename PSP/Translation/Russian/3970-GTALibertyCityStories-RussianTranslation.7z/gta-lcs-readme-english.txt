Use UMDGen to open the following:

Grand Theft Auto - Liberty City Stories (Europe) (En,Fr,De,Es,It) (v3.00).iso
cf40e781475451db431769f9ea0f7998
7A884C02

Replace the EBOOT.BIN with the one included here.