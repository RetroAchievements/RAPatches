Use with:

(Redump)
Mega Man - Powered Up (USA).iso
rahash: ae507a7581de48891cd379f6cadf2f52 
md5: 2cf4a43e8f01505645dcc2d3c60a03cb
crc: 4C24E683