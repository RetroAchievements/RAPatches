Use with:

(Redump)
filename: Little Busters - Converted Edition (Japan) (Disc 2).iso
md5: 36bf276dee1fbe8a100c68b008814e05
crc: 36539437