Use with:

(Redump)
Tekken - Dark Resurrection (USA).iso
3236024a1c151f9d5a3b23ede2fd63f6
3FFD7A9D