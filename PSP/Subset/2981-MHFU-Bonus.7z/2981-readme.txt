Use with:

(Redump) http://redump.org/disc/19303/
Monster Hunter Freedom Unite (Europe) (En,Fr,De,Es,It).iso
RA Checksum: 294a4c5028d20fa3f93b2593626235a8
MD5: 7b86d726aebdb6fc8b57e2d6678ca3ac
CRC32: 32627baa

For convenience, both bps and xdelta patches are included. Both are identical, use whichever is easier. Note that the bps patch may require a 64-bit version of Floating IPS (flips) to apply, available from the RAPatches github repo.
