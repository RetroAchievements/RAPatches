----------------------------
--   Underground Monster  -- 
--    Complete English    --
--       Translation      --
----------------------------

Underground Monster.d88
SHA-1: 0AC90C7406557E1C864183F48D015C9358221800
SHA-256: 3AAB5F828F3F4E125F35282C876AB61FBDE6BC0B71D319B61293C54AB1688B1F
MD-5: 79105C4E535EE0959435F455C52589EE

Apply with DeltaPatcher.

NOTE: All text should be translated, but if you find
anything untranslated, contact @UmbrellaTerms on Twitter.

How to run:
This is a PC-8001 game, but it can run on the PC-8801.
You will need to run the game in N Mode.

Historical Context:
It was one of the winning entries in Enix's 1st Game
Hobby Program Contest. It was published by Enix for the
PC-8001 in February of 1983. It was developed by
Osamu Hasegawa.

Translation of back of the box text:
Back of the box text:
You are an underground explorer. It’s said that there
are monsters that randomly drop treasure in the depths
of the earth. To get all that treasure for yourself,
you climb those cliffs with no regard for the risks.
You will find treasure. “Wah! Below is a steep drop
and a monster is right behind you! Get away!”

Creator: Osamu Hasegawa

Born 1965, from Hyogo Prefecture. Currently living in
Hyogo Prefecture. The National Institute of
Technology (NIT), Akashi College. 2 years of experience
with microcomputers. Hobby: Table Tennis. This game was
made by taking advantage of the machine’s capabilities
to the fullest extent, with consideration to beautiful
graphics and the game’s story. It’s really interesting.
Please try it out.
