Galactic Wars I
Copyright Nihon Falcom 1982
Platform: NEC PC-8801

Galactic Wars I English Patch
Release Date: January 27, 2024
Version: 1.0
Translation: Shawnji
Programming: Ribose & TWE
Testing & Feedback: Ribose, TWE, SlyGamer64, AnonymusAxolotl
Art Correction and Design: Sorcerian

1. Patch the original .d88 file with this .xdelta file.
2. Open the .d88 file in Disk Drive 1 in your PC-8801 emulator of choice. Use V1(H) mode at 4MHz.
   (Using S-mode will prevent the game's results screen from displaying correctly.)
3. Use the emulator's "Reset" feature (do not close the emulator).
4. On reset, the game should begin to autoload.

Enjoy!