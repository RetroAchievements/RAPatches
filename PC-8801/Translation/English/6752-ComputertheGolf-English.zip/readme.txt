Use with:

Computer the Golf.t88
4de4a94d501d8b9a001c3f61d8c57493
A149466D

Computer the Golf
Copyright Nihon Falcom 1983
Dumped by Shawnji

1. Open the .t88 file as a cassette in your PC-8801 emulator of choice.*
2. Type the following:
   MON
3. Press Enter.
4. Type "R".
5. Press Enter again.

Enjoy!

*I've had the best experience running in V1(S) mode. In V1(H) mode it wouldn't show the scorecard for some reason. 