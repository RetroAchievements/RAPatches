Use with:

(Neo Kobe)
Horror House {V1 mode, MON R, press S}.t88
cc74cd971562a5ef869823428b4c9dd9
8A6100A2