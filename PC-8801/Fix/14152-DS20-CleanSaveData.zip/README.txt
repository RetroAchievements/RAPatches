Current available dumps for Dragon Slayer Level 2.0 include existing save data. These patches "clean" dirty disk copies, not by restoring the original contents of the disk (which are unknown), but by changing the save contents to match a new game's.

The replacement save data was generated as follows:
1. Begin a new game on Phase 1
2. While the game starts, hack in one magic potion and a lot of experience in order to unlock the Save magic
3. Open the magic menu on the very first turn
4. Save
5. Remove the excess experience from the saved disk using a hex editor

Patches are available for the two known existing dumps of the game: Neo Kobe (most likely the one you want), and EGG data (for which the source D88 image must be generated using egg2d88 from a paid digital copy of the game).
