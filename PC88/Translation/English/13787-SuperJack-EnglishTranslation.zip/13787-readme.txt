Use with:

(Neo Kobe)
Super Jack [Set 2].d88
d2aff22e02df81eea501e13d75a3da28
2165121C
