Use with:

Genesis [Set 1].d88 (No-Intro)
f968098a13aa41884916e99f081f4a6d
4589218D
