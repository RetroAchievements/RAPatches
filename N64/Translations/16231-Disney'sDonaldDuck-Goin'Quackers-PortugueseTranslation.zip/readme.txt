Use with:

Donald Duck - Goin' Quackers (USA) (En,Fr,De,Es,It).z64 (No Intro)
0e0e920ab13ef13508f5a98cc4cd2ff8