Use with:

Super Smash Bros. (USA).z64 (No Intro)
f7c52568a31aadf26e14dc2b6416b2ed