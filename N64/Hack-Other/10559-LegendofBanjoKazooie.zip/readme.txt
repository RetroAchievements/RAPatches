Use with:

No Intro
Banjo-Kazooie (USA).z64
b29599651a13f681c9923d69354bf4a3
AD429961