Use with:

(No Intro)
Quest 64 (USA).z64
ea552e33973468233a0712c251abdb6b
D75B45C6