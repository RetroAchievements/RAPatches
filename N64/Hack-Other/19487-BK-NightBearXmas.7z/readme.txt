Use with:

(No Intro)
File:               Banjo-Kazooie (USA).z64
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              AD429961
MD5:                B29599651A13F681C9923D69354BF4A3