Use with:

1080 TenEighty Snowboarding (Japan, USA) (En,Ja).z64 (No Intro)
fa27089c425dbab99f19245c5c997613