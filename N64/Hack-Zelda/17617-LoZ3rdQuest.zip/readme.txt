Use with:

ZELOOTMA.Z64
ROM Checksum: 230f62c994ff072a1434df6e65e2dbe0
CRC32 Checksum: 081E2B91

