Use with:

Legend of Zelda, The - Majora's Mask (USA).z64 (No-Intro)
2a0a8acb61538235bc1094d297fb6556
B428D8A7
