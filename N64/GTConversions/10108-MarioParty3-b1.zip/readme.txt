Use with:

Mario Party 3 (USA).z64 (No Intro)
76a8bbc81bc2060ec99c9645867237cc