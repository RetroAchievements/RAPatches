Use with:

(No Intro)
File:               Banjo-Kazooie (Europe) (En,Fr,De).z64
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              525899C9
MD5:                06A43BACF5C0687F596DF9B018CA6D7F

File:               Banjo-Kazooie (USA).z64
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              AD429961
MD5:                B29599651A13F681C9923D69354BF4A3