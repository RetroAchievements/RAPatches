Use with:

(No Intro)
Kirby 64 - The Crystal Shards (USA).z64
md5: d33e4254336383a17ff4728360562ada
crc: 20A1C120

(ByteSwapped)
Kirby 64 - The Crystal Shards (USA).v64
md5: 968a49ea33d35c94a393a770a8117aa3
crc: 8EB3565B