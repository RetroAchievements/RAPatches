Use with:

(No Intro)
File:               Mario Story (Japan).z64
BitSize:            320 Mbit
Size (Bytes):       41943040
CRC32:              BD60CA66
MD5:                DF54F17FB84FB5B5BCF6AA9AF65B0942
SHA1:               B9CCA3FF260B9FF427D981626B82F96DE73586D3
SHA256:             A62C669817F87FBA067248962F6737D9A8D27E78A843798D739D9D2A39D73874
-------------------------------------------------------------------

File:               Paper Mario (Europe) (En,Fr,De,Es).z64
BitSize:            384 Mbit
Size (Bytes):       50331648
CRC32:              9FC00CE3
MD5:                3B5C99F5E7DBA06BF8237E58F6D4196B
SHA1:               1273275142B79F7443F55BD35679A19670ADFE3A
SHA256:             5540CCD817201A3F5174295DDE7FCE7E2A6F79F081209A4B6B7EEC7D9C4B88E4
-------------------------------------------------------------------

File:               Paper Mario (USA).z64
BitSize:            320 Mbit
Size (Bytes):       41943040
CRC32:              A7F5CD7E
MD5:                A722F8161FF489943191330BF8416496
SHA1:               3837F44CDA784B466C9A2D99DF70D77C322B97A0
SHA256:             9EC6D2A5C2FCA81AB86312328779FD042B5F3B920BF65DF9F6B87B376883CB5B
-------------------------------------------------------------------