Use with:

No Intro
Star Fox 64 (USA).z64
caf9a78db13ee00002ff63a3c0c5eabb
B1FCAA9C