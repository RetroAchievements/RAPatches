Use with:

No Intro
Legend of Zelda, The - Ocarina of Time (USA).v64
6697768a7a7df2dd27a692a2638ea90b
EC95702D