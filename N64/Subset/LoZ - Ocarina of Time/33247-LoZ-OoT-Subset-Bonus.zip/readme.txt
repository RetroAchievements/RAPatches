Use with:

(No Intro)
File:               Zelda no Densetsu - Toki no Ocarina (Japan) (Rev 2).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              2B2721BA
MD5:                2258052847BDD056C8406A9EF6427F13
SHA1:               FA5F5942B27480D60243C2D52C0E93E26B9E6B86
SHA256:             10833EE97CDFA1BB9B248839946992B86EC60342846682AECA06049ADB5365E5