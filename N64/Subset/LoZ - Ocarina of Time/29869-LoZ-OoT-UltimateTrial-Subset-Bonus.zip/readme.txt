Use with:

(No Intro)
File:               Legend of Zelda, The - Ocarina of Time (USA).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              CD16C529
MD5:                5BD1FE107BF8106B2AB6650ABECD54D6
SHA1:               AD69C91157F6705E8AB06C79FE08AAD47BB57BA7
SHA256:             C916AB315FBE82A22169BFF13D6B866E9FDDC907461EB6B0A227B82ACDF5B506

(No Intro + RAPatches)
File:               Legend of Zelda, The - Ocarina of Time - Ultimate Trial (v1.0.1) (RichieUltimate).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              3CB17018
MD5:                1C93B84AFFA9E3B8BE2B2B500000BE1E
SHA1:               DDE622DCD75E772E1B068837A1380CD8946BEF18
SHA256:             0E37238A512DCF4892B1BF5CFD83028FF6936C0AFC11E9A19A9695B21C89AB8B