Use with:

(No Intro)
Conker's Bad Fur Day (Europe).z64
05194d49c14e52055df72a54d40791e1
4667CFE9


(No Intro - ByteSwapped)
Conker's Bad Fur Day (Europe).v64
e31ded9c7887ebc07a343b8865a2bf55
96DBA949
