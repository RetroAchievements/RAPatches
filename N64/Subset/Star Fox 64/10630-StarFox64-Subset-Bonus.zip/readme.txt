Use with:

(No Intro)
Star Fox 64 (USA).z64
caf9a78db13ee00002ff63a3c0c5eabb
B1FCAA9C

(No Intro) [ByteSwapped]
Star Fox 64 (USA).v64
fecdcbbcd1a178a2f4b29b43facf9f39
363E7EE8