Use with:

No Intro
Super Smash Bros. (USA).z64
f7c52568a31aadf26e14dc2b6416b2ed
EB97929E