Use with:

Donkey Kong 64 (USA).z64 (No-Intro)
9ec41abf2519fc386cadd0731f6e868c
D44B4FC6
