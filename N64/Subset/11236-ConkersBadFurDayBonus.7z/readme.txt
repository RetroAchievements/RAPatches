Use ~Bonus~ Conker's Bad Fur Day (Europe).bps with:

Conker's Bad Fur Day (Europe).z64 (No-Intro)
Conker's Bad Fur Day (2001)(Rare - THQ)(EU)(en).bin (TOSEC)
05194d49c14e52055df72a54d40791e1
4667CFE9


Use ~Bonus~ Conker's Bad Fur Day (Europe) (ByteSwapped).bps with:

Conker's Bad Fur Day (Europe).v64 (No-Intro)
conker's bad fur day (europe).bin (MAME)
e31ded9c7887ebc07a343b8865a2bf55
96DBA949
