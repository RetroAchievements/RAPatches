Use with:

(No Intro)
Glover (USA).z64
87aa5740dff79291ee97832da1f86205
F874571C

(No Intro - ByteSwapped)
Glover (USA).v64
a43f68079c8fff2920137585b39fc73e
D024893A