Use with:

(No Intro)
File:               New Tetris, The (USA).z64
BitSize:            96 Mbit
Size (Bytes):       12582912
CRC32:              528A07FA
MD5:                7A28179B00734C9AA0F0609FAFAAFD5F