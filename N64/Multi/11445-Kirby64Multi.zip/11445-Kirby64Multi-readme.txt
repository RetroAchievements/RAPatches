Use with:

kirby 64 - the crystal shards (usa).bin (MameSL) /(Byteswapped No-Intro)
968a49ea33d35c94a393a770a8117aa3
8EB3565B
