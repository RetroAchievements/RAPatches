Use with:

banjo-tooie (usa).bin (MameSL) / (ByteSwapped No-Intro)
ca0df738ae6a16bfb4b46d3860c159d9
0E0DC5A5
