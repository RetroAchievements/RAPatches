Use with:

(No Intro)
File:               Legend of Zelda, The - Ocarina of Time (Europe) (Beta) (2003-02-21) (GameCube) (Debug).z64
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              5D1B2996
MD5:                3C10B67A76616AE2C162DEF7528724CF
SHA1:               CEE6BC3C2A634B41728F2AF8DA54D9BF8CC14099
SHA256:             94BDEB4AB906DB112078A902F4477E9712C4FE803C4EFB98C7B97C3F950305AB