Use with:

(No Intro) (Patch in Rev 0 Folder)
File:               SpaceStation Silicon Valley (USA).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              A606E8AE
MD5:                868B37D1B66D1D994E2BAD4E218BF129
SHA1:               E5E09205AA743A9E5043A42DF72ADC379C746B0B
SHA256:             B125BF0D761547BA878E44EF83F9E1EC3F400DA7C46CF9A404B6CAEE6F9BA473

OR

(No Intro) (Patch in Rev 1 Folder)
File:               SpaceStation Silicon Valley (USA) (Rev 1).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              E32D9E7B
MD5:                F1F1C5E2B895DB63348BC738C0CDC645
SHA1:               C968BBA6A90DB9ECBD957E910684A80726B0497D
SHA256:             EA3EA86E4012E878151BFDAA519AFE5EEE6F9388EC1CC2AE26BAF0048F0A9ABC