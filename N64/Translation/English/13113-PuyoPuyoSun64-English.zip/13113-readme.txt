Use with:

(No Intro)
Puyo Puyo Sun 64 (Japan).z64
faaa2094b04dca4c287af9334d22529d
355FF9DE