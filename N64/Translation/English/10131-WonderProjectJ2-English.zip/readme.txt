Use with:

(No Intro)
File:               Wonder Project J2 - Koruro no Mori no Jozet (Japan).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              5E8FC436
MD5:                0FF1F8628D8FE69582DB54572D2BEA79
SHA1:               3A311EC0D77D4E0FC425A99CB6B9416F072E268E
SHA256:             8BBDA06B90CA6CBB897286B05D6BBC3D87464AF6A14C3641EC84D2B25610A3AA