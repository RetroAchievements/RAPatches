Use with:

(No Intro)
File:               Tsumi to Batsu - Hoshi no Keishousha (Japan).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              CA2E5E49
MD5:                A0657BC99E169153FD46AECCFDE748F3