Base:
No-Intro
Chameleon Twist (Japan).z64
CRC-32: 6395c475

Intructions:
Apply the Chameleon Twist (Japan) (En) (v1.0) (Zoinkity).bps patch to Chameleon Twist (Japan).z64 with the Flips program.