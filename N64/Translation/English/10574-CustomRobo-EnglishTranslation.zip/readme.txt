Use with:

Custom Robo (Japan).z64 (No Intro)
a06d2e83cf2628915e8847f609474661