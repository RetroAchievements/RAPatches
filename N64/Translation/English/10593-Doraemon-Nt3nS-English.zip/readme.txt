Use with:

(No Intro)
File:               Doraemon - Nobita to 3tsu no Seireiseki (Japan).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              154E8B33
MD5:                C2166455E94E89E9E3AB612B4377C443
SHA1:               BBEB7B7A92A68B17CA72DCB9D7FB16F7B771C4F6
SHA256:             3A8C50FD245158CFD37BF6FFFD496ABD7C68B185E4DC2D901C7CC492659D38CC