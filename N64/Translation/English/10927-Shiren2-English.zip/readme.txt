Use with:

(No Intro)
File:               Fushigi no Dungeon - Fuurai no Shiren 2 - Oni Shuurai! Shiren Jou! (Japan).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              2AA6D2A1
MD5:                BBCDE4966BEE5602A80D9B8C1011DFA6
SHA1:               F97B070A1FA6AB3D190B36D6B68A2EF182D35233
SHA256:             4073A9F6516EF5D15CDD8B259A952A7D07633A2815F2A738FB5D98415D30A458