Use with:

Paper Mario (USA).z64 (No Intro)
a722f8161ff489943191330bf8416496