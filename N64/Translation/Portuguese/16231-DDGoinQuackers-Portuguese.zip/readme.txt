Use with:

(No Intro)
File:               Donald Duck - Goin' Quackers (USA) (En,Fr,De,Es,It).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              0075D32B
MD5:                56BCDFC8F0B41BF60E6A54BC60144251
SHA1:               F992A60C6E28BA818900E008FAAB01739715AE74
SHA256:             16948956781B76C13206444A14549ADFAA39F4FE9242C6014A9A0AE024FCBE54