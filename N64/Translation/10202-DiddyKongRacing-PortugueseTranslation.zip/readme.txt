Use with:

Diddy Kong Racing (USA) (En,Fr).z64 (No Intro)
4f0e07f0eeac7e5d7ce3a75461888d03