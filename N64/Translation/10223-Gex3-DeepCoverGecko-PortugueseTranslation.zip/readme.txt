Use with:

Gex 3 - Deep Cover Gecko (Europe) (En,Es,It).z64 (No Intro)
9f0492a34d7a2d7c4e9f29dc1848a04a