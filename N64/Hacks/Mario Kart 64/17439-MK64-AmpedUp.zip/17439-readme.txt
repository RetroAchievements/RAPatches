Use with:

Mario Kart 64 (USA).z64 (No-Intro)
3a67d9986f54eb282924fca4cd5f6dff
434389C1
