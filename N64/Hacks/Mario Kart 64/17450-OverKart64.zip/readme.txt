Use with:

(No Intro)
File:               Mario Kart 64 (USA).z64
BitSize:            96 Mbit
Size (Bytes):       12582912
CRC32:              434389C1
MD5:                3A67D9986F54EB282924FCA4CD5F6DFF