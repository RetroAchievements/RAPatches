Use with:

(No Intro)
File:               Super Smash Bros. (USA).z64
BitSize:            128 Mbit
Size (Bytes):       16777216
CRC32:              EB97929E
MD5:                F7C52568A31AADF26E14DC2B6416B2ED