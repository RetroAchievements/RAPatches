Use with:

Pokemon Snap (USA).z64 (No-Intro)
fc3c9329b7cdd67cf7650abf63b9a580
86A69756
