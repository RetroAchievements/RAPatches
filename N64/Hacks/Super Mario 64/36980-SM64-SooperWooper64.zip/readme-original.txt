This hack was made for the 2nd MarioJams competition, and the theme was Evolution.
When this was submitted to the competition it had numerous issues, but most of them have been fixed in this version.
Due to the nature of the competition, I was only allowed to make changes that fixed the crashing issues, and not to the actual game aspects.
As such, the text in the hub world that says you have to avoid enemies is incorrect.

#################################################################################################################

Hack made by Mishu
This hack was tested on project64 using the glideN64 plugin, but will still work on parallel or mupen.

Big thanks to Axollyon, Anonymous Moose, Pyro Jay, Reonu, Matt, and Pilz for helping
with troubleshooting and stuff.

#################################################################################################################

Model credits:

All custom models are from Pokemon Stadium 2.

Geodude
ripped/uploaded by lemurboy12, Ploaj: https://www.models-resource.com/nintendo_64/pokemonstadium2/model/30896/

Haunter
ripped/uploaded by lemurboy12, Ploaj: https://www.models-resource.com/nintendo_64/pokemonstadium2/model/30901/

Cleffa
ripped/uploaded by lemurboy12: https://www.models-resource.com/nintendo_64/pokemonstadium2/model/4957/

Hoppip
ripped/uploaded by lemurboy12, Ploaj: https://www.models-resource.com/nintendo_64/pokemonstadium2/model/30904/

Wooper
ripped/uploaded by lemurboy12: https://www.models-resource.com/nintendo_64/pokemonstadium2/model/40241/

#################################################################################################################

Song credits:

Alec's Log House - Mother 3
midi by Cyber Buddha: http://vgmusic.com/file/902c27d229ff91a03d21c764247d0b2e.html

Eterna Forest - Pokemon Diamond/Pearl
this midi is actually ripped straight from the game, found in this midi pack: https://www.mediafire.com/file/mc7kld0b3uv67ic/pkmn_nds_midis%25282%2529.zip/file

Battle at the Big Bridge - Final Fantasy V
(AKA Battle with Gilgamesh)
vgmusic doesn't say who made the midi, but here you go: http://vgmusic.com/file/f7ab0e592d5093491d2e53493820f502.html

Sound effects from Pokemon FireRed/LeafGreen
ripped/uploaded by iteachvader: https://www.sounds-resource.com/game_boy_advance/pokemonfireredleafgreen/sound/4204/
