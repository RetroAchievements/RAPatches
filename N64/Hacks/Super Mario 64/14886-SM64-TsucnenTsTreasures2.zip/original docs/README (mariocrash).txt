This hack is made by TsucnenT. Features 3 custom levels and 17 stars in total.

Practice a lot before you play it, since it commonly requires platform jumping skills and accuracy. 

Enjoy!

Credit to Magikilo for handing me the ROM and preparing the patch.

- Mariocrash
