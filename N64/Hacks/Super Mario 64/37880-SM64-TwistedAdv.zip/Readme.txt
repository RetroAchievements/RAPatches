SUPER MARIO 64 - TWISTED ADVENTURES v2.2

Original hack by SomeRussianMarioDude
Edited and updated by LinCrash

Back in 2016, I've released my second fixed warps edition on Twisted Adventures, and then 
realized how sloppy and unsatisfying it was. Now in 2024, I return again with a Take 2, 
thanks to the newfangled ASM tweaks.

---

Special thanks to FrostyZako for providing the individual non-stop star hex code!

Credits to those people below making the possible:

- aglab2 for the boundary softlock killer & parallel cam
- Cheezepin for the individual non-stop star source
- ZenonX for the anti-toxic gas camera function 
- pieordie/sm64pie for the main inspiration getting me do these fixed warps in the first place since.