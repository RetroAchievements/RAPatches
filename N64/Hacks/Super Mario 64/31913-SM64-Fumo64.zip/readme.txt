Use with:

(No-Intro)
File:               Super Mario 64 (USA).z64
Size (Bytes):       8388608
CRC32:              3ce60709
MD5:                20b854b239203baf6c961b850a4a51a2
SHA1:               9bef1128717f958171a4afac3ed78ee2bb4e86ce