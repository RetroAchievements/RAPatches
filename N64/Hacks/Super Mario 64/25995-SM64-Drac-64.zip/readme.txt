Use with:

(No Intro)
File:               Super Mario 64 (U) [!].z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              3CE60709
MD5:                20B854B239203BAF6C961B850A4A51A2