This hack is made by TsucnenT. Contains 16 stars and 3 custom levels and the difficulty is beyond 
extreme so be very skilled with your jumping!

Hint: To beat the game, you must collect all 15 stars.


Thanks to Magikilo for handing me the ROM and thanks to TsucnenT for making this fun and insane hack.

- Mariocrash