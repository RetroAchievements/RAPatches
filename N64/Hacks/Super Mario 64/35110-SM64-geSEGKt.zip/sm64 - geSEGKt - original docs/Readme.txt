SR0 The Origins (StarRevenge Beta) - Hack made by BroDute.

Since early 2012, I knew BroDute while he entered the hacking scenes, and during the making of a pre-SR1, this hack revolves stages in its very early years and the whole StarRevenge series. I am the only one who had a hold of it as no one ever got word or played it after the actual SR1 was out.

In conclusion, think of it being part of the series and doesn't take place anywhere in the timeline until their remake. Otherwise, enjoy it up for old time's sake to see how Star Revenge has started to being well known.

-----------------------------

The HUB is still unchanged but you can get access to them by the paintings:

Course 1: Green Valley (forseen in SR redone 1.3)
Course 2: Alphabet Athletic (forseen in SR1 and redone 1.3)
Course 3: Shark Bay (forseen in SR2 and SR0.5)
Course 4: Ice Mountain Valley (forseen in SR0.5)
Course 5: Title Screen (SM64 geSEGKt aka BroDute's former name)
Course 6: Oldschool Underground (forseen in SR2 and SR0.5)
Course 8: Desert of Pyramids (forseen in SR0.5)*
Course 12: Lonely Cove (forseen in SR0.5)*
Course 14: Rainbow Star Space (forseen in SR1, redone 1.3 and late redone 2.0)
Course 15: High Sky Palace (forseen in SR2 and SR0.5)*

Wing Cap: Tower of Hope (forseen in SR1, redone 1.3 and late redone 2.0)
Metal Cap: unchanged but accessible in Course 6**
Secret Slide: Brodute's Slide (forseen in SR1, redone 1.3, late redone 2.0 and SR2)
Secret Aquarium: Weegee (forseen in SR1, redone 1.3, redone 2.0 and SR2)

Bowser 1: Bowser's Lava Field (aforementioned in SR0.5?)*
Bowser 2: Bowser's Ice Pyramid (forseen in SR1), accessible past original C9

*has new stars added to make them enjoyable over their counterpart
**vanish and metal cap switches included