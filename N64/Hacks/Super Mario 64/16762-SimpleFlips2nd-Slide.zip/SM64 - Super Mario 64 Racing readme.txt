For info on how to
get the ROM to run,
check out my tutorial (takes 1 minute):
https://www.youtube.com/watch?v=HUzVTZi5ws8