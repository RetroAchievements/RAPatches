Cascade Slide by Dan from GomePlayTV (YouTube channel name: GomePlayTV)


Recommended emulator: Project 64 1.6


Remember to change the memory size to 8MB


...And you're ready to slide!