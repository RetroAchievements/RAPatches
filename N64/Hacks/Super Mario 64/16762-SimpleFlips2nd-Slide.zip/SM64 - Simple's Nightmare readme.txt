Hey simp, I hope you enjoy my hack! But before you play it, I just want to quickly say a few things.

1. This is a single star hack - I'm not sure if other people were making full 7 star levels, so this might end up being short.

2. This is the first actually playable romhack that I've made, so sorry if it's a bit too difficult or unpolished.

3. There's not a lot of text, but please make sure that you read it all.

4. If I do end up getting top 3 (I'm not counting on it lmao) you can give the money to the person below me. Not because I'm generous or anything, but because I don't want to explain this stuff to my parents, and convince them to make a paypal account.

Finally, I'd like to give a huge thanks to Kaze, as well as his discord, the SM64Hacks discord, and your (SimpleFlips') discord, for all the help they've given me.