Casino Bingo Slide by aglab2

This minihack has 1 overworld and 2 slides, one of them is "regular" slide and other one is slide with timer of 35 seconds.

Tools used to make hack:
SM64Editor 2.0.8
seq64
Quad64
HxD
armips
Lemasm
Google Sketchup
Heroes Power Plant

Thanks to sm64expert for minor asm help

Special Thanks to Mariocrash64 and MintyNate for beta-testing hack.
