There is 3 different stars to collect in this map.
retoggle to mario cam after entering a slide or building.

love you simps, big fan. this is my first ever romhack and i had a fun time making it over these 3 weeks.