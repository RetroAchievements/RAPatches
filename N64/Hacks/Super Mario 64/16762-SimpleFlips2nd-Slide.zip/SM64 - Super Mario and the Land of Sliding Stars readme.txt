Creator: Cilletix
Credits: Cheezepin, Kaze Discord
Stars: 11 (2 are just to save the game so 9 gameplay stars)

This is my very first romhack but I did put a lot of effort into it. It
took the whole 3 weeks to learn and finish everything in this.
Let me know if you think you'd like to see a whole game like this?
Thanks for playing! <3