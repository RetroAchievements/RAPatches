Opon starting the ROM you will only have a few
seconds before the stage starts.  Also the level
uses some music that I think fits the level
incredibly well.  For that reason I would appreciate
if you gave it a listen for a minute or two.  That
is if you can survive that long...