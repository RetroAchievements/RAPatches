My name is Abel Rivera, this is the single level slide rom hack for Simpleflips' competition.
I had the idea to make a rom hack since months, its name would be "Super mario 64 Bowser revenge" Idk if that
name is already taken but you get the idea, but I didn't really have time to make that rom hack.
I follow simpleflips since the better idea video, and I really loved the competition with
Nathaniel Bandy as a theme, and when I saw that the new theme will be slide I had to put all I had 
into making this hack, unfortunately I ran out of time and I could'n add all I would want, but I think 
it came out pretty good, I hope to win this competition.
BUP
BUP
BUP
BUP
BUP
BUP
BUP