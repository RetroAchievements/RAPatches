Use with:

(No Intro)
File:               Super Mario 64 (USA).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              3CE60709
MD5:                20B854B239203BAF6C961B850A4A51A2
SHA1:               9BEF1128717F958171A4AFAC3ED78EE2BB4E86CE
SHA256:             17CE077343C6133F8C9F2D6D6D9A4AB62C8CD2AA57C40AEA1F490B4C8BB21D91

-----------------------
For the optimized + Minor Enhancement patch, use the base above or the patched hack:

(No Intro + RAPatches)
File:               SM64 - Shining Stars 3 - Sanctuary of the Star Comet (v2.0) (sm64pie).z64
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              E1752304
MD5:                5428590EE7C3EDB23F7D27D04B0B3E6E
SHA1:               DF11DDF9AD924E3D2A554D13EB0E79F06DF36DF0
SHA256:             7EFE65C40B9CBB82FC234001BB125532DFB5D215CD9842615CDDD1AE71995C56