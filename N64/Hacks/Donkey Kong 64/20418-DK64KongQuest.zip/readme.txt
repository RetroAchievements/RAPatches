Use with:

(No Intro)
File:               Donkey Kong 64 (USA).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              D44B4FC6
MD5:                9EC41ABF2519FC386CADD0731F6E868C