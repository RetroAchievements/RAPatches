Use with:

(No Intro)
File:               Legend of Zelda, The - Ocarina of Time (USA).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              CD16C529
MD5:                5BD1FE107BF8106B2AB6650ABECD54D6
SHA1:               AD69C91157F6705E8AB06C79FE08AAD47BB57BA7
SHA256:             C916AB315FBE82A22169BFF13D6B866E9FDDC907461EB6B0A227B82ACDF5B506