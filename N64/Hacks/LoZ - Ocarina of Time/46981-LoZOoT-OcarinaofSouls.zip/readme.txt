Use with:

(No Intro)
File:               Legend of Zelda, The - Ocarina of Time - Master Quest (Europe) (GameCube) (Debug).z64
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              A1D34E08
MD5:                09AE099051BDF6377D482D1944171DFC
SHA1:               CFECFDC58D650E71A200C81F033DE4E6D617A9F6
SHA256:             DD30B6F31F764E024D5D79D6BF4C27F077A2FF917AE7D5E73F79E8967F64144E