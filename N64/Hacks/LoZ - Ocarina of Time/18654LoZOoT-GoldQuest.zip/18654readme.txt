Use with:

(No Intro)
Legend of Zelda, The - Ocarina of Time (USA) (Rev 2).z64
57a9719ad547c516342e1a15d5c28c3d
32120C23