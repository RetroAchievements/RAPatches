--------------------------------------------
| Thanks for playing The Corrupted Jiggys! |
|          A game by Sorra1-Mods           |
|   https://www.youtube.com/@Sorra1-Mods   |
--------------------------------------------

=== Important:

- I recommend playing this game on emulator (Project64 3.0.1+), also not on console.
  Best is Project64 with the GLideN64 video plugin. Playing on console is possible, but I don�t recommend it because of ugly Z-fighting in the world geometry. Please play on emulator if you can.
  Playing on Project64 3.0.1+ is needed - version 2.3.x crashes the game on entering World 3 or talking with Moneybag.

- When you see your first and second "gruntycoin", please don�t collect them while a dialog is running.
  It won't show you the "gruntycoin" dialog. Wait until the current dialog is over, and then collect it. This is only relevant for the first and second gruntycoin you collect.


=== Collecting items

- I recommend trying to collect as many items as possible in your first playthrough. The game is made such that reaching the endboss requires collecting most items in the game. Only around 20 notes and 4 jiggys are what you can skip across the 9 worlds.
  If you also wish to see the secret world at the end, all jiggys and gruntycoins in the game are required.

- There are a total of 97 jiggys (not 100) and 910 notes
- World 5 and World 7 only have 9 jiggys.
- World 4 and World 9 don't have Witch Switches. 
- Instead of the Witch Switch in World 9, a jiggy is placed on the world entrance of World 9.


=== Issues when pressing certain switches

- When a Witch Switch has no collision (which can happen although quite rarely), please continue to play the world normally otherwise. When you've collected everything you need in the world, leave it and go in again to press it.
  While this should help, it might rarely not. When it doesn't, please come back later and try it again. 
  If that also doesn't help, unfortunately I can't do much about it - the issue only happened once across many tests, and I can't reproduce it consistently. Hopefully it doesn't happen again.

- For the switch that spawns the Graveyard's jiggy podium, coming from World 5 (the Gold Mine):
  1. If nothing happens when you press the switch in the hub to spawn the Graveyard jiggy podium, please reload the game. Not a save state / quicksave, but a normal in-game save & load like in the original game.
  2. If the cutscene works but you go to the next room/map (the graveyard with the puzzle for the graveyard) and the podium is missing, please leave the room and reload the game. Not a save state / quicksave, but a normal in-game save & load like in the original game.


=== Other issues

- It can happen (though rarely) that the game freezes. It's really rare but it can happen and I don't quite know why. 
  When it happen and you have a save state to load, it probably won't help. The freeze will happen again when it�s the "start menu or dialog" freeze. 
  You will need to load the game normally with an in-game save like a normal game (no quickload / save state). The freeze should not happen anymore.

- The Worker Enemy in the last world has a larger hitbox, due to its custom animation.

- In case it was unclear, if you first saw the credits before collecting all gruntycoins, and then finished collecting the coins afterwards, you'll need to go and watch the credits again before the "special" thing happens in Spiral Mountain.
  If you've already got all the coins the first time you see the credits and warp back to SM, you're all good.

- Once you collect all gruntycoins and have seen the credits, please head straight into the portal without closing the game.
  Otherwise, some issues may occur - when you have entered the portal, you can then save/load the game without problems.

  But if you DID close the game early, here's how to proceed:
    1. You will spawn in Hubbs Village after restart. Don't do anything until you see a cutscene.
    2. Now head back to Spiral Mountain. When you see a strange picture and can't move, save and quit the game again.
    3. Now when you're in Hubbs Village, no cutscene will trigger. You can head back to Spiral Mountain and enter the portal.



========================== SPOILER ============================
| A warning if you void out/die in the final secret world..
|                          -------
| In the secret last world after you collect everything, a game exists where you must find Moneybag five times and attack him.
| When you do this, he runs away and spawns somewhere else. But if you fall into the void in this world, he turns invisible. That�s a bug. 
| To fix it, please leave the world and enter it again. That should fix the problem.
|
| It happens everytime you fall into the void. If you can't find Moneybag, you may have forgotten to re-enter the world after falling out.
| Don�t worry, the orbs don�t reset when you leave the world.
|
| Just in case, here are the 5 places he can be found:
| - Moneybag 1: Inside the house near Orb 1. From the entrance to the world, head to the left.
| - Moneybag 2: Near the time switch for Orb 2.
| - Moneybag 3: Near the house of Orb 7.
| - Moneybag 4: In the house on the last island (on top of Orb 6).
| - Moneybag 5: On the place in front of the tower that spawns when you collect 2 orbs.
|
| When Moneybag isn�t on one of these 5 places, please re-enter the world, and he should be there.
|------------------




