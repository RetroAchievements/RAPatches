Use with:

(No-Intro)
File:               Banjo-Kazooie (USA).z64
Size (Bytes):       16777216
CRC32:              ad429961
MD5:                b29599651a13f681c9923d69354bf4a3
SHA1:               1fe1632098865f639e22c11b9a81ee8f29c75d7a