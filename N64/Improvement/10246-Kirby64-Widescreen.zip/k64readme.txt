Use with:

(No Intro)
File:               Kirby 64 - The Crystal Shards (USA).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              20A1C120
MD5:                D33E4254336383A17FF4728360562ADA