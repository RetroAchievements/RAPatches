Use with:

(No Intro)
Diddy Kong Racing (USA) (En,Fr).z64
4f0e07f0eeac7e5d7ce3a75461888d03
EB759206