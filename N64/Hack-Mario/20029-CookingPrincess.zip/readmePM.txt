Use with:

(No Intro)
Paper Mario (USA).z64
a722f8161ff489943191330bf8416496
A7F5CD7E