Use with:

(No Intro - BigEndian)
Super Mario (USA).z64 
20b854b239203baf6c961b850a4a51a2
3CE60709