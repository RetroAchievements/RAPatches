SM74EE + Parallel Lakitu Cam / Infinite Lives 

Use with:

Super Mario 74 - Extreme Edition (English).z64 (GoodTools)
ee7673685f78ab9a6990b4f36eea1df3
354EFD0C


Super Mario 74 - Extreme Edition (English)

Use with:

Super Mario 64 (USA).z64 (No-Intro)
20b854b239203baf6c961b850a4a51a2
3CE60709