Use with:

(No Intro)
File:               Super Mario 64 (Japan).z64
BitSize:            64 Mbit
Size (Bytes):       8388608
CRC32:              DD801954
MD5:                85D61F5525AF708C9F1E84DCE6DC10E9