Use with:

Mario Party (U) [!].z64 (No-Intro)
8bc2712139fbf0c56c8ea835802c52dc
4D60ABE5
