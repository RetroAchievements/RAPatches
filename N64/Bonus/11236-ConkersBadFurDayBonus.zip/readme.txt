Use with:

No Intro
Conker's Bad Fur Day (Europe).z64
05194d49c14e52055df72a54d40791e1
4667CFE9