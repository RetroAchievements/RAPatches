Use with:

Pyoro64 NTSC.n64 (No-Intro)
2ac0f88bea02d67896ffeae9e8ec72e7
B7EBDDC6
