Use with:

Super Mario 64 (USA) - Analog Camera.z64 (GoodTools)
b09b5785d32acb192d283b07594d3ab7
A9C7A6CF

Super Mario 64 (USA).z64 (No-Intro)
20b854b239203baf6c961b850a4a51a2
3CE60709