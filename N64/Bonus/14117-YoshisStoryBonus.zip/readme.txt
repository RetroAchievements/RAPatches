Use with:

No Intro
Yoshi's Story (USA) (En,Ja).z64
ROM Checksum: 586a092e22604840973b82dfaceac77a
CRC32 Checksum: A1453E0D

No Intro [ByteSwapped]
Yoshi's Story (USA) (En,Ja).v64
ROM Checksum: d3436319d51df291ba71a2e512ddb7b5
CRC32 Checksum: 01A4B1E9

