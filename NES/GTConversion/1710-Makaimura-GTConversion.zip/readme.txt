Use with:

Makaimura (Japan).nes (No Intro)
V14-/V15+ RA Checksum: 9346ebec7fb8c5c61f937ca46a096c69
ROM Checksum: 50341185cae666e292c39192140a6338
CRC32 Checksum: 8C3FE6FB