Use with:

Ikari (Japan).nes (No Intro)
V14-/V15+ RA Checksum: 32fdfb48b1e8cee9dce2aa434d032fb8
ROM Checksum: bbd0ed86c22c00bebb6890046be8fdef
CRC32 Checksum: 68B0CFDCF