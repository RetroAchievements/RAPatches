Use with:

Castlevania III - Dracula's Curse (USA).nes (No Intro)
RA Checksum: bfc4d9791d9fe9c181dad794d66def4f
ROM Checksum: d16a502d0125f23cc3d980ddc6b6f2e8
CRC32 Checksum: 7CC9C669