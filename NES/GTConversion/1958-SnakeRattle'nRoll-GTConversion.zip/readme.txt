Use with:

Snake Rattle n Roll (USA).nes (No Intro)
RA Checksum: 7b8b76e5688c7d21d40fe3692861ce1e
ROM Checksum: 774e0f994c95d59c916c0070f39d430e
CRC32 Checksum: 558F9A33