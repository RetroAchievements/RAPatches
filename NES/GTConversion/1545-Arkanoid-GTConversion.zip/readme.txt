Use with:

Arkanoid (USA).nes (No Intro)
RA Checksum: 0ccc1a2fe5214354c3fd75a6c81550cc
ROM Checksum: 6a2bfa3c6e9b1ce1e21aabd0dfbf2779
CRC32 Checksum: EE93A28C