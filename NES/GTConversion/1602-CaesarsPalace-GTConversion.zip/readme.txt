Use with:

Caesars Palace (USA).nes (No Intro)
V14-/V15+ RA Checksum: 899a8d8a8d05d5809a4e9d948ead32e0
ROM Checksum: 0938264b8a88de8989d83cbf432c174e
CRC32 Checksum: E814D0D1