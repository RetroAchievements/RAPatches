

Use with:

Radia Senki - Reimei Hen (Japan).nes (No-Intro)
f520d2c3cf075a7421efc134ac3dbaee
3BCA1CD7
