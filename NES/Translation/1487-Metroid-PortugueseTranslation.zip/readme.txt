Use with:

Metroid (USA).nes (No Intro)
V14-/V15+ RA Checksum: b2d2d9ed68b3e5e0d29053ea525bd37c
ROM Checksum: d77c8053168da14b360bf5caeccc5964
CRC32 Checksum: A2C89CB9