Use with:

File:               Adventures of Lolo (USA).nes (No-Intro)
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              3D59CDDD
MD5:                C0B0B485D2646C13EF9032D83E725F3E