Use with:

(No Intro)
Bucky O'Hare (Europe).nes
ROM Checksum: b8d5ccc66d440dbf50465fd4f66f6cef
CRC32 Checksum: 18776F36