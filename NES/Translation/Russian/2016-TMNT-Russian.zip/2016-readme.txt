Use with:

(No-Intro)
Teenage Mutant Ninja Turtles (USA).nes
1ae34bcb5f9db9de417a9df5072f4620
120BD608