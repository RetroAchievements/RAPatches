Use with:

(No Intro)
Dizzy the Adventurer (USA) (Aladdin Compact Cartridge) (Unl).nes
0702f827d28226fabe030384bc404061
96DC81C7