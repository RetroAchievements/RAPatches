Use with:

(No Intro)
Gun.Smoke (USA).nes
ROM Checksum: 071cee3611e37dfb58fab341bed5e8c6
CRC32 Checksum: FC48FC3C