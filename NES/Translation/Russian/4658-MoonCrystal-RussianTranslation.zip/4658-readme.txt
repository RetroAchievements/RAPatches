Use with:

(No Intro)
Moon Crystal (Japan).nes
57f95b7133721ff32c5c5aaa10448f14
A5AEE1BF
