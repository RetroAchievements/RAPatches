Use with:

(No Intro)
File:               New Ghostbusters II (Europe).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              C066A82E
MD5:                E92B0A9DBFBDE24CE4FDA229A8893908
Headerless MD5 (RA) 4F544268850F91F13734A044F87038CC