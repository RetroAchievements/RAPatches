Use with:

(No-Intro)
Chip 'n Dale - Rescue Rangers (USA).nes
5b36cb8f2ebaac205b9b72e5c8a80dec
776B5730