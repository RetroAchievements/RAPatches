Use with:

(No Intro)
Isolated Warrior (USA).nes
ROM Checksum: 0b8cee97f6fd1e49900088cf7b0f4454
CRC32 Checksum: D2FD4220