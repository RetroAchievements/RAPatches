Use with:

Amagon (USA).nes (No Intro)
ROM Checksum: eb345e1d637f5280f886202742ad5ee8
CRC32 Checksum: 467A3680