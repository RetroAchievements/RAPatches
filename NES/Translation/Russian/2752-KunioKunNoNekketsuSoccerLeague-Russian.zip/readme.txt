Use with:

(No Intro)
Kunio-kun no Nekketsu Soccer League (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              907D7BCB
MD5:                54947CB5718BA8579E0C3A0A731F60E4