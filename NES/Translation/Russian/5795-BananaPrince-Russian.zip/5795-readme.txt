Use with:

(No Intro)
Bananan Ouji no Daibouken (Japan).nes
88aa384d916a7d513198af250c4e8f48
4C7E9492