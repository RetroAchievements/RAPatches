Use with:

File:               Adventures of Bayou Billy, The (USA).nes (No-Intro)
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              F280923F
MD5:                0D2B6D1A40E4EF6B365B305672804E16