Use with:

Archon (USA).nes (No Intro)
ROM Checksum: 5afa04adf845ae79f910701dab7c92d0
CRC32 Checksum: 57CAFD51