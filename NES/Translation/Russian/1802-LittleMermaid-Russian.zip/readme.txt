Use with:

Little Mermaid, The (USA).nes (No Intro)
ROM Checksum: 79229d79aadd0b676342257f9b23de7d
CRC32 Checksum: 9F2C4807