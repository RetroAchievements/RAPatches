Use with:

(No-Intro)
Chip 'n Dale - Rescue Rangers 2 (USA).nes
e3200570577098ac9a77a8023736b711
00CE4821