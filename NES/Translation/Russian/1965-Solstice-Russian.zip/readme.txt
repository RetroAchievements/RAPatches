Use with:

Solstice - The Quest for the Staff of Demnos (USA).nes (No Intro)
ROM Checksum: 1a9dad0fa3322ebe4d36cfd4dfcf4516
CRC32 Checksum: 7CCA8158