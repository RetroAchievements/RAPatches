Use with:

(No Intro)
Friday the 13th (USA).nes
md5: fb28a7a570cce987485f97057627dab2
crc: 4EF69333