Use with:

File:               Adventures of Lolo 2 (USA).nes (No-Intro)
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              F4CC279A
MD5:                DA9B5DC883A456394CE7B65545EE0952