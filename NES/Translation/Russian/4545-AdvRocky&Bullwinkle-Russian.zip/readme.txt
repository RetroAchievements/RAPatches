Use with:

File:               Adventures of Rocky and Bullwinkle and Friends, The (USA).nes (No-Intro)
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              99C5174D
MD5:                AE322FCF4102ED130C30C9A90FAF652B