Use with:

File:               Earthbound (USA) (Proto).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              F5EF5002
MD5:                5BACF7BA94C539A1CAF623DBE12059A3

Headerless Data:
CRC32:              53A9E2BA
MD5:                84E8FED10D7C339F726D52CB152078E1