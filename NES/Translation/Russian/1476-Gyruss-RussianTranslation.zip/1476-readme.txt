Use with:

(No-Intro)
Gyruss (USA).nes
d22232a3971d4f866fae17fc837fad10
7CBDE0CD