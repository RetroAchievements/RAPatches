Use with:

Beetlejuice (USA).nes (No Intro)
ROM Checksum: 4ea797a24bf323707757e5e280f910d2
CRC32 Checksum: 8CEC72CF