Use with:

Dick Tracy (USA).nes (No Intro)
V14-/V15+ RA Checksum: c730e42bd60ba9bd0bcb196ce1fc3cfe
ROM Checksum: 35074c8b0622e429a65287a25f01f40b
CRC32 Checksum: E431136D