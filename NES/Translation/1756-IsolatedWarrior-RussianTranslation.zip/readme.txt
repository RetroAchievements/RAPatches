Use with:

Isolated Warrior (USA).nes (No Intro)
RA Checksum: b69780b6878c050a243b8a5e9bad83b5
ROM Checksum: da01075315eb22eb41c3d04e0fbeef92
CRC32 Checksum: 43D7A888