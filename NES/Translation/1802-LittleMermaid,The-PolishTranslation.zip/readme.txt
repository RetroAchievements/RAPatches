Use with:

Little Mermaid, The (USA).nes (No Intro)
V14-/V15+ RA Checksum: 725026e6566fe3996e11811fadc0f7d0
ROM Checksum: 7a0b80fefb770bf5139a3d09e7835280
CRC32 Checksum: 08EB97DB