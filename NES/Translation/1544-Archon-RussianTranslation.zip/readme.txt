Use with:

Archon (USA).nes (No Intro)
V14-/V15+ RA Checksum: 0f3b320959931b549eab42566aeadb63
ROM Checksum: 4777689bfc7ad9e36136235fc774a36d
CRC32 Checksum: C00D228D