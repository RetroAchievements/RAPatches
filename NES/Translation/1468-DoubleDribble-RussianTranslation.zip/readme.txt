Use with:

Double Dribble (USA) (Rev A).nes (No Intro)
V14-/V15+ RA Checksum: a18ad877abc0882d1bb72233b6fa5e99
ROM Checksum: e1b768a0f5bb9c31572bf61b1c84dc67
CRC32 Checksum: E3E0BC5F