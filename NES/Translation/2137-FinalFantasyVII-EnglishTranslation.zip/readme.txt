Use with:

Final Fantasy VII (NJ063) (Ch).nes (GoodTools)
V14-/V15+ RA Checksum: 9ad49f7a07481c367289e442420fa294
ROM Checksum: 1b07874d73756f1ec33a957f1640153c
CRC32 Checksum: E5BF8F0C