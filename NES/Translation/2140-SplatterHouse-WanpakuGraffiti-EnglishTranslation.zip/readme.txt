Use with:

Splatter House - Wanpaku Graffiti (Japan).nes (No Intro)
RA Checksum: d48f63a48cf051a1f3261a29549ba173
ROM Checksum: 4fa13d2e51a3559d710ea3112e023dc7
CRC32 Checksum: B7EEB48B