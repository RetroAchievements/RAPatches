Use with:

Friday the 13th (USA).nes (No Intro)
RA Checksum: 7b1f3ead3e05455f14babc5c6e9ff3a4
ROM Checksum: 823d631e20fe6239207965be6a453141
CRC32 Checksum: F19A4249