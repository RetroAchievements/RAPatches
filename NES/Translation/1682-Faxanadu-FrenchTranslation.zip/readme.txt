Use with:

Faxanadu (USA).nes (No Intro)
V14-/V15+ RA Checksum: da0dae68ce4220d669fd032dbf5937a6
ROM Checksum: ad723974809278bdad547191be936d9c
CRC32 Checksum: 272826CF