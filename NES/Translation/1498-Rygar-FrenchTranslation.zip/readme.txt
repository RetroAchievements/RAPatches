Use with:

Rygar (Europe).nes (No Intro)
RA Checksum: de9bcff6b3c93a4be9dcef851b27c388
ROM Checksum: 5809d2ebf32ce8f89c0720a83a0feb8b
CRC32 Checksum: BC10A83E