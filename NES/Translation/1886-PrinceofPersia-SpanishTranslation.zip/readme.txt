Use with:

Prince of Persia (USA).nes (No Intro)
V14-/V15+ RA Checksum: c153e769a114e684960533db620f6346
ROM Checksum: c21e7a8965a3be35519a43260ada4007
CRC32 Checksum: 43C7E445