Use with:

(No Intro)
Spartan X 2 (Japan).nes
3450e85e842f13fe75280122b9265f5e
98A8B3D1
