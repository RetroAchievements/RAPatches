Use with:

(No Intro)
File:               Nazo no Murasamejou (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              9A523757
MD5:                FA04B0B2D99D560E7076198AB72A15D3