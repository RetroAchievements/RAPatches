Use with:

(No Intro)
File:               Tokkyuu Shirei - Solbrain (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              6A09E2BB
MD5:                2D60CCA6117509998A9D9A232D80ADD6
Headerless MD5:     4CE24FCDEA0F2E6B504B679EFC7EAFC8