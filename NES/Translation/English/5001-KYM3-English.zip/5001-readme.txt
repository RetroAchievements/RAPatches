Use with:

(No Intro)
File:               Kaiketsu Yancha Maru 3 - Taiketsu! Zouringen (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              6947B6E4
MD5:                AE2D3FFA9B68160871EB907D85FCD42F