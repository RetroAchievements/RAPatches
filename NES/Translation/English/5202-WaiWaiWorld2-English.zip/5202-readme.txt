Use with:

(No Intro)
Wai Wai World 2 - SOS!! Paseri Jou (Japan).nes
1efd84e2f967ed9577d6d64e733c81b0
083B1E00