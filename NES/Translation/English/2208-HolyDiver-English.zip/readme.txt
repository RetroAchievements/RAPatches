Use with:

(No Intro)
Holy Diver (Japan).nes
ROM Checksum: 975a4d99639579074efaa812acfdc486
CRC32 Checksum: 973B308E