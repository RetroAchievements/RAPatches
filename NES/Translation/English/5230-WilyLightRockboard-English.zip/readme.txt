Use with:

(No Intro)
File:               Wily & Right no Rockboard - That's Paradise (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              EBFBDB1E
MD5:                44C5A3DB3E0B2FC04CFF34294598928F
SHA1:               FC62A8232B96E098F9175870F7CD0D38068E7770
SHA256:             D36BD983AD8B87103A7298C80AE0ABA05ACF01220F3A679C85499B22B67785CC
Headerless MD5:     D4F59A4481496972C55B38F88C5F2C78