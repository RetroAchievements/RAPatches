Use with:

(No Intro)
File:               Zuizhong Huanxiang X3 (China) (Aftermarket) (Pirate).nes
BitSize:            8 Mbit
Size (Bytes):       1048592
CRC32:              99F0B772
MD5:                A016BCF679531EFFB41FD5DF7D365AF4
SHA1:               E5F1C53282FD89E6420BB857640EDCC4AD11FBBF
SHA256:             0F71B964F0A7F5EADA10D23A163995156352137A8361CE2B21281D386440D332
Headerless MD5      6800B1C3E913B6CDC14AE1B489CD8859