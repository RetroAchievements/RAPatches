Use with:

(No-Intro)
File:               Final Fantasy II (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              9D0529EF
MD5:                4175FC8F00FF6644921D9D816391B3A1
Headerless MD5:     374ED97BE8BFD628F6B359A720549ECD