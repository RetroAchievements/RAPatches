Use with:

(No Intro)
File:               Akira (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              9DBD5DFB
MD5:                B7CE9FCB26417A4FF21AB33190B21554
Headerless MD5 (RA)	15A6EE7C758E80B0E143F90185FA1B02