Use with:

(No Intro)
File:               Erika to Satoru no Yume Bouken (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              4C9606CE
MD5:                664F7EA1E31E975A5EF747FF637D96BD
Headerless MD5:     E9393CF6E90F5A59BEDF4232E81CEA60