Use with:

(No Intro)
File:               Keroppi to Keroriinu no Splash Bomb! (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       163856
CRC32:              CC6FBDAE
MD5:                D57DAF5848CAE6640577E605B7CFE4B3
Headerless MD5:     9BDD8AB04E1B1318DF720526C932AB8E