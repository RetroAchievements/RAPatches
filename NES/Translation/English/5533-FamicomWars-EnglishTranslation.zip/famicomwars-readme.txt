Use with:

(No Intro)
File:               Famicom Wars (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       196624
CRC32:              D70C59B9
MD5:                9DAD65BFAA2D11D91161B58A928A2F8B
Headerless MD5:     922F4F86C8719D1CEB9B7773600348AC