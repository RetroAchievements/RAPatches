Use with:

Hokuto no Ken 2 (Japan).nes (No-Intro)
4e44940551e330e30d0f10629d0ff81c
7539D3D2
