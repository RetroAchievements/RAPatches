

Use with:

Ninja Jajamaru - Ginga Daisakusen (Japan).nes (No-Intro)
46a95a93a5add5fdbfe03cee0afee66d
E81E2B30
