Use with:

(No Intro)
Joy Mech Fight (Japan).nes
f047abf10d1e72d5fbed7ca9391db10c
889942FE