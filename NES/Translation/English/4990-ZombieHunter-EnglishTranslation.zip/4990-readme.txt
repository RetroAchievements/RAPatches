Use with:

(No Intro)
Zombie Hunter (Japan).nes
26934541d95f88eb4c153495d896e38f
6806820F