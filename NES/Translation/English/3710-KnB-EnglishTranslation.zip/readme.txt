Use with:

(No Intro)
File:               Ki no Bouken - The Quest of Ki (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       196624
CRC32:              FFA34761
MD5:                170B96C9F9C4BE13DBAEF6050FDCC534
Headerless MD5 (RA) 6BD900B4F8F7FD41164B2EE14C088605