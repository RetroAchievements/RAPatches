Use with:

(No Intro)
File:               Kyouryuu Sentai Zyuranger (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              EAD2C628
MD5:                BE3D3640322205F0C91169FD9F1BC906
SHA1:               654228FBC298260D680350634C93A4A05CB45834
SHA256:             FB23DC5B9E4D22C5CCA8B68EB5AEFF5BA78DC1AD46847772BDBF00810C1185EB