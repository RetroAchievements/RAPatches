Use with:

(No Intro)
File:               Final Fantasy - Taikong Zhanshi V (China) (v1.1) (Pirate).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              1FD7DC66
MD5:                6A08DD8ACEFC99E628153C70EDF752B0
SHA1:               B2BFB583B86601A8C3FFD7F094815FE64D3FCF43
SHA256:             86D0ADEFFF8969DCFF7030874112EB4F719BA92303987643F254CB377388F51A
Headerless MD5      7E11DCE0A838C1F92140F26E7F83C665