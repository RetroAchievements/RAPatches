Use with:

(No Intro)
File:               Batsu & Terry - Makyou no Tetsujin Race (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              5D472584
MD5:                2ED5959C6C54F479D2FF91731CD89BCE
Headerless MD5:     FBC46D607EE554C8388D2903138CE7EE