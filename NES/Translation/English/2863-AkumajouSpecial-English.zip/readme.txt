Use with:

(No Intro)
Akumajou Special - Boku Dracula-kun (Japan).nes
ROM Checksum: 658693554bef354a3e2811e5b259cbcd
CRC32 Checksum: C3945386