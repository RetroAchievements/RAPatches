Use with:

(No Intro)
Sweet Home (Japan).nes
ROM Checksum: 761c3fbbbd4ea29f19e28311a583de3a
CRC32 Checksum: 6AB7673A