Use with:

(No Intro)
Ninja Hattori-kun - Ninja wa Syugyou de Gozaru no Maki (Japan).nes
4d9337fb682808b75299e1cc764a4ba4
2F1CCD71
