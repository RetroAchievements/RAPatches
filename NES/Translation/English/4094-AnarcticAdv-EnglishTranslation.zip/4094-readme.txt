Use with:

(No Intro)
Kekkyoku Nankyoku Daibouken (Japan).nes
c96cdacaf89fde3054e22f82af61b102
D1F8BDE2
