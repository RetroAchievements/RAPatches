Use with:

(No Intro)
Crisis Force (Japan).nes
ROM Checksum: 527d20fc46583fb034e8e53789fc6c0c
CRC32 Checksum: A980813D