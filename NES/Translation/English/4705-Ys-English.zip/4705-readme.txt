Use with:

(No Intro)
Ys (Japan).nes
07eb0e198fd89da66b4dece54d89ecb2
DDCCE534