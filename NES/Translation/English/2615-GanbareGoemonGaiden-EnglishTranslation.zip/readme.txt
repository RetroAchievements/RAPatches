Use with:

(No Intro)
File:               Ganbare Goemon Gaiden - Kieta Ougon Kiseru (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              B51CD53E
MD5:                8E72EC5B142253E4D6AD25681F869350