Use with:

(No Intro)
File:               Bloody Warriors - Shan-Go no Gyakushuu (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              76823B90
MD5:                1F572AC47FB1CE4BCAB100B341CC5E72
Headerless MD5:     4A8AEF5781BBBCCB9E87B95C993FE2B7