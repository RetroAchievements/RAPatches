Use with:

(No Intro)
Konami Wai Wai World (Japan).nes
3b249ad69985c006e4f6b8dd7d1196f4
3095F6D1
