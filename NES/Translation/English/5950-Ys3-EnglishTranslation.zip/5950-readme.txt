Use with:

(No Intro)
Ys III - Wanderers from Ys (Japan).nes
D4E0C638
7ee5310ca895d32ada2a363b47ab4614