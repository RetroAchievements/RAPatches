Use with:

(No Intro)
File:               Lagrange Point (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              A1E48D00
MD5:                363594C901EEDB0BA16BE97EA193F41F
Headerless MD5:     5184D4316F858A52B091869F46FE1A95