Use with:

(No Intro)
File:               Fire Emblem - Ankoku Ryuu to Hikari no Tsurugi (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              3452E97C
MD5:                095B2041905318F9026D9A5811E52292
SHA1:               0179C550D424E0397496078789E7B116601D120C
SHA256:             718770A459C4C1140EFCDDAA78C2D44EEFC32DE373692D9FDFCC3A032E1F1731
Headerless MD5      31B08C81F13E76247F052E80669E8C41