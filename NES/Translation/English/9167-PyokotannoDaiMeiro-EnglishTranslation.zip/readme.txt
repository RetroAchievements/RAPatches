Use with:

(No Intro)
File:               Pyokotan no Daimeiro (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              1BB879B0
MD5:                21965DC6632E06BFF7FA25AE8FAF9F71
Headerless MD5 (RA) 045E3579061B7FB4F9F892B8863761B8