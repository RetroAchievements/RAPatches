Use with:

Downtown Special - Kunio-kun no Jidaigeki Da yo Zenin Shuugou! (Japan).nes (No-Intro)
244ea67ed19e870081491ebb00aa4d03
A74B96B9