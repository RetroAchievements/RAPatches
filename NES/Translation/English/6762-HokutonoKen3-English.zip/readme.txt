Use with:

(No Intro)
File:               Hokuto no Ken 3 - Shin Seiki Souzou Seiken Retsuden (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              12B32580
MD5:                B9628301F0049937976ECF14325477D8
SHA1:               C12A27D9100636A94353620A5DC323691F9BDA64
SHA256:             33749A84C90496A57B5537DE946D268AB909609634C427063EDF6E3CE0CCDB4A
Headerless MD5 (RA) E402788CC7AA56A74C7534D594B8CE51