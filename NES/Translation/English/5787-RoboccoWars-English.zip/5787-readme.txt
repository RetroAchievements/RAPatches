

Use with:

Robocco Wars (Japan).nes (No-Intro)
1067fa4d52e1c47ed639b6d60b679a8b
1371ACFF
