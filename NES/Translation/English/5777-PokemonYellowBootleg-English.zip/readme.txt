Use with:

(No Intro)
File:               Leidian Huang - Pikachu Chuanshuo (China) (Aftermarket) (Pirate).nes
BitSize:            16 Mbit
Size (Bytes):       2097168
CRC32:              F4EBE9B2
MD5:                D4F7FEA1AD69DF66E1CF861FABD6796A
SHA1:               88CCFB00E1A18AE3C1711EB88D43628E26EA7897
SHA256:             450D40C0D648F8651AC6B42F1C094921CB2202ED420194E65271E2F7B40C65ED
Headerless MD5      187489CB099905016A16B73B2543FFB8