Use with:

(No Intro)
Cosmo Police Galivan (Japan).nes
cdf1f060f467f88c25eb3efb783541e2
BCCADA80