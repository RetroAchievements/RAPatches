Use with:

(No Intro)
Splatterhouse - Wanpaku Graffiti (Japan).nes
ROM Checksum: cb0c40716808d4173fc4a3fddbae015e
CRC32 Checksum: E9D134D4