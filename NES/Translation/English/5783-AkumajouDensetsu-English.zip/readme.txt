Use with:

(No Intro)
Akumajou Dracula (Japan).nes
b28b00195e56b548880192140b4648f0
93F0488C