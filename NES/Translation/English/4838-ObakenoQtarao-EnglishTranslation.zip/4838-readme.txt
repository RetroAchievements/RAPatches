Use with:

(No Intro)
Obake no Q Tarou - Wanwan Panic (Japan).nes
4047bf40ac438c6dfc8b86e20d246b03
49673028
