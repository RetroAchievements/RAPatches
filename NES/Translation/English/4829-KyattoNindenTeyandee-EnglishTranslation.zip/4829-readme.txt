Use with:

(No Intro)
Cat Ninden Teyandee (Japan).nes
220837002c6c6d94b769e2ac15c9cebb
FE3E6F45
