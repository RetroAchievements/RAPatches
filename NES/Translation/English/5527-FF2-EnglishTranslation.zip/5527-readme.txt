Use with:

(No-Intro)
Final Fantasy II (Japan).nes
4175fc8f00ff6644921d9d816391b3a1
9D0529EF
