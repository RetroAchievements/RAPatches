Use with:

Fire Emblem Gaiden (Japan).nes (No-Intro)
7dee7324cad643eb2d3e652500e4962d
E93A6ADB
