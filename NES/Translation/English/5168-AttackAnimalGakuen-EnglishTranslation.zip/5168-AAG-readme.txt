Use with:

Attack Animal Gakuen (Japan).nes (No-Intro)
02c66932c3e5b69fe5c5ade0363545fa
FD43E1A7
