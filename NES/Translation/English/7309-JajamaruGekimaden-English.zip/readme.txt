Use with:

(No Intro)
File:               Jajamaru Gekimaden - Maboroshi no Kinmajou (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              214B9BC6
MD5:                7B88C5976483D424E9ACAC003E946A1F
SHA1:               909EA44DA2B704E88B4058631B985897CD6AE41C
SHA256:             FD07BA29CC9DA86181EB23FA3697F5A556CA97ABED6F264F83178050770E4093
Headerless MD5      17021086C31E64C2A284DCA3F6F42DA5