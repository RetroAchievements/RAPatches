Use with:

(No-Intro)
Majou Densetsu II - Daimashikyou Galious (Japan).nes
49d668413737e58c7771759abb6ce81e
763F2D28