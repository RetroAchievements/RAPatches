Use with:

(No Intro)
File:               JJ (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              338C11D5
MD5:                E1B95707AD4F4516009977FCB84DD0B2
Headerless MD5:     CE4D5BDA746A72E02FCFD547492551BC