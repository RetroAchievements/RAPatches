Use with:

Cocoron (Japan).nes (No-Intro)
348a3df67e2cf00d7be367223734aa3b
375CDC25
