Use with:

(No Intro)
File:               Mugen Senshi Valis (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              63A4A11C
MD5:                A6ADA3CDEF3842C97D854030BA35A7EF
Headerless MD5:     E907C8E985EA0FDC87D8AEEBB6E71D47