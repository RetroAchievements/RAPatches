Use with:

(No Intro)
File:               Perman Part 2 - Himitsu Kessha Madoodan o Taose! (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              6846FD7F
MD5:                812688CE18E5B583BDDAFBF85BBD83F5
Headerless MD5:     89AB4C55AC6D5312F1BF6C1AE8EC120F