Use with:

Kanshakudama Nage Kantarou no Toukaidou Gojuusan Tsugi (Japan).nes (No-Intro)
68f9cad1ccc767db8c75e57e47a056a1
FC6DCEB8
