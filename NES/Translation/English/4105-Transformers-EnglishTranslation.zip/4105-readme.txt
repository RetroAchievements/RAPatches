Use with:

(No Intro)
Tatakae! Chou Robot Seimeitai Transformers - Convoy no Nazo (Japan).nes
df8f2a2626eff8848dc3ed1d941388d4
8B75BA7E
