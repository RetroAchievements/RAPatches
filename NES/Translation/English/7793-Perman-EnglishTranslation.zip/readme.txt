Use with:

(No Intro)
File:               Perman (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              93F7C1A9
MD5:                1B9F650A256E13ECA0A4C12603A3C58E
Headerless MD5:     7DAB9743C00C4648CA140479FA79A550