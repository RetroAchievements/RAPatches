Use with:

(No Intro)
File:               Dragon Scroll - Yomigaerishi Maryuu (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              169B8310
MD5:                E923D5E059CC86A1A6865EB5E25438CC
Headerless MD5:     695D86D2746758474AC2186B8BDE2165