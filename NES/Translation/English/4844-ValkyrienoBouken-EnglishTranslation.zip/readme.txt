Use with:

(No Intro)
File:               Valkyrie no Bouken - Toki no Kagi Densetsu (Japan).nes
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              F9768D2A
MD5:                414830DDA0377F1E1D9DAC3017E438D4
Headerless MD5:     6D7F0B19C764A04D2AF762A4791B096C