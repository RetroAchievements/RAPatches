Use with:

(No-Intro)
Getsu Fuuma Den (Japan).nes
c461528449c73043fa1f0da7351bca63
F311279A
