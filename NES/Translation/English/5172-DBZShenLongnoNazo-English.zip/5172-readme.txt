Use with:

Dragon Ball - Shen Long no Nazo (Japan).nes (No-Intro)
b5b0d9a7624f12e39ca0048ffe6b7b77
2506FB77
