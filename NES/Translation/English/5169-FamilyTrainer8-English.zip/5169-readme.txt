Use with:

Family Trainer 8 - Totsugeki! Fuuun Takeshi-jou (Japan).nes (No-Intro)
111e2510bd3e606715e721e68c03fb55
B61C6360
