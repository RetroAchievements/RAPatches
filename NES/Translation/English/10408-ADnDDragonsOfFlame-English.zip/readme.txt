Use with:

(No-Intro)
File:               Advanced Dungeons & Dragons - Dragons of Flame (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              DA38E889
MD5:                7AC846792AC2E46B30C10A6219EFC7AB
SHA1:               926EE7592F45FD204A371F78600E7F37272E5143
SHA256:             FF9CA5FEA895C846B8F38B1AC159FB689673D47A8208C38EC68C96A240C1C615
Headerless MD5:     AC7FA71CFBBE4CE59897E2818F5A3651