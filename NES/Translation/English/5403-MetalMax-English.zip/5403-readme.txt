Use with:

Metal Max (Japan).nes (No-Intro)
9f2283f41b025aa80982fe470f5e825e
6D1E1743
