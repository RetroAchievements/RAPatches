Use with:

(No Intro)
File:               Jekyll Hakase no Houma ga Toki (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              32749C58
MD5:                DEA3209B1FD62A5F2BCA4EFD36CCBDC5
Headerless MD5:     50B9ECC2AF9F0A3C13917486AC9643DC