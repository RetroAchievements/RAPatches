Use with:

(No Intro)
File:               Magical Kid's Doropie (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              C57F1561
MD5:                E0975B14FD1AB4D1414B698B366FDD86
Headerless MD5:     EDD9F8247E5761963E3EB3FA27FB7507