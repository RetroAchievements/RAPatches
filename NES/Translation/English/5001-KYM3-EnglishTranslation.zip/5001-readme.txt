Use with:

(No Intro)
Kaiketsu Yancha Maru 3 - Taiketsu! Zouringen (Japan).nes
0beca3a3a12ba875360a4aa65b5d7943
F86D5C4C