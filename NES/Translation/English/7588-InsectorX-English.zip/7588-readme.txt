Use with:

(No-Intro)
Insector X (Japan).nes
26e5ada9fbac3137a94096bd5b0638ca
7DAB812D