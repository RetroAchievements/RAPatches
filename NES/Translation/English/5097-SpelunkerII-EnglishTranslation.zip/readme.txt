Use with:

(No Intro)
File:               Spelunker II - Yuusha e no Chousen (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              67B12EB4
MD5:                E6F3DEBD3638BEBA235C0E68FC82663D
Headerless MD5:     F49FA32D46FDE0234F81C5D7094F1CA6