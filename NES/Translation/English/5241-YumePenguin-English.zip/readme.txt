Use with:

(No Intro)
Yume Penguin Monogatari (Japan).nes
4dca72063fb2453b6d79f3e927c8ef5c
70428FDF