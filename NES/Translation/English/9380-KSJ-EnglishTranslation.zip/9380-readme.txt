Use with:

Kyouryuu Sentai Zyuranger (Japan).nes (No-Intro)
be3d3640322205f0c91169fd9f1bc906
EAD2C628
