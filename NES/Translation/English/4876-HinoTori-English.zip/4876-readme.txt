Use with:

(No Intro)
Hino Tori - Houou Hen - Gaou no Bouken (Japan).nes
6bcb33e53364a26a87b3c9506a1d1a47
8E0B2FD4
