Use with:

(No Intro)
Urusei Yatsura - Lum no Wedding Bell (Japan).nes
8c096e0a4d57d9d286506daea1d11dbf
BBD0542B