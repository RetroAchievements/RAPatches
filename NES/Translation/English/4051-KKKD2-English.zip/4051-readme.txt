Use with:

(No Intro)
Kero Kero Keroppi no Daibouken 2 - Donuts Ike wa Oosawagi! (Japan).nes
67ad29407e2adeb4ea4c675b62c2abe6
BD6C180B
