Use with:

(No Intro)
File:               Takahashi Meijin no Bouken-jima IV (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              5EF1196B
MD5:                041EE92C6A2A2A6956D85385E682C0D7

Headerless Data:
CRC32:              7BD8F902
MD5:                17F974B2180DBC3247787CEDD4B82597