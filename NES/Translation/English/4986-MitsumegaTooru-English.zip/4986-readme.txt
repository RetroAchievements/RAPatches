Use with:

Mitsume ga Tooru (Japan).nes (No-Intro)
a985f91a621b65f5e5db0c983c19c795
73542B44
