Use with:

(No Intro)
Ys II - Ancient Ys Vanished - The Final Chapter (Japan).nes
d049522a58edd921c1488c6f95a814ec
B1C019AB