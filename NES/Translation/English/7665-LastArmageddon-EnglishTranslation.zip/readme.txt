Use with:

(No Intro)
File:               Last Armageddon (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              97AC4BD0
MD5:                DD6B17DE78F221582AD904CCA0DFBFAA
Headerless MD5:     F3599CF87354D60B1E6F6882EC3E7ED3