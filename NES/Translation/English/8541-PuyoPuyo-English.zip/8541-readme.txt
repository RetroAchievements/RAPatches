

Use with:

Puyo Puyo (Japan).nes (No-Intro)
0a2b4e9e85541b0eb09041bb1a0b8d65
A8857E10
