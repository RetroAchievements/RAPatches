Use with:

(No Intro)
File:               Chester Field - Ankoku Shin e no Chousen (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              C8BEAD93
MD5:                36AB0A194307722ED6105819A320DDAB
Headerless MD5:     0EF3F3DE697F999172358C3868B903CD