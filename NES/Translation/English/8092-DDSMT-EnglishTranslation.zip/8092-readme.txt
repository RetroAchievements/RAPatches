Use with:

Digital Devil Story - Megami Tensei (Japan).nes (No-Intro)
99fba6d02d110914c09a16e13f488cb5
682C4603
