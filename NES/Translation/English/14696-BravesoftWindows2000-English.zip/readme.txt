Use with:

(No Intro)
File:               Bravesoft Windows 2000 (Russia) (Subor Keyboard) (Aftermarket) (Pirate).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              2B956CCF
MD5:                B44D44EB874F8A9735E070909C8C0A69
SHA1:               9D55ECD06B471EA508EF03EFACB186F5AAE64302
SHA256:             673B5F299D8CB1FE2DD7DE1C0FD701871739C91B99473FCA3EC7825C0E7A4483
Headerless MD5      A92340EF85C400F2A475FB902E275C98