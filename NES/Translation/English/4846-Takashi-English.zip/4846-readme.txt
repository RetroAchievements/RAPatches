Use with:

(No Intro)
Takeshi no Chousenjou (Japan).nes
41936e258e0cf74c47a13f5b6049c338
E810B35C