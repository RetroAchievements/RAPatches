Use with:

(No Intro)
File:               Ushio to Tora - Shinen no Taiyou (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              4F3BAB82
MD5:                6EF40979664615152A527206C9BDB351
Headerless MDS:     99552570212D49EF461037D1A5D46411