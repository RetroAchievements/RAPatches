Use with:

(No Intro)
File:               Mickey Mouse III - Yume Fuusen (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              8AD9A9BE
MD5:                81EC831FB959C1F8BA7945D8D5869F60

