Use with:

(No Intro)
Dragon Ball - Daimaou Fukkatsu (Japan).nes
98a8d5fd527dc9a851d5e43220c8b94a
A3F4A010
