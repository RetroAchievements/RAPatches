Use with:

(No Intro)
Hebereke (Japan).nes
1efdab0641c6d72c54bf5a57e23250bb
2A137974