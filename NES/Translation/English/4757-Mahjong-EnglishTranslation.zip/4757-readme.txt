Use with:

(No Intro)

Mahjong (Japan) (Rev 1).nes
abbb1295845e99c8d5bdf4d26cd641a6
87C340BE

Mahjong (Japan) (Rev 2).nes
0648e6bdf652c24e2b1a680c890f3ec0
0D9E7B5F