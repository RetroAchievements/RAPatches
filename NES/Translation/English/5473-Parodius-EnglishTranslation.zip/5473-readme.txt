Use with:

(No-Intro)
Parodius Da! (Japan).nes
93edead96a12320b9958b0bcbd911675
81586940
