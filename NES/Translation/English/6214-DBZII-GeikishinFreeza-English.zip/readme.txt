Use with:

(No Intro)
File:               Dragon Ball Z II - Gekishin Freeza!! (Japan) (Rev 1).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              0C06A072
MD5:                0460DC99C8DE4B5146291F3A2310FD87
SHA1:               661CD5892281ACE89403A673E8657DAEF60FDF09
SHA256:             EDD7F6A4707E8CE797BEC6DC8C28249B66C2A249EF8474D63A0398F66098DFC9