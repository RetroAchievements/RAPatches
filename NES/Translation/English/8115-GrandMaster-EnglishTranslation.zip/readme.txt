Use with:

(No Intro)
File:               Grand Master (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              EFCAAA8D
MD5:                A7E7B2ADDAC788E2994A5B8AEF7417E4
Headerless MD5 (RA) 730EBA9A9F5C23C01B97F9AAA0CD39E0