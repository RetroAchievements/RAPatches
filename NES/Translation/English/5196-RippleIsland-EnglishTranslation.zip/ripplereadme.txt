Use with:

(No Intro)
File:               Ripple Island (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              F416286D
MD5:                DD7268D00E002096A4EB8675865999EE
Headerless MD5:     F7464B2BE4B9E49F425279BED15F2345