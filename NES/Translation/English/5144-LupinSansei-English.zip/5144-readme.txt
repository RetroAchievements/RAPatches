Use with:

Lupin Sansei - Pandora no Isan (Japan).nes (No-Intro)
7df229fd06eb8359a1d1d8aa666cf027
B86381CE
