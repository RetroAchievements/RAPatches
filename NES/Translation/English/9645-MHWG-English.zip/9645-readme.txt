Use with:

Mashin Eiyuu Den Wataru Gaiden (Japan).nes (No-Intro)
ed54f9887f5ad6a2219fe6712f9fedd1
B563981F
