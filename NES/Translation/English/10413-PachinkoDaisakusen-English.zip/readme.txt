Use with:

(No Intro)
Format:		Headered
File:		Pachinko Daisakusen (Japan).nes
Size:		262160
CRC32:		ec6d7a77
MD5:		cc2e4a95311891cd9a51d206ee1794f2
SHA-1:		8c5940f6cd2a88a3bbc104b677551372cd6c9a53
SHA-256:	564732741c36882904d29990e7854482f09b5d4633c3a14af2853c026ba88420