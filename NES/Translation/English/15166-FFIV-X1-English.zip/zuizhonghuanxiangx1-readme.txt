Use with:

(No Intro)
File:               Zuizhong Huanxiang X1 (China) (Aftermarket) (Pirate).nes
BitSize:            8 Mbit
Size (Bytes):       1048592
CRC32:              4BFD1A54
MD5:                9EF1A3E91DFA146ECE580AC77841D505
SHA1:               7C4373D38F56648A660C1F6D0FB0EB191F8FF5F6
SHA256:             4A0378612241CC64F9C529537D5FA4180A67116C5887B50B755726E69F89F8FE
Headerless MD5      3BB7994D89F67AD4428A72632A947388