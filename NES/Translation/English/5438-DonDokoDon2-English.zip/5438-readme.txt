Use with:

Don Doko Don 2 (Japan).nes (No-Intro)
b5d1be255753ba78fd55b7d02ff9e789
F5BDB3DC
