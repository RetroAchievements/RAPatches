Use with:

(No Intro)
File:               Romancia (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              98028824
MD5:                7DC9EC99E920A933CCC36BBFD11A9705