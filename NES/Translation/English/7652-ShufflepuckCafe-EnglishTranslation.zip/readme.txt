Use with:

(No Intro)
File:               Shufflepuck Cafe (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              35B39E8A
MD5:                FCA00783FE6009132013A8C0B8C5F1A1
Headerless MD5:     9138CD2210FC8A7E31943EFA35E6A46A