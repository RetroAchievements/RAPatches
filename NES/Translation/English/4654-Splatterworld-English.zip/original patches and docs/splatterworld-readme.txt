SPLATTERWORLD
ENGLISH TRANSLATION V1.00
Copyright 2025 by Aeon Genesis
http://www.aeongenesis.net

ToC

0.  Hosting notes
0.1 Content Warning
0.2 Compatibility Warning
1.  About Splatterworld
2.  Patch History
3.  Patch Credits and Contributors
4.  Known issues
5.  Optional extra patches
6.  Application Instructions


---------------
0.Hosting Notes
---------------
Please note that romhack.ing is an authorized patch redistributor.
This patch is expressly forbidden from being hosted at romhacking.net.

-------------------
0.1 Content Warning
-------------------
Splatterworld includes depictions of various dictators from history (yes, including that one) as entities that the player can summon. They are not part of the story, but they are part of the gameplay. Speaking for myself I feel it is important, for historical reasons, to present the game as it originally was, rather than to try to change it; therefore these figures names and appearances are unaltered. That said, nobody on the team condones these figures, what they did, or what they stand for. I want to be upfront about these figures' presence in the game and our approach to their inclusion, so that players can approach it forewarned.

-------------------------
0.2 Compatibility Warning
-------------------------
Several versions of the ROM with different headers are floating around on the internet. This patch should work on all of them, and *hopefully* will correct their headers; reference the checksum information at the end of this readme. The ROM should be mapper 210, submapper 1. This is the correct header:

4E 45 53 1A 10 20 23 D8 10 00 70 00 00 00 00 01

(Mapper 210, submapper 1. 256K PRG, 256K CHR, 8KB SRAM, battery. Vertical mirroring.)

Note that the patch expands the ROM to have 512K PRG; your header should look like this after patching:

4E 45 53 1A 20 20 23 D8 10 00 70 00 00 00 00 01

This mapper is not widely supported, however it has been tested and is working on the Mesen 2 emulator and on FCEUX. At the time of writing, the Everdrive N8 Pro *does not* correctly support this mapper, even though it claims to do so.

In short:

TESTED AND WORKING:    Mesen2, FCEUX
NOT WORKING CURRENTLY: Everdrive N8 Pro

---------------------
1.About Splatterworld
---------------------
Splatterworld is several things.

First, it is a cutesy RPG spinoff of Namco's Splatterhouse property. It's a sequel to the Splatterhouse Wanpaku Graffiti cutesy platformer on the Famicom, which was never released outside of Japan. It's a parody of horror films and loves to poke fun at them.

It's also a prototype. The game was never commercially released, and was only made available online on Halloween night this year (2025.) Naturally, I jumped right on it.

The game is fully playable from end-to-end. There are a few notable bugs, but nothing game-breaking or that you'd probably notice during a casual run. There are also a few things that could be polished: there's no separate boss battle music and music frequently restarts. But for the most part what we have here is a full-sized Splatterhouse RPG for the NES/Famicom!

The translation is also complete and with no known issues. Enjoy!

---------------
2.Patch History
---------------

December 3, 2025 - Initial v1.00 Release

---------------
3.Patch Credits
---------------
THE SPLATTERWORLD CORE TEAM
Gideon Zhi    - Project leader, lead romhacker, assembly work
Rahan         - Translation

And of course, a very special thanks to the rest of the community who helped out!

In no particular order:
-- Garrett Gilchrist, for the title screen, walkthrough, and ASM hints
-- Calico, for tips on NES ROM expansion
-- Kris Knigge, for translation and localization
-- Bodb, for translation and localization
-- blueskyrunner, for Everdrive tips
-- MoriyaMug, for translation
-- Ness, for general tips and testing

--------------
4.Known Issues
--------------
There are no known issues.

------------------------
5.Optional Extra Patches
------------------------
As of this writing the following optional extra patches are available:

* RUN BUTTON: Moves the in-game menu to the Start button. Hold the B button to run.

See below for application instructions. More optional extra patches may or may not be made available at a later date.

--------------------------
6.Application Instructions
--------------------------
TL;DR - Most people should probably just use the combo patch, but the others are provided for the sake of authenticity.

This archive contains four xdelta patches:
splatterworld.xdelta 
splatterworld_j_run_button.xdelta
splatterworld_e_run_button.xdelta
splatterworld_combo.xdelta

splatterworld.xdelta
This is the translation by itself. Apply to a Japanese ROM for the most authentic original experience.

splatterworld_j_run_button.xdelta
This is the run button patch by itself. Apply to the Japanese ROM to have a Japanese version of the game with a run button. *NOT* compatible with the English version of the game.

splatterworld_e_run_button.xdelta
This is the run button patch by itself, versioned for the English-patched ROM. Apply to the English ROM to have an English version of the game with a run button. *NOT* compatible with the Japanese version of the game.

splatterworld_combo.xdelta
This is the translation combined with the run button patch. Apply this to the Japanese version of the game to get both the translation and the run button patch.

The patch uses a ROM with the following checksum information as its base:

CRC32:   8896F790
MD5-SUM: F41563D4706FF69ECC3B9AC31CB3B80E
SHA-256: 147CD108A25B755225506E42505C1C0635DF0B41E6422C6E85CDBAC2D4EA1209

After patching, the translated rom should have the following checksum information:
CRC32:   C62DB604
MD5-SUM: 48FE677B3DB65DE82439ABBF3146C800
SHA-256: F0062DDF8FD6A1EDFF5686EB21A6887331D093169930EC3C2B95BF31EB723E71

After patching and with the optional run button hack, it should have the following checksum information:
CRC32:   6AB9E947
MD5-SUM: 0F6F34E942F9F96F9EAC7BFF51D53D5E
SHA-256: 357B3364AF9D4F8BF8ED4EED8269259A911A3D8F41199B9687E4CBD63E9E55C3