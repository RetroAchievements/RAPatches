Use with:

(No Intro)
File:               Splatterworld - Rick to Kyoufu no Daiou (Japan) (Proto).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              CB9EF0BA
MD5:                E0229519009256F8F26FC09B577758BF
SHA1:               F422F625BC69925B6DDBAAAA3A24631F1F659837
SHA256:             D370A2345AF1EB570D70357C9EA64A0F655C9AF950D8897F4F45703A0F4EC9CC
Headerless MD5:     36063063DE9DB636AEE583471DF34718