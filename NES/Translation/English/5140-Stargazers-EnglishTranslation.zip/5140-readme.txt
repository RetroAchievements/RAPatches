Use with:

(No Intro)
Hoshi o Miru Hito (Japan).nes
ba8cf13e8d4ccd88609e42d4a76816ad
9904D6AA