Use with:

(No Intro)
File:               Hikari no Senshi Foton - The Ultimate Game on Planet Earth (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              058D3638
MD5:                A7A44D94BE46A1430B34165355B5B36C
SHA1:               6E3ED8313DE387C5C5B8820E1714DA0056536E2F
SHA256:             A0EE3BE24DF4EC9316637EC4A8C5A8629C59BD33E07B6CCFF31D656522514C70
Headerless MD5      56E7B7345AE95BB836B09D7A3130E58D