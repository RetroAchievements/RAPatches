Use with:

(No Intro)
Time Zone (Japan).nes
5b3b928816948eda2e1b15e62c14143c
58BCC214
