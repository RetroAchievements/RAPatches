Use with:

(No Intro)
File:               Jesus - Kyoufu no Bio Monster (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              82EA77A5
MD5:                1D6195537C8B7ABED788CEB9562E4C05
SHA1:               C1271DDCC6B6B2BAE990F2B79AD94EA337456BB4
SHA256:             F05148C0CC53C0BF9538EC4350007378B51FA6D661B40F39A0EFEBE300DCCE59