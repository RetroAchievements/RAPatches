Use with:

(No Intro)
Popeye no Eigo Asobi (Japan).nes
1d56770a314e90933b9d6e7e6ae5402c
ACEF1C5B