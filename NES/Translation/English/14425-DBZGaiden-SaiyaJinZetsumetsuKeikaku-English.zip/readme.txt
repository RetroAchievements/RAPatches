Use with:

(No Intro)
File:               Dragon Ball Z Gaiden - Saiya Jin Zetsumetsu Keikaku (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              B63E1069
MD5:                4C92346DE71444811955951EE852CE4A
SHA1:               33EB849A139B89D21B2DA48B810196A8971A0D0D
Headerless MD5:     A0FFFEC6C04845233B92524F6AB396B8