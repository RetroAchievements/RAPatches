Use with:

no intro

File:               Chrono Trigger - Shikong Zhi Lun (China) (Pirate).nes
BitSize:            16 Mbit
Size (Bytes):       2097168
CRC32:              0CD5B4B6
MD5:                D3E3A17FCEDC00E17DEC9821620D2D62
SHA1:               104E4C349DF9C8EE7D29D4A8B5C6036229CA9E7F
SHA256:             C98BF57106137D44F38D7E15DBDF5CC6B6AD7E22A880F9E445C928EA23C847EB
Headerless MD5:     27FD3BA457290496E95DE79760CB4F5C