Use with:

(No-Intro)
Taiyou no Yuusha - Fighbird (Japan).nes
e3c46ffa56120249d68d54050b2f4ea8
2F37E9EC