Use with:

(No Intro)
File:               Musashi no Bouken (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              4CD86D34
MD5:                661C3AB77D5E8445F950976C6AD6BE48
Headless MD5:       1D8BBC8316F06AC14A2B0333BD154060