

Use with:

Choujin Sentai Jetman (Japan).nes (No-Intro)
6568be2cdb51cff714b7818d17beed3b
69B355F1
