Use with:

(No Intro)
Hello Kitty World (Japan).nes
0187914a1e3121bccabe9783a3a776da
C31BCF11
