Use with:

(No Intro)
File:               Mahou no Princess Minky Momo - Remember Dream (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              D1B65A3E
MD5:                38A1B85316DBF334B331E459B69D6470
SHA1:               3E2C584210A5859C3D94163D47210FC880EA3BB8
SHA256:             EC7CDF936B81199A74914F234F27B808C6B3799A2627D0B754C3841B9221B051
Headerless MD5      DE8C6AE2D39B061786D2883EDCDCA807