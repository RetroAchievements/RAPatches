Use with:

(No Intro - iNES or NES 2.0 Headered)

Mahjong (Japan) (Rev 1).nes
RA Checksum: 251a9334f4c0d5b44f4cd8be92d059c7
ROM Checksum: 920804d698d88bbc43022df8e56269af
CRC32 Checksum: CB99AFE8

or

Mahjong (Japan) (Rev 2).nes
RA Checksum: 38abeee1b7148a5ff13f8f2ef6ab22e9
ROM Checksum: 3452906c1c1d7a2760bf7a91652a7ccf
CRC32 Checksum: 41C49409