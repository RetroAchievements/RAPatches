Use with:

(No Intro)
Cosmo Police Galivan (Japan).nes
md5: cdf1f060f467f88c25eb3efb783541e2
crc: bccada80