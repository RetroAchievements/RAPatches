Use with:

1943 - The Battle of Midway (USA).nes (No Intro)
V14-/V15+ RA Checksum: 190d10a3685f87ba32135ac595283f36
ROM Checksum: deeaf9d51fc3f13f11f8e1a65553061a
CRC32 Checksum: D131BF15