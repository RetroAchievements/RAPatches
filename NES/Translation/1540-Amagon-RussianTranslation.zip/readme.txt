Use with:

Amagon (USA).nes (No Intro)
V14-/V15+ RA Checksum: d8bd241e27f2c1812751e4e92c7ec68e
ROM Checksum: 07cf64f91db3a32e3525f3bec1115c71
CRC32 Checksum: D1BDE95C