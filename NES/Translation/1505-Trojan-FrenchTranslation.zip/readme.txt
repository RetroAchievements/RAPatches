Use with:

Trojan (USA).nes (No Intro)
V14-/V15+ RA Checksum: 7a35172f2c7edf08d63d256252c725e5
ROM Checksum: 7ceafee55263403e25eee9831cadaa1e
CRC32 Checksum: CF378FB2