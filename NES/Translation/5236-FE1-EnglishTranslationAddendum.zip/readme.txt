Use with:

Fire Emblem - Ankoku Ryuu to Hikari no Tsurugi (Japan).nes (No Intro)
ROM Checksum: dcf3887d32bec83a5c0a85c314579c56
RA Checksum: 31b08c81f13e76247f052e80669e8c41
CRC: D770FF13

Original Patch: https://www.romhacking.net/translations/2800/