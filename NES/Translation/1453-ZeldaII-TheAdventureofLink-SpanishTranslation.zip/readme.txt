Use with:

Zelda II - The Adventure of Link (USA).nes (No Intro)
V14- RA Checksum: 066e04b9cbc87a3e1a3059651bc68ef3
V15+ RA Checksum: 88c0493fb1146834836c0ff4f3e06e45
ROM Checksum: 764d36fa8a2450834da5e8194281035a
CRC32 Checksum: E3C788B0