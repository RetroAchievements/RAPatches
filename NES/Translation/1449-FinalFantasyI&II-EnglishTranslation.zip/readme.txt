Use with:

Final Fantasy I, II (Japan).nes (No Intro)
V14-/V15+ RA Checksum: 4b3342b2c143dade012df596e2b31174
ROM Checksum: 6cdb7b50c897956a9b32e5aa27a37216
CRC32 Checksum: 6F8906AD