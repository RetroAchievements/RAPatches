Use with:

Dragon Warrior III (USA).nes (No Intro)
V14-/V15+ RA Checksum: 16a03048ce659d3d733026b6b72f2470
ROM Checksum: 3ef863d2df43e805bad70f74f0ccd909
CRC32 Checksum: 0EB63E83