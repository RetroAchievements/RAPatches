Use with:

(No Intro)
Kid Icarus (USA, Europe).nes
md5: dbcc29e554efe78c1e4f77f675265d48
crc: 65338A67