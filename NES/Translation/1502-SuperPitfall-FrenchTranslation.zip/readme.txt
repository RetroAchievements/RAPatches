Use with:

Super Pitfall (USA).nes (No Intro)
V14-/V15+ RA Checksum: 89af175e32fbd07b70b16ba32b4fab30
ROM Checksum: cc9fa49d1c3756a7a9533b8f040e0c4c
CRC32 Checksum: A4958020