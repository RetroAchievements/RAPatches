Use with:

Wacky Races (USA).nes (No Intro)
RA Checksum: 9ca3418958e5d58e8e2fbb9abf13be51
ROM Checksum: c952e53c6df29b5c1438113a763ecdec
CRC32 Checksum: 6A862965