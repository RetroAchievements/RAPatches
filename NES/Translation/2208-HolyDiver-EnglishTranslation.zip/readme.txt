Use with:

Holy Diver (Japan).nes (No Intro)
RA Checksum: 6d71d45c282a7b923497fe59813035ec
ROM Checksum: 68b496a65571bce9c8e7be7667155c96
CRC32 Checksum: C4CF0E8E