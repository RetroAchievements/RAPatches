Use with:

Kid Icarus (USA, Europe).nes (No Intro)
V14-/V15+ RA Checksum: 8c45f4401cdae82b6079f9740007c8c5
ROM Checksum: d464e3e3877a759b8053210baaebc890
CRC32 Checksum: 0B30E036