Use with:

Legend of Zelda, The (USA) (Rev A).nes (No Intro)
V14-/V15+ RA Checksum: d3f453931146e95b04a31647de80fdab
ROM Checksum: f4095791987351be68674a9355b266bc
CRC32 Checksum: 02BB0C56