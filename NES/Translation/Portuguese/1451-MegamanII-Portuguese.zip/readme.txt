Use with:

Mega Man 2 (USA).nes (No Intro)
V14-/V15+ RA Checksum: 0527a0ee512f69e08b8db6dc97964632
ROM Checksum: 8e4bc5b03ffbd4ef91400e92e50dd294
CRC32 Checksum: 5E268761