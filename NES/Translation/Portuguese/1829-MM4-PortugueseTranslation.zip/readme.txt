Use with:

(No Intro)
Mega Man 4 (USA).nes
ROM Checksum: 7daebae488795835f962e875ee1f75e8
CRC32 Checksum: 49DF22C4