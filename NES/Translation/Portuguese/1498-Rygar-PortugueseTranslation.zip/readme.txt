Use with:

Rygar (USA) (Rev 1).nes (No Intro)
ROM Checksum: 8b50dea3b7ae2cb8bc91f6197fcd6079
CRC32 Checksum: 930A783D