Use with:

Final Fantasy (USA).nes (No Intro)
V14-/V15+ RA Checksum: 24ae5edf8375162f91a6846d3202e3d6
ROM Checksum: 9b0f042cfdc5f9e8200b47104a4768a9
CRC32 Checksum: AB12ECE6