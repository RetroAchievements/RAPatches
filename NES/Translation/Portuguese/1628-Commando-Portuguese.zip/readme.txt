Use with:

Commando (USA).nes (No Intro)
ROM Checksum: 8da183ec734fba08ad906949ba330efd
CRC32 Checksum: D68EF22A