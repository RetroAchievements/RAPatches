Use with:

(No Intro)
Akumajou Densetsu (Japan).nes
cec72ea12b1e5c1798631c9024410f65
2EAD04C5