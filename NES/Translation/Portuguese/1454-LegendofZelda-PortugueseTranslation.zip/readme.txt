Use with:

Legend of Zelda, The (USA).nes (No Intro)
V14-/V15+ RA Checksum: d9a1631d5c32d35594b9484862a26cba
ROM Checksum: 337bd6f1a1163df31bf2633665589ab0
CRC32 Checksum: D7AE93DF