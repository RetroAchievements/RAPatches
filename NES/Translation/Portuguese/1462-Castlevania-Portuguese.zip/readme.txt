Use with:

(No Intro)
File:               Castlevania (USA) (Rev 1).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              12A6CB14
MD5:                A1B849F232781D0E929435DF447822B5
Headless MD5:       728E05F245AB8B7FE61083F6919DC485