Use with:

Adventure Island II (USA).nes (No-Intro)
c55034ca190c9ba87b9a4a9cb9f3284d
CCA56A6F
