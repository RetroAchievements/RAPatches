Use with:

1943 - The Battle of Midway (USA).nes (No Intro)
ROM Checksum: 3948924cefe485a5f52fe7af4e3abd25
CRC32 Checksum: 46F660C9