Use with:

(No Intro)
Mega Man 6 (USA).nes
ROM Checksum: 7a3fbab64ed19a5d5e08c38654af37aa
CRC32 Checksum: FA9EC0C4