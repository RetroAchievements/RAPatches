Use with:

(No Intro)
File:               Circus Charlie (Japan).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              963DD3C3
MD5:                0D5260519C3DA652A980C8F2581FDADA
Headerless MD5:     67342016DAFC69887D0FF24ED2A7AEFF