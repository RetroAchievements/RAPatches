Use with:

DuckTales 2 (USA).nes
ROM Checksum: a7f36933b432856ad073aed8673b750c
CRC32 Checksum: D709F01C