Use with:

Fire Emblem Gaiden (Japan).nes (No-Intro)
80eb5117de63422898c3e80eb8745bac
0A187CB4
