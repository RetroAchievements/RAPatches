Use with:

Nightmare on Elm Street, A (USA).nes (No Intro)
V14-/V15+ RA Checksum: 5f62fab71cf3f8e90ac3af2775c8d630
ROM Checksum: 2a13dab59e7545d39117439e738e48ba
CRC32 Checksum: 2A83DDC5