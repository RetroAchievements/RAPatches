Use with:

Bionic Commando (USA).nes (No Intro)
V14-/V15+ RA Checksum: 36f9c268d5152085c914eb732392848e
ROM Checksum: e2c5df63af6617474b3338f968a21ffb
CRC32 Checksum: 1B2BAD13