Use with:

(No Intro)
Micro Machines (USA) (Aladdin Compact Cartridge) (Unl).nes
5a985e55e8bbc2b0bfcb5bf15a94bb0e
45705BDC