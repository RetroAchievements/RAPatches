Use with:

(No Intro)
Ike Ike! Nekketsu Hockey-bu - Subette Koronde Dairantou (Japan).nes
26d654a0c0e658ac7728adf2f3f50899
942F2511
