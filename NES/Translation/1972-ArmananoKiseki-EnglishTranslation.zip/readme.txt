Use with:

1. No-Intro verified dump:
Armana no Kiseki (Japan).fds
CRC32: EC6D5DE3
MD5: 98ac12e7f11b0aaf082c9cf45103c430
SHA-1: 93d8d3b4b74fe087cc31b75aee2607ecc7a1d2dd 

2. Third party bad dump, base rom used by the original patch:
Armana no Kiseki (Japan).fds
CRC32: BB32BBD7
MD5: 80e3dfaa9dfc3304506b6f103aa8bcc4
SHA-1: 2a8cc598e252df860cfe7768ca9a90b2256ddd7d 