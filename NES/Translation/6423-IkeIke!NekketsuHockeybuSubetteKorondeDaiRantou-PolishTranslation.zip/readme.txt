Use with:

Ike Ike! Nekketsu Hockey-bu - Subette Koronde Dairantou (Japan).nes (No Intro)
V14-/V15+ RA Checksum: 88a2648e02e69d28108817481250da66
ROM Checksum: 84731d4572a99d3d0b91840b63a50b58
CRC32 Checksum: 659021A1