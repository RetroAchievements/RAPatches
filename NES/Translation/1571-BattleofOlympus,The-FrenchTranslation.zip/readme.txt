Use with:

Battle of Olympus, The (Europe).nes (No Intro)
V14-/V15+ RA Checksum: abf97d9e3e1c97efd93fb90be6824e89
ROM Checksum: 99fdf4b85d42f87e7b3570048dbcddbe
CRC32 Checksum: 7BB5F30D