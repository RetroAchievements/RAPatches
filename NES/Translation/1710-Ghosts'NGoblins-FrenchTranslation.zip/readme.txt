Use with:

Ghosts'n Goblins (USA).nes (No Intro)
V14-/V15+ RA Checksum: 8c3c9b041392f8ef06f6b0c7432c589c
ROM Checksum: 6dd3872fff67b4f324a740aa87ac2b93
CRC32 Checksum: 87ED54AA