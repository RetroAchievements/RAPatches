Use with:

(No Intro)
File:               Portopia Renzoku Satsujin Jiken (Japan).nes
BitSize:            320 Kbit
Size (Bytes):       40976
CRC32:              0633BA05
MD5:                8BEA5C0A89DD03E3EFF01425A48AE05F
Headerless MD5:     24F1D824A2E187603A22AF0C4612EE5F