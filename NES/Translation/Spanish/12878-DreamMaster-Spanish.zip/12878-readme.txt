Use with:

(No Intro)
Namco Prism Zone - Dream Master (Japan).nes
7c3fcf66917c7e176407a7c29a4f7a62
7906BDC7