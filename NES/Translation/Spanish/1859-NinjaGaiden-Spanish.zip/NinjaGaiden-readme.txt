Use with:

(No Intro)
Ninja Gaiden (USA).nes
ROM Checksum: 15c46b30c216086d1f215977a1019691
CRC32 Checksum: 80D3B95E