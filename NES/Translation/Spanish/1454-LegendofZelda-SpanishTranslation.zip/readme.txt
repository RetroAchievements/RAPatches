Use with:

Legend of Zelda, The (USA).nes (No Intro)
ROM Checksum: 337bd6f1a1163df31bf2633665589ab0
CRC32 Checksum: D7AE93DF

Use with:

Legend of Zelda, The (USA) (Rev 1).nes (No Intro)
ROM Checksum: f4095791987351be68674a9355b266bc
CRC32 Checksum: 02BB0C56