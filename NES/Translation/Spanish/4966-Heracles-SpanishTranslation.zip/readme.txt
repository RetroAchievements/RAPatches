Use with:

(No Intro)
File:               Heracles no Eikou - Toujin Makyou Den (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              15985F55
MD5:                0C66D59C5C4E00CA5A99FBE30627ECEE
Headerless MD5:     B649DF6B089F0C486624AF492CEFB667