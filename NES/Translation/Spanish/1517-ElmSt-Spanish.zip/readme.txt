Use with:

Nightmare on Elm Street, A (USA).nes (No Intro)
ROM Checksum: 6e2bea2f28a368e36c30dad9486fbf4b
CRC32 Checksum: 55E284DA