Bienvenido al readme, el juego "Captain Tsubasa" esta traducido al 99%, quise subirlo rapido para 
que lo juegen y al menos puedan ver parte de la trama (como en el manga) y algunas cositas exclusivas de este juego
de la serie.

por si algunos nombres no se ven bien (problema del espacio de caracteres) les dejo completo los nombres

1. Tetsuo Ishida
(Escuela Secundaria Minamiuwa)
(se parece a ishizaki XD)

2. Kazuto Takei

Prefectura de Ehime
 Escuela secundaria Minamiuwa

3. Makoto Souda, Prefectura de Osaka Escuela 
secundaria Azumaichi DF (Todo Japón Jr. Juvenil DF)

4. Hiroshi Jito

Prefectura de Nagasaki
Hirado Junior High School
DF

Japon Jr.
DF

5. Hikaru Matsuyama

Hokkaido
Furano Junior High School
 MF

Todo Japón Jr. Juvenil
DF

6. Kojiro Hyuga
Tokyo

Toho
Gakuen Junior High School
 CF

All Japan Jr. Youth
CF

7. Kazuki Sorimachi
Tokio

Toho
Gakuen Junior High School
 FW

All Japan Jr.
Suplente juvenil

8. Takeshi Sawada

Tokio Toho
Gakuen Junior High School
 MF

All Japan Jr.
Suplente juvenil

9. Ken Wakashimazu
Tokio

Toho
Gakuen Junior High School
 GK

Japon Jr.
GK

10. Genzo
Wakabayashi


Japon Jr.
Suplente juvenil (GK)

11. El Cid Pierre


Francia Jr. Mediocampista
Juvenil

12. Karl Heinz
Schneider


Alemania Occidental
Jr. Juvenil
CF

13. Hermann Kalz Centrocampista juvenil


de Alemania Occidental

14. Franz Schester Centrocampista juvenil


de Alemania Occidental

15. Manfred
Margus Delantero Juvenil Jr.


de Alemania Occidental

16. Deuter Muller


Alemania Occidental
Jr.
Portero juvenil

17. Sharana

Portugal
Jr.
Mediocampista Juvenil

18. Macher

Polonia
Jr. Juvenil
FW

personajes femeninas: Sanae Nakazawa, Yayoi Aoba, Kumi Sugimoto, Azumi
Hayakawa.

19. Munemasa Katagiri

20. Roberto Hongo
(Roberto Hongo).

Gracias por informarte, espero que te haya servido, seguire con mas proyectos, chau!