Use with:

v1.2 (Wave)
(No Intro)
File:               Kid Klown in Night Mayor World (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              A474CCAC
MD5:                220AF5AB6C61A21582FFDB86690A72EC

v1.1 (Wave)
(No Intro)
File:               Mickey Mouse III - Yume Fuusen (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              8AD9A9BE
MD5:                81EC831FB959C1F8BA7945D8D5869F60

