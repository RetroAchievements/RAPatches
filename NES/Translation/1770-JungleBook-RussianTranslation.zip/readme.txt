Use with:

Jungle Book, The (USA).nes (No Intro)
RA Checksum: 36108cbd6c4bc09aa39f6eb9dc72150a
ROM Checksum: 6b15c1e79af6091cf04220b2b3aa99ba
CRC32 Checksum: 4B849368