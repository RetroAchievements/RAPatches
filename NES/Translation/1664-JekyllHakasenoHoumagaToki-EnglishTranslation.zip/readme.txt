Use with:

Houma ga Toki (Japan).nes (No Intro)
V14-/V15+ RA Checksum: 50b9ecc2af9f0a3c13917486ac9643dc
ROM Checksum: dfe9bd158718eaf176b3f4b6415aa5b3
CRC32 Checksum: A5B34384