Use with:

(No Intro)
Gun.Smoke (USA).nes
ROM Checksum: 071cee3611e37dfb58fab341bed5e8c6
CRC32 Checksum: FC48FC3C

Gun.Smoke (Europe).nes
ROM Checksum: 621fd9d940c8491103245dde437581ac
CRC32 Checksum: A32F885C