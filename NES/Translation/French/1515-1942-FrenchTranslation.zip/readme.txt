Use with:

JJ (Japan).nes (No Intro)
V14-/V15+ RA Checksum: ce4d5bda746a72e02fcfd547492551bc
ROM Checksum: 922b994012a7da34d55119e94a93d463
CRC32 Checksum: 8093EC6F