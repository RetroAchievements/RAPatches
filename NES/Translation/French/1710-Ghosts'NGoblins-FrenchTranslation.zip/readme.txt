Use with:

Ghosts'n Goblins (USA).nes (No Intro)
ROM Checksum: 80dcd911aaa221fd3de883d5128eb97c
CRC32 Checksum: 102A8B76