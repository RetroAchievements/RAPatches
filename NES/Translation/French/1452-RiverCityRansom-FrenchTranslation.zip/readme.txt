Use with:

River City Ransom (USA).nes (No Intro)
V14- RA Checksum: 8c301b400fb93fe75fec1087dbadc7cc
V15+ RA Checksum: 439a3420552a300089ddef13b7e83765
ROM Checksum: 294e4fa092db8e29d83f71e137d1f99f
CRC32 Checksum: C3508F7E