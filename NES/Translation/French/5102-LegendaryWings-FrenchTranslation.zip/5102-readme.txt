Use with:

Legendary Wings (USA).nes (No-Intro)
7fddfd4a58335f17dccf86209077c885
06D74045
