Use with:

(No-Intro)
RoboCop (USA).nes
91a7b30e34b650dd317876cee184d7d9
A294B655