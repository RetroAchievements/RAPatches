Use with:

Trojan (USA).nes (No Intro)
ROM Checksum: 1c378fb8d78877c997437dc2b25d475a
CRC32 Checksum: 58F0506E