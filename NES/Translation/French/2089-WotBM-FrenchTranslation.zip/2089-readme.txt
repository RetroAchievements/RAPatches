Use with:

(No Intro)
Wrath of the Black Manta (USA).nes
fcb7fa2bb16fa07a600b0a78955e4ad8
0AC8F20B