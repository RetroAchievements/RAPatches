Use with:

Rad Racer (USA).nes (No-Intro)
290050da1c45f29daed877c7e14330d9
DC03411A
