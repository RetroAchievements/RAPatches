Use with:

Maniac Mansion (USA).nes (No Intro)
V14-/V15+ RA Checksum: 3905799e081b80a61d4460b7b733c206
ROM Checksum: 8ccb428390b2ac83744b36bfc98e3ff6
CRC32 Checksum: 68309D06