Use with:

Battle of Olympus, The (Europe).nes (No Intro)
ROM Checksum: 7a9b241d305b8592f5c31d2030bdf0fd
CRC32 Checksum: BE68177D