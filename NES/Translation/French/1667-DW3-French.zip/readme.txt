Use with:

Dragon Warrior III (USA).nes (No Intro)
ROM Checksum: 5f585a1c9d855a585e7fc92309f844dd
CRC32 Checksum: 5716BD04