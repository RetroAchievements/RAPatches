Use with:

(No Intro)
Wacky Races (USA).nes
ROM Checksum: d4a7276cda69dd2d2fee8a736ed2bc6e
CRC32 Checksum: FBACC3CD