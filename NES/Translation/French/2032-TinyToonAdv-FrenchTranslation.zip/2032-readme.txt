Use with:

(No-Intro)
Tiny Toon Adventures (USA).nes
5eec30f2589a2b0bc600ee448236f66f
2264393E