Use with:

Super Pitfall (USA).nes (No Intro)
ROM Checksum: 177d2ed56cacb4a4dd0892605a817b02
CRC32 Checksum: 33525FFC