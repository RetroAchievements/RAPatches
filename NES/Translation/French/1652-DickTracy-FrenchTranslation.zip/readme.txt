Use with:

Dick Tracy (USA).nes (No Intro)
ROM Checksum: 9ff88ff18b0a4b8a51bf7776f4bcf1f4
CRC32 Checksum: 73F6CCB1