Use with:

(No Intro)
File:               Ice Climber (USA, Europe, Korea).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              70044A74
MD5:                D35F9979F206897DF94FB5425E23FC85
Headerless MD5:     C9C94DF2EBB19BD6D717B2CFBF977574