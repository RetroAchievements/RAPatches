Use with:

Bionic Commando (USA).nes (No Intro)
ROM Checksum: 2d5d6b062716385da2ab59c2a005c29d
CRC32 Checksum: 5D78010D