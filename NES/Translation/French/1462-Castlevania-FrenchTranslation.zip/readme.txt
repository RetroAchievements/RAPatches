Use with:

(No Intro)
Castlevania (Europe).nes
7da16a9ec10426363df22ae3a0fbbc91
4D782455