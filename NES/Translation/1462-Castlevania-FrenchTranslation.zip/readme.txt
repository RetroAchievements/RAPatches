Use with:

Castlevania (Europe).nes (No Intro)
V14-/V15+ RA Checksum: ab930e91eb9bb51e8acbf7bf2187f369
ROM Checksum: 10faa6e18bd5574932ec07cadaee0471
CRC32 Checksum: 9A3CF4D6