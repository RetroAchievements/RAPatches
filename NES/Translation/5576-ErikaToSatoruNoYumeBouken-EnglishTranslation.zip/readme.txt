Use with:

No Intro
Erika to Satoru no Yume Bouken (Japan).nes
e9393cf6e90f5a59bedf4232e81cea60
1E6A5A77