Use with:
Ninja Ryuuken Den (Japan).nes (No-Intro)
RA Hash b0430c155e39e89cbba8f3d143027387
