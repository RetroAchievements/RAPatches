Use with:

Final Fantasy II (Japan).nes (No Intro)
RA Checksum: 374ed97be8bfd628f6b359a720549ecd
ROM Checksum: 74669f264df775499830f9e6fb60a1e7
CRC32 Checksum: B7327510