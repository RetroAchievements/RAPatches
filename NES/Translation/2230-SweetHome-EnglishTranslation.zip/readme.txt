Use with:

Sweet Home (Japan).nes (No Intro)
V14-/V15+ RA Checksum: c2195553173ad11c978f49c45ecac49c
ROM Checksum: 49dd966e8a0e17bae16bc3d393c9d742
CRC32 Checksum: 40803BC5