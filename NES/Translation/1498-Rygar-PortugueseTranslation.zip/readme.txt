Use with:

Rygar (USA) (Rev A).nes (No Intro)
V14-/V15+ RA Checksum: 50dd77437fafae2ddf89dc6b8967b494
ROM Checksum: 527cc09ab3a503372abbbf567b76db46
CRC32 Checksum: 04CDA7E1