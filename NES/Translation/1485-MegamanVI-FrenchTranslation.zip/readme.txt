Use with:

Mega Man 6 (USA).nes (No Intro)
V14-/V15+ RA Checksum: 00f8cbeba7db567d1083053b30a93ada
ROM Checksum: 37bb1a39a69bc6d1bccae0dd5411330d
CRC32 Checksum: 1EFCAC48