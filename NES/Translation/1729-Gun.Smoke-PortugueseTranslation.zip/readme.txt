Use with:

Gun.Smoke (USA).nes (No Intro)
V14-/V15+ RA Checksum: 20291670aa8d77217fbc0c7dcdc45250
ROM Checksum: b7323d5cf56f4049e20d44815ca6c45a
CRC32 Checksum: 6B8F23E0