Use with:
Dragon Ball - Daimaou Fukkatsu (Japan).nes (No-Intro, iNES header)
CRC32: beff8c77
MD5: 8859146539c5f1e8c63ee607ed35f06e
RA: 603e5da6c292c5885ebc70e11c4cf5f4
