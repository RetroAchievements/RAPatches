Use with:

(No-Intro)
Final Fantasy III (Japan).nes
ec81c6820151ff0e148840cc56f9a520
4EA1E076
