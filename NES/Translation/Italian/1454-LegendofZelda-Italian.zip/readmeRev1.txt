Use with:

Legend of Zelda, The (USA) (Rev 1).nes (No Intro)
ROM Checksum: f4095791987351be68674a9355b266bc
CRC32 Checksum: 02BB0C56