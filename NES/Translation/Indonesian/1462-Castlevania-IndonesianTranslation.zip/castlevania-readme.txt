Use with:

(No Intro)
File:               Castlevania (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              AE0FA667
MD5:                379DE955AF1C8F3AE231783831793B8A
Headless MD5:       756170BA1E06FA26C60D10114DC6A5AE