Use with:

Crisis Force (Japan).nes (No Intro)
RA Checksum: 836b1dcd4b31889d0eab3081329b7529
ROM Checksum: 4cda9b5f7d06f336a3434c9e1adc1c2e
CRC32 Checksum: C4520781