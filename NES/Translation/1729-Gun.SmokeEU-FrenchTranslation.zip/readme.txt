Use with:

Gun.Smoke (Europe).nes (No Intro)
V14-/V15+ RA Checksum: f92df93c9d4c9428fe28e410d05c3569
ROM Checksum: 0afac1fc6b286dea9cb37b6cf8854d40
CRC32 Checksum: 746B58DF