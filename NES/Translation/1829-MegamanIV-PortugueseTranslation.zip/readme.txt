Use with:

Mega Man 4 (USA).nes (No Intro)
V14-/V15+ RA Checksum: db45eb9413964295adb8d1da961807cc
ROM Checksum: 7521eb54199f73cb04e1ccdd15ca971d
CRC32 Checksum: ADBD4E48