Use with:

Commando (USA).nes (No Intro)
V14-/V15+ RA Checksum: 7667cebf11c3d7a39575af91606bf412
ROM Checksum: 04763afda47b3d10375059c7dbed8bd2
CRC32 Checksum: 41492DF6