Use with:

Solstice - The Quest for the Staff of Demnos (USA).nes (No Intro)
V14-/V15+ RA Checksum: 79130862501091b3923e71af3cfc3032
ROM Checksum: a42e31d875d0573ba858de365628f608
CRC32 Checksum: 1D60732E