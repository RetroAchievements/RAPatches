Use with:

(No Intro)
Mega Man 2 (USA).nes
302761a666ac89c21f185052d02127d3
80e08660