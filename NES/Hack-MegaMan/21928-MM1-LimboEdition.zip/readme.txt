Use with:

(No Intro)
File:               Mega Man (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              A46011A0
MD5:                E5A3A1305D9CFD6CACE48097A0621F36
Headerless MD5:     4DE82CFCEADBF1A5E693B669B1221107