Use with:

Rockman 2 - Dr. Wily no Nazo (Japan).nes (No-Intro)
770d55a19ae91dcaa9560d6aa7321737
30B91650
