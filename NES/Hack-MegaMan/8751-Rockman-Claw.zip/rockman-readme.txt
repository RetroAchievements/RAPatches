Use with:

(No Intro)
File:               Rockman (Japan) (En).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              77D3C5F8
MD5:                31B6014705C24CC87DDE2273278F1CD0
SHA1:               A62F997DA28E2776DC4FE7B6A32F9179E971E4C0

Headerless Data:
CRC32:              D31DC910
MD5:                8D5A61F42D92EE61D05083263A11FCA1