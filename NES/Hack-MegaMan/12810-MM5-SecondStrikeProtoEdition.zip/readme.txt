Use with:

(No Intro)
File:               Mega Man 5 (USA).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              5E023291
MD5:                D7D22BF9EDFB16469975F7F4D8DA518F
Headerless MD5:     4482FBBBC77E03266B979F5028D4B51D