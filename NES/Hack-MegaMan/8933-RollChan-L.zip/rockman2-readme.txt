Use with:

(No Intro)
File:               Rockman 2 - Dr. Wily no Nazo (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              EE7F1751
MD5:                4C992BBDDCC0702E531EB8C9DAD78E53

Headerless Data:
CRC32:              6150517C
MD5:                770D55A19AE91DCAA9560D6AA7321737