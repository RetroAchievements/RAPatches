Use with:

Rockman (Japan) (En).nes (No-Intro)
8d5a61f42d92ee61d05083263a11fca1
E0141A24
