Use with:

(No Intro)
Mega Man (USA).nes
8cfaa33b1ec522ce89ab82af2dd17da7
ca2ab7e2