Use with:

Mega Man 4 (USA).nes (No-Intro)
db45eb9413964295adb8d1da961807cc
FC88B9FD
