Use with:

(No Intro)
File:               Rockman 2 - Dr. Wily no Nazo (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              EE7F1751
MD5:                4C992BBDDCC0702E531EB8C9DAD78E53