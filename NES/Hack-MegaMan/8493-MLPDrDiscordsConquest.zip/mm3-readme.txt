Use with:

(No Intro)
Mega Man 3 (USA).nes
6c591b7228fd31cbe0bf49243c012095
45134a3e