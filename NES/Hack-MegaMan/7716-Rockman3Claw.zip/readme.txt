Use with:

(No Intro)
File:   Rockman 3 - Dr. Wily no Saigo! (Japan).nes
CRC32:  FCD80415
MD5:    B24D6FB41B89A7575093BA27882EC018