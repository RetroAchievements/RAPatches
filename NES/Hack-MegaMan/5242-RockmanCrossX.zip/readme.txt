Use with:

Rockman 5 - Blues no Wana! (Japan).nes
433e0032be55a0ef23e7e67311977fe6
9D01E44C