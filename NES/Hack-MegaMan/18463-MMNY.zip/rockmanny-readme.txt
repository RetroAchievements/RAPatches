Use with:

(No Intro)
File:               Rockman (Japan) (En).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              77D3C5F8
MD5:                31B6014705C24CC87DDE2273278F1CD0
SHA1:               A62F997DA28E2776DC4FE7B6A32F9179E971E4C0

Headerless Data:
CRC32:              D31DC910
MD5:                8D5A61F42D92EE61D05083263A11FCA1



(No Intro)
File:               Rockman 5 - Blues no Wana! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              7E9259BF
MD5:                A850E746C243B873C6E558605B378908

Headerless Data:
CRC32:              FDDF2135
MD5:                328F55E3BEFF0B28A0DF4D5AB7CFCD3A



(No Intro)
File:               Rockman 6 - Shijou Saidai no Tatakai!! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              4F7F15F5
MD5:                D9A4EED8B3C13A6BD74B2E9D20385AFB

Headerless Data:
CRC32:              2D664D99
MD5:                5F7C75797B9FC649029FBFFFFBFD5DCD