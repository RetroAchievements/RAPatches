Use with:

(No Intro)
File:               Journey to Silius (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              1E5D2648
MD5:                03779FC352A51B1594445E587F99AFAE