Use with:

(No Intro)
File:               Mappy (Japan).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              7354615C

Headerless Data:
CRC32:              5D1301C5
MD5:                87ECD2CC23DE21FFD69439DB9A1CA778