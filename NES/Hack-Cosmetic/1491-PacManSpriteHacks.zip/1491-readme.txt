Use with:

(No Intro)
File:               Pac-Man (USA) (Namco).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              15D202D8
MD5:                3DDCA58C51DD38D59F9271D24E7105F9

Headerless Data:
CRC32:              9E4E9CC2
MD5:                CA606BD8A875A396D52735C3BB84FA67 (RAHASH)