Use with:

(No Intro)
Moai-kun (Japan).nes
61ce9019cb8e94dbe160024d33e6ceb8
8D76A40E