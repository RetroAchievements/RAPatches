Use with:

(No Intro)
Zelda II - The Adventure of Link (USA).ness
ROM Checksum: e6dd4104fa46eb4bef2cb52dc341dd38
CRC32 Checksum: 861C3FE6
