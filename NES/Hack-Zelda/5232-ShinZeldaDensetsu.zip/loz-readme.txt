Use with:

(No Intro)
File:               Legend of Zelda, The (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              F6AB7C20
MD5:                37E2240A75B51B7B517F0E8350488A7B