File to Patch to;

The Legend of Zelda (USA)
RA Hash: d9a1631d5c32d35594b9484862a26cba