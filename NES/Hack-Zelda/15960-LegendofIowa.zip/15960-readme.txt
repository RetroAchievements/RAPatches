Use with:

(No Intro)
Legend of Zelda, The (USA).nes
4156f66c0fac36222b5a1da05db85d68
316cff69