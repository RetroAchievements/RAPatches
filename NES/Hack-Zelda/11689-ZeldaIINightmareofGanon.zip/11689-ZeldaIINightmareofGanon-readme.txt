Use with:

Zelda II - The Adventure of Link (USA).nes (No-Intro)
88c0493fb1146834836c0ff4f3e06e45
E3C788B0
