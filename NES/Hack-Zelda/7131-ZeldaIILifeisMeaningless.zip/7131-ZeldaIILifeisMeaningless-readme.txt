Use with:

Legend of Zelda, The (USA).nes (No-Intro)
d9a1631d5c32d35594b9484862a26cba
F6AB7C20
