Use with:

(No Intro)
File:               Legend of Zelda, The (USA) (Rev 1).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              E47960E0
MD5:                614FB3085826E62F3BE3A3FE0B931689

File:               Legend of Zelda, The (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              316CFF69
MD5:                4156F66C0FAC36222B5A1DA05DB85D68