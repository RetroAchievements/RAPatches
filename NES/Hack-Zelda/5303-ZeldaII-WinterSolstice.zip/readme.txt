Use with:

(No Intro)
Zelda II - The Adventure of Link (USA).nes
ROM Checksum: 764d36fa8a2450834da5e8194281035a
CRC32 Checksum: E3C788B0