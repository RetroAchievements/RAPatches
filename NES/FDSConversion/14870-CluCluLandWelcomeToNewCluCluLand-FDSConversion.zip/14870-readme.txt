Use with:

No Intro
Clu Clu Land (USA) (GameCube Edition).nes
MD5: 06b883c9fc6b9f4c1212a1cfd94d5eb5
CRC: 2132CD51

Original patch created by Morgan Johansson, found at https://www.romhacking.net/hacks/1327/