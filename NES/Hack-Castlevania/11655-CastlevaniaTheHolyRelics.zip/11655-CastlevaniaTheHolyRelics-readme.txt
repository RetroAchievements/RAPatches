Use with:

Castlevania (USA) (Rev A).nes (No-Intro)
728e05f245ab8b7fe61083f6919dc485
856114C8
