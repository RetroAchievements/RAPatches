Use with:

No Intro (Headered)
Castlevania (USA) (Rev 1).nes
52eb3f7e2c5fc765aa71f21c85f0770e
856114C8