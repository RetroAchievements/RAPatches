Use with:

(No Intro)
Castlevania (USA).nes
379de955af1c8f3ae231783831793b8a
ae0fa667