Use with:

Castlevania (USA) (Rev A).nes (No Intro)
V14-/V15+ RA Checksum: 728e05f245ab8b7fe61083f6919dc485
ROM Checksum: 52eb3f7e2c5fc765aa71f21c85f0770e
CRC32 Checksum: 856114C8