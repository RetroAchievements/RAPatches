Use with:

Bugs Bunny Birthday Blowout, The (USA).nes (No Intro)
RA Checksum: 7622e7d6a786eec7b09948e109c3400a
ROM Checksum: 96ae665d902eaa69c7a36979b7ef530d
CRC32 Checksum: 38FDB7F4