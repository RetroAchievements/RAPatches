Use with:

(No Intro)
File:               Armana no Kiseki (Japan).fds
BitSize:            1023 Kbit
Size (Bytes):       131000
CRC32:              EC6D5DE3
MD5:                98AC12E7F11B0AAF082C9CF45103C430

Change extension to ".nes" 