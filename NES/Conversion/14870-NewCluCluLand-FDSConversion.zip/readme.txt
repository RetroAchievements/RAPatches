Use with:

(No Intro)
File:               Clu Clu Land (World).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              22515E9E
MD5:                0050F76B0C51BE46BDF5AF19569EA253
Headerless MD5:     EEBA6EF8992074C5EBBDF0ECD9468E10

File:               Clu Clu Land (World) (GameCube Edition).nes
BitSize:            320 Kbit
Size (Bytes):       40976
CRC32:              2B3F6238
MD5:                6F4648032C2225D4900E174696549331
Headerless MD5:     1DE41E13A2E691A8CC13B757A46AE3B8

File:               Clu Clu Land (World) (Virtual Console).nes
BitSize:            192 Kbit
Size (Bytes):       24592
CRC32:              D6997EAF
MD5:                E8CDD3601C07F0A45C3BA9648EDC5976
Headerless MD5:     F4D4EB0E4D2CF398732BD462190CCDD0