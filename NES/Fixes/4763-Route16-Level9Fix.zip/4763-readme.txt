Use with:

(No Intro)
File:               Route-16 Turbo (Japan).nes
BitSize:            320 Kbit
Size (Bytes):       40976
CRC32:              114E118F
MD5:                D6B632DD54713077CCBD28150FEDA8D4