Use with:

(No Intro)
File:               Captain Comic - The Adventure (USA) (Unl).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              9357A157
MD5:                CCDB987E5F0DED02FD4FE31D81A52F97