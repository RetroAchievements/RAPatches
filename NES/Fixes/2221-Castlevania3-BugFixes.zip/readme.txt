Use with:

(No Intro)
File:               Castlevania III - Dracula's Curse (USA).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              7CF70CDE
MD5:                561999DAA97A1C30C81CAB5142A1D672

Headerless Data:
CRC32:              ED2465BE
MD5:                BFC4D9791D9FE9C181DAD794D66DEF4F