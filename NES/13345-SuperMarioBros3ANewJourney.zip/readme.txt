Use with:

Super Mario Bros. 3 (USA).nes
e4e0d4135bedd79d2f73b1ba31aee899
051DB4CA