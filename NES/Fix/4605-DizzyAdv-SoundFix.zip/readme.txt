Use with:

(No Intro)
File:               Dizzy the Adventurer (USA) (Aladdin Compact Cartridge) (Unl).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              96DC81C7
MD5:                0702F827D28226FABE030384BC404061