Use with:

(No Intro)
File:               Zuizhong Huanxiang X2 (China) (v1.0) (Aftermarket) (Pirate).nes
BitSize:            8 Mbit
Size (Bytes):       1048592
CRC32:              C9F2EAAB
MD5:                E9EDBD6998EA7933219D8894586D59CF
SHA1:               57808683BEEB4A364D76B4830D734D69FCA86391
SHA256:             53B0CDBEA53C44414839B70A808D5F893C0D14A297B036E27F348A8B8EFF39FE
Headerless MD5:     3939D4FE933B9390D802E0B925A3828E