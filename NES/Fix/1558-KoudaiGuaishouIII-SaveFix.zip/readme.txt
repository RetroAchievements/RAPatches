Use with:

(Lost Level Archive)
File:               Koudai Guaishou III - Pokemon Diamond III (China) (Bootleg).nes
BitSize:            8 Mbit
Size (Bytes):       1048848
CRC32:              725A7EAE
MD5:                964A77006AAD0F6FD098F89FE8ED8E34
SHA1:               186F739E271CA7D51B8401AA2570EDF21B14AEE9
SHA256:             F9D89E7E1EFEEF89DB7EBD5226C23B1ECFBA3E324F4F2230966ECE2B7A4D963E
Headerless MD5:     7FD412D83853297CD8D24A096FCC0E5B