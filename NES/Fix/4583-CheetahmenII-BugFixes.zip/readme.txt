Use with:

(No Intro)
[Cheetahmen II (USA) (Unl).nes]
[7DE9209BADB217F4F042FE1A09496030]
[10C7F6E8]