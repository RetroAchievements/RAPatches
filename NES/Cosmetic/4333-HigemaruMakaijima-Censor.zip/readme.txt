Use with:

(nointro)
File:               Higemaru - Makai-jima - Nanatsu no Shima Daibouken (Japan).nes
Size (Bytes):       131088
CRC32:              534734b1  
MD5:                a1233b8a1fdb8be3a3a8a8617fe720f8
SHA-1:              0b48dbdfd8fc93de71f3abf2664ad675ddf51762
SHA-256:            c52aa475af9a6370dd7652e6d0df82d7904bef5ffa09d010e83cdeb2b445e8c1