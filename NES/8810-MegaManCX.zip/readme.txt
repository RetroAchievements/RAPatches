Use with:

Mega Man 2 (USA).nes (No Intro)
f22aebc8cc8ab797851d9070b43ad091
81D3BE98