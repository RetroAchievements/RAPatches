Use with:

Yume Penguin Monogatari (Japan).nes (No-Intro)
e659890d46a5ac9a347e0b85b352f1d0
E1686577
