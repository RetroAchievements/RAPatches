Use with:

Darkwing Duck (USA).nes (No-Intro)
eb9713d1cac3586601833d8df854114e
307D0FC4

Darkwing Duck (U).nes
eb9713d1cac3586601833d8df854114e
C7E6CC19
