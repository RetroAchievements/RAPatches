Use with:

Cat Ninden Teyandee (Japan).nes (No-Intro)
d909ecf9d6deb7a35263e6aa6b2f0cfe
6F1485ED
