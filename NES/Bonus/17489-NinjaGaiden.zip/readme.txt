Compatible with any of the following No-Intro bases (verify individual support in the forum thread):
Ninja Gaiden (USA).nes
Ninja Gaiden (USA) (Beta).nes
Ninja Ryuuken Den (Japan).nes
Ninja Ryuuken Den (Japan) (Wii Virtual Console).nes
Ninja Gaiden (Japan) (Wii U Virtual Console).nes
Shadow Warriors - Ninja Gaiden (Europe).nes
Shadow Warriors - Ninja Gaiden (Europe) (Virtual Console).nes
