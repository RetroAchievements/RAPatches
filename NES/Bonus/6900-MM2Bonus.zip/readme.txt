Use with:

(No Intro)
Mega Man (USA).nes
md5: 8e4bc5b03ffbd4ef91400e92e50dd294
crc: 5E268761
RA hash: 0527a0ee512f69e08b8db6dc97964632