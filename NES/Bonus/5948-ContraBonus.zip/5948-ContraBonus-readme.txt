Use with:

Contra (USA).nes (No-Intro)
5a5c2f4f1cafb1f55a8dc0d5ad4550e5
C50A8304
