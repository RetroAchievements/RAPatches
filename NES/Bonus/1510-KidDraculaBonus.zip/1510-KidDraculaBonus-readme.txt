Use with:

Akumajou Special - Boku Dracula-kun (Japan).nes (No-Intro)
96084e640ed9a02c644b39986c269662
F916D969
