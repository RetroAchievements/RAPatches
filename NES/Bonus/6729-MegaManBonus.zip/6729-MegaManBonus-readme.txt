Use with:

Mega Man (USA).nes (No-Intro)
4de82cfceadbf1a5e693b669b1221107
5DED683E
