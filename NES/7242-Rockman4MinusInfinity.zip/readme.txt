Use with:

Rockman 4 - Aratanaru Yabou!! (Japan).nes
8b4b65d68dedc70a537505bda430dae9
771A9138