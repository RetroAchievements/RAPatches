Use with:

(No Intro)
File:               Final Fantasy (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              AB12ECE6
MD5:                9B0F042CFDC5F9E8200B47104A4768A9
Headerless MD5:     24AE5EDF8375162F91A6846D3202E3D6