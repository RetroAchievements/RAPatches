**INFO**

Welcome to 'Easy Mode' of the rom hack known as Dragoon X Omega II Final v2!
These are 'xdelta' patches so you'll need to grab an xdelta patcher (and possibly a GUI for it) to patch it up; there are several such utilities on RomHackingDotNet (RHDN) and Zophar's Domain

Two Patches are included
-DXO2 - Easy Mode Patch - 536 bytes - Created 16 Sept 2015
-DXO2 - EM Bosses Buffed Patch - 794 bytes - Created 16 Sept 2015

You need the NES version of the Final Fantasy 1 USA ROM in order to use any of these patches!
Where to get the ROM?  Use your imagination and think about it :P

Your ROM should have all of the following hashes match up:

Final Fantasy (USA).nes - NOINTRO
CRC32: AB12ECE6
MD5: 9B0F042CFDC5F9E8200B47104A4768A9
SHA-1: 80CE108FBC066C985D4FB541BD68E9A7C8994FEB
SHA-256: D360BEEEE19A69D1C92D02292167C57F2D3CA8405B79101FC8C2F39DEA549667

First, grab the Dragoon X Omega II (DXO2) patch from RHDN or another mirror (since author's website is 404)
Second, patch up the ROM with the DXO2 hack FIRST
Third, apply ONE of these xdelta patches to your DXO2 ROM file
Now you are ready to go.  Put it on a flash cart and enjoy it on your original NES system!  (or be a lamer and use an emulator)

And if anyone bothers to sell these as reproduction carts, may you forever have fecal matter coming out of your anus!


**CHANGES**

v1.0 -- 16 Sept 2015

Stats
-Doubled all starting stats; Evade is 75% base and Hit is 25% base
-Max possible HP/MP/stat gains with 'strong' stat gains every level
-Unlock new 'tier' of spells every 5 levels
-Max out all magic points at 9 each much sooner than normal; happens around Level 33 with 232425 exp total

EXP
-Needed XP to next level reduced by 50% for all levels
-Original required 989641 to get max level; now you need 494821 instead

Costs
-All costs of buyable items everywhere have been reduced by ~50%

Spells
-Aura has been granted a narrower range of ~7 variation for healing to make earlier levels more tolerable
-Auratap has been similarly buffed to have a narrower ~15 range instead of the usual range

Weapons
-Omega Rifle nerfed to only 75 hit% but now you start with base 25 hit% instead to reduce the frustration of missing too often in early levels

Helms
-All Helms edited have Evade Penalty scale up from 1 to 5 percent for the first 5 helms, then scale back down from 5 to 1 percent for the last 5 helms
-Power Helm now resists Poison
-Zeite Helm now resists Stun
-Regal Helm now PSI-resistant and resists Instant-Death
-Spline Helm now resists all PSI and status effects

Armors
-All Armors prior to Argus Armor now start at 5% Evade Penalty and increase by a steady 2% each time
-All Armors prior to Argus Armor now start at 5 DEF and increase by a steady 5 DEF each time
-Power Armor now casts Aura when used in combat
-Argus Armor buffed to have only 10% Evade Penalty instead of 19% and casts Aura when used in combat
-Myra Armor buffed to have 128 DEF rather than half the DEF of Argus; now you can use it as a viable clear upgrade
--Myra Armor was not as 'Psi Resistant' as you would think; it is now resistant to more Psi spells and instant death

Enemies
-All Bosses, SuperBosses & the Final Boss now have 10x health and increased stats to keep them from being total pushovers; some have also been granted a few new tricks to kill you with
-Feros, Samael, Baal, and Marduke are now considered minibosses and have been buffed accordingly!
-Due to possible 'difficulty cliff' with this issue I have made two versions of the patch both with and without the boss buffs; they are both included in the archive so choose your destiny!
-You gain 10x more EXP and Arca from defeating the harder versions, so it is well worth it!



**CREDITS**
-Me, obscurumlux01, for making this hack
-FFHackster is AWESOME!  Major kudos to Disch!  I was able to do in less than 24 hours what would've easily taken me WEEKS of hex editing & testing manually!
-You, for reading this far!
-Any rights not explicitly granted under 'Permissions' are reserved by me
-The Dragoon X Omega II Team for making such a fantastic rom hack!

The Dragoon X Omega II Team is:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Graphics/Level Design: Thaddeus
Scenario/Music/Gameplay/Programming: Sliver X
Programming: Gavin



**WARRANTY/DISCLAIMER**

By downloading/using this patch you hereby disclaim any and all liability and legal claims against myself for any reason at ANY point now or in the future for both yourself and any others who may inherit your estate or have attorney capability/power on your behalf.

If you do not agree to these terms and the permissions below, then you must immediately DELETE this patch and NEVER use it.



**PERMISSIONS**

I grant a perpetual royalty-free worldwide permission to use and mirror/publically distribute this patch for any NON-COMMERCIAL USE under the following conditions:

-Website and/or file hosting must NOT 'malvertising' such as: popups, popunders, 'heatmap' tracking, WebRTC IP unmasking, compromised advertising servers, flash advertisements (whether they auto-play or not), any banner ads larger than 128 x 64 pixels, any banner ads that animate more frequently than once every 5 seconds, and similar types of advertising not covered here but may still exclude a website from permission
--If in doubt, ask me to check out your website/host before mirroring this patch!

-DO NOT PLACE THIS PATCH ON ANY REPRODUCTION CART YOU DID NOT CREATE YOURSELF BY YOUR OWN KNOWLEDGE, SKILL, AND WITH TOOLS THAT YOU OWN!

-This patch may be publically performed by YouTubers and streamed freely without worries as long as the warranty and all other permissions are followed.  Such videos and multimedia content may be monetized without any royalty or other monetary obligations.

-The entirety of permissions to use this patch are NULL AND VOID unless ATTRIBUTION is given in all content that displays, distributes, or uses this patch by textual attribution to both the author of the DXO2 rom hack and myself for this patch.  Any multimedia content must include audio attribution as well as information in the Video Description area regarding where the patch was obtained.  A simple audio phrase can be spoken such as 'This Rom Hack is Dragoon X Omega Two and was created by the DXO2 Team of Thaddeus, Sliver X, and Gavin.  The Easy Mode hack was created by obscurumlux01 of Romhacking Dot Net'.



**CONTACT**

If you have questions, you may contact me via RHDN as obscurumlux01 or via e-mail as 'spammeplease_AT_caramail_DOT_COM'
If you are silly enough to e-mail me asking for a ROM; I will let you know just how much of a derp you are ;)