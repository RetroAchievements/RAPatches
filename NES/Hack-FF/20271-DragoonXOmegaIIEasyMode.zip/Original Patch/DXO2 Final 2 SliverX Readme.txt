    /-\______________________________/_\ 
   /   \$    Dragoon X Omega II    $/   \
  /  _  \$        FINAL 2         $/  _  \
 / -{X}- \$$$$$$$$$$$$$$$$$$$$$$$$/ -{X}- \
 \   -   /2008 Sliver X & Thaddeus\   -   / 
  \  |  /$$$$$$$$$$$$$$$$$$$$$$$$$$\  |  /
   \ | /$__________________________$\ | /
    \-/	                             \-/

############
#What It Is#
############

A full scale hack of Final Fantasy, nothing remains but the core programming routines.
It features all new graphics, music, levels, enemies, text, statistics and more. Think 
of it as a "Total Conversion" for the NES.

This is the utterly final release of the game. All known bugs are now truly fixed,
and the game has reached a level of polish I wish was attained at the v1.0 release
in 2006.

#######
#Usage#
#######

Apply Dragoon X Omega II (Final) (FF1 Hack).ips to the ROM named Final Fantasy (U) [!].nes with
the IPS patcher of your choice.

Usage of any other ROM dump of Final Fantasy may cause issues, as they have not been tested
and are not what the hack was based off of.


#############
#What's New?#
#############

See Changelog.txt for details.

#######
#Misc.#
#######

A palette file called Dragoon X Omega II (Final) (FF1 Hack).pal is included. While it is not needed to
play the game it will make it look much better, as the game's graphics were designed with it in mind.

Please consult the documentation of your NES emulator of choice for info on how to load external palettes.


#########
#Credits#
#########

The Dragoon X Omega II Team is:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Graphics/Level Design: Thaddeus
Scenario/Music/Gameplay/Programming: Sliver X
Programming: Gavin

Additional help was given by the following people:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
bitmaster: Found the fix for FFHackster's map corruption bug.
DahrkDaiz: Removed Nasir Gabelli's checksum code, fixed the Item use bug, and added the B Dash hack.
Dan: Provided help locating several assembly level issues.
Disch: Creator of FFHackster! Also fixed the sprite layer on dialogue box display and provided the animated water hack.
Kapow: Assisted in fixing some of the last remaining assembly bugs.
Lenophis: Fixed a couple of assembly bugs.
Vystrix Nexoth: Artist of the cursor, and provided much info that was of immeasurable help.


#########
#Contact#
#########

I (Sliver X) may be reached at the following address: panicus@gmail.com