Use with:

(No Intro)
File:               Final Fantasy (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              5C892F3B
MD5:                D111FC7770E12F67474897AAAD834C0C
Headerless MD5:     24AE5EDF8375162F91A6846D3202E3D6