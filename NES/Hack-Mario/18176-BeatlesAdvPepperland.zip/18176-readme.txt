Use with:

(No Intro)
Super Mario Bros. 2 (USA).nes
55f7030dc6173f2a0145a97f369f49f4
43507232