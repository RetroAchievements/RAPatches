Use with:

(No Intro)
File:               Super Mario Bros. 3 (USA).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              661019C6
MD5:                85F0DDDDFE4AB67C42ABA48498F42FDC
Headerless MD5:     B76F978AD3076EA67F2B0ACA7399C9E9