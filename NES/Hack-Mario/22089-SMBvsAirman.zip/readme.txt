Use with:

(No Intro)
File:               Super Mario Bros. (World).nes
BitSize:            320 Kbit
Size (Bytes):       40976
CRC32:              3337EC46
MD5:                811B027EAF99C2DEF7B933C5208636DE
Headerless MD5:     8E3630186E35D477231BF8FD50E54CDD