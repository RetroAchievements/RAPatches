use with:
Bugs Bunny Crazy Castle, The (USA).nes (No-Intro)
6BC8F54DC358AA35F6259715E5143B37
E50A9130