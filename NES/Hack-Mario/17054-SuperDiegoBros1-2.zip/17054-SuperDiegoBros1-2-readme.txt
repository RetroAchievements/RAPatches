Use with:

Super Mario Bros. (World).nes (No-Intro)
8e3630186e35d477231bf8fd50e54cdd
3337EC46

Super Mario Bros. (World).nes (No-Intro 2021) | Super Mario Bros. (World) (HVC-SM).nes (Recent Version)
8e3630186e35d477231bf8fd50e54cdd
006EA95A

