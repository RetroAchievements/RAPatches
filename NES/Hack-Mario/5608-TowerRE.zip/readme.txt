Use with:

Super Mario Bros. (World) (HVC-SM).nes
b6fa79abf0aa1bce8831c7c5ad8ab1f2
006EA95A