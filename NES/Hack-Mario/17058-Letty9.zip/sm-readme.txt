Use with:

(No Intro)
Super Mario Bros. (World).nes
393a432f
f94bb9bb55f325d9af8a0fff80b9376d