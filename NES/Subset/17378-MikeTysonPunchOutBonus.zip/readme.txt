Use with:

No Intro
Mike Tyson's Punch-Out!! (Japan, USA) (Rev 1).nes (Headered)
MD5 Checksum: c119a5a9b0e2959ad5d11562f9f4ce55
CRC Checksum: 3DF8E170

