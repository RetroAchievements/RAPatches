Use with:

(No-Intro)
Darkwing Duck (USA).nes
MD5: da86da29043284e236b5ece1c293c5ee
CRC: A157E56C