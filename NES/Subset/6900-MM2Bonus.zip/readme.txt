Use with:

(No Intro)
Mega Man 2 (USA).nes
md5: 302761a666ac89c21f185052d02127d3
crc: 80E08660