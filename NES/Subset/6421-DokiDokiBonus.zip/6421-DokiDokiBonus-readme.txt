Use with:

Doki!Doki! Yuuenchi - Crazy Land Daisakusen (Japan).nes (No-Intro)
8844e3d93e6bbe1abd973fe65e1781b6
97C3FAA2
