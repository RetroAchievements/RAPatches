Use with:

(No Intro)
File:               Battle of Olympus, The (USA) - clean.nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              B99394C3
MD5:                021D505BD7F5EA9101C33171FEEBDF3A
SHA1:               DC1ED05F850070CCD73DC1D0F52CDA0277A0EF05
SHA256:             A5832CC017A5AE484CF3BCC2F0829EAEF380D4876AB1F4DD22F2E5A9D8E956E6


