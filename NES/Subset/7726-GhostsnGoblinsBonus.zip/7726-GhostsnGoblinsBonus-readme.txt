Use with:

Makaimura (Japan).nes (No-Intro)
9346ebec7fb8c5c61f937ca46a096c69
8C3FE6FB
