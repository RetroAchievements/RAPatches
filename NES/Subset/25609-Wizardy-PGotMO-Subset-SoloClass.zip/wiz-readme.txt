Use with:

(No Intro)
File:               Wizardry - Proving Grounds of the Mad Overlord (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              E59540AF
MD5:                A3CEA0820E7F8702190E8B98ED16DCF5