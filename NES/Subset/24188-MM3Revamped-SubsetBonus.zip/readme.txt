Use with:

(No Intro)
File:               Mega Man 3 (USA).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              45134A3E
MD5:                6C591B7228FD31CBE0BF49243C012095

or

(No Intro + Patch)
File:               Mega Man 3 Revamped (v1.1) (TheSkipper1995).nes
BitSize:            6 Mbit
Size (Bytes):       786448
CRC32:              C3642ED1
MD5:                6C2D110B963CAC92F89268CB3EF2B9FC