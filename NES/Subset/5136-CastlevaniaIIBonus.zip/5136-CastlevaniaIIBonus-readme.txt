Use with:

Castlevania II - Simon's Quest (USA).nes (No-Intro)
87dae73b0c4c8fdeba8cf4209df87e2c
38E82FAB
