Use with:

Castlevania II - Simon's Quest (USA).nes (No-Intro)
755f9086b0567243b3ce25cc8a6dfd17
A9C2C503
