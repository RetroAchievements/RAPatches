Use with:

(No Intro)
File:               Doki! Doki! Yuuenchi - Crazy Land Daisakusen (Japan).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              06E9100A
MD5:                F849E6C16861DDA6094EE2DFA9CEB3E7