Use with:

(No Intro)
File:               Kings of the Beach - Professional Beach Volleyball (USA).nes
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              5C4D864E
MD5:                9E019C54864F6C4E7C4846B1A3546D25
SHA1:               F050BF9C78694332C27D7B9FDB9EF7150C30F45A
SHA256:             A38E9A8789230AF6312C9299199D52C625D3167C0C29960F1F9C0D723E3C62FB
Headerless MD5:     477380C53CA9EC486EB0DC5DFF0F2B1F