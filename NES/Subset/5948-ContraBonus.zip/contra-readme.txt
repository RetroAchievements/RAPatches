Use with:

(No-Intro)
Contra (USA).nes
MD5: cdf73714ff3ef47f4eeb2b71707be2a0
CRC: 52CD5CD8