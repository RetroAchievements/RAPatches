Use with:

(No Intro)
File:               Ninja Gaiden III - The Ancient Ship of Doom (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              BABD39FA
MD5:                569B3382638A1C9094E2C40B35F359C7
SHA1:               3F2E6DAC76BA14EFC177B5653AB043E53A04D365
SHA256:             49846B57FEE22AE0E3AD86DB5B9220F5F78B94317316135CBD71F12DE4FB6458