

Use with:

Doki!Doki! Yuuenchi - Crazy Land Daisakusen (Japan).nes (No-Intro)
f849e6c16861dda6094ee2dfa9ceb3e7
06E9100A
