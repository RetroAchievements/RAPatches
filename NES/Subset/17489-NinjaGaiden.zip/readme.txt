Use with:

Ninja Gaiden (USA).nes (No Intro)
ROM Checksum: 0c2cccda6ba6cab7bede0ff05e7f6852
CRC32 Checksum: 11F953F6

Ninja Ryuuken Den (Japan).nes (No Intro)
ROM Checksum: 8cba2ce8b55408b6c8cd1387467abc07
CRC32 Checksum: BA7818A1

Ninja Ryuuken Den (Japan) (Wii Virtual Console).nes (No Intro)
ROM Checksum: 34192f3c5f4e61de7b9fe7c1e8d0c865
CRC32 Checksum: 120cf477

Ninja Gaiden (Japan) (Wii U Virtual Console).nes (No Intro)
ROM Checksum: 7cd36a6018297f90e8d085133cd58bdf
CRC32 Checksum: 6d58ca57