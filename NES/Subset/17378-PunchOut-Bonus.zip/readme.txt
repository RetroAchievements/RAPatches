Use with:

No Intro
File:               Mike Tyson's Punch-Out!! (Japan, USA) (En) (Rev 1).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              ACD20BD8
MD5:                2E3D646EECBCDB6E7DA3D0A6EDFB325B

Headerless Data:
CRC32:              2C818014
MD5:                5BC7FAC06E58FDA15FD981FD03572C34

