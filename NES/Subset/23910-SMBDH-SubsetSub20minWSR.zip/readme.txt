Use with:

(No Intro)
File:               Super Mario Bros. + Duck Hunt (USA).nes
BitSize:            640 Kbit
Size (Bytes):       81936
CRC32:              ECF8416F
MD5:                64DE01B0E87C86E096A69EB31AB04001