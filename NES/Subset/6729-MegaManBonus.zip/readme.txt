Use with:

(No-Intro)
Mega Man (USA).nes
MD5: 8cfaa33b1ec522ce89ab82af2dd17da7
CRC: CA2AB7E2