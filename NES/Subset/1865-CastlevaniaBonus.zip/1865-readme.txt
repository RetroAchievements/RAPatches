Use with:

(No-Intro)
Castlevania (USA).nes
MD5: 379de955af1c8f3ae231783831793b8a
CRC: AE0FA667