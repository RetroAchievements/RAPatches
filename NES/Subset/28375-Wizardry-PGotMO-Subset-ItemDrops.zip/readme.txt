Use with:

(No Intro)
File:               Wizardry - Proving Grounds of the Mad Overlord (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              D9BB572C
MD5:                9CEE61A4394001CED4A2D2E8B08FF627
Headerless MD5:     227672ACA26C27DEF9C0FCF61B3B5F4D