Use with:

No Intro
Final Fantasy (USA).nes
MD5: 24ae5edf8375162f91a6846d3202e3d6
CRC: AB12ECE6