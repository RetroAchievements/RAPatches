Use with:

No Intro
Final Fantasy (USA).nes
MD5: 9b0f042cfdc5f9e8200b47104a4768a9
CRC: AB12ECE6