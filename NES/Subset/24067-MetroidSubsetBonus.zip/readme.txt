Use with:

File:               Metroid (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              D1A02CAB
MD5:                397D10E475266AD28144A5FA6EC3C466