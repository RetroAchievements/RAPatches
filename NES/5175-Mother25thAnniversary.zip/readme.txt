Use with:

EarthBound Beginnings (USA, Europe) (Virtual Console).nes (No Intro)
5bacf7ba94c539a1caf623dbe12059a3
F5EF5002