Use with:

Mega Man 3 (USA).nes (No Intro)
75b924155cafee335c9ea7a01bfc8efb
452D8089