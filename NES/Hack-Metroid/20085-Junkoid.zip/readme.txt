Use with:

Metroid (USA).nes (No Intro)
ROM Checksum: 397d10e475266ad28144a5fa6ec3c466
CRC32 Checksum: D1A02CAB