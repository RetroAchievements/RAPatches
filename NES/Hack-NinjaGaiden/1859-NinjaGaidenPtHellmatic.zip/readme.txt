Use with:
Ninja Gaiden (USA).nes (No-Intro)
RA Hash 07c1b92ae9b78f209075a8cc6d3eebf0
