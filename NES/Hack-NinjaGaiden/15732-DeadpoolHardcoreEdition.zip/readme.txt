Use with:

(No Intro)
File:               Ninja Gaiden (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              11F953F6
MD5:                0C2CCCDA6BA6CAB7BEDE0FF05E7F6852
Headerless MD5:     07C1B92AE9B78F209075A8CC6D3EEBF0