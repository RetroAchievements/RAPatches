Use with:

(No Intro)
Ninja Gaiden (USA).nes
15c46b30c216086d1f215977a1019691
80d3b95e
