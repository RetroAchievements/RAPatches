Use with:

Ninja Gaiden (USA).nes (No-Intro)
b68c50666a44f518185b06d759065ddc
12849521
