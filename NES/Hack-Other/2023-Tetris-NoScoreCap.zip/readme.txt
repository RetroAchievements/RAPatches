Use with:

(No Intro)
File:               Tetris (USA) (Tengen) (Unl).nes
BitSize:            384 Kbit
Size (Bytes):       49168
CRC32:              AE473687
MD5:                2AA73CC1B57A42A61E5CB3E84908064D
Headerless MD5:     117C38986584C88263414B7ABB98667C