Use with:

(No Intro)
Dragon Warrior (USA).nes
479373cdffd4bf37ab8de6a895d48e05
2E1DAC12