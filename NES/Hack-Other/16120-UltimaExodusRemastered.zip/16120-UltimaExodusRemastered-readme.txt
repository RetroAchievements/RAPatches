Use with:

Ultima - Exodus (USA).nes (No-Intro)
a4317a080ea111c8be02ed7c23cc8977
DBD44D33
