Use with:

Ghostbusters (USA).nes (No-Intro)
734c4ff66aa541b202c2b2c51cab4bbb
0C66EF43
