Use with:

File:               Earth Bound (USA) (Proto).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              F5EF5002
MD5:                5BACF7BA94C539A1CAF623DBE12059A3

