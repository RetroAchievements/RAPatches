Use with:

(No Intro)
Color a Dinosaur (USA).nes
6e83fc8e10924d6353b90b4c7ff436d6
322a6cca