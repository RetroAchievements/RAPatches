Use with:

Color a Dinosaur (USA).nes (No-Intro)
99dd1d23a46e68b7163dbc5bb69b9929
59C6079B
