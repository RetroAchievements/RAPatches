Use with:

(No Intro)
File:               Dragon Warrior (USA).nes
BitSize:            640 Kbit
Size (Bytes):       81936
CRC32:              2E1DAC12
MD5:                479373CDFFD4BF37AB8DE6A895D48E05