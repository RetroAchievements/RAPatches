Use with:

(No Intro)
Blaster Master (USA).nes
defdc476e96dd44b4863e360456b8cd3
c3961ce2