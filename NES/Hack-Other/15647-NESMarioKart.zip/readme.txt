Use with:

R.C. Pro-Am (USA) (Rev 1).nes (No Intro)
500b1dff51abc465b26c069e9b730dd4
0296E5F4