Use with:

Metroid (USA).nes (No-Intro)
b2d2d9ed68b3e5e0d29053ea525bd37c
617DC46A
