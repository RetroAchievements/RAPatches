Use with:

(No Intro)
File:               Summer Carnival '92 - Recca (Japan) (En).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              48A42E2F
MD5:                D1977209742B71A93E4EBC1AFA0063DC
Headerless MD5:     86E917C37515ACE20D3B50DCA4551F3B