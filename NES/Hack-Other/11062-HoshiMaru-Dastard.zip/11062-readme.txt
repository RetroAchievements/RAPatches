Use with:

(No Intro)
File:               Hoshi o Miru Hito (Japan).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              0EC30976
MD5:                FC6A1D4F5C6CD7FDA3143024DFA20E55