Use with:

(No Intro)
Hoshi o Miru Hito (Japan).nes
MD5: ba8cf13e8d4ccd88609e42d4a76816ad
RA Hash: f16e4b4516d190296095ab4f30e44c0d
CRC: 9904D6AA