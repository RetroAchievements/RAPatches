Use with:

(No Intro)
Felix the Cat (USA).nes
MD5: e8dcb66a8e2090d74c7ebfb78049fad0
CRC: 47F0E924