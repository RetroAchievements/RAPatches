Use with:

(No Intro)
File:               Hoshi no Kirby - Yume no Izumi no Monogatari (Japan).nes
BitSize:            6 Mbit
Size (Bytes):       786448
CRC32:              248C7140
MD5:                582FFBD982A91F5ABBEA251C2D7EDA13
Headerless MD5:     4D22184ED99EFEC06BBEC5CD7805CC56