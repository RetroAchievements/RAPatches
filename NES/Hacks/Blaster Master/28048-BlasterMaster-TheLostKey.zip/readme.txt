Use with:

(No Intro)
File:               Blaster Master (USA).nes (No-Intro)
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              C3961CE2
MD5:                DEFDC476E96DD44B4863E360456B8CD3