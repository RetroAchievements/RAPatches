Use with:

File:               Zelda II - The Adventure of Link (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              861C3FE6
MD5:                E6DD4104FA46EB4BEF2CB52DC341DD38

(No Intro) (Older)
Zelda II - The Adventure of Link (USA).nes
ROM Checksum: 764d36fa8a2450834da5e8194281035a
CRC32 Checksum: E3C788B0

