Use with:

(No Intro)
File:               Zelda II - The Adventure of Link (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              E3C788B0
MD5:                764D36FA8A2450834DA5E8194281035A
Headerless MD5:     88C0493FB1146834836C0FF4F3E06E45