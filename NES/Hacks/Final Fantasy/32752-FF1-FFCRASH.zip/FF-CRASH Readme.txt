FF: CRASH - v1.06

Please see the manual included with the download for information about this project.


How to patch:

Just load up the "Final Fantasy - FF_CRASH.ips" into Lunar IPS (or a suitable substitute) with a US version Final Fantasy 1 ROM (ROM details below) and apply patch. After that you should be ready to play.

Thanks for checking out this project!

- Celdia


ROM Information

Filename - Final Fantasy (U) [!].nes
CRC32 - 5c892f3b
MD5 - D111FC7770E12F67474897AAAD834C0C


Version Changes / Known Bugs

Known Bugs in v1.06 - Occasionally the Cure and Heal (1st tier) spells will heal party members for a great deal more
			damage than intended (200+ instead of 40~). Doesn't negatively affect gameplay; not interested
			in chasing this error down for the time being.

			Upon reaching the Experience required for Level 17, characters will immediately jump to Level 18
			at the end of the same battle. 

		      Game Manual not updated to read v1.06 - still reads as v1.02, content of manual is accurate for v1.06
v1.06 - - Equipment Changes
	Fixed some mundane armor that was flagged to cast spells in battle
	Fixed some magical armor that didn't have flags for spells in battle
	
	- Misc Changes
	Added Weapon and Armor spoiler spreadsheet to archive

v1.05 - Not Released; changes listed with v1.06 above

v1.04 - - Equipment Changes
	Fixed Faerie Ring to properly protect from Poison-element
	Fixed Mythril Armor icon to reflect that it is Light Armor (again)
		
	- Map Changes
	Added in treasure chests that have Wind Cloak and Ceramic Ring items
	Increased gil rewards in mid-game accessible treasure chests
	Fixed exit teleporters in Temple of Chaos (Revisited) maps to put player outside of the Temple entirely	
	Changed the contents of a treasure chest that had the wrong item in it

v1.03 - Not Released; changes listed with v1.04 above

v1.02 - - Magic Changes
	Improved Chakra effectivity
	Improved Aero effectivity
	Changed Silence to target all enemies

	- Enemy Changes
	Reduced Garland's Defense
	Replaced Silence on most enemy spell lists with a new single-target Mute spell

	- Class Changes
	Touched up Monk/Master sprites

	- Equipment Changes
	Fixed Hero Sword class flags
	Fixed Mythril Armor icon to reflect that it is Light Armor

	- Misc Changes
	Fixed some text errors - mostly names missing trailing spaces
	Fixed an overworld forest tile that wasn't flagged for forest effect


v1.01 - Updated mismarked information in the manual.
	Fixed some incorrect flags on spells.

	
