Final Fantasy - Economic Collapse
v1.1
by: The Mystical One

The destruction wrought by the fiends of chaos has caused the global economy to fall into ruin.
Shops shutter and fall into disrepair.
Magicians vanish to other realms, their students no longer able to afford their services...
Four heroes appear holding orbs, but they must find their own supplies and equipment.

- All shops have been closed and blocked off, their goods emptied.
- Inns and Clinics remain open
- Treasures and enemies are unchanged.
- Dungeon and overworld maps are unchanged.
- Includes Anomie's dash enhancement so you can run while suffering through the economic despair

Patches:
(No Intro)
File:               Final Fantasy (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              8125B019
MD5:                A475798CBD5787B3B9736F238B8032C1
SHA1:               E8F34D93576048528BE4CB736F292EDB431083E0
SHA256:             2F5D5FF2E22FB31C64D92DC783AF443F94340B365595CD6B8D77E8C9B3A54820
Headerless MD5:     24AE5EDF8375162F91A6846D3202E3D6