GFF (Grond's Final Fantasy) version 3.2 [September 4, 2013]

[This document to be viewed using a fixed-width font such as Fixedsys or Courier.]



>> About This Hack <<

The purpose of this hack is to take an already great game and greatly improve on it by enhancing it
with special features, ironing out wrinkles in the gameplay (poor balance, annoying quirks, and game-
breaking bugs); and to a somewhat lesser extent, to put my own personal spin on the game.



>> Notable Changes From FF1 <<

-Many bugfix and enhancement patches made by other ROMhackers applied
-New, animated title added at game startup
-Menu color can be changed--press B at the title repeatedly to cycle through the available colors
-Names of most things expanded and altered
-Saving is now done from the main menu instead of via inns, tents, & such
-You can now sort your magic spells and delete unwanted ones
-In-game world map slightly improved; now accessed by pressing Select+Start instead of B+Select
-B-Button dash available at all times, even on the airship
-Water & such things are animated now, and some areas have palette-cycling effects
-Default (pre-bought/equipped) equipment & spells added at new game
-Censored graphics from the Japanese version restored
-Boss battles have their own songs now, instead of the normal battle music
-Dual-wield ability given to Ninja and Monk/High Monk
-Random battle rate is slightly decreased if a Rogue or Ninja is the party leader
-A few new stat-boosting consumable items added
-Most damaging-dealing spells should usually hit in the greater half of their damage range now
-Elemental magic does 2x (instead of 1.5x) damage against vulnerable enemies (3x if at level 50)
-Some spells switched around; some had effects and/or effectivity altered
-Properties of some weapons and armor altered; some were changed into entirely different things
-Shop inventories modified a bit; prices of many things lowered a little
-Sanctuary (formerly Clinic) can now heal petrification and poison, in addition to death
-Magic Evasion of most foes lowered to a more reasonable amount
-Enemy groups' "ambush" values now roughly scale with the point in the game in which they are met
-Several area maps altered a bit (mostly cosmetically) and quite a few treasures changed
-A few walk-through-able secret walls added here and there
-Some towns have a hidden treasure to find
-Two hidden bonus areas added: one accessed from the first town (but only late in the game) and 
 one from the last town, south of the hidden magic shops
-Ship puzzle game now gives 500 Gold (50000 if at level 50)
-All party members always gain experience after battle, even if dead or petrified
-In determining preemptives/ambushes, all party members' Agility and Luck are considered (rather
 than only the leader's); if a Rogue or Ninja is the leader, a minor bonus is given at this time
-Oasis remains after rescuing the Fairy (sells the stat-boosting items)
-Harm (Dia) spells now injure enemies in the "Evil" category as well as the Undead
-You can "shoo" most bats away by talking at them
-Level gains occur more rapidly, especially towards the beginning
-New Game Plus mode added--beat the game to restart with your stats, equipment, spells, and gold
 intact, but events, treasures, levels, job class, and items reset
-Game altered to run on iNES Mapper 4 instead of 1
-Plenty of other minor changes & one or two surprises



>> Job Class Overview <<

Fighter [-> upgrade: Paladin]
<Pros>: A good attacker; Generally has the highest HP and defense; Has the most equipment options
<Cons>: No magic until class change
<Notable changes from FF1>:
-Paladin can learn all White spells of levels 1-4
-Paladin can equip the White Robe

Rogue [-> upgrade: Ninja]
<Pros>: Has unique abilities; Is the best at escaping; Becomes a good attacker later in the game
<Cons>: Somewhat feeble until after class change; No magic until class change
<Notable changes from FF1>:
-When he is the leader, receive more preemptives/less ambushes, and fewer random battles in dungeons
-Ninja can now dual-wield
-Ninja's equipment options restricted--no more heavy armor or large swords, axes, or hammers

Monk [-> upgrade: High Monk]
<Pros>: Attack and defense are generally good at low levels and superb at high levels; Needs no armor
<Cons>: Has the lowest Magic Evasion of all; No spellcasting ability at all; Few equipment options
<Notable changes from FF1>:
-Can dual-wield his weapons
-Gets double hits even when using weapons now
-Can no longer equip armor (except the Ribbon), but Absorb now equals [Level x2] instead of [Level]
-Unarmed Critical Hit rate is now [Level] rather than [Level x2]

Red Mage [-> upgrade: Red Wizard]
<Pros>: The most well-rounded class, with access to good weapons, armor, and both types of magic
<Cons>: Lower MP growth and total MP than other mages; Doesn't seem so stellar in the late-game
<Notable changes from FF1>:
-Red Wizard can now equip the White and Black Robes

White Mage [-> upgrade: White Wizard]
<Pros>: Access to all White Magic--for protection and recovery, with some damage-dealing (Dia, Holy)
<Cons>: A poor physical attacker

Black Mage [-> upgrade: Black Wizard]
<Pros>: Access to all Black Magic--for nuking foes and raising allies' attack (Strike/Sever, Haste)
<Cons>: Physcial attack and HP are quite poor



>> Hit Rate / Magic Evade Rate increase per level<<

Fighter........2 / 3
Rogue..........2 / 3
Monk...........1 / 3
Red Mage.......2 / 3
White Mage.....1 / 3
Black Mage.....1 / 3
Paladin........3 / 2
Ninja..........3 / 2
High Monk......2 / 1
Red Wizard.....2 / 2
White Wizard...2 / 2
Black Wizard...2 / 2



>> Technical Notes <<

INT Patch parameters:
-INT adjustment divisor: [INT/32]
-Enemy INT: [MagDef/8]
-INT contribution to spell hit chance: [INT/2]
-Base spell hit chance: 128
-Elemental weakness bonus to hit chance: 64
-Elemental resistance penalty to hit chance: 128
-INT contribution to spell damage: [8*INT/32]
-INT contribution to healing magic: [8*INT/32]
-Base heal spell doubling chance: 0
-"Neg. Effect 2" spells base HP limit: 400
-INT bonus to "Neg. Effect 2" spells: [32/32]
-INT contribution to FEAR: [8*INT/32]
-INT contribution to FOG : [2*INT/32]
-INT contribution to LOCK: [4*INT/32]
-INT contribution to INVS: [4*INT/32]
-INT contribution to SABR hit%: [4*INT/32]
-INT contribution to SABR damage: [2*INT/32]
-INT contribution to invoked weapons/armors: none
-MUTE prevents magic and invoked weapons/armors
-SLEP waking threshold: 254 HP
-Poison damage for players: [MaxHP/20]
-Poison damage for enemies: [MaxHP/20]
-Regen amount for enemies: [MaxHP/25]

Physical attack parameters:
-Base hit chance: 168
-Attacker Dark penalty: 64
-Target Dark bonus: 64
-Category/element bonus to damage: 10
-Category/element bonus to hit chance: 32
-Damage penalty vs. resisted element*: 5
-Hit rate penalty vs. resisted element*: 16
*weapons with the Status element receive no penalty



>> Miscellaneous Notes <<

-Dual-wield: For the secondary weapon, only the damage and hit% are utilized; Only the primary
 weapon's special element/category damage bonus and crit% are used
-When dual-wielding, the weapon in the uppermost slot is the primary weapon and must be equipped
 first--the secondary weapon can be in any other slot
-The Ribbon now, rather than being considered headgear, has no armor "type" and can take the place
 of any other type of armor
-"Solo" quests should still be doable, though they may or may not be harder than in the original FF1



>> Thanks To <<

-AnomieX: Disassembly, & tons of bugfixes and enhancements!
-AstralEsper: Helped with several things!
-Bregalad: No-menu-music patch!
-CaptainMuscles: Dual-wield patch!
-Disch: FFHackster, disassembly, & water animation hack!
-Goongyae: Extended character names & etcetera!
-Karatorian: "Kung Fu" bugfix, & a handy ROM map!
-Lenophis: DTE in-battle patch!
-LeviathanMist: Ported the new songs from Origins/DoS!
-Paulygon: Made FFHacksterPlus & useful Game Genie codes!
-whoever I forgot! ;P
