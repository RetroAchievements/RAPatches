Use with:

(No Intro)
Final Fantasy (USA).nes
a475798cbd5787b3b9736f238b8032c1
8125b019