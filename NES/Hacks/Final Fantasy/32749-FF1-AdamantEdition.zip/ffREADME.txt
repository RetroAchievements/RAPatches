Final Fantasy 1 - Adamant Edition, v1.1
Praetarius5018




can select from 12 classes
--------------------------

Fighter
can use swords, axes and the heaviest armor

Rogue
dual wields knives, 8 hits, deals highest damage against low def targets

Bl.Belt
unarmed expert, highest m.def and lv50 damage

RedMage
can use swords and a good portion of white and black magic but has only mediocre stats

WhiteMage
can cast every white spell

BlackMage
can cast every black spell

Paladin
sword fighter with limited selection of white spells (up to level 5)

Ninja
dual wielding glass canon, can learn some black magic spells (up to level 5)

Druid
unarmed brawler that learns some support spells of all levels

Shaman
can learn every support spell

Magus
can learn every damage spell

Sage
can learn every spell but slow gain of spell charges


other changes
-------------
-Bahamut's blessing changed from class upgrade to +20 m.def
-changed several spells
-INT increases effectiveness of spells
-for spellcasting items INT is treated as half its normal value
-damage spells increase power by INT/2 for aoe spells and INT*11/16 for single target spells
-heal spells increase healing by INT/4
-status spells have accuracy of 168+INT-M.DEF
-removed chance of spells to deal double damage
-spells instead roll twice for extra damage with higher chance for the upper end with high INT
-spell weakness changed from +50% to +5 power with higher chance to roll high damage
-LOCK and XFER auto-succeed
-display m.def in status
-m.def capped at 150
-HP gain per lv changed from VIT/4+1 or VIT/4+[20..25] to always VIT/2+5
-base stats no longer have a 25% chance to increase on a level where they are not guaranteed to increase
-Bl.Belt no longer gets x2 on hit count
-Bl.Belt damage changed from 2xLv to (STR/2+Lv)
-base hits increased from hit%/32+1 to a constant based on class, e.g. fighter has 5, rogue 8
-atk+(STR/2) gets halved in battle after damage range calculation
-base accuracy down from 168 to 108
-adapted enemy stats to general changes
-regular enemies have slightly less m.def and most of them at least one weakness now
-bosses have a bit more HP, spellcasting bosses have improved spellsets
-roughly doubled exp gain from enemies, bosses even more
-decreased gold gain in late game areas
-decreased item and spell costs for early game especially
-clinic always costs 100
-inn always costs 30
-bottle costs 20000 instead of 50000
-enemies no longer auto-wake up, instead wake up chance is based on m.def
-edits stats of weapons and armors, replaced some useless items (e.g. nunchucks)
-weapons effective against specific types get +40 acc. and +10 damage
-replaced shields with rings
-in general chest-only equipment sells for less
-replaced 3rd ribbon chest with a 2nd opal braclet
-more endgame equipment has elemental resistances
-applied most known bug fix patches
-applied some speedup patches
-unlinked several marsh cave chests, added a few extra
-made several battle formations runnable that weren't before
-specifically only "boss" formations, EARTH, FIRE, WarMECH and their linked formations are unrunnable
-edited room with FLOATER to be protected against WARP
-moved the bats in earth cave into dedicated bat rooms
-added a shortcut back up behind the vampire in earth cave
-can dash with B button


note:
dual wielding requires the first weapon to be in the first weapon slot




Credits
-------

Anomie		- various patches
AstralEsper	- various patches
Bregalad	- no menu music change
CaptainMuscles	- Dualwield Patch
Disch		- FFHackster, various patches