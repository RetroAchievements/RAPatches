Use with:

(No Intro)
File:               Super Mario Bros. 3 (USA).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              661019C6
MD5:                85F0DDDDFE4AB67C42ABA48498F42FDC

(No Intro)
File:               Super Mario Bros. 3 (USA) (Rev 1).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              E8C3AF69
MD5:                E883E0D43448D9FDD8CE626F75FE4E5D
