beta 4.2
4-27-23

ONLY PATCH ROMS THAT ARE (USA) OR (PRG0)
DO NOT PATCH ROMS THAT SAY (REV), GAME WILL NOT WORK PROPERLY/AT ALL

*changes
1: more timing fixes for shell actions crashing rom
2: stop infinite entry to first completed toad house in World 2
3: fixed issues where player 2 could not re-enter sun stage, if cleared by player 2
4: fixed entering non stages on world 2 map

There are two ips patches. Gameplay functions the same with each one, only difference 
is you can now decide what in-game color you want Toad to be in. Red, or blue.

	Super Mario Bros. 3 (b4.2_4-27-23_BT).ips [Blue Toad]
	Super Mario Bros. 3 (b4.2_4-27-23_RT).ips [Red Toad]

-infidelity