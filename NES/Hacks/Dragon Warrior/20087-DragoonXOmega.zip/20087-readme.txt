Use with:

(No Intro)
Dragon Warrior (USA).nes
479373cdffd4bf37ab8de6a895d48e05
2E1DAC12

The 'Original Patch' folder also includes the original patches and readmes/manual stuff as well.

Be sure to use the patch "Dragoon X Omega - Gold Edition - Amnethen Apocalypse (v2.0f) (Silver X) (Addendum) (obscurumlux01)" on an UNHEADERED NES ROM file or it may not work properly.
You must source your own ROM that matches the above MD5 and CRC32 hashes.