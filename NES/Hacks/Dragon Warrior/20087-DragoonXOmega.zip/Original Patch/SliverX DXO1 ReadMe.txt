       #########################################################
      #$#                      #                              #$#
     #$$# Dragoon X Omega 2.0f # Original Game:Dragon Warrior #$$#
     #$$#         (GOLD)       #                              #$$# 
     #$$#######################################################$$# 
     #$$#                                                     #$$#
     #$$#    Hacked by Sliver X (sliverx@hotmail.com)         #$$# 
      #$#          http://sliverx.cg-games.net                #$#
       #########################################################

I recommend FCE Ultra to run this game.

Using NESticle is not advisable, since the music will sound
shitty and some of the graphical effects Dragon Warrior can
do won't be emulated. 

Enabling scanlines will make this game look a lot better 
on a computer monitor.

If you have a bunch of gifs and an html page in your ROM directory
instead of a folder named Manual, make sure you extract will full paths
with whatever archiver you're using.
***********************************************************************


A little over two years ago I released a hack of Dragon Warrior called 
Dragoon X Omega. Some things that should have been done weren't.
I got bored a few days ago. I finished it. 

***********************************************************************
Thanks to everybody who mailed me over the past couple of years with
comments on this hack. I hope you all enjoy this.

KNOWN BUGS:

I've tested the living shit out of the game, and everything looks great.
If I actually missed anything this time, I should be shot. Though nothing
major, here's a list of the bugs that are still left:

When you use the Sonic Orb in battle, the music starts going faster
for the duration of the fight.
(Still a bug, but not as bad as in v2.0)

On some emulators, when changing from one song to another, the last note
from the previous song will still sound out. (Not sure if it's an
emulation issue or my hacking.. Either way, it doesn't do it on FCE Ultra.)

After getting Argus, it starts to play the Cave music/When you use the Atomic
Bomb, it starts to play the Nico Resort Music. I can't find how the game
says "Jump to what was previously playing" instead of "Jump to this song".


