Hello everyone, I'm Daedalus007 the author of this 'Amnethen Apocalypse' version of the rom mod 'Dragoon X Omega 1' for the NES game Final Fantasy 1.
My old RHDN (romhacking dot net) username was obscurumlux01.
I actually used to go by several different names on RHDN because of reasons I won't get into here but the short version is that the RHDN admin and I didn't get along.
In any case, the new online username I go by on Discord, Steam, and other spots is 'Daedalus007' so I'll include my updated contact info and links below.
I wanted to do this in lieu of editing the original ReadMe files.

I won't have any updates or further business with the RHDN website anymore because i'm effectively locked out of all my old accounts because of the previous issues with the RHDN admin.
Keep an eye using my socials below and thanks for playing!
I am open to feedback/critique/criticism!

There is a quirk to patching up the roms if you want to use the original patches: both the original DXO1 and my addendum 'Amnethan' patches are meant to be used on a 'headered' NES rom with an iNES header.
The IPS file in the main directory named "Dragoon X Omega - Gold Edition - Amnethen Apocalypse (v2.0f) (Silver X) (Addendum) (obscurumlux01).ips" is meant to be used on a 'headerless' NES rom file.
Just keep that in mind.

----------------------------------------------------------------------------------------------

Info & Social Media Linkage
Discord: daedalus007
Steam: https://steamcommunity.com/id/Daedalus007/
Odysee Referral Link: https://odysee.com/$/invite/@Daedalus6878:0
Github: https://github.com/Daedalus007

Modding List
Chrono Trigger (SNES) - Johnny Jackpot:  romhacking.net/hacks/2950
Chrono Trigger (SNES) - Racing Fixes:  romhacking.net/hacks/2949
Chrono Trigger (SNES) - Reptite Reshuffle:  romhacking.net/hacks/2951
Dragoon X Omega (NES) - Amnethen Apocalypse:   romhacking.net/hacks/2544
Dragoon X Omega 2 (NES) - Easy Mod:   romhacking.net/hacks/2541
FF12: The Zodiac Age (PC) - Daedalus Mega Mod Pack:  nexusmods.com/finalfantasy12/mods/37
Phantasy Star 1 Retranslation (SMS) - Daedalus Edition:  github.com/Daedalus007/psrp-daedalus
Shining in the Darkness (Sega Genesis) - Thornwood Terrors Collection:   forums.shiningforcecentral.com/viewtopic.php?f=2&t=26510&p=718632 (slightly buggy/untested)
WoW TBC (PC) - Daedalus Mutes Annoying TBC Sounds Mod:  nexusmods.com/worldofwarcraft/mods/832

Modding Utillities
Floating IPS (Oct 2020): github.com/Daedalus007/Flips-daedalus

Steam Guides
Eternal Senia KillQuests Guide:  steamcommunity.com/sharedfiles/filedetails/?id=1410355333
Legionwood 1 Stats/Builds Guide:  steamcommunity.com/sharedfiles/filedetails/?id=1455687436
WarFrame MR9 Test Guide:  steamcommunity.com/sharedfiles/filedetails/?id=2497061067

----------------------------------------------------------------------------------------------