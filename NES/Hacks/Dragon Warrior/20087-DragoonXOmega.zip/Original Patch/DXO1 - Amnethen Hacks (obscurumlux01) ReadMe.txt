**CREDITS**

Dragoon X Omega I Final
by Sliver X

Dragoon X Omega - Amnethen Apocalypse (plus all sub-patches)
by obscurumlux01

Thanks to Sliver X for creating DXO and thanks to all those below who created utilities & information that I used in creating my own rom hacks
Detailed links & information are in the sections directly below
Support the ROM Hackers & Translators by NOT redistributing any rom hacks/translations prepatched onto the ROMs!



**TOOLS USED**

The Dragon Warrior Massive Data Editor (DW1MDE) from RHDN by 'Roto'.
It is also available on Zophar's Domain and they seem to be the same archive (exact same SHA-256 hashes and version info)

The DW1MDE is a DOS tool so I had to use DOSBox to run it; what a pain in the ass!
The program will not work if run directly, you have to run DOSBox.exe first and then navigate to the directory within the DOSBox virtual hard drive and THEN run the exe

The Dragon Warrior Town Editor (TOWNEDIT) from RHDN.
It is a DOS tool that I also had to use DOSBox to run; has a menu item to 'Run Nesticle' which should let you know how old it is.



**USEFUL LINKS**

Dragon's Den: Dragon Warrior 1 Shrine with downloadable name stat generator and helpful info
http://www.woodus.com/den/games/dw1nes/

Dwedit's TOWNEDIT website
http://www.dwedit.org/townedit/

Roto's Dragon Warrior Massive Data Editor
http://www.romhacking.net/utilities/62/

Woodus Online Name Stats Calculator & Battle Simulator
http://www.woodus.com/den/games/web/dwsim/

Map of the Overworld can be found here; some areas annotated by me (without spoilers):
https://anony.ws/i/2015/09/19/DXOOverworldfcf15.png

Original Maps are from here including maps of every dungeon/area (major location & name spoilers):
http://dxo.arc-nova.org/

Ryan's 8-bit Formula FAQ for DW1 can be found here (GameFAQs mirror, original is gone):
http://db.gamefaqs.com/console/nes/file/dragon_warrior_formula.txt



**ROM INFO**

Dragon Warrior 1 - NES
CRC32: CAAF5C6B
MD5: 1CFEEAC7A20B405780EEA318D3D1AF2A
RIPEMD-160: E2B70CE0A688024CB8BE1662406184EC7A1F0518
SHA-1: 6A50CE57097332393E0E8751924FD56456EF083C
SHA-256: A7ECD04C70FFF7CA3F0CD7E262377097305A30C9B5BFA27D7341F454E252BE17

iNES header
Nintendo Entertainment System/NES/Famicom/Game Axe (Redant)
Dragon Warrior (U) (PRG 0)
Nintendo
U.S.A.
81920 Bytes (0.6250 Mb)
Padded: No
Interleaved/Swapped: No
Backup unit/emulator header: Yes, 16 Bytes
Internal size: 0.6250 Mb
Internal PRG size: 0.5000 Mb
Internal CHR size: 0.1250 Mb
Memory mapper (iNES): 1
Mirroring: Horizontal
Save RAM: Yes
512-byte trainer: No
VS-System: No
Date: 8/1989
Checksum (CRC32): 0x3b3f88f0
DAT info:
  Nintendo Entertainment System/NES/Famicom/Game Axe (Redant)
  Dragon Warrior (U) (PRG 0)
  U.S.A.
  81920 Bytes (0.6250 Mb)
  nes-20031208.dat (1.9.8-3-NES, 8/12/2003, NES)



Dragoon X Omega 1 Gold Edition v2 Final - NES
CRC32: BF1668DE
MD5: 391658486D844469171444DE00523A07
RIPEMD-160: 335010C4E246677BAA9B589FF746E27DC84443CA
SHA-1: 21ABA023A691CE0AF3E15D09CF6C052FF54DA1D0
SHA-256: 566967AD33EEC2E68DD805CE46C346831070B607CDF627CE96F26D9CC0DBCF8B

iNES header
Nintendo Entertainment System/NES/Famicom/Game Axe (Redant)
82048 Bytes (0.6260 Mb)
Padded: Maybe, 111 Bytes (0.0008 Mb)
Interleaved/Swapped: No
Backup unit/emulator header: Yes, 16 Bytes
Internal size: 0.6250 Mb
Internal PRG size: 0.5000 Mb
Internal CHR size: 0.1250 Mb
Memory mapper (iNES): 1
Mirroring: Horizontal
Save RAM: Yes
512-byte trainer: No
VS-System: No
Checksum (CRC32): 0x4454b274



**INSTRUCTIONS**

1. Obtain a legal copy of the Dragon Warrior 1 (USA) NES ROM that matches the hashes above; how you do so is something that you can figure out yourself
2. Patch it with the Dragoon X Omega v2.0f - Gold Edition IPS patch from RomHacking Dot Net (RHDN) using Floating IPS or another program
2a. Floating IPS is recommended because it works better than Lunar IPS, is fully backwards-compatible with it, and also can create and apply BPS patches if you ever need it
3. Verify your ROM hashes of your patched DXO1 ROM match the ones included above!
4. Patch up with one or more of the 'Amnethen' IPS patches included in this archive.
5. Finally, just copy the fully-patched ROM to a flash cart (or be a lamer and use an emulator)



**INTRO**

Welcome to the 'Amnethen' ROM Hacks Collection! aka the 'Easy Mode' of another hack called Dragoon X Omega I - Gold Edition v2.0f!
These are 'IPS' patches so you'll need to grab an IPS patcher of your choice (such as Floating IPS) to patch it up
There are several such utilities on RomHackingDotNet (RHDN) and Zophar's Domain

Several patches are included; make the game as easy as you like!  YOU decide!
All of the patches are inter-compatible with each other!
If you want to just have everything in one go, use the 'Amnethen Apocalypse' Patch!

Amnethen Apocalypse Patch (All) - 5673 bytes - Created 28 Sept 2015
Amnethen Cult Patch (Map) - 5520 bytes - Created 28 Sept 2015
Amnethen Grace Patch (Magic) - 21 bytes - Created 25 Sept 2015
Amnethen Ingenuity Patch (Pills) - 20 bytes - Created 22 Sept 2015
Amnethen Power Patch (Weapon/Armor) - 86 bytes - Created 22 Sept 2015
Amnethen Wisdom Patch (XP) - 71 bytes - Created 27 Sept 2015
Extra 'Cheat' File in .cht format:  Amnethen Reprieve (Cloak/Repel is Always ON) - 25 bytes - Created 26 Sept 2015



**STORY** (Amnethen Cult/Apocalypse)

The full horror of the Neverborn has driven many people to despair and suicide
A mysterious cult has risen to power and the one they worship is not easily known
Who is their mysterious revered person?  What mysteries await our heroine as she battles for her survival?
The influence of the Amnethen Cult is everywhere and only YOU can figure things out!
Fortunately for our heroine, an incredibly helpful ally awaits you in Amnethen Keep to assist the start of your journey; seek them out.

Note:
In gaming terms, you'll see mysterious symbols everywhere on the overworld & dungeon/town maps that represent the cult
It will become obvious by the end who the mysterious person is
Absolutely no text or in-game story were altered to accomodate this mini-story; consider it a side-quest you can pursue or ignore
The symbol you see has many meanings and such an omen can mean good or ill depending on your disposition
I leave it up to the player to decide for themselves what the cult means and how to respond to their marks
The ally in Amnethen Keep will restore all your PSI when you talk to them; this is the same NPC function as the one from Dragon Warrior 1 for NES.  For some stupid reason they were originally behind a card-key door rather than someone you could talk with normally like everyone else.
One very minor glitch with the map changes at Amnethen Keep results in one roaming NPC starting out 'stuck' in the wall.  They'll move out of the wall if you sit there looking at them for 20 seconds or less.  When I went to talk to Vin at the end of the game, that NPC was stuck in the wall 2 tiles up and could not get out.  Oh well, let that stupid/rude guard rot ;)



**CHANGELOG**

Amnethen Wisdom -- (XP Requirements Reduced)
-XP needed to level has been reduced by ~75%

Amnethen Grace -- (Weapon/Armor Price Reduction)
-All Weapons and Armor are discounted by 50%

Amnethen Ingenuity -- (Pill Price Reduction)
-Pills now 50% off the normal price!

Amnethen Power -- (Magic Costs Reduced)
-Use of 'Aura' (Heal) is now 1 MP instead of 2 MP because it scales very poorly to your level and only ever heals from 8 to 17 HP! (Pathetic in combat after level 7 and near-useless after level 10; use Pills instead!)
-Use of 'Bolt' (Hurt) is now FREE because it scales very poorly to your level and only ever does damage between 4 and 15 HP! (Near-useless in combat after level 7 and Ice Arm weapon or better)
-Use of 'Stare' (Sleep) is now 2 MP instead of 3 MP to match the original values in Dragon Warrior 1 for NES
-Use of 'Psi Block' (StopSpell) is now 2 MP instead of 3 MP to match the original values of Dragon Warrior 1 for NES
-Use of 'Outwarp' (Outside) is now 6 MP instead of 7 MP to match the original values of Dragon Warrior 1 for NES
-Use of 'Cloak' (Repel) is now FREE; it works identical to 'Skunk Spray' (Fairy Water) and will ONLY affect enemies that would auto-run from you due to your power/strength/level

Amnethen Cult -- (Map/Town Changes)
-The entire Overworld is changed as well as every Town, Dungeon and Cave.  Some changes are more noticeable than others
-Dragonlord's Castle was mostly left alone aside from first/last levels being slightly tweaked cosmetically
-Weapons & Armor merchants are near size-3 block tables; Items & Specialty merchants are near size-2 block tables; Innkeepers are also size-2 block tables but are the only ones with 'beds' in their areas.
-Beware the mazes, both in caves and on the overworld; you never know what to expect when you head down a narrow area!

Amnethen Reprieve -- (Cloak/Repel Always ON)
-This is only available as a .CHT file for emulators; the address modified is outside the scope of a Game Genie and may or may not work on a Pro Action Replay cheat device on real hardware
-Even if you don't yet have the 'Cloak' (Repel) ability yet, you can still obtain the benefits of it without having to waste money on Skunk Spray (Fairy Water)
-This removes all encounters with monsters that would auto-run from you due to your power/strength/level
-Unfortunately if you are level 16+ with high enough stats, this would completely remove all overworld encounters outside of the forced-encounters in specific locations
-Thankfully this is mitigated in the dungeons/caves (including the Final Boss Dungeon) since those areas are unaffected by the 'Cloak' ability
-This cheat is very useful after you are no longer interested in ever encountering the time-wasting enemies that you would just one-shot anyways



**LICENSE**

This patch and readme are released under the Creative Commons Attribution NonCommercial ShareAlike v4.0 International version

Limited Commercial Use:
Permission is granted ONLY to those making online videos (such as YouTube) and streaming (such as Twitch) who make their videos publically available for COMPLETELY FREE VIEWING (without registration or sign-in); if so, then you may monetize via sponsorships/advertisements at the beginning/end or during the video.

All other commercial uses are NOT PERMITTED.
Commercial use up to and including all aspects of placing the ROM data onto physical media is NOT PERMITTED.

The full legal text of the license is here:
http://creativecommons.org/licenses/by-nc-sa/4.0/legalcode



**GAME TIPS**

-Since this game uses the Dragon Warrior 1 engine, some of the same bugs/glitches apply.
-This means you can buy and use the 'Nanotech Glove' (Dragon's Scale) to gain +2 Defense and then sell it while keeping the stat boost permanently!
-The 'Sapphire Ring' (Fighter's Ring) does absolutely NOTHING.  It doesn't even change the text of any of the NPCs in Usand like it should.  Just use it once to 'equip' it and then sell it.

-There's one really evil/terrible red herring in the first town visible right near your starting area.  One of the NPCs mentions a town to the southwest (Tor) for better weapons but fails to mention the monsters around that town will tear you apart.  Typical newbie-trap.  Due to glitches with the original game in monster placement, these were transposed onto this game and you have a high chance of encountering monsters that you cannot have any hope of defeating at early levels (or even surviving their initial assault if you are ambushed).
--This red herring is somewhat averted if you use the 'Amnethen Cult' map patch; swamps to the east and mountains to the south are added to show where you should NOT venture.  Even the derpiest newbie will see the ice before reaching the mountains and realize they should turn back.

Some names translated to DW1 town names so you get an idea of where to level.
-Nico Resort = Kol; but moderately high level mobs surround the town; recommended to have 'Stare'.
-Tor = Garinham; but significantly high level mobs surround the town the more you go into the forested areas; there's a specific point where you can easily cross from easier mobs to 'holy cow I died'; recommended to have best Weapon/Armor from Phuun before exploring past the town.
-Phuun = Rimuldar; significantly easier mobs than usual except for the brutal miniboss (Level 10 minimum & best buyable weapon/armor & tons of luck required); outside the MiniBoss this is a great grinding area to level up safely and Phuun sells the gear you'll need to reach Usand and explore the lower half of the world properly.
-Usand = Cantlin; significantly strong mobs around here and you should rush to the town and upgrade gear as soon as you can with cash you already obtained elsewhere.
-GammaTek = Hawksness/Charlock Castle; among the strongest enemies in the game; do not even attempt to come here unless you are level 15+ with the best buyable weapons/armor from Usand; come prepared with consumables (specifically Pills and Key Cards) and gear!  An NPC at Usand used to work at GammaTek so be sure to talk to them!

Since the main character is female, some of the best female names are:
Aeris, Aerith, Mara, Gwen for a STR/AGI build
Zelda, Edea, and Ceres for a STR/HP build



**FINAL THOUGHTS/CONTACT**

If you need to get in touch with me, send me an e-mail to spammeplease@caramail.com
If my e-mail suddenly poofs for whatever reason then the best place to reach me is on the RomHacking Dot Net forums by sending a PM to obscurumlux01
I will rarely check it but I should be able to see it.

Go play the official Dragon Quest games already!  The remakes of Dragon Quest 1 + 2 Reprise for the Super Famicom (together on one cartridge) are AMAZING and are even better with the English Translation Patch.  We did get them officially in English but in a bastardized and shrunken Game Boy Color port.  :(

Dragon Quest Reprise 1+2 translation patch can be found here:
http://www.romhacking.net/translations/337/

The addendum patch for the above to fix some minor errors can be found here:
http://www.romhacking.net/translations/2165/