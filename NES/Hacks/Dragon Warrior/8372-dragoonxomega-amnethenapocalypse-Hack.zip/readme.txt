Use with:

Dragon Warrior (USA).nes (No-Intro)
e8382f82570bc616b0bcc02c843c1b79
CAAF5C6B
