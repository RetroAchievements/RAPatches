Use with:

(No Intro)
Rockman 4 - Aratanaru Yabou!! (Japan).nes
75e1d0a0b90c1099be6a650d5cd6e205
9378fdb4