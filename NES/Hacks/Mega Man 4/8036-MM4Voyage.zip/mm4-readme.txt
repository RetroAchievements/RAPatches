Use with:

(No Intro)
Mega Man 4 (USA).nes
7daebae488795835f962e875ee1f75e8
49df22c4