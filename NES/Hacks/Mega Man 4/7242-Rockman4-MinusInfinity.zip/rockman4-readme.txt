Use with:

(No Intro)
File:               Rockman 4 - Aratanaru Yabou!! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              9378FDB4
MD5:                75E1D0A0B90C1099BE6A650D5CD6E205

Headerless Data:
CRC32:              F161A5D8
MD5:                9DE64E4C39DEAFCDD2C186B6327E4F61