Use with:

(No Intro)
File:               Kirby's Adventure (USA) (Rev 1).nes
BitSize:            6 Mbit
Size (Bytes):       786448
CRC32:              C68F0885
MD5:                A3DDE61DF4BC4EBCE2A60C2CF869081E
Headerless MD5:     758744EC2D2FA3D1F2020586401F97E8