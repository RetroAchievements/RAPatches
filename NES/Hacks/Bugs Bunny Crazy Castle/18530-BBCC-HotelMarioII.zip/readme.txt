https://www.romhacking.net/hacks/2182/
Use with:

(No Intro)
File:               Bugs Bunny, The - Crazy Castle (USA).nes
BitSize:            768 Kbit
Size (Bytes):       98320
CRC32:              FC7EB9B9
MD5:                87B9C24290C64D274B9B5DB9C6FC2461
SHA1:               D145F3312331443FE0A53487BC2E8A372AFA80F4
SHA256:             61B1808F5E362B7D14B00291C438F7231B59CC129A16A131BD78808BD6A25F0E
Headerless MD5:     6BC8F54DC358AA35F6259715E5143B37