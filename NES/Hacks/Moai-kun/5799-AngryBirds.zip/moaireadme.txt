Use with:

(No Intro)
File:               Moai-kun (Japan).nes
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              8D76A40E
MD5:                61CE9019CB8E94DBE160024D33E6CEB8
Headerless MD5:     F9C3ED69DC61E18BC9919397AD6627C2