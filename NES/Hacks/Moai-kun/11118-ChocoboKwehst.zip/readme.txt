Use with:

(No Intro)
   Format:	Headered
   File:	Moai-kun (Japan).nes
   Size:	65552
   CRC32:	8d76a40e
   MD5:		61ce9019cb8e94dbe160024d33e6ceb8
   SHA-1:	5cb692af3b847ea9b169359c1f8cafbe4d3b43a4
   SHA-256:	64867e837925daed9826487d0568c861d66817b7904149534fdc6ba319a376d3
   Note:	[iNES header is '4E 45 53 1A 02 04 31 08 20 00 00 00 00 00 00 01'. Headered ROM created using NewRisingSun's NES 2.0 XML version 2021-12-25 and Kitrinx's NES Header Repair Tool commit 77920fc]