Use with:

(No Intro)
File:               Mega Man (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              CA2AB7E2
MD5:                8CFAA33B1EC522CE89AB82AF2DD17DA7