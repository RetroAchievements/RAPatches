Use with:

(No Intro)
Ghostbusters (USA).nes
c81254a0119efce108e38cac31eeb0d1
9ddd0864