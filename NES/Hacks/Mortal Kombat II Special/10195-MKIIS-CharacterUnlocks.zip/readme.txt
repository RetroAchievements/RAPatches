Use with:

(No Intro)
File:               Mortal Kombat II Special (Taiwan) (En) (Aftermarket) (Pirate).nes
BitSize:            5 Mbit
Size (Bytes):       655376
CRC32:              2E0A3512
MD5:                433547A392D8249815859963FE117192