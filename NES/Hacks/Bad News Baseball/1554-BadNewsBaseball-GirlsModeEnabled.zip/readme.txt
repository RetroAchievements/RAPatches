Use with:

(No Intro)
File:               Bad News Baseball (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              BC43373C
MD5:                D8CA2B29417AFE17DA44F7D317A4A976
Headerless MD5:     7FAF90637145B04A2F0C21D05960A7DC