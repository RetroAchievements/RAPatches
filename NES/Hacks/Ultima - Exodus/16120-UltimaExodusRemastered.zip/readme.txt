Use with:

(No Intro)
File:               Ultima - Exodus (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              EB9EBA3F
MD5:                3B35203E50D14F5A361F259DB63D0FB9

Headerless Data:
CRC32:              A4062017
MD5:                A4317A080EA111C8BE02ED7C23CC8977