Use with:

(No Intro)
File:               Fire Emblem - Ankoku Ryuu to Hikari no Tsurugi (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              D770FF13
MD5:                DCF3887D32BEC83A5C0A85C314579C56
SHA1:               DBB7C47AE41FB1A2AD1C7188946233027DC9E29F
SHA256:             2A58A10BE334F9CC0BE0C678B6C1082B0A936DE20DC39F528C46D32F3A6A3376
Headerless MD5      31B08C81F13E76247F052E80669E8C41