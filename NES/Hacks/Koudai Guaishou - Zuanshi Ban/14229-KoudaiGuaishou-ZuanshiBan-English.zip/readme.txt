Use with:

(No Intro)
File:               Koudai Guaishou - Zuanshi Ban (China) (Aftermarket) (Pirate).nes
BitSize:            8 Mbit
Size (Bytes):       1048592
CRC32:              FD0823D4
MD5:                DF3956535B1F8596A79A47F2EC3E3CD2
SHA1:               38798AE5DC339B700EBF23B1BCBD1EA2E4DE75B4
SHA256:             6211CFB9608CF5C202D255B5084673008A467FE06D327C47310E38816A549632
Headerless MD5:     61D27F3AB6F81D12816A41DF0889DE0E