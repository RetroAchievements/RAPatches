Use with:

(No Intro)
File:               Batman - The Video Game (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              395569EC
MD5:                2E9F52556273AA735D0E75649541D812
Headerless MD5:     341F6FD28FCDC7E246DED2750DD1C1E9