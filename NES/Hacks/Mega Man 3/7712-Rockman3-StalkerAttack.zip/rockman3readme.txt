Use with:

(No Intro)
File:               Rockman 3 - Dr. Wily no Saigo! (Japan).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              FCD80415
MD5:                B24D6FB41B89A7575093BA27882EC018
Headerless MD5:     4F168C40EF35E5A0F4256D707067526F