Use with:

(No Intro)
File:               Mega Man 3 (USA).nes
BitSize:            3 Mbit
Size (Bytes):       393232
CRC32:              45134A3E
MD5:                6C591B7228FD31CBE0BF49243C012095
Headerless MD5:     4A53B6F58067D62C9A43404FE835DD5C