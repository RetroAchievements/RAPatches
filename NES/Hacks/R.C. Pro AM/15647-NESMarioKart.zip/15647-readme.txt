Use with:

(No Intro)
R.C. Pro-Am (USA) (Rev 1).nes
a889179fad4988ea4a9bb31611620070
e60be3de