Use with:

(No Intro)
File:               Rockman 6 - Shijou Saidai no Tatakai!! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              4F7F15F5
MD5:                D9A4EED8B3C13A6BD74B2E9D20385AFB

Headerless Data:
CRC32:              2D664D99
MD5:                5F7C75797B9FC649029FBFFFFBFD5DCD