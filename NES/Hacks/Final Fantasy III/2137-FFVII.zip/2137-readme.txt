Use with:

(No Intro)
File:               Final Fantasy III (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              4EA1E076
MD5:                EC81C6820151FF0E148840CC56F9A520

Headerless Data:
CRC32:              57E220D0
MD5:                45A7D02ED0DC92665A30DA1D9B4AF35D