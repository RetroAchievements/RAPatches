Use with:

Final Fantasy III (Japan).nes (No-Intro)
45a7d02ed0dc92665a30da1d9b4af35d
170163F1
