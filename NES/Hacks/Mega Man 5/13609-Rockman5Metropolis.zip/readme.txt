Use with:

(No Intro)
File:               Rockman 5 - Blues no Wana! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              9D01E44C
MD5:                433E0032BE55A0EF23E7E67311977FE6
Headerless MD5:     328F55E3BEFF0B28A0DF4D5AB7CFCD3A