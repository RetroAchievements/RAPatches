Use with:

(No Intro)
File:               Rockman 5 - Blues no Wana! (Japan).nes
BitSize:            4 Mbit
Size (Bytes):       524304
CRC32:              7E9259BF
MD5:                A850E746C243B873C6E558605B378908

Headerless Data:
CRC32:              FDDF2135
MD5:                328F55E3BEFF0B28A0DF4D5AB7CFCD3A