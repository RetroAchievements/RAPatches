Use with:

(No Intro)
File:               Punch-Out!! (Japan) (En) (Shouhin Golf Tournament US Course).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              046BA9FD
MD5:                75DE6072B706D33A431F9C97E707829B
SHA1:               DCD22E7335191269A3D08E7719985DA5DCC52E00
SHA256:             5A104AB00CF46EC045D9CDB0A7FA2C4D8D59DBA85F28B96E7840926039A91081
Headerless MD5:     6288936A2C92B11096CB4F825F4D5070