Use with:

Mike Tyson's Punch-Out!! (Japan, USA).nes (No-Intro)
1ddde6a84e43ad524a3f81fbfe22f9fc
83DB7938
