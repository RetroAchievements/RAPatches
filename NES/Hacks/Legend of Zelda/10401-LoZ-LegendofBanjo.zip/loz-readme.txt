Use with:

(No Intro)
File:               Legend of Zelda, The (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              D7AE93DF
MD5:                337BD6F1A1163DF31BF2633665589AB0
Headerless MD5:     D9A1631D5C32D35594B9484862A26CBA