Use with:

(No Intro)
File:               Legend of Zelda, The (USA) (Rev 1).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              02BB0C56
MD5:                F4095791987351BE68674A9355B266BC
Headerless MD5:     D3F453931146E95B04A31647DE80FDAB