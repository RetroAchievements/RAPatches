===============
1. Introduction
===============

Zelda: Ancient Dungeon is a completely new way to play the original The Legend of Zelda on NES.  This romhack makes The Legend of Zelda play like a roguelike.  Venture through a randomized, ever-changing dungeon with progressive difficulty the further you go.  Collect classic items and upgrades, and battle familiar foes throughout your journey.  Every playthrough is different.  Ganon is lurking deep within the dungeon, but beware, for if you perish, you'll have to start all over from the beginning.  Are you up to the challenge?

==================
2. Getting Started
==================

Zelda: Ancient Dungeon is distributed as an .ips patch.
Use your favorite patching program (I use Floating IPS) to apply the patch.
You must use the Rev-A (or PRG1) version of the Zelda ROM.

==============
3. How To Play
==============

The game takes place entirely inside the dungeon.  You begin each dungeon dive with your wood sword as well as arrows (but no bow to use them).  Every time you step through a door, the room you see and the enemies within are randomly selected.  Defeat all the enemies to open the doors, then proceed to the next room.  This isn't your typical Zelda dungeon as going back the way you came will likely lead to a completely different room than before.  The rooms will contain more deadly enemy groups the further you go

===========
4. Controls
===========

Zelda: Ancient Dungeon has the same familiar combat controls as the classic The Legend of Zelda, with only a few changes:
- The subscreen has been completely disabled.
- The Start button now pauses the game, instead of Select.
- The Select button cycles through your B button equipment, so any item swapping happens during active gameplay.

===================
5. Special Features
===================

Roguelike Gameplay:  Every playthrough is different and it is all included directly in the ROM file.  No external randomization programs needed, just load and play!

Dynamic Enemy Loading:  Normally the overworld and each dungeon has a specific set of enemies available.  In Ancient Dungeon, new enemies are loaded dynamically during every room transition.  This means there are no restrictions in the combinations of enemies you may encounter in the dungeon.

Additional Item Abilities:  Some special items, like the raft, have no use in the dungeons and are not included in this hack.  However the items that are included may have some additional utility in this romhack.  For example, the stepladder still lets you walk on water spaces, and in this romhack it also adds extra rooms to the pool of available rooms.  There may even be some secret features out there for you to discover!

Other Secrets:  Only the most intrepid explorers will uncover further mysteries the Ancient Dungeon has to offer!

=============
6. References
=============

Data Crystal Wiki:
Very useful resources here!
https://datacrystal.romhacking.net/wiki/The_Legend_of_Zelda

Disassembly by Aldo Núñez:
Absolutely essential to understanding everything about the game
https://github.com/aldonunez/zelda1-disassembly

============
7. Changelog
============

v1.0 - 2022/12/08
Initial Version