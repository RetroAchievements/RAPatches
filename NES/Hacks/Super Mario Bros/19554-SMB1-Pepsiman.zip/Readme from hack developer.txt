Thank you very much for downloading this Hack, I hope you will have Fun with it!
If you want you can play some of the older versions, I recommend the newest version(1.1.1) 

Patch Notes:

1.0:

-first sprites  
-first color palletes 
-levels
-text
-Pepsiman physics
-fireball physics

1.1:

-changed some titlescreen and ui sprites
-changed street sprite
-changed treesprite
-changed $-blocks to Pepsi-blocks
-changed pepsican(Pepsi-block) sprite
-changed box sprite
-changed fireball to pepsiball
-changed castle and skullflag to pizzaflag
-changed underground pipe color pallete

1.1.1:

-fixed Pepsiballcan (full sprite is now flashing)
-changed vine to pole 