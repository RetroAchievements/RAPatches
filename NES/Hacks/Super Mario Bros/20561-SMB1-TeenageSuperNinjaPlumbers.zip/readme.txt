Use with:

(No Intro)
File:               Super Mario Bros. (World).nes
BitSize:            320 Kbit
Size (Bytes):       40976
CRC32:              393A432F
MD5:                F94BB9BB55F325D9AF8A0FFF80B9376D
Headerless MD5:     8E3630186E35D477231BF8FD50E54CDD