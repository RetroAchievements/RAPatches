Batman Shadows of Gotham v1.1
(Shadow of the Ninja hack)
by Magnus Nilsson

How to use
----------
Apply the ips to Shadow of the Ninja (USA).nes

CRC-32: F74A04AB
SHA-1: C35EA6624D37D57953E4C06197BE5C54931A7139
MD-5: D459BAE7337C21CE0D380EFA86CBBDE9

Changes
-------
Graphics, text, unlimited continues and minor level edits.

1.1 minor grammarfix to intro.

About
------
This hack changes Shadow of the Ninja into a Batman game.
Players have been changed to Batman and Robin. Enemies
and bosses have been turned into classic Batman villains
including Scarecrow, Penguin, Riddler, TwoFace and the Joker
to name a few. 

This is my most ambitious hack yet and I'm very proud
how it turned out. The Batman coat fit the original very
well and I've spent days to ensure a high quality hack.

(C) Magnus Nilsson 2014
