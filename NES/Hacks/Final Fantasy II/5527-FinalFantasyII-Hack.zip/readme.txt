Use with:

Final Fantasy II (Japan).nes (No-Intro)
374ed97be8bfd628f6b359a720549ecd
B7327510
