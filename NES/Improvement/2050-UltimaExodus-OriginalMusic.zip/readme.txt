Use with:

(No Intro)
File:               Ultima - Exodus (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              C1A9E6C0
MD5:                4740AF03D83472F4A50872FB8A369C29