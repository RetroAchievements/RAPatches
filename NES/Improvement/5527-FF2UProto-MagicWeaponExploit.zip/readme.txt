Use with:

(No Intro)
File:               Final Fantasy II (USA) (Proto).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              DC3A74D3
MD5:                E62A995A365994D1593000C50FC73D43
Headerless MD5:     4D259632662A581F8F80FF3DC1C3498E