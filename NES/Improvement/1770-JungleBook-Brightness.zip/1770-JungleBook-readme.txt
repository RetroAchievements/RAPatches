Use with:

(No Intro)
Jungle Book, The (USA).nes
ROM Checksum: a41e90140349c06b8d57c5e7b0320fb1
CRC32 Checksum: DAAE79C0