Use with:

(No Intro)
Felix the Cat (USA).nes
MD5: 9ac05a0ec9d615e18c74b4c0b16844e6
CRC: 3856F581