Use with:

(No Intro)
Deja Vu (USA).nes
8a4e0e04d747238454d620a80b22e7fa
A9613A33