Use with:

(No Intro)
File:               Snake Rattle n Roll (USA).nes
BitSize:            512 Kbit
Size (Bytes):       65552
CRC32:              20A97B3E
MD5:                A1114589D5A219A9A546B5768BFF51F7