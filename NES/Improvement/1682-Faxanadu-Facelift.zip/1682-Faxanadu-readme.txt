Use with:

Faxanadu (USA).nes (No Intro)
ROM Checksum: 2a8a8344c47cf13d94c220dcc7e1ed1a
CRC32 Checksum: D8F265FC