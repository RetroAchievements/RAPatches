Use with:

(No Intro)
File:               Little Nemo - The Dream Master (USA).nes
BitSize:            2 Mbit
Size (Bytes):       262160
CRC32:              71D868C4
MD5:                7D774124D8FE1ED4A21F6CC8A34AA800