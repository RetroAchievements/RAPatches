﻿********************************************************************************
*                  Bishoujo Senshi Sailor Moon (PC-Engine CD)                  *
*                          English Translation Patch                           *
*                              v1.1 (13 May 2020)                              *
*                                                                              *
*                        TheMajinZenki -- Translation                          *
*                               Supper -- Hacking                              *
*                               cccmar -- Editing and Testing                  *
*                    William A. Braell -- Lyrics Translation                   *
*                             Xanathis -- Testing                              *
********************************************************************************

Following the Makai Tree incident and the departure of Ail and An, the five 
Sailor Senshi enjoy a newfound period of peace. With no enemies to fight, they 
return to their colorful, but ordinary, daily lives. But one night, Luna and 
Artemis sense several mysterious shadows releasing dark energy – energy like 
that of a Youma. Could the vanquished Dark Kingdom have somehow returned? The 
Senshi have dark secrets to uncover, and enemies old and new alike to face...if 
they can ever stop goofing off at the arcade.

Bishoujo Senshi Sailor Moon (Pretty Soldier Sailor Moon) for the PC-Engine Super 
CD-ROM² system is a 1994 visual novel based on the famous manga/anime franchise 
of the same name. A self-described "adventure-style digital comic", it features 
an original story set between the Makai Tree and Black Moon arcs of the Sailor 
Moon R anime. All five of the original Sailor Senshi are available as playable 
characters, each with their own story; their five separate plots overlap to form 
a larger whole. It features extensive voice acting from the cast of the TV show, 
as well as two original vocal songs.

This patch fully translates the game into English. In addition to translating 
the text, it adds subtitles to all voice-only scenes, and adds both 
transliterated and translated subtitles to song lyrics. It also includes an 
in-game bonus gallery of unused art and sound assets that were discovered during 
production of the translation. And for those who might prefer it, an alternate 
edition of the patch is provided which retains Japanese honorifics and certain 
Japanese terminology.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patch Editions
  II.   Patching Instructions
  III.  Running the Game
  IV.   Bonus Content
  V.    Known Issues
  VI.   Authors' Comments
  VII.  Special Thanks
  VIII. Version History

                    ****************************************
                    *          I. Patch Editions           *
                    ****************************************

There are two slightly different editions of the translation included in this 
download: the standard edition and the "honorifics" edition.

The standard edition of the patch is localized as "Pretty Soldier Sailor Moon", 
and is basically edited in the normal way we would handle any other game. 
Japanese honorifics such as -san and -chan are removed, and Japanese terminology 
is generally not used. All legible Japanese text is translated into English, 
including text in image backgrounds.

The "honorifics" edition (a.k.a. the "weeb" edition) is localized as "Bishoujo 
Senshi Sailor Moon". In addition to retaining honorifics, it uses various 
Japanese terms that dedicated Sailor Moon fans are expected to be familiar with. 
These include "Senshi", "Shitennou", "Tuxedo Kamen", and a few others. Japanese 
text that appears in image backgrounds is unaltered. A small number of other 
bits and bobs are also rendered more directly, such as some uses of "eh?" as an 
exclamation of surprise.

The two editions are identical outside of these minor cosmetic differences; 
we're not changing the names to the '90s dub versions or anything like that. Use 
whichever one suits your tastes.

                    ****************************************
                    *      II. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

First, an important note: This game is *not* "Sailor Moon Collection". It's 
"Bishoujo Senshi Sailor Moon". Sailor Moon Collection is a completely different 
and less interesting PCECD title consisting of minigames aimed at children. Many 
people (and cataloging sites) have gotten the two games mixed up due to their 
relative obscurity and this one's undistinctive name, so before anything else, 
make sure you're trying to patch the right game.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard extensions used in this 
section, or use them differently from normal, which makes things very confusing. 
Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distribution 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent the Redump disc image, just split up into its 
component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

Note that regardless of how you patch, the translated disc image will be 
substantially smaller than the original. This is normal and intended; the 
original game makes use of a PC-Engine CD BIOS feature that allows a redundant 
copy of the game data to be stored on the disc and automatically used if the 
primary version gets damaged. This is not important in the context of a 
translation patch – emulated discs should never get "damaged", and if you're 
playing on real hardware and manage to corrupt the disc, then you can presumably 
burn another copy at your leisure. So we decided to save ourselves the hassle 
and you the hard drive space by just getting rid of the redundant data.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches the 
verified "good" image as listed on Redump.org, and if all the tracks on the disc 
are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  Redump name: Bishoujo Senshi Sailor Moon
  CRC32:       b318d9c2
  MD5:         86a30b952b5bd70b1212f92fcca886a4
  SHA-1:       868a40278c4e4ef2da9fa082dbdbba88966ea8c0

See Redump for full details: http://redump.org/disc/16749/

If your disc image is a match, then all you need to do is apply an xdelta patch 
to the BIN or IMG file, then rename it and pair it with one of the CUE files 
provided in the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Select one of the two .xdelta patch files in the "redump_patch" folder 
based on whether you want the standard edition of the patch or the "honorifics" 
edition. The "honorifics" edition's filename contains a version number ending in 
"-with-honorifics".
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply your chosen 
patch to the BIN or IMG file. If you get an error, you'll need to try one of the 
other patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     It may actually work for this specific game, but won't work in general.
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory contains two CUE files, one for each edition 
of the patch. Select the one whose name matches the edition of the patch you 
used to patch the disc. Now, rename your disc image so it has *exactly* the same 
name as the CUE, except with a .bin extension instead of .cue.
     Important: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc image, but splits it up into separate tracks instead of 
combining them into a single file. It's easily recognized by the presence of 24 
separate BIN files and a single CUE.
  
  Before patching: 
  
  - Make sure that your disc's CUE file has a name like "Bishoujo Senshi Sailor 
Moon (Japan).cue".
  
  - Make sure that the BIN files are named in the format "Bishoujo Senshi Sailor 
Moon (Japan) (Track 01).bin", "Bishoujo Senshi Sailor Moon (Japan) (Track 
02).bin", etc., up through "Bishoujo Senshi Sailor Moon (Japan) (Track 24).bin".
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch.bat". If you want the 
"honorifics" edition of the patch, drag-and-drop onto 
"binpatch_with_honorifics.bat".
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. The "splitbin_patch" directory contains two CUE files, one for each edition 
of the patch. Select the one whose name matches the edition of the patch you 
used to patch the disc, and use it to play the game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump dump, or you otherwise couldn't get method 
A to work, it may still be possible to patch it. If your disc is in BIN+CUE 
format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"bssm.bin" and "bssm.cue", or "bssm.img" and "bssm.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto "binpatch.bat". If you want the 
"honorifics" edition of the patch, drag-and-drop onto 
"binpatch_with_honorifics.bat".
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

Note that there appears to be at least one disc image floating around that has a 
bad CUE file which doesn't list the audio pregaps correctly, causing the audio 
files to get ripped wrongly and throw off their timing. If you find that the CD 
audio in the patched version is not properly synchronized with the game visuals, 
try substituting the included "fixed_original_disc_cue.cue" file in the 
"auto_patch" directory for your original disc's CUE:
  
  1. Open "fixed_original_disc_cue.cue" in a text editor.
  
  2. In the first line of the file, change "YOUR BIN NAME HERE.bin" to match the 
name of your BIN file (e.g. "bssm.bin").
  
  3. Change the filename of "fixed_original_disc_cue.cue" to match the name of 
your BIN file (e.g. "bssm.cue").
  
  4. Redo the patching procedure described above.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 24 of your image, which should be the only ISO file, 
onto "isopatch.bat". If you want the "honorifics" edition of the patch, 
drag-and-drop onto "isopatch_with_honorifics.bat".
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *        III. Running the Game         *
                    ****************************************

If you're unfamiliar with the PC-Engine, figuring how to run CD-based games can 
be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games, including this 
one, target the Super CD-ROM² and are not compatible with the original, 
unenhanced CD-ROM².

Regular CD-ROM² games require a BIOS in order to run, but Super CD-ROM² games 
require a special, more powerful BIOS. So in order to play this game on an 
emulator, you *must* have a ROM image of the Super CD-ROM² System Card Version 
3.00! Using lower versions will cause the game to give you an error message when 
it starts up. Not having the BIOS means it won't work at all.

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Other emulators have their own setup procedures, so 
check their documentation for instructions.

It's also important to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with button inputs being ignored, check your emulator's 
settings.

                    ****************************************
                    *          IV. Bonus Content           *
                    ****************************************

While the game itself is simple enough that it really doesn't need any 
explanation, it has a few hidden commands that are very useful, as well as some 
bonus material added for the translation.

  * The game normally doesn't allow voiced lines to be skipped until their audio 
finishes playing. However, this can be overridden with a cheat code: at the 
title screen, rotate the D-Pad five times clockwise starting from "Up". A sound 
will play once the code is entered correctly.

  * To access a visual/sound test, use the "New Game" option on the title screen 
to go to the character select menu. There, rotate the D-Pad five times 
counterclockwise starting from "Up". Upon correct entry, a sound will play, and 
the game will display all the characters' transformation sequences and attacks 
before depositing you at the sound test.
  
  * After entering the previous code, press the Run Button at the sound test to 
skip immediately to the game's climax and ending sequence. ...Or at least that's 
what would happen in the original game.
  
  * In an extra feature added for the translation, pressing the Run Button on 
the sound test will now lead to a menu in which you can choose to either view 
the ending as normal, or to instead view an extensive gallery of unused scenes, 
graphics, and dialogue that were uncovered while making the translation.
  
  * If you play the game on a system with the wrong BIOS version (not 3.00), 
you'll get an error message. It has a special accompanying audio message from 
the game characters that's been subtitled for the translation, so you might want 
to try running the game with the wrong BIOS just for fun.

                    ****************************************
                    *           V. Known Issues            *
                    ****************************************

There are no known issues with the patch itself, but do take note of the 
following:

  * As mentioned above, this game only supports two-button Control Pads, and 
will experience heavy input "glitches" (button presses not registering, cursor 
moving by itself, etc.) if run in six-button mode. Make sure that your console 
or emulator is set up to use two-button mode.

  * In the original game, Makoto's route had two lines of dialogue which 
attempted to play sound files that don't actually exist on the disc. This caused 
major problems internally that resulted in the game trying to load garbage data 
off of the CD and play it as a sound file, but by pure chance, nothing 
particularly noticeable ended up happening when the game was played on the 
original hardware (though some emulators would freeze when this occurred).
    These bugs have been fixed for the patch. One of them (the Usagi Dynamic) 
just had a mistake in the file name, so it plays as intended now. The other 
audio file was left off of the disc entirely, though, so there's no way to 
restore it. As a result, Makoto's line "Hahahah...S-Sorry, but...Hahahah!" 
during her conversation with Kiyomi has no voiceover, despite all other lines in 
the scene being voiced.
  
  * In the scene where Sailor Venus gets trapped in a barrier, there was a very 
obvious animation error that resulted in the scene rapidly and repeatedly 
cutting between a shot of the barrier and a close-up of Venus' face. This was 
caused by the game loading the wrong range of graphics for the animation, and 
has been fixed for the translation.
    One of the shots of Usagi during her semi-final battle probably has the same 
issue, but since it could plausibly be passed off as a stylistic choice, we left 
it alone.
  
  * At one point in her route, Ami refers to how the Senshi "used to live inside 
the Crystal Palace on the moon". As Sailor Moon fans will know, this is 
factually incorrect; the Crystal Palace is a feature of the future Crystal 
Tokyo, not the past Moon Kingdom. The characters should not even be aware of its 
existence at the point in the series when this game is set. This is a writing 
error that existed in the original game, not a translation issue.
  
                    ****************************************
                    *        VI. Authors' Comments         *
                    ****************************************
  
  ------------
  -- Supper --
  ------------
  
  Confession: I've never actually watched the Sailor Moon anime. In fact, I've 
only ever even read the first arc of the manga. Nonetheless, here we somehow are 
at the third Sailor Moon game I've done a translation hack for. The whole series 
is just one of those things I picked up by cultural osmosis a long time ago, and 
despite never really "getting into" the franchise in the normal way, it's 
something I've always enjoyed without quite understanding why.
  
  My work on this actually goes back to April 2018. Shortly after the release of 
the translation I did with Eien Ni Hen for the Sailor Moon beat-'em-up on the 
Mega Drive, I received an unexpected tip from Aerialrave about a translator 
who'd expressed interest in working on the PC-Engine game. I'd previously played 
it a little and was quite keen on it, so I did some preliminary hacking work and 
got in touch with the person. Though we made some initial arrangements for the 
translation and I went ahead and did the bulk of the hacking work, we ultimately 
fell out of contact and the project went dormant.
  
  Then at the end of last year, TheMajinZenki was itching for a new project to 
work on, and I discovered this was the only ready script I had on hand. After 
trying and failing to contact the original translator I'd been working with, we 
decided it was a dead project and that it would be okay to start it over with a 
new team. If you're that original translator and only finding out about this 
now... well, sorry, but we tried to get in touch with you first.
  
  So with that settled, we got back to work. I'd already done most of the 
difficult technical stuff during the initial attempt in 2018, so I ended up 
spending much of my time on the script editing. Fun fact: whenever multiple 
characters have the same scene in different routes, the game actually has a 
close-but-not-quite-duplicate copy of the script for each character. This made 
editing a real fun job because things had to be kept consistent for all the 
different copies of the same scene... and some scenes are shared among all five 
characters. I think we managed to pull it off, though. If you find any 
inconsistencies in different versions of a scene, they were like that in the 
original game. Probably.
  
  I also made the decision to make two different editions of the patch, one with 
honorifics/Japanese terminology and one without. I put up a poll on the Sailor 
Moon Forum during editing asking people's preferences for this – perhaps some of 
you guessed what I was up to? – and while the majority of responses supported 
leaving honorific stuff out, I felt like some people might still want it.
  
  The two patch editions are also a preemptive deterrent against anyone who 
might complain about my choices of terminology for the standard edition of the 
patch. Yes, I'm aware that "Sailor Soldier" is not the officially-used 
"translation" for "Sailor Senshi", but frankly I don't like the official "Sailor 
Guardian" term at all. If you're bothered by that choice or by anything else in 
the standard patch, then I invite you to use the honorifics-in edition. Or 
better yet, go download the freely available source code for this translation 
from its page on stargood.org and make your own version of the game with 
whatever text you want. You can use the DiC dub names, translate it into French, 
anything you like. I won't complain (probably).
  
  This is my first released translation project for a CD-based console, and was 
also my first time really dealing with audio-only scenes and vocal songs. Doing 
in-engine subtitles for scenes that were never intended to have them is not 
exactly the easiest thing in the world; I was actually quite lucky that this 
game doesn't use any hardware tricks that could have really made things 
complicated. I think the results are satisfactory, though since I haven't been 
able to test the game on real PC-Engine hardware, I still have my fingers 
crossed that the subtitles will be properly synced as they are on emulators.
  
  In the course of the project, I also discovered an absurd amount of unused 
content – almost 10% of the files on the game disc! Since some of it was 
actually quite interesting and fleshed out the story better than the finished 
product did, I decided to put it together into a bonus gallery accessible in the 
game itself. (Believe it or not, this actually took *less* time than writing a 
TCRF article would have.) Consider checking it out after you've completed the 
story.
  
  This will most likely be the last Sailor Moon game translation I work on, for 
the simple reason that we seem to have run out of worthwhile games that haven't 
already been translated. Pretty much everything that's left seems to be varying 
degrees of targeted squarely at children (Sailor Moon Collection and numerous 
Sega Pico games), low-quality (the later fighting games), or of little interest 
to anyone outside Japan (the arcade quiz game). This was by far the most 
interesting game left, as well as the largest Sailor Moon game I've done 
personally, so I'm glad we could go out with a bang.
  
  Given its obscurity, I'm still not sure much of anyone will actually play 
this, even with the draw of being a Sailor Moon game. But if you do, I hope you 
enjoy it. We put a lot of work into it, and I'd like to think the result is a 
polished, quality product.
  
  -------------------
  -- TheMajinZenki --
  -------------------

  I don't really know much about the series, so this translation was a bit of a 
challenge. I had to do a lot of research for things that were probably obvious 
for any fan of the series. With that said, I did my best to convey the 
personality of the characters properly. I hope you enjoy :)
  
  ------------
  -- cccmar --
  ------------

  Sailor Moon... who hasn’t heard this name really? It’s certainly one of the 
most well-known anime franchises in the West, and it has significant name 
recognition elsewhere too. This game is a VN that consists of 5 chapters as it 
were, with some degree of overlap to them. Generally, the script was pretty 
straightforward to edit. Overall, it’s a pretty long game if you decide to work 
your way through all 5 chapters. While there aren’t that many forks (and the 
changes are pretty much universally inconsequential to the plot itself) it 
offers a lot of spoken dialogue and funny situations reminiscent of the 
anime/manga. I hope you enjoy it, seeing that PCE-CD translations aren’t 
particularly common.

                    ****************************************
                    *         VII. Special Thanks          *
                    ****************************************

We'd like to extend special thanks to Aerialrave, without whom this project 
would probably never have happened. Things may not have turned out as originally 
envisioned, but hey, here we are now!

Thanks to William A. Braell, whose existing translations on Sailormusic.net for 
the game's opening and ending themes were used for the in-game subtitles. Check 
the following pages for the full lyrics:
  https://sailormusic.net/lyrics/koisuru-otome-wa-makenai/
  https://sailormusic.net/lyrics/onaji-hoshi-ni-umareta-futari-dakara/

Thanks as well to elmer for providing immensely helpful resources and support 
for PC-Engine hacking, including a special bugfixed Windows binary of bchunk 
that's used in the patching process.

And thanks to SadNES cITy Translations for the Delta Patcher program, which is 
bundled with this patch as a convenience.

Special thanks to Sailor Moon aficionados vivify93 and mzlab for playing the 
initial release of the patch and leaving detailed feedback. Due to their help, 
several translation errors were fixed and various other improvements made for 
the v1.1 release. If you ever play Sailor Moon: Another Story, be sure to check 
out the much-needed update that they made to the original 1999 translation!

                    ****************************************
                    *        VIII. Version History         *
                    ****************************************

v1.0 (19 Apr 2020): Initial release.

v1.1 (13 May 2020):
  - Fixed the message displayed at startup if the Backup Memory is too full to 
hold a save file, which had accidentally been left untranslated. Thanks to ran 
on the RHDN forums for reporting this.
  - Added support for the common "split BIN" format used by certain archival 
sites to the patching process.
  - Miniscule art touch-ups (e.g. subtitle outlines that had a few pixels 
missing).
  - Various small translation fixes and tweaks, courtesy of vivify93 and mzlab:
    - Corrected one of Zoisite's lines: during the scene at Naru's house, he 
should have referred to the Black Crystal rather than the Silver Crystal.
    - One of Queen Beryl's lines should have referred to Tuxedo Mask choosing 
Serenity over her; it said the opposite instead.
    - Removed a stray "onii-san" that had been mistakenly left in the 
no-honorifics version of the patch.
    - Changed instances of "akuryo taisan" to "evil spirit, begone" in the 
no-honorifics edition of the patch.
    - Changed Rika Fukami's name in the credits to "Rica Fukami", which seems to 
be how she styles her name in English.
    - A few extremely minor changes to wording here and there.
