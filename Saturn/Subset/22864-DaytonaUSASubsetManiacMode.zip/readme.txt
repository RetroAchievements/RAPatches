Use with:

(Redump)
File:               Daytona USA (USA) (Track 01).bin
BitSize:            72 Mbit
Size (Bytes):       9551472
CRC32:              302A51B7
MD5:                9138D2F1C105422CFC9162224D924246