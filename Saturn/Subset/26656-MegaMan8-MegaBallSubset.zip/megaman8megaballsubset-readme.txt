Apply patch to Mega Man 8 (USA) (Track 1).bin, naming it "Mega Man 8 - Mega Ball Subset (Track 1).bin"
Mega Man 8 (USA) (Track 2).bin can keep the original file name, use the .CUE file provided with this patch.

Use with:
(REDUMP)
File:               Mega Man 8 (USA) (Track 1).bin
BitSize:            2 Gbit
Size (Bytes):       296361408
CRC32:              4EEA7AE5
MD5:                A4D575CD681B7D7C88B45D639ED7FFB7