Use with:

(Redump)
File:               Magical Night Dreams - Cotton 2 (Japan) (Track 1).bin
Size (Bytes):       37951872
CRC32:              f110ab6b
MD5:                e3d6c7826c57ced4565ef3ef88bfd0b1
SHA1:               25366440f350ec6620e4f78ce61774238766caeb