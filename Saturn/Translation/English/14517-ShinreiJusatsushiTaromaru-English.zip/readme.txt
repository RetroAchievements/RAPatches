Use with:

(Redump)
File:               Shinrei Jusatsushi Taroumaru (Japan) (Track 01).bin
BitSize:            71 Mbit
Size (Bytes):       9375072
CRC32:              EFE9589B
MD5:                0117A9985542CF5AFEEA10327C6AF89B
SHA1:               7D6CCC28B0C9074175110023967DEF08AE42638B
SHA256:             790F95BCECAD708001366761991A62EFBF2B621522B05597A4E10875722F6545

File:               Shinrei Jusatsushi Taroumaru (Japan) (Track 13).bin
BitSize:            352 Mbit
Size (Bytes):       46146240
CRC32:              04D76CEA
MD5:                CB998C1A1F1E490A0014B902AEE5065E
SHA1:               BE70FB3500058192FD5BCFA0A13349B9E9DEDF96
SHA256:             7BC519AE2154E68F8002E5DB031D32589EB11621503FB534E85EA8145EEC878B

File:               Shinrei Jusatsushi Taroumaru (Japan) (Track 18).bin
BitSize:            36 Mbit
Size (Bytes):       4769856
CRC32:              B830CB98
MD5:                BA3A6806BD81EB37D40C89927B9E5813
SHA1:               91BF3ADF5B62587C07CC2865EDF883AD524956D1
SHA256:             BD0915AC37C403D2E3B90A1593C41EC3C353D249D7A38BDBFBCC4FA97CEBAFED

