Use with:

(Redump)
File:               DeathMask (Japan) (Disc 1) (Track 1).bin
BitSize:            2 Gbit
Size (Bytes):       391295184
CRC32:              DCDD5B21
MD5:                BCC8BE03C0B50265D2639EAE08576FF7
SHA1:               0F0712E6F93BCFF1CF85396282A8695A09D3439D
SHA256:             E4C1BA18367EFE93AC2C1445B8B18C89644F769A063D4B09E7CF0AFCE5657F17

Regarding rename-track-2.bat:
- Make sure it's in the same directory as the track 2 bin file.
- Running it will rename track 2 of discs 1-3 to match the provided .cue file. It'll work on them separately or all at once, so long as they're all in the same directory.