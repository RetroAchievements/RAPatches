Use with:

(Redump - Unmerged .bins)
File:               Yumimi Mix Remix (Japan) (Track 1).bin
BitSize:            2 Gbit
Size (Bytes):       316275792
CRC32:              C66910EB
MD5:                B26C298765D94FB0CB15790A06FE25C8
SHA1:               6F7934BEDAE3BD577E115AFC43DFD3B9BB5E338B
SHA256:             1C2D1EAC535A79EEC8DEA4CFB546EE9274DC8609D689BA65925E0C9E870D7323

File:               Yumimi Mix Remix (Japan) (Track 2).bin
BitSize:            159 Mbit
Size (Bytes):       20970432
CRC32:              5C51CD9B
MD5:                1B79BD69D1FB19C8A47BB576636B39BC
SHA1:               F85A0686E804132774F6D7737464F24E4ADF47B6
SHA256:             955CC2DA71772F7A48F7F1DEE1A195EC11520BFDBA1EA839F3119DACD4B9C96F

File:               Yumimi Mix Remix (Japan) (Track 3).bin
BitSize:            268 Mbit
Size (Bytes):       35167104
CRC32:              5FE94902
MD5:                FC1117B35537CAC79CB83CF3444C09F3
SHA1:               1792E217798339275D6E341A20C6CD7798454673
SHA256:             6E78A9C1B83392DC5DEFBC2EBCB20725B74FCB8F991016FB37BF8A8F61B7C86F

File:               Yumimi Mix Remix (Japan) (Track 4).bin
BitSize:            118 Mbit
Size (Bytes):       15483216
CRC32:              D668E6A9
MD5:                1E4D46D4D9EB4C63133BA75305A0941D
SHA1:               B935C628D433A389BE368C2583B63D376776AD8D
SHA256:             EA6EBAB04E46A3CCC03570C87AB5F690DAAC50C6AFE374D343ABEE7C5F41EBBC

====================================================================================

(Redump - Merged .bins)
File:               Yumimi Mix Remix (Japan).bin
BitSize:            2 Gbit
Size (Bytes):       387896544
CRC32:              8C291EE5
MD5:                D8661E29C0B882AFC09F8C9FB42B06AB
SHA1:               77793FE43F10CCB19A724E78D16AC4FDB7C711B3
SHA256:             9FF12BF7938DEA9A32938F42BD523D4BF40CFFB9DB5C42D52F0B187BFDC81FDD