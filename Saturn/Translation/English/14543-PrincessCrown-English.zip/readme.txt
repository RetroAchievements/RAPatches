Use with:

(Redump)
File:               Princess Crown (Japan) (Rev A) (11M) (Track 01).bin
BitSize:            666 Mbit
Size (Bytes):       87339168
CRC32:              E7305871
MD5:                1B070C4C2E108A791E17E0109DF168EB
SHA1:               AEF5549E5578C410383CBAB178AC04B3C4B046E6
SHA256:             668E1981C698CF8000C3A6D799057DCFC0449F71A2DAF4C089E3DDB1EF63B688