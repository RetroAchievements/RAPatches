Use with:

(Redump)
File:               Arcana Strikes (Japan) (Track 1).bin
BitSize:            3 Gbit
Size (Bytes):       503991264
CRC32:              CDD01A7C
MD5:                2F9BB94DC1CD9DADBA6878D19236DDE3
SHA1:               3CEF10BE4E49EC2255F505F11683A7B4B04C846D
SHA256:             95851A39733B520480421EA9BCCF40CA93C1AC240967181D8E314D0EA636CC36