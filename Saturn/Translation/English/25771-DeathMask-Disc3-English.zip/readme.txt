Use with:

(Redump)
File:               DeathMask (Japan) (Disc 3) (Track 1).bin
BitSize:            3 Gbit
Size (Bytes):       486953376
CRC32:              CC219F8A
MD5:                F52DEF3556EF45F9FEBFD18BF54719CE
SHA1:               0D06428279F297A0C024A711324E1817F624DA7B
SHA256:             EFDA16A9E1635089C28EAB4FAE6A93C12CE70C87562C10921E694E4A241C9806

Regarding rename-track-2.bat:
- Make sure it's in the same directory as the track 2 bin file.
- Running it will rename track 2 of discs 1-3 to match the provided .cue file. It'll work on them separately or all at once, so long as they're all in the same directory.