Use with:

(Redump)
File:               DeathMask (Japan) (Disc 2) (Track 1).bin
BitSize:            3 Gbit
Size (Bytes):       535230528
CRC32:              194E0875
MD5:                C53CA6A7D9D33C31A156897CA34301BF
SHA1:               7C49EDDC462008B449D92555772B985A02A3E727
SHA256:             A3320FFC9EC0583759A30CBC4E2C66A1AC33BA8950B6DA227DF36C0469D8DC5A

Regarding rename-track-2.bat:
- Make sure it's in the same directory as the track 2 bin file.
- Running it will rename track 2 of discs 1-3 to match the provided .cue file. It'll work on them separately or all at once, so long as they're all in the same directory.