@echo off
setlocal
cd /d "%~dp0"

for %%D in (1 2 3) do (
    if exist "DeathMask (Japan) (Disc %%D) (Track 2).bin" (
        ren "DeathMask (Japan) (Disc %%D) (Track 2).bin" "DeathMask (Japan) (En) (v0.2) (ShadowMask) (Disc %%D) (Track 2).bin"
        echo Renamed Disc %%D
    ) else (
        echo Disc %%D not found - skipping.
    )
)

echo.
echo Finished!
pause