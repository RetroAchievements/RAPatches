Use with:

(Redump)
File:               Falcom Classics (Japan) (Disc 1) (Game Disc) (Track 01).bin
BitSize:            185 Mbit
Size (Bytes):       24263232
CRC32:              2D079F77
MD5:                287ADC660E0D65E5AE3600157DB6C9D5
SHA1:               F400588A0BE305A36583846A814CC0631EDE0FA6
SHA256:             B44566DE1F06AD4621311004B6FE744FA40941C005D01BA304566A36BD78F2BB

Use the xdelta for the separate RA Hash. Using the original ppf patch will result in the same RA hash as the base game. 