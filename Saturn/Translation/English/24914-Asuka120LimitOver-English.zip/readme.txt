Use with:

(Redump)
File:               Asuka 120% Limited - Burning Fest. Limited (Japan) (Track 01).bin
Size (Bytes):       62337408
CRC32:              1DB11C62
MD5:                9F943972333E83A4D2C15CF0BB9F3434