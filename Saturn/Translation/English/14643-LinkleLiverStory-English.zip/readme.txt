Use with:

(Redump)
File:               Linkle Liver Story (Japan) (Track 1).bin
BitSize:            692 Mbit
Size (Bytes):       90709584
CRC32:              4BD10720
MD5:                F396D1AA11425C04F4DF1E01233DBCE9
SHA1:               027D53152475029182E182CA7C1DF3B97AC7C0E2
SHA256:             2B138CA74AB3F69C66D4AFA27DE8B555250A6DB64E4099173D59DC32861EE7D7