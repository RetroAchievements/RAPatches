Sega Xtreme contest entry 2022 for Knight 0f Dragon

Wachenoder Translation.

In this version, you will find almost all of the text translated in some capacity.

It currently uses the translation script found at game faqs by Glenn Rudy III and his wife.

Images with text have also been translated.

Play the game using multi track, since single seems busted.

This release is to ensure compatability and freezeless playthroughs.

If you would like to make a small donation and buy me a cup of coffee as a thanks, please send via paypal to knight0fdragon@gmail.com

If you would like to discuss the patch, or get the most up to date build,  please visit my discord channel at https://discord.gg/yWnUVCr or visit one of my friends below.


https://discord.gg/snRw4KzHBy Sega Xtreme
https://discord.gg/cYwykZxXxw Sega Saturn Shiro
https://discord.gg/yWnUVCr My Shining Force 3 Discord

Special thanks to Glenn for providing awesome resources, as well as Sega Shiro for hosting the patch at the last second.

Sources used or helpful to understand:

Translation by Glenn.
https://gamefaqs.gamespot.com/saturn/574646-wachenroder/faqs/25258

Manual translation by Glenn.
https://gamefaqs.gamespot.com/saturn/574646-wachenroder/faqs/25257

Name origins.
https://www.dampfkraft.com/wachenroder/character-name-origins.html