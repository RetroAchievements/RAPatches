FILE "Wachenroeder (Japan) (En) (v0.49) (Knight0fDragon) (Track 1).bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
FILE "Wachenroeder (Japan) (En) (v0.49) (Knight0fDragon) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Wachenroeder (Japan) (En) (v0.49) (Knight0fDragon) (Track 3).bin" BINARY
  TRACK 03 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Wachenroeder (Japan) (En) (v0.49) (Knight0fDragon) (Track 4).bin" BINARY
  TRACK 04 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
FILE "Wachenroeder (Japan) (En) (v0.49) (Knight0fDragon) (Track 5).bin" BINARY
  TRACK 05 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
