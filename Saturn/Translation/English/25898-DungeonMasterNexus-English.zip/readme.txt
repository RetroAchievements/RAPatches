Use with:

(Redump)
File:               Dungeon Master Nexus (Japan) (Track 1).bin
BitSize:            1 Gbit
Size (Bytes):       139278384
CRC32:              6852311B
MD5:                D83623212C7FD61623377CC9074BF3EA
SHA1:               2218799E3D832651BAED624563C6027E99856297
SHA256:             91A6E0BBED515475BE57BF073AA9EA613B49EB65FB4B85FF06472025F9F3676D