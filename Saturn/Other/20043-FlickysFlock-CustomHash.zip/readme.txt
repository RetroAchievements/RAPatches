Use with:

(itch.io)
File:               game.iso
BitSize:            9 Mbit
Size (Bytes):       1255424
CRC32:              3C4F1E04
MD5:                EB2520B413E4CCEF967A725F1273C7D2
SHA1:               B4DA7C9B67A4B76E8931CB810BD992F59491951A
SHA256:             4170868FC9B203B0099528137BE666A8672904740D95E730F6BF55DB873CA523

https://github.com/slinga-homebrew/Flickys-Flock/releases

The game as-is will load a different entry since the header does not have a unique identifier.

The patch was made simply to change the hash.