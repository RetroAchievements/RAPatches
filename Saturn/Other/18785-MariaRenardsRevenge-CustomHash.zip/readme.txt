Use with:

(itch.io)
File:               game.iso
BitSize:            292 Mbit
Size (Bytes):       38277120
CRC32:              826C0841
MD5:                047653CE4F9FDADBD50E9644ABA446D0
SHA1:               38F3EE2E943ACDFA08B3A9F1023542C110F2A3B9
SHA256:             6D812589178E57265B71DB2A4BBBD2DCC1811F4028B9414001DD57DF7310F106

https://z-team.itch.io/maria-renards-revenge-sega-saturn

The game as-is will load a different entry since the header does not have a unique identifier.

The patch was made simply to change the hash so it could get an entry.

Hopefully the finished game has a unique identifier!