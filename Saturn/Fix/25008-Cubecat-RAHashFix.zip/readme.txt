Use with:

File:               sl_elf.iso
BitSize:            18 Mbit
Size (Bytes):       2457600
CRC32:              FAE8E944
MD5:                93F40E540C2DA2B8BA9A082144937460
SHA1:               16EC1202C39F756A1D30DE9EC9F8FBD44DC3CC95
SHA256:             040BBBE1E9ABC9F4A2E85DD355D167AB8991BD22D4058256043F1ACDD84D27DC

Game is available here: https://segaxtreme.net/threads/cubecat-updated-builds.25188/