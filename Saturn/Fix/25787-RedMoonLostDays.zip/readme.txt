Use with:

(itch.io - https://neuromage.itch.io/red-moon-lost-days)

File:               Red Moon Lost Days (Disc 1) (Track 1).iso
BitSize:            110 Mbit
Size (Bytes):       14493696
CRC32:              A089E74E
MD5:                8A954C87E84F46BCE8687CAE9B3ACD08
SHA1:               58E55E5CA5A79B41AB8DE2364D63DDBC6FD3BD79
SHA256:             ADC88E13D68FE1BC95B01FA12A7414A2FC7057326725573E64BC6D3380B4352B

File:               Red Moon Lost Days (Disc 2) (Track 1).iso
BitSize:            96 Mbit
Size (Bytes):       12599296
CRC32:              5013F806
MD5:                D999AE268AFCB86D5F4E7C5C92603F2E
SHA1:               79D4B1612C3CA0AC7DD17F9122820C2A190F8992
SHA256:             B05FF777D6CEF39EEAE978F9A716D8D5A501A3942BDF498925F0676CB3917D21