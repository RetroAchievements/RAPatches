Use with:

(Homebrew)
File:               sl_elf.iso
BitSize:            56 Mbit
Size (Bytes):       7110656
CRC32:              f13ea949
MD5:                0864e19d0d6060fd79b45507181828ab
SHA1:               88b525d48644f467b9ce9993b01b3b28c414c257
SHA256:             49dace66004ed25c2e6f92432513f536fc0426d6a0173ca94de765c9087670b6

The above can be found at https://segaxtreme.net/resources/irreel-unreal-for-sega-saturn.140/

Or just get the patched game at https://github.com/RetroAchievements/RAPatches/raw/refs/heads/main/misc/homebrews/IRR%C3%89EL%20(v0.018)%20(XL2)%20(RA%20Compatible).zip