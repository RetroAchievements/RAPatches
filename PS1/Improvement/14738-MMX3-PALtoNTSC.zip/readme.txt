this patch is for the redump dump, you'll know because it has multiple bin files.
apply the patch to the Mega Man X3 (Europe) (Track 01).bin file (crc32: 9110886c) and have fun.

changelog:
v1.0
initial release.
