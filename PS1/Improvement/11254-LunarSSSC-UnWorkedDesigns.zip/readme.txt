         **************************************************************
         * Lunar: Silver Star Story Complete - Un-Worked Design Patch *
         *                 Version 0 (9 Apr. 2017)                    *
         *            by Supper (suppertails66@gmail.com)             *
         **************************************************************

This is a patch that fixes many issues introduced in the US version of the 
PlayStation game Lunar: Silver Star Story Complete by its publisher, Working 
Designs. The US release of the game heavily tampers with the enemy stats, 
decreases the amount of money and experience earned in battles and on the 
overworld, and makes several other frustrating changes to gameplay. This patch 
aims to restore the gameplay to match the original Japanese version.

              ****************************************************
              *                     Changes                      *
              ****************************************************

* All regular enemies have their stats restored to their original levels from 
the Japanese version. (In general, the US version reduced enemy HP by 10%, 
increased Attack by 20-40%, reduced EXP payout by 15%, and reduced Silver payout 
by 11%.)
* The stat scaling used for bosses now functions as in the Japanese version. 
(The US version increased the scale rate of some stats for certain bosses, and 
increased the minimum scaled level by 2-6 levels for all bosses.)
* Chests now give out their original amounts of money. (The amounts were halved 
in the US version.)
* Additionally, a hidden Silver bonus in the Vane library was restored to 100s. 
(It was reduced to 10s in the US version).
* Jessica's Escape Litany spell now costs the original 1 MP rather than 20 MP.
* The note containing the solution to the first puzzle in Myght's Tower, which 
was deliberately removed in the US version, has been restored.
* In the US version, the hint text for the final color-order puzzle in the 
Goddess Tower was changed to an incorrect order that doesn't reflect the actual 
solution; it's been changed to the proper order.
* Alex's Ocarina is no longer required to finish the game. It's now also 
possible to give it to Nall, as in the Japanese version.

One notable change in the US version that isn't reverted by this patch is the 
locations and availability of the bonus items (bromides, "Rememberizer"). While 
I'd like to fix these as well, it's difficult because (a) it takes a lot of 
finnicky scripting work, and (b) more importantly, I don't have translations of 
the Japanese dialogue for events that were removed from the US version, which 
makes doing a real restoration impossible. Sorry -- I'll try to do something 
about it in the future if the opportunity arises.

Other changes in the US version (e.g. rumble and analog support, outtakes, the 
horrible horrible made-up script) have been kept.

For further details on the alterations in the US version, see this page (though 
I may not have written the Regional Differences section yet, depending on when 
you read this): https://tcrf.net/Lunar:_Silver_Star_Story_Complete_(PlayStation)

              ****************************************************
              *               Patching Instructions              *
              ****************************************************

--- WHAT YOU'LL NEED ---
* BIN/CUE format images of both discs of the US version of Lunar: Silver Star 
Story Complete (PlayStation). These should match the listings on redump.org (see 
http://redump.org/disc/2676/ and http://redump.org/disc/2677/). Note that your 
disc images *must* be split into separate tracks -- see below.
* If you're on Windows, the xdelta patching utility (http://xdelta.org/) is 
provided in this distribution. On other platforms, you'll need to acquire 
version 3.0.8 or later on your own.

--- AUTOMATIC PATCHING METHOD (WINDOWS) ---

First, you need to make sure that for the game's two discs, you have three files 
each (six files in total) representing the three separate tracks on each disc. 
Track 1 is the game data, and the other two are audio tracks. If you have a 
single BIN for each disc, you need to split them into their three component 
tracks. See the instructions in the "Manual Patching Method" section.

Next, you must ensure that the filenames of the three files for each disc end in 
"(Track 1)", "(Track 2)", etc, and rename them appropriately if they do not. For 
example, a valid filename would be "Lunar - Silver Star Story Complete (USA) 
(Disc 1) (Track 1).bin". This is necessary so the patcher can find all the 
tracks based on their number.

If both those conditions are satisfied, and you're using Windows:
  * Move your disc image files into the same directory as the program.
  * Drag and drop the BIN file representing Disc 1, Track 1 onto 
binpatch_disc1.bat.
  * Drag and drop the BIN file representing Disc 2, Track 1 onto 
binpatch_disc2.bat.

If everything works, this should produce six new files, three for each disc:
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 1) (Track 1).bin"
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 1) (Track 2).bin"
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 1) (Track 3).bin"
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 2) (Track 1).bin"
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 2) (Track 2).bin"
  * "Lunar - Silver Star Story Complete Un-Worked Design (Disc 2) (Track 3).bin"
  
Included in this patch are two CUE files, one for each disc: "Lunar - Silver 
Star Story Complete Un-Worked Design (Disc 1).cue" and "Lunar - Silver Star 
Story Complete Un-Worked Design (Disc 2).cue". To play the game, load one of 
them in your emulator of choice.

Some emulators such as Mednafen allow multiple discs to be specified in a .m3u 
playlist file. To play the game on these emulators, load the included M3U file, 
"Lunar - Silver Star Story Complete Un-Worked Design.m3u".

If this doesn't work, try using the manual patching method below to diagnose the 
problem.

--- MANUAL PATCHING METHOD ---

As mentioned above, if you only have one BIN file for each disc, you'll first 
need to split it into separate tracks. There are certainly tools that can do 
this for you automatically based on the CUE files, though I don't have any I can 
recommend to you. In the worst case, you can do it manually according to the 
following specifications (based on data from redump.org):

Disc 1:
  * Track 1: position 0, size 693402528
  * Track 2: position 614666976, size 26570544
  * Track 3: position 641237520, size 8041488
  * TOTAL SIZE: 614666976

Disc 2:
  * Track 1: position 0, size 693402528
  * Track 2: position 693402528, size 26570544
  * Track 3: position 719973072, size 8041488
  * TOTAL SIZE: 728014560

--- PATCHING STEPS---
1. First, !!!***verify that your BIN files have the correct MD5 hashes***!!! 
They should be as follows:

Disc 1, Track 1: ff8c7002690e8ea8f109ac04626937ed
Disc 2, Track 1: 38d241e69b55b72c43c8e53e4d070765

(The other tracks aren't patched, so they don't matter.)

If your files' hashes don't match, the patch almost certainly won't work. You 
can obtain the hashes by using the md5sum utility on *nix, or the FCIV utility 
(https://support.microsoft.com/en-us/kb/889768) on Windows.

2. Use xdelta to apply "Lunar - Silver Star Story Complete Un-Worked Design 
(Disc 1) (Track 1).xdelta" to the BIN representing Disc 1, Track 1. If you're 
using the command line, this would look something like:

xdelta3 -d -s "Lunar - Silver Star Story Complete Un-Worked Design (Disc 1) 
(Track 1).xdelta" "Lunar - Silver Star Story Complete (USA) (Disc 1) (Track 
1).bin" "Lunar - Silver Star Story Complete Un-Worked Design (Disc 1) (Track 
1).bin"

If you use a GUI wrapper, it should be self-explanatory, but make sure the 
output file is named "Lunar - Silver Star Story Complete Un-Worked Design (Disc 
1) (Track 1).bin".

3. Repeat the above procedure for Disc 2, Track 1, obviously changing filenames 
as appropriate. Make sure you use the other xdelta file, "Lunar - Silver Star 
Story Complete Un-Worked Design (Disc 2) (Track 1).xdelta".

4. Rename the four track files that you didn't patch to "Lunar - Silver Star 
Story Complete Un-Worked Design (Disc 1) (Track 2).bin", etc., as appropriate.

5. Included in this patch are two CUE files, one for each disc: "Lunar - Silver 
Star Story Complete Un-Worked Design (Disc 1).cue" and "Lunar - Silver Star 
Story Complete Un-Worked Design (Disc 2).cue". To play the game, move them to 
the same directory as your patched disc images and load one of them in an 
emulator.

6. For emulators like Mednafen that use M3U playlist files to load multiple 
discs at once, an M3U file is also included ("Lunar - Silver Star Story Complete 
Un-Worked Design.m3u"). Again, make sure it's in the same directory as the disc 
image files before using it.

--- TROUBLESHOOTING ---
* If the patched BIN files won't run, check the MD5 hashes of your original BIN 
files. The correct hashes are given in the steps above. If they don't match, try 
using BIN/CUE files generated by a different program.
* If the automatic patching method fails to produce any files, make sure they're 
named correctly (they must end in "(Track 1)", "(Track 2"), etc.).

              ****************************************************
              *                  Known Issues                    *
              ****************************************************

* Bromides are still in their altered locations from the US version.
* The "Rememberizer" is still only available for free for a limited time.

I'd like to point out that LunarNET lists several supposed "regional 
differences" that are actually incorrect. The following points were *not* 
changed between the US and Japanese PlayStation versions, as far as I can tell, 
and so I've left them as they are in the patch. Perhaps some of these were 
actually differences between the various console ports?
* Male hot springs cutscenes only trigger one at a time in both JP and US 
versions.
* In both versions, Alex and Luna have no MP in the epilogue, and the 
(nonfunctional) White Dragon Wings remain in the player's inventory.
* The actual order of the last color puzzle in the Goddess Tower is the same in 
both versions, though the hint text was modified.

              ****************************************************
              *                 Version History                  *
              ****************************************************

Version 0 (4/9/17)
  * Initial release.

              ****************************************************
              *                  Special Thanks                  *
              ****************************************************

* Cebix, for the excellent psximager utilities
* LunarNET, for listing several changes I didn't know about
* Everyone on ROMhacking.net who provided feedback and support
