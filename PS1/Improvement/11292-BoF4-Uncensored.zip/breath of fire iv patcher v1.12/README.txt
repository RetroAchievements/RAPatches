uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu
Breath of Fire IV Uncensored
v1.12 (30/12/2023)
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn

-------------------------------------
Table of Contents
-------------------------------------

0. Credits                  - [CRED]
1. Using the patcher        - [USNG]
    1.1 Compatibility
        1.1.1 Other hacks
        1.1.2 Save files
    1.2 Patching
2. Changelog                - [CLOG]



------------------------------[USNG]
0. Credits
------------------------------------

Navarchos       - Hacking, programming, script editing
Lazarus_DS      - Original translations
FlamePurge      - Script editing and modifications

Thanks to SpyroChr for getting me to do this in the first place, and to 
everyone who's expressed interest and given feedback.
The open source projects used by this patcher can be found at LICENSES.txt.
The source code for the patcher can be found in resources/src.zip.



------------------------------[USNG]
1. Using the patcher
------------------------------------

+++ 1.1 Compatibility +++
The patcher is currently designed to work with only the North American release
of the game (SLUS-01324).
An image of the Japanese release (SLPS-02728) must be also be supplied to 
uncensor the third scene.

++ 1.1.1 Other hacks ++
This may or may not work with other hacks for Breath of Fire IV. The Dengeki
Store patch and the subtitled intro FMV are two hacks that are known to be
compatible with the uncensor. The Classic Controls hack does not work with
the uncensor currently, as its patch conflicts with the uncensor's patch.

Here are the files changed by this hack:
- ./SLUS_013.24
- ./BIN/BATTLE/AB000_00.EMI (identify)
- ./BIN/BMAGIC/MAGIC239.EMI (identify)
- ./BIN/SYSTEM/GAME.EMI
- ./BIN/SYSTEM/INIT.EMI (identify)
- ./BIN/WORLD/AREAD145.EMI (3rd scene)
- ./BIN/WORLD/AREAD157.EMI
- ./BIN/WORLD/AREAM027.EMI
- ./BIN/WORLD/AREAM031.EMI

++ 1.1.2 Save files ++
Save files created by the original, censored game may or may not work. See
the instructions below to check whether or not your save file is compatible.

Abbreviations:
UV+3 - Uncensored version (third scene uncensored)
UV-3 - Uncensored version (third scene not uncensored)
OV   - Original, unmodified NA version

IF you want to play UV+3:
    IF you are playing from start to finish using a save file created by UV+3:
        Everything is OK.
    ELSE IF you are using a save file created by the OV:
        It depends on where you are along the game in that save file.
        IF you have not reached Chapter 3 in the save file:
            Everything is OK.
        ELSE IF you have reached Chapter 3 in the save file:
            IF you are at or before Pabpab in the save file:
                Everything is OK.
            ELSE IF you have obtained the Deluxe Rod in the save file:
                IF you have reached Koshka or Saldine:
                    Everything is OK, but don't revisit the <?> before Saldine.
                ELSE:
                    Switch to UV-3.
            ELSE IF you have cleared the game in the save file:
                Don't revisit the <?> before Saldine.
    ELSE IF you are using a save file created by UW-3:
        The compatibility tree for the OV save file applies.

ELSE IF want to play UV-3:
    IF you are playing from start to finish using a save file created by UV-3:
        Everything is OK.
    ELSE IF you are using a save file created by the OV:
        Everything is OK.


+++ 1.2 Patching +++
1. Open the patcher. The patcher comes as "patcher.exe" in the .zip file. It 
does not install locally.

    1a. If you want to play the game on a PS3, PS Vita, or PSP, use
    "patcheralt.exe". The rest of the instructions apply for both patchers.

2. Open the image of the North American release. If you have "Track 1" and
"Track 2", just use "Track 1"/whatever the bigger one is.

    2a. The third scene can be optionally uncensored as well. Check "Uncensor 
    the third scene" and supply an image of the Japanese release. Similary, use
    "Track 1"/the bigger one if there are two files.

    2b. The Identify restoration hack can be optionally enabled. Check "Restore
    identify". This will allow Scias to obtain Identify. The spinner can be used
    to adjust at what level Scias obtains the ability. 3 is the default level, 
    as it allows Scias to obtain Identify when he joins your party. This 
    overwrites whatever abilities that Scias might have gained at that level.

3. Press patch. The patcher will not modify the North American image you give
to it, but will generate a .bin and .cue files in the same folder as the 
patcher. If you wish, these two files can be moved to your game folder.


For the patcher to run properly, it is recommended that you have over 1 GB of 
free space on your disk. Do not modify anything in the "resources" folder.



------------------------------[CLOG]
2. Changelog
------------------------------------
31/12/2023  - v1.12     - the Identify patcher issue wasn't resolved in
                          the previous version
17/07/2023  - v1.11     - fix Identify patcher not working properly
09/10/2022  - v1.1      - fix incorrect enemies being loaded
                        - fix issue with censored scenes not working on
                          images created by patcheralt.exe
07/10/2022  - v1.01     - add alternative patcher using psx-mode2
30/09/2022  - v1.0      - first public release
