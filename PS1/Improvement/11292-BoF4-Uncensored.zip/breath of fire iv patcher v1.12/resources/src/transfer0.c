/*
 *Copyright (C) 2022 Navarchos
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdint.h>
#define SOURCE_BASE 0xA4000
#define TARGET_BASE 0xBB000

int main(void)
{
    FILE *area_source = fopen("./bof_tmp0/BIN/WORLD/AREAD013.EMI", "rb");
    if (!area_source)
    {
        printf("Error opening texture source!\n");
        return 1;
    }
    FILE *area_target = fopen("./bof_tmp0/BIN/WORLD/AREAM027.EMI", "r+b");
    if (!area_source)
    {
        printf("Error opening target file!\n");
        return 1;
    }

    fseek(area_source, SOURCE_BASE + 0x2C, SEEK_SET);
    fseek(area_target, TARGET_BASE + 0x1C14, SEEK_SET);
    uint8_t buffer[20];

    // first section
    for (uint8_t i = 0; i < 16; i++)
    {
        fread(buffer, 1, 20, area_source);
        fwrite(buffer, 1, 20, area_target);
        fseek(area_source, 44, SEEK_CUR);
        fseek(area_target, 44, SEEK_CUR);
    }

    // second section
    fseek(area_target, TARGET_BASE + 0x2814, SEEK_SET);
    for (uint8_t i = 0; i < 16; i++)
    {
        fread(buffer, 1, 20, area_source);
        fwrite(buffer, 1, 20, area_target);
        fseek(area_source, 44, SEEK_CUR);
        fseek(area_target, 44, SEEK_CUR);
    }

    fseek(area_source, SOURCE_BASE + 0x102C, SEEK_SET);
    for (uint8_t i = 0; i < 16; i++)
    {
        fread(buffer, 1, 20, area_source);
        fwrite(buffer, 1, 20, area_target);
        fseek(area_source, 44, SEEK_CUR);
        fseek(area_target, 44, SEEK_CUR);
    }

    fclose(area_source);
    fclose(area_target);

    return 0;
}
