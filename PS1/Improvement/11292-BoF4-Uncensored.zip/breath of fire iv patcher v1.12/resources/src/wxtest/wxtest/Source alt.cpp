/*
 *Copyright (C) 2022-2023 Navarchos
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <wx/app.h>
#include <wx/button.h>
#include <wx/checkbox.h>
#include <wx/frame.h>
#include <wx/filepicker.h>
#include <wx/filefn.h>
#include <wx/menu.h>
#include <wx/msgdlg.h>
#include <wx/panel.h>
#include <wx/spinctrl.h>
#include <wx/stattext.h>
#include <wx/tooltip.h>
#include <wx/utils.h> 

class App : public wxApp
{
public:
    virtual bool OnInit();
};

class Frame : public wxFrame
{
public:
    Frame();

private:
    wxPanel* panel = new wxPanel(this);
    wxMenuBar* menu_bar = new wxMenuBar();
    wxMenu* help_menu = new wxMenu();
    wxFilePickerCtrl* en_file_picker = new wxFilePickerCtrl(panel, wxID_ANY,
        "", "Select the English (NA) ISO file", "Disc image files (*.iso;*.img;*.bin)|*.iso;*.img;*.bin",
        { 50,30 }, { 250, 50 });
    wxStaticText* en_label = new wxStaticText(panel, wxID_ANY, "English image file", { 50, 80 }, { 200, 20 });
    wxFilePickerCtrl* jp_file_picker = new wxFilePickerCtrl(panel, wxID_ANY,
        "", "Select the Japanese (JP) ISO file", "Disc image files (*.iso;*.img;*.bin)|*.iso;*.img;*.bin",
        { 50, 100 }, { 250, 50 });
    wxStaticText* jp_label = new wxStaticText(panel, wxID_ANY, "Japanese image file", { 50, 150 }, { 200, 20 });
    wxCheckBox* third_scene_checkbox = new wxCheckBox(panel, wxID_ANY, "Uncensor the third scene",
        { 150, 170 }, wxDefaultSize);
    wxStaticText* scias_label = new wxStaticText(panel, wxID_ANY, "Level at which Scias\nobtains Identify", { 35, 220 }, wxDefaultSize);
    wxToolTip* scias_label_tooltip = new wxToolTip("The default is 3. Overrides any existing skill gained at that level, if there are any.");
    wxSpinCtrl* scias_lvl = new wxSpinCtrl(panel, wxID_ANY, "3", { 150, 220 }, wxDefaultSize, wxSP_ARROW_KEYS, 3, 99, 3);
    wxCheckBox* identify_checkbox = new wxCheckBox(panel, wxID_ANY, "Restore Identify", { 150, 260 }, wxDefaultSize);
    wxButton* run_button = new wxButton(panel, wxID_ANY, "Patch!", { 100, 300 }, wxDefaultSize);

    //void OnReadme(wxCommandEvent& event);
    //void OnAbout(wxCommandEvent& event);
    void OnCheck3rdScene(wxCommandEvent& event);
    void OnSelectENImage(wxCommandEvent& event);
    void OnSelectJPImage(wxCommandEvent& event);
    void OnCheckIdentify(wxCommandEvent& event);
    void OnRun(wxCommandEvent& event);
};

wxIMPLEMENT_APP(App);

bool App::OnInit()
{
    Frame* frame = new Frame();
    frame->Show(true);
    frame->SetSize({ 400, 400 });
    return true;
}

Frame::Frame() : wxFrame(NULL, wxID_ANY, "Breath of Fire IV patcher")
{
    jp_file_picker->Enable(false);
    jp_label->Enable(false);
    third_scene_checkbox->SetValue(false);
    scias_label->Enable(false);
    scias_lvl->Enable(false);
    run_button->Enable(false);

    /*
    help_menu->Append(wxID_HELP, "README.txt");
    help_menu->AppendSeparator();
    help_menu->Append(wxID_ABOUT, "About");
    menu_bar->Append(help_menu, "Help");
    SetMenuBar(menu_bar);
    */

    scias_lvl->SetToolTip(scias_label_tooltip);

    //Bind(wxEVT_MENU, &Frame::OnReadme, this, wxID_HELP);
    third_scene_checkbox->Bind(wxEVT_CHECKBOX, &Frame::OnCheck3rdScene, this);
    en_file_picker->Bind(wxEVT_FILEPICKER_CHANGED, &Frame::OnSelectENImage, this);
    jp_file_picker->Bind(wxEVT_FILEPICKER_CHANGED, &Frame::OnSelectJPImage, this);
    identify_checkbox->Bind(wxEVT_CHECKBOX, &Frame::OnCheckIdentify, this);
    run_button->Bind(wxEVT_BUTTON, &Frame::OnRun, this);
}

/*
void Frame::OnReadme(wxCommandEvent& event)
{
    wxMessageBox("Success!", "Breath of Fire IV patcher", wxOK | wxICON_INFORMATION);
}
*/

void Frame::OnCheck3rdScene(wxCommandEvent& event)
{
    if ((&event)->IsChecked())
    {
        if (jp_file_picker->GetPath() == wxEmptyString
            || en_file_picker->GetPath() == wxEmptyString)
            run_button->Enable(false);
        else
            run_button->Enable(true);
        jp_file_picker->Enable(true);
        jp_label->Enable(true);
    }
    else
    {
        if (en_file_picker->GetPath() == wxEmptyString)
            run_button->Enable(false);
        else
            run_button->Enable(true);
        jp_file_picker->Enable(false);
        jp_label->Enable(false);
    }
}

void Frame::OnSelectENImage(wxCommandEvent& event)
{
    run_button->Enable(true);
}

void Frame::OnSelectJPImage(wxCommandEvent& event)
{
    if (en_file_picker->GetPath() != wxEmptyString)
        run_button->Enable(true);
}

void Frame::OnCheckIdentify(wxCommandEvent& event)
{
    scias_label->Enable(!scias_label->IsEnabled());
    scias_lvl->Enable(!scias_lvl->IsEnabled());
}

void Frame::OnRun(wxCommandEvent& event)
{
    // extract English ISO
    std::string en_path_arg = (en_file_picker->GetPath()).ToStdString();
    en_path_arg.insert(0, 1, '\"');
    en_path_arg.append("\" -x bof_tmp0 -s out.xml");
    wxExecute("./resources/dumpsxiso.exe " + en_path_arg, wxEXEC_SYNC);

    // patch AREAM027.EMI and add new portrait
    std::string AREAM027_xdelta_arg = "-d -s ./bof_tmp0/BIN/WORLD/AREAM027.EMI ./resources/AREAM027.EMI.xdelta ./resources/AREAM027.EMI";
    wxExecute("./resources/xdelta3.exe " + AREAM027_xdelta_arg, wxEXEC_SYNC);
    wxCopyFile("./resources/AREAM027.EMI", "./bof_tmp0/BIN/WORLD/AREAM027.EMI", true);
    wxRemoveFile("./resources/AREAM027.EMI");
    wxExecute("./resources/transfer0.exe", wxEXEC_SYNC);

    // patch AREAM031.EMI
    std::string AREAM031_xdelta_arg = "-d -s bof_tmp0/BIN/WORLD/AREAM031.EMI resources/AREAM031.EMI.xdelta resources/AREAM031.EMI";
    wxExecute("./resources/xdelta3.exe " + AREAM031_xdelta_arg, wxEXEC_SYNC);
    wxCopyFile("./resources/AREAM031.EMI", "./bof_tmp0/BIN/WORLD/AREAM031.EMI", true);
    wxRemoveFile("./resources/AREAM031.EMI");

    // patch AREAD157.EMI
    std::string AREAD157_xdelta_arg = "-d -s bof_tmp0/BIN/WORLD/AREAD157.EMI resources/AREAD157.EMI.xdelta resources/AREAD157.EMI";
    wxExecute("./resources/xdelta3.exe " + AREAD157_xdelta_arg, wxEXEC_SYNC);
    wxCopyFile("./resources/AREAD157.EMI", "./bof_tmp0/BIN/WORLD/AREAD157.EMI", true);
    wxRemoveFile("./resources/AREAD157.EMI");

    // patch GAME.EMI
    std::string GAME_xdelta_arg = "-d -s bof_tmp0/BIN/SYSTEM/GAME.EMI resources/GAME.EMI.xdelta resources/GAME.EMI";
    wxExecute("./resources/xdelta3.exe " + GAME_xdelta_arg, wxEXEC_SYNC);
    wxCopyFile("./resources/GAME.EMI", "./bof_tmp0/BIN/SYSTEM/GAME.EMI", true);
    wxRemoveFile("./resources/GAME.EMI");

    // patch SLUS_013.24
    std::string EXE_xdelta_arg = "-d -s bof_tmp0/SLUS_013.24 resources/SLUS_013.24.xdelta resources/SLUS_013.24";
    wxExecute("./resources/xdelta3.exe " + EXE_xdelta_arg, wxEXEC_SYNC);
    wxCopyFile("./resources/SLUS_013.24", "./bof_tmp0/SLUS_013.24", true);
    wxRemoveFile("./resources/SLUS_013.24");

    if (third_scene_checkbox->IsChecked())
    {
        // extract Japanese ISO
        std::string jp_path_arg = (jp_file_picker->GetPath()).ToStdString();
        jp_path_arg.insert(0, 1, '\"');
        jp_path_arg.append("\" -x bof_tmp1");
        wxExecute("./resources/dumpsxiso.exe " + jp_path_arg, wxEXEC_SYNC);

        // patch AREAD145.EMI
        std::string AREAD145_xdelta_arg = "-d -s resources/AREAD145tmp.EMI resources/AREAD145.EMI.xdelta resources/AREAD145.EMI";
        wxExecute("./resources/transfer1.exe", wxEXEC_SYNC);
        wxExecute("./resources/xdelta3.exe " + AREAD145_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/AREAD145.EMI", "./bof_tmp0/BIN/WORLD/AREAD145.EMI", true);
        wxRemoveFile("./resources/AREAD145.EMI");
        wxRemoveFile("./resources/AREAD145tmp.EMI");

        // patch GAME.EMI
        std::string GAME2_xdelta_arg = "-d -s bof_tmp0/BIN/SYSTEM/GAME.EMI resources/GAME2.EMI.xdelta resources/GAME.EMI";
        wxExecute("./resources/xdelta3.exe " + GAME2_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/GAME.EMI", "./bof_tmp0/BIN/SYSTEM/GAME.EMI", true);
        wxRemoveFile("./resources/GAME.EMI");

        // patch SLUS_013.24
        std::string EXE_xdelta_arg = "-d -s bof_tmp0/SLUS_013.24 resources/SLUS_013.24.2.xdelta resources/SLUS_013.24";
        wxExecute("./resources/xdelta3.exe " + EXE_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/SLUS_013.24", "./bof_tmp0/SLUS_013.24", true);
        wxRemoveFile("./resources/SLUS_013.24");

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
        wxShell("rmdir bof_tmp1 /Q /S");
#else
        wxShell("rm -rf bof_tmp1");
#endif
    }

    if (identify_checkbox->IsChecked())
    {
        // patch AB000_00.EMI
        std::string AB000_00_xdelta_arg = "-d -s bof_tmp0/BIN/BATTLE/AB000_00.EMI resources/AB000_00.EMI.xdelta resources/AB000_00.EMI";
        wxExecute("./resources/xdelta3.exe " + AB000_00_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/AB000_00.EMI", "./bof_tmp0/BIN/BATTLE/AB000_00.EMI", true);
        wxRemoveFile("./resources/AB000_00.EMI");

        // patch MAGIC239.EMI
        std::string MAGIC239_xdelta_arg = "-d -s bof_tmp0/BIN/BMAGIC/MAGIC239.EMI resources/MAGIC239.EMI.xdelta resources/MAGIC239.EMI";
        wxExecute("./resources/xdelta3.exe " + MAGIC239_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/MAGIC239.EMI", "./bof_tmp0/BIN/BMAGIC/MAGIC239.EMI", true);
        wxRemoveFile("./resources/MAGIC239.EMI");

        // patch INIT.EMI
        std::string INIT_xdelta_arg = "-d -s bof_tmp0/BIN/SYSTEM/INIT.EMI resources/INIT.EMI.xdelta resources/INIT.EMI";
        wxExecute("./resources/xdelta3.exe " + INIT_xdelta_arg, wxEXEC_SYNC);
        wxCopyFile("./resources/INIT.EMI", "./bof_tmp0/BIN/SYSTEM/INIT.EMI", true);
        wxRemoveFile("./resources/INIT.EMI");

        // place Identify in Scias' skill table
        wxExecute("./resources/scias.exe " + std::to_string(scias_lvl->GetValue()));
    }

    wxExecute("./resources/mkpsxiso.exe out.xml -y -o \"Breath of Fire IV Uncensored.bin\"", wxEXEC_SYNC);
    wxCopyFile("./mkpsxiso.cue", "./Breath of Fire IV Uncensored.cue", true);
    wxRemoveFile("./mkpsxiso.cue");


#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
    wxShell("rmdir bof_tmp0 /Q /S & del out.xml");
#else
    wxShell("rm -rf bof_tmp0 & rm -f out.xml");
#endif

    wxMessageBox("Success!\nThe uncensored image can be located in the same folder as this patcher.", "Breath of Fire IV patcher", wxOK | wxICON_INFORMATION);
}
