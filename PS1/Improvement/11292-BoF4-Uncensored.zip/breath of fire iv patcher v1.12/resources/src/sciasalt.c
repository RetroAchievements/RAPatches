#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

int main(int argc, char **argv)
{
    uint8_t skill[1] = {0xef};
    int lvl = atoi(argv[1]);
    if (lvl > 99) lvl = 99;
    else if (lvl < 3) lvl = 3;
    lvl -= 3;
    FILE *game_emi = fopen("./resources/GAME.EMI", "r+b");
    fseek(game_emi, 0xF56E + 8 * lvl, SEEK_SET);
    fwrite(skill, 1, 1, game_emi);
    fclose(game_emi);

    return 0;
}
