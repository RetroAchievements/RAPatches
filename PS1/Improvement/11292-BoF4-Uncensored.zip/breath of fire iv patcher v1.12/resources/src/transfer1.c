/*
 *Copyright (C) 2022 Navarchos
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define JP_SCENE_START      0xdf000
#define JP_PORTRAIT_START   0xd7800
#define JP_INSERT0_START    0xdfddc
#define JP_INSERT1_START    0xdfe70
#define EN_JUMP             0xd5800

uint32_t from_little32(uint8_t bytes[4])
{
    return bytes[0] | bytes[1] << 8 | bytes [2] << 16 | bytes[3] << 24;
}

uint8_t *to_little32(uint32_t x)
{
    uint8_t *bytes = malloc(sizeof(uint8_t) * 4);
    uint32_t scan = 0x000000ff;
    for (int i = 0; i < 4; i++)
    {
        bytes[i] = (x & scan) >> (i * 8);
        scan <<= 8;
    }
    return bytes;
}

int main(void)
{
    uint8_t section[360000];
    FILE *transplant = fopen("./bof_tmp1/BIN/WORLD/AREAD145.EMI", "rb");
    if (!transplant)
    {
        printf("Transplant file not found!");
        return 1;
    }
    FILE *old = fopen("./bof_tmp0/BIN/WORLD/AREAD145.EMI", "rb");
    if (!old)
    {
        printf("Target file not found!");
        return 1;
    }
    FILE *target = fopen("./resources/AREAD145tmp.EMI", "w+b");

    uint32_t section_size;
    uint32_t excess;
    uint32_t addr = 0x800;
    uint8_t buf32[4];

    fread(section, 1, 2048, old);
    fwrite(section, 1, 2048, target);

    for (int i = 0; i < 11; i++)
    {
        fseek(old, 0x10 + i * 16, SEEK_SET);
        fread(buf32, 1, 4, old);
        section_size = from_little32(buf32);
        if ((excess = section_size % 2048) != 0)
            section_size += 2048 - excess;
        fseek(old, addr, SEEK_SET);
        fread(section, 1, section_size, old);
        fwrite(section, 1, section_size, target);
        addr += section_size;
    }

    // portraits
    fseek(transplant, JP_PORTRAIT_START, SEEK_SET);
    fread(section, 1, 28672, transplant);
    fwrite(section, 1, 28672, target);

    fseek(old, EN_JUMP, SEEK_SET);
    fread(section, 1, 2048, old);
    fwrite(section, 1, 2048, target);

    fread(section, 1, 3564, old);
    fwrite(section, 1, 3564, target);
    fseek(transplant, JP_INSERT0_START, SEEK_SET);
    fread(section, 1, 4, transplant);
    fwrite(section, 1, 4, target);
    fread(section, 1, 144, old);
    fwrite(section, 1, 144, target);
    fseek(transplant, JP_INSERT1_START, SEEK_SET);
    fread(section, 1, 196, transplant);
    fwrite(section, 1, 196, target);
    fread(section, 1, 6332, old);
    fwrite(section, 1, 6332, target);

    //
    section[0] = 0x00;
    section[1] = 0x70;
    fseek(target, 0xc0, SEEK_SET);
    fwrite(section, 1, 2, target);

    //
    section[0] = 0x4c;
    section[1] = 0x22;
    fseek(target, 0xe0, SEEK_SET);
    fwrite(section, 1, 2, target);

    //
    section[0] = 0xd1;
    fseek(target, 0x2000 + 0xd6778, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd682c, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6908, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6a48, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6bf4, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6bf4, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6ce4, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6dbc, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6e80, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x8f;
    fseek(target, 0x2000 + 0xd6d04, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x8a;
    fseek(target, 0x2000 + 0xd6d18, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x5b;
    fseek(target, 0x2000 + 0xd6dd4, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x28;
    fseek(target, 0x2000 + 0xd6de8, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x12;
    fseek(target, 0x2000 + 0xd6dec, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6e88, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6ec8, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6f28, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0xb8;
    fseek(target, 0x2000 + 0xd6e8d, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x46;
    fseek(target, 0x2000 + 0xd6e95, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6ea9, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6f3d, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0xa9;
    fseek(target, 0x2000 + 0xd6ecd, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6f35, SEEK_SET);
    fwrite(section, 1, 1, target);

    //
    section[0] = 0x72;
    fseek(target, 0x2000 + 0xd6f2d, SEEK_SET);
    fwrite(section, 1, 1, target);

    fseek(target, 0x2000 + 0xd6f41, SEEK_SET);
    fwrite(section, 1, 1, target);

    uint32_t addrsing[8] = {
        0x2000 + 0xD6FA4,
        0x2000 + 0xD6FA8,
        0x2000 + 0xD6FB0,
        0x2000 + 0xD6FD8,
        0x2000 + 0xD6FFC,
        0x2000 + 0xD7030,
        0x2000 + 0xD7068,
        0x2000 + 0xD7E8C
    };

    uint32_t pointer;
    uint8_t *buf32p;
    for (int i = 0; i < 8; i++)
    {
        fseek(target, addrsing[i], SEEK_SET);
        fread(buf32, 1, 4, target);
        pointer = from_little32(buf32);
        pointer += 200;
        buf32p = to_little32(pointer);
        fseek(target, addrsing[i], SEEK_SET);
        fwrite(buf32p, 1, 4, target);
        free(buf32p);
    }

    uint32_t addrplur[4][2] = {
        {0x2000 + 0xD70C4, 12},
        {0x2000 + 0xD7B10, 31},
        {0x2000 + 0xD7E18, 23},
        {0x2000 + 0xD820C, 13}
    };

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < addrplur[i][1]; j++)
        {
            fseek(target, addrplur[i][0] + j * 4, SEEK_SET);
            fread(buf32, 1, 4, target);
            pointer = from_little32(buf32);
            if (pointer > 0x801f1680)
            {
                pointer += 200;
                buf32p = to_little32(pointer);
                fseek(target, addrplur[i][0] + j * 4, SEEK_SET);
                fwrite(buf32p, 1, 4, target);
                free(buf32p);
            }
        }
    }

    fclose(transplant);
    fclose(old);
    fclose(target);
}
