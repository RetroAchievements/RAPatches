this patch is for the redump dump, you'll know because it has multiple bin files.
apply the patch to the Mickey's Wild Adventure (Europe) (Track 01).bin file (CRC32: 3AB548F8 or 6BA284AD)
or Mickey's Wild Adventure (Europe) (EDC) (Track 01).bin file (CRC32: 41AED5BF)
according to the dump you got and don't forget to edit your cue file if you rename the bin files.
xdelta 3.1.0 was used to create the patches.
have fun!

changelog:
v1.3
rebased hack on edc version of the iso. this will hopefully fix some issues some people were having.

v1.2
added alternative patches for the newer edc and no-edc dumps.

v1.1
y-pos adjustment, it shouldn't affect most emulators but necessary on real hardware.

v1.0
initial release.