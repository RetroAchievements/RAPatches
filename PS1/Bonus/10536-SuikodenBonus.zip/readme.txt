Use with: 

Suikoden (USA).bin (Redump) - use 1.0, NOT 1.1/Rev 1
RA Checksum: ef046ead448119490ce4c0640cdcb393
md5: c10448fdabcce4dd8efccd5b6d369fa6
CRC: 5CB74712
