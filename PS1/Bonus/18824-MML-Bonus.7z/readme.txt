Use with:
(Redump)
Mega Man Legends (USA) (Track 1).bin
MD5: 5d275ab5d6e4ab79b792990c70cc5970
CRC: 1F55BD97



Instructions:

- Use the provided xdelta patch on "Mega Man Legends (USA) (Track 1).bin"

- Save as "Mega Man Legends (USA) (Track 1) (Bonus).bin" and delete original bin.

- "Mega Man Legends (USA) (Track 2).bin" should remain untouched.

- Replace "Mega Man Legends (USA).cue" with "Mega Man Legends (USA) (Bonus).cue"

