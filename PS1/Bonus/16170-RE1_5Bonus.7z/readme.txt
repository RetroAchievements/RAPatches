Use ~Prototype~ Resident Evil 1.5 MZD (Fixed) [Bonus].bps with:

Resident Evil 1.5 (Proto + Hack).bin
RA hash: 42bd3a24c993b993a4f7992d0a29720d
MD5: 1403b776f85a7c1e4800e0f7a28f7771
CRC32: 963c412d


Use ~Prototype~ Resident Evil 1.5 MZD (Grant) [Bonus].bps with:

RA hash: 6fb2418c1078867555c2c79fd08f5746
MD5: 9387b5cd27b9bde136e5a25e5ad7a2e2
CRC32: 20768ae3


Use ~Prototype~ Resident Evil 1.5 MZD (Old Weapon) [Bonus].bps with:

RA hash: 57b8bc8a20cbc84117a4200b851b5f32
MD5: 750173e115d34f878724ae5d124aa28a
CRC32: 5ae9a0a8
