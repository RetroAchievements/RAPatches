Use with:

(Redump)
Suikoden II (USA).bin [SLUS-00958]
MD5: d0e75f47e4b2451339a5f13ad821ca5d
CRC: 7FBE0579