Use with:

(Redump)
Suikoden II (USA).bin
d0e75f47e4b2451339a5f13ad821ca5d
7FBE0579