Use with:

(Resume)
Final Fantasy Chronicles - Final Fantasy IV (USA) (Rev 1)
md5: A9CB3EBBBC9759D45EEB5E5832B0D252
CRC: E3290277
