Use with:

Redump
Tony Hawk's Pro Skater 3 (USA).bin
MD5: 06c7b61e953f0777803b7d6a90b09f86
CRC32: 85114182
RA Checksum: 2179b75dda735509ab4f34da438c372b