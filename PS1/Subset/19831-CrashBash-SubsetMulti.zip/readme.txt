Use with:

(Redump)
Crash Bash (USA).bin
637f2286b1071d42f883e5592cf2df69
69A6CD83