Use with:

(Redump)
Final Fantasy VIII (USA) (Disc 1).bin
50d5b62e81b5369f18c8a145af716af9
2691D2DE

Final Fantasy VIII (USA) (Disc 2).bin
2ae4e2022d376a0775e66369de96dc59
E3EB68DF

Final Fantasy VIII (USA) (Disc 3).bin
58461d8ea573b990c7bbcc32d0feb8a8
D38EE91E

Final Fantasy VIII (USA) (Disc 4).bin
5a83d022aa592d4e91c02943467d1fd6
6CFB6ADF