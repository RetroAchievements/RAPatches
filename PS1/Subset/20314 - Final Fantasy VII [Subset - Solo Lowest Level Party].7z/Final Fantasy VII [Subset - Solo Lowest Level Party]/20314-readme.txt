Patch: Final Fantasy VII [Subset - Solo Lowest Level Party] (USA) (Disc 1).xdelta
Use with: Final Fantasy VII (USA) (Disc 1).bin [Redump]
Original BIN Checksum: cce4e76d020b47847fe8e2f81ff613db
Original RA Checksum: 665933b4dbbdfa04b328a2deccea2a30
Patched BIN Checksum: 7ef6050629443eec144f64e8e51831c5
Patched RA Checksum: f9bcb9d8f234994bcbfd7ae0a5872480

Patch: Final Fantasy VII [Subset - Solo Lowest Level Party] (USA) (Disc 2).xdelta
Use with: Final Fantasy VII (USA) (Disc 2).bin [Redump]
Original BIN Checksum: ccf63cd314d3e79878323199eb09d7dd
Original RA Checksum: 22e745953a67496b8d2f41e091de3811
Patched BIN Checksum: 4f12237f955a5ff93892bf3d3f4ff499
Patched RA Checksum: 138a0013ffd3fa973ed21e59c554ffd0

Patch: Final Fantasy VII [Subset - Solo Lowest Level Party] (USA) (Disc 3).xdelta
Use with: Final Fantasy VII (USA) (Disc 3).bin [Redump]
Original BIN Checksum: eac916b42d5c24f951c8dec2f13a63de
Original RA Checksum: f0bab44902aa941830a686bb11f85356
Patched BIN Checksum: 67ae729a76e10052156dd2aba6a66cc8
Patched RA Checksum: fc2b784f029a4522cf36b0d870a6881b