Patch: Final Fantasy VII [Subset - Bonus] (Disc 1).xdelta
Use with: Final Fantasy VII (USA) (Disc 1).bin [Redump]
Original BIN Checksum: cce4e76d020b47847fe8e2f81ff613db
Original RA Checksum: 665933b4dbbdfa04b328a2deccea2a30
Patched BIN Checksum: fe66ad7a5f8c0402f5fd799041c6fecc
Patched RA Checksum: 56b51ed5c62a82fdbd4534b5988f1471

Patch: Final Fantasy VII [Subset - Bonus] (Disc 2).xdelta
Use with: Final Fantasy VII (USA) (Disc 2).bin [Redump]
Original BIN Checksum: ccf63cd314d3e79878323199eb09d7dd
Original RA Checksum: 22e745953a67496b8d2f41e091de3811
Patched BIN Checksum: fb0a662636a2b4cc1e739043684fd9bb
Patched RA Checksum: 42c4d95f128cbd162cef987a60493f28

Patch: Final Fantasy VII [Subset - Bonus] (Disc 3).xdelta
Use with: Final Fantasy VII (USA) (Disc 3).bin [Redump]
Original BIN Checksum: eac916b42d5c24f951c8dec2f13a63de
Original RA Checksum: f0bab44902aa941830a686bb11f85356
Patched BIN Checksum: 689257f70dfa4bb83056195859bb9250
Patched RA Checksum: c8625f30ef75bd54353a76da276001d9

Patch: Final Fantasy VII [Subset - Bonus] (Disc 4).xdelta
Use with: SaGa Frontier (USA).bin [Redump]
Original BIN Checksum: 95f57b8f33470e6763c0a947b9e1a13f
Original RA Checksum: adac89b48ca06ec74c29222fa7dba568
Patched BIN Checksum: 6b656fd6305ba31a933f6fe0448978fd
Patched RA Checksum: c7d956f5cc57efa0d7cbd954d16f7f19



