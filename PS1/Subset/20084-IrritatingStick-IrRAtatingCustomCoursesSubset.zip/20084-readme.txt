Base:
Redump
Irritating Stick (USA).bin
CRC-32: e5c40f9d

Intructions:
Apply the Irritating Stick (USA) [Subset - IrRAtating Custom Courses].xdelta patch to Irritating Stick (USA).bin with the xdelta program. Copy the desired memory card file to your memory card directory. Load the patched .bin file with the .cue file that is provided. 