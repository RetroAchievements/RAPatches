Patch: Final Fantasy VII [Subset - LLNIIENACMO] (USA) (Disc 1).xdelta
Use with: Final Fantasy VII (USA) (Disc 1).bin [Redump]
Original BIN Checksum: cce4e76d020b47847fe8e2f81ff613db
Original RA Checksum: 665933b4dbbdfa04b328a2deccea2a30
Patched BIN Checksum: 33846255ca2efb7b92193798d6cc3996
Patched RA Checksum: 3a6aec54b34a26b1a454049af58c08de

Patch: Final Fantasy VII [Subset - LLNIIENACMO] (USA) (Disc 2).xdelta
Use with: Final Fantasy VII (USA) (Disc 2).bin [Redump]
Original BIN Checksum: ccf63cd314d3e79878323199eb09d7dd
Original RA Checksum: 22e745953a67496b8d2f41e091de3811
Patched BIN Checksum: 63148b082386a491357c64f48a95b365
Patched RA Checksum: c79e573e97d495050987fda7c48f1a13

Patch: Final Fantasy VII [Subset - LLNIIENACMO] (USA) (Disc 3).xdelta
Use with: Final Fantasy VII (USA) (Disc 3).bin [Redump]
Original BIN Checksum: eac916b42d5c24f951c8dec2f13a63de
Original RA Checksum: f0bab44902aa941830a686bb11f85356
Patched BIN Checksum: eebb81873237553231a07e10b1d63f87
Patched RA Checksum: 92ad091b6cb9e8581b4639fc23d1ada5