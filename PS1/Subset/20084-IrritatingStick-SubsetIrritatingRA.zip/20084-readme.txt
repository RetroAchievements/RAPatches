Use with:

Redump
Irritating Stick (USA).bin
MD5: 9d25afc7525fa6d2c4a487174e260c5c
CRC32: b57cd541
RA Checksum: 7b2a12c096662d1c43bddcbe182b687c