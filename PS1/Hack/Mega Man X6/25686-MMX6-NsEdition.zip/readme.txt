Use with:

(Redump)
File:               Mega Man X6 (USA) (Rev 1).bin
BitSize:            4 Gbit
Size (Bytes):       599985792
CRC32:              8E6D014D
MD5:                237B6FEDDD1A88E86AB1CDDC8822F03F