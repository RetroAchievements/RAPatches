Use with:

(Redump)
Final Fantasy IX (USA) (Disc 1).bin
MD5: dfe70b9dbdabf6b80c27d244a3b172df
CRC: 49521342