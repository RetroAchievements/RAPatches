Use with:

Redump
Chocobo no Fushigi na Dungeon (Japan).bin
MD5: 52914d6bf757433174016768f17e016c
CRC32: 6add0f2b
RA Checksum: 99c6a75f233fb74567d7807a0395b31b