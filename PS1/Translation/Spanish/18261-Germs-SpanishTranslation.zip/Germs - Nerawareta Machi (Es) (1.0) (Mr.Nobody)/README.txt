###################################################################
Germs Nerawareta Machi Traducción en castellano v1.0 (Octubre 2021)
###################################################################

## Introducción ##

Germs es un juego de mundo abierto, por el que se puede navegar caminando, conduciendo un coche o tomando 
un autobús. Aunque gran parte del juego consiste en explorar y resolver puzles. Durante el combate, si los 
jugadores pierden no mueren, sino que acaban infectados, por lo que tienen que correr al hospital para 
curar su infección. El protagonista es un periodista que ha regresado a su ciudad natal para investigar 
los misteriosos sucesos relacionados con las extrañas criaturas mutantes que aparecen en la región.

El parche ha sido testado en una PS1 y se ha completado sin problemas.

El 100% de los dialogos/imágenes están completamente en castellano.
Para esta primera versión no se han añadido acentos ni caracteres especiales a la fuente.


## Instalación ##

- Arrastra y suelta el archivo BIN en "Arrastra el archivo BIN sobre este archivo.bat".
- Se generarán "germs_nawareta_machi_esp.bin" y "germs_nawareta_machi_esp.cue" en la misma carpeta del parche.
- ¡Que lo disfrutes!

* Si no usas Windows puedes utiliza el archivo .xdelta3 en la carpeta "patch_data" 
en su archivo BIN para aplicar el parche con programas como xdelta.


## Créditos ##

Mr. Nobody 	- Hack / Traducción al castellano 


## Contacto ##

¿Has encontrado fallos o has tenido algún problema? Pasa por nuestro discord:
*  https://discord.gg/bewGNtm

También puedes seguirme para apoyar otras traduciones y proyectos:

https://www.youtube.com/channel/UCIKecQiCyFs9fGBBZ2WEPdg
https://mrnobodystudios.blogspot.com/
https://twitter.com/mrnobodystudios
http://www.romhacking.net/community/4650/