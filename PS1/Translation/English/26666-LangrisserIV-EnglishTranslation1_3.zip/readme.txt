Use with:

(Redump)
Langrisser IV & V - Final Edition (Japan) (Disc 1) (Langrisser IV Disc) (Track 1).bin
MD5: fc0e02b6f2221b6e84e86fa41a193be1
CRC32: aff30325
File Size: 549.64 MB (576338784 Bytes)