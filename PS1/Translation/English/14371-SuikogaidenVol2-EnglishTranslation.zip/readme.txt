
-------------------------------------------------------------------------------

                  - Suikogaiden Translation Project presents: -
                    Suikogaiden Vol.2: Duel at Crystal Valley

      Original Title: Genso Suikogaiden Vol.2: Crystal Valley no Kettou

-------------------------------------------------------------------------------

Table of contents:

1. Applying the patch
2. Technical notes
3. Translation notes
4. Credits
5. A short word

-------------------------------------------------------------------------------

1. Applying the patch

-------------------------------------------------------------------------------

What you'll need:

- an ISO of your copy of Suikogaiden Vol.2
- PPF-O-Matic (http://www.romhacking.net/utilities/356/)
- the patch

1. Start PPF-O-Matic and where it says ISO file load up your image of the game.
2. Where it says Patch you load the patch file.
3. Press apply.
4. Burn the image to disc or load the ISO in your emulator of choice.

-------------------------------------------------------------------------------

2. Technical notes

-------------------------------------------------------------------------------

- If you load data from Suikogaiden Vol.1 and that data has Suikoden and
Suikoden II data on it and the hero from Suikoden is called TcDohl, the game
will automatically correct this to Tir. All other names will be transferred
exactly as they are in your Suikoden II game.

- This is a Japanese game so remember that the O button confirms and X cancels.

-------------------------------------------------------------------------------

3. Translation notes

-------------------------------------------------------------------------------

Most people who have played the games in the series (in particular the earlier
ones) will know that when it comes to the translations, they're... iffy at best
and inconsistent between games.

Rather than stay 100% true to the official translations, we have chosen to go
for a correct translation instead, which means that some terms have changed
from what you may be familiar with.


- Sealed Orbs: This is the same as Rune Crystals in Suikoden II's English
translation. Later entries, like Suikoden V, also use Sealed Orbs so this
should be a familiar term if you've kept up with the series.

- Talismans: For reasons that aren't really understood, these are called
Scrolls in all the English games that feature them. Not only is it inaccurate,
but when you see Nash use them, you'll see that the word doesn't fit their
description.

- Fire Hero: Called the 'Flame Champion' in Suikoden III but the 'Fire Hero'
in Suikoden II. As the original Japanese doesn't really allow for "champion" as
a translation, we've gone with the correct one.

- Keepers of the Flame: Called 'Fire Bringer' in Suikoden III, but 'Keepers of
the Flame' in Suikoden II. As 'Fire Bringer' is completely nonsensical as a
name for a group of people, we have gone with 'Keepers of the Flame'.

- Danceny: Called Dunceney in Suikoden II's translation, Miklotov's sword
is supposed to be named after a character from the 18th century novel
"Les Liaisons Dangereuses". As such it has been corrected.

- Grosser Fluss, etc.: These are not flights of fancy on the translators part,
they actually use the German words in the Japanese text as well. Apparently
it's a thing in Harmonia to give stuff names in German. For reference this is
what they mean:

 Grosser Fluss = Great Flow
 Weiss         = White
 Schwarz       = Black

-------------------------------------------------------------------------------

4. Credits

-------------------------------------------------------------------------------

- Project Leader -

 Raww Le Klueze

- Translators -

 Kestrel (Episodes 1 & 3)
 Graeme Howard (Episode 2)
 Raww Le Klueze / Magi (Episode 4)

- Translation Checkers -

 Raww Le Klueze
 Magi
 
- Tech Team - 

 Rufas
 David Holmes
 Pokeytax

- Image Editors -

 Raww Le Klueze (Title Screen)
 Scarlet (Episode Cards)

- Special Thanks -
 rin_uzuki
 Everyone on the Suikogaiden Translation Project's Forum

-------------------------------------------------------------------------------

5. A short word

-------------------------------------------------------------------------------

So here we are - almost 6 months have passed since we released the patch for
Vol.1 and now we're finally releasing the patch for Vol.2 and closing the book
on this project.

After spending several years on this, it feels slightly strange to finally
complete it.

Many people have been involved with this project, and without them we would be
lost but thanks goes in large part to Pokeytax. Without him Vol.1 would 
probably still be in limbo, and without rin_uzuki starting the project in the
first place, it is very likely no one else would have. However, it's thanks to
the hard work of everybody involved that this is possible.

I was simply here to guide it through its finishing paces and I thank everyone
involved.

With that said, even though it's almost 13 years after the Japanese release,
it is now possible to enjoy the full Suikoden series in English for the first
time, so please, do enjoy it.

- Raww Le Klueze
September 5th 2013

-------------------------------------------------------------------------------
