Use with:

King's Field (Japan).bin (REDUMP)
c2b8b1652407c6c8107b0c93e20624a6
54C8F64A
