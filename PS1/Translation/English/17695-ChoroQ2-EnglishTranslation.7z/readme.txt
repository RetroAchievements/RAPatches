Use with:

(Redump)
Choro Q 2 (Japan) (Track 1).bin
MD5: eca4cf24b8dd960dc71bf31c36b8cbed
CRC: 36F21378