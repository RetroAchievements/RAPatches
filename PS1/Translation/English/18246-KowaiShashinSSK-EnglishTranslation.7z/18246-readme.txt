Use with:

(Redump)
Kowai Shashin - Shinrei Shashin Kitan (Japan).bin
MD5: 885253d8a5dbf83ff55d14c4d4c277e8
CRC: 500487D6