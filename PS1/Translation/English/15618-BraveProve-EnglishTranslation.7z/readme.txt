Use with:

(Redump)
Brave Prove (Japan).bin
2ede8a69149c9e0d1280eb37016440aa
BC99727A