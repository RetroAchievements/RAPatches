Use with:

iS - Internal Section (Japan).bin
MD5: 765c5e9d7ab335d97818ab092eb17b60
RA Checksum: aa3b44d1fdefc947cd2b5769efa8dbea
http://redump.org/disc/5413/

This patch was originally obtained here: https://www.romhacking.net/translations/1265/
All three patches were used, then ECC errors were corrected to allow the game to run on more accurate emulators, such as Beetle PSX HW.
Tool used to fix these errors: https://www.romhacking.net/utilities/1550/
