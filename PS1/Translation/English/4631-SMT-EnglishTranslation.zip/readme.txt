Use with:

(Redump)
Shin Megami Tensei (Japan).bin
59e8eb95e20c5d65dd1158d5a43c850c
13676EAD

https://www.romhacking.net/translations/6610/