Use with:

(Redump)
File:               Moon - Remix RPG Adventure (Japan) (Rev 1).bin
BitSize:            4 Gbit
Size (Bytes):       640491936
CRC32:              4B828F86
MD5:                CDDCA6A65595FB84AB7F79F7763A84CA