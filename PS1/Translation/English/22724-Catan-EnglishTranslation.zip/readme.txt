Use with:

(Redump)
Catan - Die erste Insel (Germany) (Track 1).bin
MD5: d90d59ffce104a91ac729edae1697a13
CRC32: 91000F37
File Size: 253 MB (265660752 Bytes)

Patched (Track 1).bin and .cue can be dropped into the same
directory as the base game.