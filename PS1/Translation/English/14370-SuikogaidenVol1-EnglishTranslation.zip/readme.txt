
-------------------------------------------------------------------------------

                  - Suikogaiden Translation Project presents -
                    Suikogaiden Vol.1: Swordsman of Harmonia

           Original Title: Genso Suikogaiden Vol.1: Harmonia no Kenshi

-------------------------------------------------------------------------------

Table of contents:

1. Applying the patch
2. Technical notes
3. Translation notes
4. Credits
5. Thanks For a Job Well Done

-------------------------------------------------------------------------------

1. Applying the patch

-------------------------------------------------------------------------------

What you'll need:

- an ISO of your copy of Suikogaiden Vol.1
- PPF-O-Matic (http://www.romhacking.net/utilities/356/)
- the patch

1. Start PPF-O-Matic and where it says ISO file load up your image of the game.
2. Where it says Patch you load the patch file.
3. Press apply.
4. Burn the image to disc or load the ISO in your emulator of choice.

-------------------------------------------------------------------------------

2. Technical notes

-------------------------------------------------------------------------------

- If you wish to load data from Suikoden II it has to be from a NTSC U.S. game,
it will not work with a PAL / European save.

- This is a Japanese game so remember that the O button confirms and X cancels.

-------------------------------------------------------------------------------

3. Translation notes

-------------------------------------------------------------------------------

Most people who have played the games in the series (in particular the earlier
ones) will know that when it comes to the translation they're... iffy at best
and inconsistent between games.

Rather than stay 100% true to the official translations we have chosen to go
for a correct translation instead, which means that some terms have changed
from what you may be familiar with.


- Sealed Orbs: This is the same as Rune Crystals in Suikoden II's English
translation. Later entries like Suikoden V also use Sealed Orbs so this
should be a familiar term if you've kept up with the series.

- Talismans: For reasons that aren't really understood these are called
Scrolls in all the English games that feature them. Not only is it inaccurate,
when you see Nash use them you'll see that the word doesn't fit their
description.

- Exorcism: The Rune is called Resurrection in all English games and the spell
Charm Arrow. We can't work out why the rune and spell have different names
since they're the exact same in the Japanese games, and both are wildly
inaccurate so we've corrected them. For reference, when Exorcism Talismans are
mentioned it's about the spell.

- Mathers: Called Mazus in Suikoden II's translation, but he is named after
Samuel McGregor Mathers, the translators just didn't understand it. Since we
know that this was the intention of the creators we have corrected it.

- Grosser Fluss, etc: Yeah, they actually use the German words in the Japanese
text as well. Apparently it's a thing in Harmonia to give stuff names in
German. For reference this is what they mean:

 Grosser Fluss = Great Flow
 Weiss         = White
 Schwarz       = Black
 Stern         = Star
 Mond          = Moon
 Sturm         = Storm

-------------------------------------------------------------------------------

4. Credits

-------------------------------------------------------------------------------

- Project Leader -

 rin_uzuki

- Game Ripper - 

 Shu Xion

- Translators -

 rin_uzuki (Chapter 1 - 3)
 Niahak (Chapter 4)
 Pelto (additional translation)
 Sage (additional translation)

- Translation Checkers -

 Raww Le Klueze
 Magi
 arkady18

- Tech Team - 

 Rufas
 David Holmes
 Pokeytax

- Image Editors -

 Raww Le Klueze
 Scarlet

- Game Testers -

 Pokeytax
 Raww Le Klueze
 Drasis
 darthzack
 SolidSnake916
 Mikhal
 Man in Black
 Neocactar

- Team Motivator -

 Celest

- Special Thanks -

 Everyone on the Suikogaiden Translation Projects Forum and all proofreaders


-------------------------------------------------------------------------------

5. Thanks For a Job Well Done

-------------------------------------------------------------------------------

Hello, all!
rin_uzuki here. 

It's been a long journey, but we've finally made it--Suikogaiden I is now
available to play in English for the first time ever! A lot of sweat, blood
andeven tears went into our translation and patch of this game, and we hope
everyone will enjoy the fruit of our labors. 

Although I appreciate when people take the time to thank me as the 'leader' of
the Suikogaiden I Translation Project, after the translation stage was
complete, this project was carried almost solely on the shoulders of our dear
technical team; Raww Le Klueze, Pokeytax, Rufas, David Holmes and the others.
They deserve your thanks most of all, as the patch wouldn't have been a
possibility without them, so be sure to send your thankful emails and
goodwill-filled vibes along to them, too!

Special thanks also  goes out to our ever-present team motivator, Celest, and
everyone else who's taken the time to cheer us all on over the past five years.
As RLK wrote so succienctly in the credits, thanks really are due to everyone
on the forums. I wish we could list you all! My apologies to those who are
absent from the list; it's by no means an exhaustive one, which I think would
have been impossible at this point due to the sheer number of people who have
lent us their support over the years. Each and every one of you were valuable
to this project's success, whether or not your name's listed up above. So
don't take it to heart if you're not there--take it to heart that you were
there for the ride and helped make Suikogaiden in English a reality!

I'm so glad we were all able to meet and make this project a success! 
Now, as usual, I'm writing far too much, so I'd better wrap this up before you
have a full-length novel on your hands. 

Job well done, lasses, lads. Time to rest up for a bit and get our HP and MP
restored.

Enjoy the patch (especially Sierra's bit, eh?), and let's all meet again
someday!

- rin_uzuki
March 18th, 2013 
11:43pm

(First update on the Suikogaiden website: July 1st 2008, 11:43pm.)

-------------------------------------------------------------------------------
