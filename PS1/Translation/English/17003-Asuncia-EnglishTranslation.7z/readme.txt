Use with:

(Redump)
Asuncia - Majou no Jubaku (Japan).bin
6abc9324d5bf43e97b3f3d0ce0217d86
E4521B6E