===============================================================================
Tales of Phantasia PS1
English Localization version 1.0
Produced by Phantasian Productions
http://www.tales-cless.org/

Readme written by and from the perspective of Cless
===============================================================================

Table of Contents:

 1. Introduction
 2. Patching Instructions
 3. Known Issues
 
================================================================================
 1. Introduction
================================================================================
This is a fan localization for the ground-up remamke of Tales of Phantasia
released for the Sony PlayStation in Japan on December 23rd, 1998.

This project has been in the works since the early months of the year 2000.
It's finally released to the public on December 31st, 2012.

This patch is confirmed to work on real, modified PlayStation 1 and
PlayStation 2 consoles.

===============================================================================
 2. Patching Instructions
===============================================================================
See this forum post:
http://forum.tales-cless.org/tales-of-phantasia/patching-instructions-1345/

===============================================================================
 3. Known Issues
===============================================================================
Don't give your characters any names that will take up a ton of screen space.
Stupid nonsense names with lots of Ws, w's, or m's, that is. This may cause the
text in some places to overflow the text box and possibly go off-screen. The
rule of thumb here is, if you MUST rename your characters, make them no longer
than the name "Woodrow" takes up. "Woodrow" contains two of the widest
characters, and five characters of about average length. Honestly, just about
any reasonable name I can think of that's 7 letters or less takes up a good
deal less screen space than "Woodrow" does.

The shop named "Tiger Blade" is unaffected by the arte name selector.
Unfortunately, there's apparently some kind of bug in the World Map menu's code
that causes the entire list of town and shop names to disappear if we use the
variable that selects the name based on setting.

Text formatting may be a little odd in some places. I wanted to do some more
manual formatting, but didn't get around to it, and the occasional manually
formatted line isn't very nice looking. Most people probably won't care about
or notice this though. One of my rules of thumb was to get new sentences to
begin after a linebreak.

A glitch once occurred during the second of the final battles that froze the
game on a PlayStation 2 console during pre-beta testing. The cause of this is
unknown, and we have been unable to reproduce it after several attempts to do
so. It may have just been some incredibly random unexplainable thing.