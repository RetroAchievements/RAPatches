Use with:

(Redump)
Breath of Fire III (USA).bin
361401817312d45eef0a05a8dd717308
CFB1F3F0