Use with:

(No Intro)
Digimon World 2003 (Europe) (En,Fr,De,Es,It).bin
md5: da76a5685b875c353343102b7587fded
crc: 007DF18E