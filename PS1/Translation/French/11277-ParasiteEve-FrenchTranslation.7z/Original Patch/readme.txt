                             %%%%%%%%%
                     @#@@@@@#@        %%
            @     ##@@@@@@@@@###        %%
                @@@@@#  %    @##          %                  @@@@@@#
             #  #@@@    %     ##           %%          @@@@@@      @#
              #  @     %     @#@      @###   @@@@@@@@@@
              @ @#     %     #@       ########%
              @##       %   ##        @###@    %
              @@        % ###         @##@     %%        @@@@@#@@@@@@@#
             @#@#       %#@          @##@      @@@@@@@@@@
      [   p  @@a@#  r@@@%a    s    i@###t@@##e@  %   e    v    e     ]
            @@@@#@@@     %        @######        %
            @@@@ @        %       @####          %
            @###  @       %        ###@           %
             ###   #       %       ###            %
              ###   @       %      @##@           % @#@@@@@#@
               ###  @        %%    @@#@@@@@@@@@@@@@@@#@@@@
                  @  @         %      @@@@@@@@## %
                 @ ######       %%              %
                  @#   @#         %%%%         %
                         @            %%%%%%%%%
                                                      traduction fran�aise
  					                 patch version 0.9

--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~RPG-T~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
***********************http://rpgplayer.uhrft.org*************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
************************PARASITE EVE �SquareSoft**************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--------------------------------------------------------------------------

			Vendredi 23 Janvier 2004

                                  ROAR !

Bonjour � vous tous et merci d'avoir t�l�charg� ce patch et de lire ce
readme! Nous sommes fiers de pouvoir vous proposer la traduction de cet
excellent jeu qu'est Parasite Eve, vous permettant pour la premi�re fois
de le d�couvrir en fran�ais dans sa totalit�. Et nous sommes d'autant
plus fiers qu'il s'agit de la premi�re traduction d'un RPG PSX exclusif
:)

Alors, voyons voir ce que contient ce dossier compress�:
- pe-patch.paq  le patch en lui-m�me
- readme.txt    le fichier que vous lisez

Vous allez avoir besoin de CD-Tool ou de LuaPatcher pour utiliser ce
patch, CD-Tool �tant un logiciel linux, et LuaPatcher son interface
Windows. Vous trouverez ces deux fichiers dans la partie t�l�chargement
du site de rpgplayer.

Vous trouverez les instructions d'utilisation � la fin de ce document.

REMARQUE TRES IMPORTANTE: ce patch ne marche QUE sur la version
am�ricaine de Parasite Eve. Il faut patienter un peu le temps que le
patch soit adapt� pour la version japonaise. Merci � Sandro05 pour nous
avoir donn� un coup de main pour nous procurer cette version.


--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~LE JEU EN LUI-M�ME~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--------------------------------------------------------------------------

Parasite Eve est la premi�re tentative de Rpg de SquareSoft � la sauce
Survival, sorti le 9 Septembre 1998. Un jeu tr�s controvers� � sa sortie
qui ne re�ut pas les �loges de la presse sp�cialis�e, et qui fut per�u
comme un jeu moyen compar� � ce qui se faisait et se pr�parait �
l'�poque (FFVIII en l'occurence, car PE contenait la d�mo de ce
dernier). N�anmoins l'impact sur les joueurs fut diff�rent, et bon
nombre d'entres eux ont trouv� que PE �tait au contraire dot� d'un petit
on-ne-sait-quoi qui le diff�renciait des autres, peut-�tre �tait-ce d� �
son sc�nario original, ses personnages charismatiques et son aspect
'film'...

LE SCENARIO

Non non, ne partez pas! Je n'ai pas l'intention de vous spoiler le
sc�nario, mais simplement le survoler globalement :) Ce qu'il faut
savoir est que Parasite Eve (le jeu) est la suite d'un film du m�me nom
sorti uniquement au Japon en 1997, produit par la Gainax(!), avec pour
compositeur Joe Hisaishi (!). Je ne peux que vous conseiller de voir le
film, apr�s avoir essay� le jeu, (sous peine de vous spoiler le jeu^^),
m�me si ce n'est pas du grand art, le film est assez sympatoche � voir
(idem que le jeu, la presse dit le contraire :-D).

Bref! Le jeu commence � Manhattan quelques ann�es apr�s les incidents
qui s'�taient d�roul�s au Japon. Aya, Inspecteur de Police de New-York
se rend � la l'Op�ra du Carnegie Hall pour assister � une repr�sentation
pour Christmas Eve (la Veille de No�l aux USA). La soir�e se pr�sente
bien, jusqu'au moment o�, tout le monde commence � prendre feu les uns
apr�s les autres dans la salle bond�e. Tout le monde est pris de panique
et tente de fuir tant bien que mal. Seules Aya et la myst�rieuse
cantatrice restent indemnes. Cette derni�re va tenir des propos �tranges
et troublants pour Aya, qui va d�couvrir les pouvoirs qui sont en elle.
Aid�e de son co�quipier Daniel, puis d'un scientifique Japonais, Maeda,
qui d�tient des r�v�lations importantes sur ce m�me incident au Japon,
elle va se mettre � la poursuite de cette jeune femme... Eve. Elle seule
peut l'emp�cher de d�truire l'humanit�.

Je vous souhaite de (re)d�couvrir ce jeu g�nial! Bon jeu!

--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~~LA TRADUCTION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--------------------------------------------------------------------------

- Les deux tar�s : 
------------------

ToraKami: torakami@free.fr
C'est moooooooooooi! :D La traduction de PE remonte � tr�s tr�s
longtemps, en 2000 pour �tre pr�cis :) Ca faisait d�j� deux ans que
j'avais un site d'�mulation et je venais de d�couvrir la traduction de
l'un de mes jeux pr�f�r�s par un certain groupe ^^ J'ai donc eu envie de
laisser tomber l'�mulation pour me lancer dans la traduction. J'avais un
bon niveau d'anglais, j'en avais fait mes �tudes etc... Mes services
furent refus�s par le groupe en question, du coup, j'ai eu envie
d'innover et de commencer une traduction sur PSX... Mais n'ayant pas les
comp�tences 'techniques' (hacking) pour �a, je me suis 'amus�' � relever
tous les textes � la main sur papier avant de les taper sous Word ;)
Deux semaines plus tard, la traduction de PE �tait t�l�chargeable en
html sur mon site "Rpgplayer". Entre temps, je me suis mis � faire la
m�me chose pour Chrono Cross, que j'ai fini de la m�me mani�re, 14 mois
plus tard et j'ai encha�n� sur Grandia 2... Puis il y eut pas mal de
changements entre temps, Yaz0r s'est joint � moi pour Chrono Cross, et
Pixel a suivi quelques mois plus tard pour Parasite Eve. C'est un grand
honneur que d'avoir pu b�n�ficier de leur savoir-faire, et j'esp�re
encore aujourd'hui pouvoir �tre � la hauteur de leur travail. Je n'ai,
et je n'aurai jamais, la pr�tention de pouvoir affirmer que mon travail
est g�nial, surtout compar� aux grandes 'figures' du monde de la
traduction "amateur" (qui entre-nous est parfois meilleure que celle
dite professionnelle...). Je vous laisse tous seuls juges. En bref,
merci � tous de jouer � cette traduction, je r�alise enfin mon but
premier; pouvoir partager une passion de 16 ans maintenant, celle du jeu
vid�o et d'avoir pu contribuer de fa�on 'active' en apportant ma pierre
� l'�difice. Bon, je m'arr�te l�, m�me si �a fait quelque chose de voir
aboutir ses heures incalculables de travail. Allez, je vous laisse
tranquille! (Que voulez-vous j'adore �crire. :P ) Jouez-bien, et on se
retrouve bient�t pour Chrono Cross! :)

Pixel : pixel@nobis-crew.org
Bon, je lui donne la parole, mais il sera s�rement moins bavard que moi :P

 "Mais si j'ai des choses � dire.
  
  Tout d'abord, que je suis extr�mement content de la sortie de ce
  patch. C'est la premi�re fois qu'aboutit mon travail dans le domaine
  de la traduction. J'esp�re bien que ce n'est pas la derni�re fois ;-)

  J'avais commenc� � regarder Parasite Eve comme une sorte de
  distraction au d�part. Mais rapidement, je me suis rendu compte que ce
  hack serait loin d'�tre simple � r�aliser. J'avais abandonn� lorsque,
  � force de me faire harceler de tous les cot�s, j'ai pouss� mon
  travail � fond sur ce projet. Ca m'a permis de faire �norm�ment de
  progr�s dans le domaine du hacking PSX en g�n�ral, (ce qui est d�j�
  tr�s b�n�fique) et de faire plaisir � un ami tr�s cher.
  
  J'ai pass� de longues heures et plusieures nuit blanches � tenter
  d'analyser ce jeu, tournant et retournant les informations qui �taient
  devant mes yeux dans tous les sens. J'ai fini par r�ussir � trouver la
  quasi totalit� des choses � modifier dans ce jeu (voire un peu plus,
  ce qui a beaucoup aid� aux tests du jeu)
  
  De plus, au d�but, j'avais fait des bidouilles bien moches et bien
  rapides pour ins�rer le texte. Seulement, c'�tait pas suffisant:
  ToraKami a r�ussi � d�passer l'espace que mes bidouilles avaient
  lib�r�. Ce qui m'a caus� encore plus de tracas: il m'a fallu
  programmer un (tr�s) gros logiciel de patch de jeu PSX, ce qui m'a
  valu encore plus d'heures de travail et de nuit blanches.
  
  Au final, j'ai pass� beaucoup beaucoup beaucoup plus de temps sur
  Parasite Eve que je ne l'aurais pens� au d�part. Mais de ce fait, je
  me suis vraiment investi dans ce projet, et je pense avoir r�ussi �
  produire un patch d'une qualit� acceptable. J'esp�re en tout cas de
  tout coeur que vous appr�cierez."


TRADUIT / PAS TRADUIT / INFORMATIONS TECHNIQUES (BUGS) :
--------------------------------------------------------

Toutes les choses suivantes sont traduites; �cran de publication, �cran
titre, les textes principaux et secondaires, les menus (non graphiques),
les descriptifs, les objets, les combats, et la carte.

Il y a par contre divers petits ic�nes en anglais qui ne sont pas
traduits.

Et voici le petit 'hic' de cette traduction: il y a quelques petites
choses qui n'ont pas pu encore �tre traduites. En premier lieu, il y a 
quelques images statiques, comme le tutorial, ou les noms des jours. Il
s'agit en effet des images de fond du jeu, et sont stock�es suivant un
format relativement incompr�hensible. Ensuite, la vid�o d'intro n'est
pas traduite. Dessus se trouvent les noms des jours, et une petite
phrase: "The worst foe lies within the self". Pour le moment, nous
allons laisser les traductions de ces �l�ments dans le fichier
divers.htm que vous trouverez sur le CD une fois patch� et/ou sur
le site de RPG-T.

Point de vue technique, les sauvegardes anglaises ne marcheront pas sur
cette version fran�aise. Ceci � cause de gros changements dans tout le
programme du jeu.


ANECDOTES :
-----------

Les petites anecdotes de cette traduction concernent surtout les
magnifiques contre-sens que contiennent la version US. Je me suis amus�
� en corriger un maximum sans perdre le fil du sc�nario, fort
heureusement, parce que c'�tait carr�ment abusif � ce niveau l� (et
je ne compte pas les erreurs de sc�nario par rapport au film...) Mais
bon, la version fran�aise corrigera une bonne partie de tout �a ;)

Parmi les plus "amusantes", voici celles que j'ai retenues :

Au tout d�but du jeu, donc, tout le monde prend feu � cause d'Eve... Une
grande partie du public s'enfuit tant bien que mal, ainsi que le
"petit-ami" d'Aya qu'elle fait �vacuer � coup de coude (d'ailleurs,
lui reste avec Aya, et ne prend pas feu, �a commence bien ;) Bref...
Durant tout le jeu, en US, tout le monde parle d'Aya comme 'the only
survivor', soit la seule survivante. Donc, on peut se dire, "ok...
personne n'a surv�cu sauf elle, on aurait pu croire que non, mais bon
s'ils le disent...". Mais non! Parce que juste avant, Daniel dit que
des gens ont vu son petit-ami s'enfuir, donc il est pas mort! Ca c'est
le premier point, et le second, c'est un autre policier qui dit qu'un
grand nombre de br�l�s sont � l'h�pital et que certains vont mourir,
et... par d�duction, d'autres non :P Je me suis pench� sur la question
du 'comment ont-ils pu faire un contre-sens aussi minable en US?'...
Facile en fin de compte... Dans la version jap, Aya n'est pas la seule
'survivante', mais celle qui a surv�cu sans aucune blessure/br�lure,
tout ce que vous voulez... C'est donc 'une miracul�e', en quelque sorte.
Voil�, o� �a voulait en venir. En plus, le mot convient tr�s bien pour
l'effet 'sensas' des journalistes, et pour l'aspect un peu myst�rieux...
bref, le pb �tait r�gl� ;)

Deuxi�me ENORME contre-sens qui g�che au plaisir du jeu US, vient de ce
cher Wayne � l'armurerie... qui... comment dire... raconte un peu tout
et son contraire :D C'�tait assez dr�le, m�me si �a m'a donn� la naus�e
en lisant �a ;) Une fois qu'il prend le poste de chef de l'armurerie, il
dit � Aya qu'� pr�sent il prend les commandes en mains et que les
autorisations et tout �a, c'est termin�, mais qu'il "aimerait bien" des
cartes de collection de temps � autre! L�, on se dit... chouette, on va
pouvoir modifier ses armes � gogo! H���������� non! Parce que, quand on
lui reparle peu apr�s, qu'est-ce qu'il nous sort ce cher Wayne?? "Il te
faut une autorisation ou une Carte!"... Et l�... On pleure :D Idem, j'ai
tourn� ces phrases de fa�on, � ce qu'on se fasse pas de fausse joie :P

Il y a d'autres "incoh�rences" tout au long du jeu. (Attention spoiler).
Style, pourquoi le clown dans les loges n'a-t-il pas cram� comme les
autres figurants? Bon ok, il prend feu apr�s avoir rencontr� Aya, mais
c'est pas une raison :D

Ensuite il y a la sc�ne o� l'on d�couvre Maeda... Il y a trois flics, et
lui. L'un d'eux prend feu... Et les auuuuutres, pourquoi ils crament
pas? Et Maeda qui s'enfonce dans la rue justement barricad�e pour cette
raison, idem... Enfin bref... Chacun peut s'inventer une version comme
�a ;)

--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~INFOS ET REMERCIEMENTS~~~~~~~~~~~~~~~~~~~~~~~~~~
--------------------------------------------------------------------------

Remerciements :
---------------

Tout d'abord, je tiens � remercier GreatSkaori pour avoir enquiquin�
Pixel jusqu'� ce qu'il craque � faire ce hack de Parasite Eve. Sans lui
cette grosse larve n'aurait encore rien commenc� ;) Je ne sais pas ce
que GreatSkaori lui a fait pour qu'il s'y mette, mais �a a march�...
(Non, nous ne parlerons pas de la chaude nuit � l'h�tel lors du
Cartoonist, ni de la nuit pass�e chez lui ^^). En tout cas, merci mon
vieux, tes sacrifices n'auront pas �t� vains. Vous retrouverez aussi sa
'patte' dans quelques phrases de Parasite Eve que j'ai gard� de la
premi�re traduction papier.

Niark niark, merci aussi � ma chtite puce, Esper, pour �tre repass�e
derri�re moi afin de tuer les derni�res fautes (de frappes �videmment!)
et pour m'avoir tap� sur les doigts pour mes "incoh�rences
scientifiques" (au moins j'aurais retenu que les "nucleus" ne sont pas
des nucl�ons, mais des noyaux de cellules, de m�me que "organelle" en
anglais donne le m�me mot en fran�ais :P ). Bref, merci aussi pour ton
soutien, c'est pour �a que je t'aime ;)

Je tiens �galement � remercier Aurette pour avoir effectu� le meilleur
b�ta-test de Parasite Eve. Gr�ce � elle les derni�res fautes ont �t�
purement et simplement �radiqu�es.

Merci �galement aux autres b�ta-testeurs, ainsi qu'� ceux qui se sont
barr�s avec le patch b�ta sans plus donner signe de vie ;-) Tant pis
pour eux s'ils ont gach� des CD's avec cette version bugg�e ^^

Infos :
-------

Voici les explications sur l'utilisation de ce patch. Ce patch
fonctionne sur un principe cr�� pour l'occasion. Il faut donc des
logiciels sp�ciaux pour utiliser ce patch. Le logiciel de base est
CD-Tool, qui est disponible uniquement pour linux, et une interface
windows bas�e autour de CD-Tool a �t� cr��, appel�e LuaPatcher. Ces deux
logiciels sont disponible en t�l�chargement sur le site de rpgplayer.

CD-Tool fonctionne en cr�eant une image "iso" de toutes pi�ces. Il va
utiliser soit le CD original du jeu, soit une image iso. Sous windows,
la lecture du CD ne marche qu'avec Windows 2000/XP, et encore, il a �t�
rapport� que des erreurs �taient apparemment possibles.

Remarque importante: CD-Tool ne supporte que des images iso en "mode
raw-2352". En clair, les images iso produites par le logiciel CDRWin (le
gros fichier .bin), le logiciel Clone CD (le gros fichier .img), ou le
logiciel gratuit IsoBuster (faire "extract raw" sur le CD).

Et bien �videmment, l'image ISO produite sera aussi en mode raw-2352,
que vous pouvez graver avec beaucoup de logiciels, comme Nero, convertir
avec cdmage, ou utiliser directement dans ePSXe, voire Daemon Tool. Si
vous avez besoin (et que vous avez la flemme d'utiliser cdmage), vous
pouvez faire le fichier "cue" correspondant, en prenant simplement le
notepad et en �crivant:

FILE "FICHIER.BIN" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
      
en rempla�ant FICHIER.BIN par le nom de fichier iso que vous avez mis en
destination. Cela vous permettra de graver l'image iso avec encore plus
de logiciels, comme CDRWin, ou CloneCD sous windows, et cdrdao, ou
cdrecord sous linux.

Pour patcher:

Le patch fonctionne indif�remment sur le CD1 ou le CD2 du jeu. Il
identifie automatiquement le CD, et effectue son travail.

Si vous utilisez windows, vous avez le logiciel LuaPatcher qui
fonctionne de mani�re tr�s simple. Vous sp�cifiez la source (soit le
lecteur CD, soit une image iso) l'image iso de destination, et le
fichier .paq du patch. Vous faites "Ok" et vous patientez jusqu'� la fin
du processus.

Si vous utilisez linux, il vous faut utiliser CD-Tool, et voil� la
syntaxe � utiliser:

  cd-tool -v -a pe-patch.paq <source> luapatch main <destination>

en rempla�ant "<source>" par l'image iso source, ou bien le texte
"CD:xx" comme j'explique au dessous, et "<destination>" par l'image iso
de destination. Attention: ne mettez surtout pas le m�me fichier source
et destination.

Si vous voulez lire depuis le lecteur cd, mettons, le device /dev/cdrom,
alors en tant qu'image source, sp�cifiez "CD:/dev/cdrom".

L�gal :
-------

Cette traduction et ce patch est la propri�t� de Rpg-T. Vous pouvez
distribuer librement l'archive du patch, sur quelque support que ce
soit, tant que vous conservez l'archive telle quelle. En revanche, un
petit message par e-mail pour informer de la distribution de notre patch
sera le bienvenu ;-) Parasite Eve, le jeu, est (C) SquareSoft. Si vous
voulez utiliser ce patch, vous devez le faire sur l'original du jeu, que
vous obtiendrez dans des boutiques d'import. Ne faites pas de copies
ill�gales. L'utilisation de ce patch et du programme associ� demeure �
vos risques et p�rils.

Divers :
--------

Tous vos commentaires sont les bienvenus sur les forums de notre petite
communaut� :

http://forum.bessab.net/

--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~PROJETS A VENIR~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--------------------------------------------------------------------------

Voici quelques projets PSX � venir chez les diff�rents groupes! 


Chrono Cross       (http://rpgplayer.uhrft.org) (hack: Yaz0r / trad: ToraKami)
XenoGears          (http://dem.nobis-crew.org)
Legend of Mana     (http://generation9.uhrft.org / http://finaltranslation.uhrft.org)
Tales of Destiny (http://generation9.uhrft.org / http://finaltranslation.uhrft.org)
Threads of Fate    (http://terminus.romhack.net)

--------------------------------------------------------------------------

Merci � vous d'avoir lu ce fichier jusqu'au bout, m�me si c'�tait plus
que barbant ;)


Guillaume 'ToraKami' Moerman - torakami@free.fr
Nicolas 'Pixel' Noble - pixel@nobis-crew.org
