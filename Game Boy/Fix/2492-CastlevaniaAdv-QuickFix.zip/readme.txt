Use with:

(No Intro)
File:               Castlevania - The Adventure (USA).gb
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              216E6AA1
MD5:                0B4410C6B94D6359DBA5609AE9A32909
SHA1:               FD9116EFCD8EB9698F483CC5745F83B3674D7D13
SHA256:             EDB101E924F22149BDCBCFE6603801FDB4EC0139A40493D700FA0205F6DAB30C