Use with:

No-Intro
Wario Land - Super Mario Land 3 (World).gb 
d9d957771484ef846d4e8d241f6f2815
40BE3889