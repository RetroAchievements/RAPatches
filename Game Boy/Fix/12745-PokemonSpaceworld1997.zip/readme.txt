Use with:

(No Intro)
File:               Pocket Monsters Gin (Japan) (Demo) (Spaceworld 1997) (SGB Enhanced) (Debug).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              2C5732DB
MD5:                FA65D3759BB17C489DE171A598BA4913

File:               Pocket Monsters Gin (Japan) (Demo) (Spaceworld 1997) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7246170A
MD5:                C52A677C35F15320D5B495E14809F00D

File:               Pocket Monsters Kin (Japan) (Demo) (Spaceworld 1997) (SGB Enhanced) (Debug).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              C2CA5626
MD5:                2EADBED83B775C097FF79E5128D1184F

File:               Pocket Monsters Kin (Japan) (Demo) (Spaceworld 1997) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              ABEDD2BF
MD5:                3C407114DE28D17B7113A2C0CEE9A37C
