Use with:

File:               Mole Mania (USA, Europe) (SGB Enhanced).gb (No-Intro)
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              2C36C74C
MD5:                F28ADE3926852A8AD2E449C274683956