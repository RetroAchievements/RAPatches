Use with:

File:               Final Fantasy Adventure (USA).gb (NoIntro)
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              18C78B3A
MD5:                24CD3BDF490EF2E1AA6A8AF380ECCD78