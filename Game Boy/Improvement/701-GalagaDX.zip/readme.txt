Use with:

(No Intro)
File:               Arcade Classic No. 3 - Galaga & Galaxian (USA) (SGB Enhanced).gb
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              6A6ECFEC
MD5:                19FD29EFAF7EA9E314BD613954A92169
SHA1:               739671D6CF151FA5527D68F78345197D278CDF19
SHA256:             5775ABA89EEA82BB2A3095E8590E7C552E458C93B6403DD985E3B3E646F190AB