Use with:
Asterix (Europe) (En,Fr,De,Es,It).gb (No-Intro)
812db832566202610bb1e42e643e2b93
097FFE2C