Use with:

No Intro
Super Robot Taisen (Japan).gb
7BB8A5BC9E55A05EBA1A3FCBF460A9B5
7DD9D7D6
