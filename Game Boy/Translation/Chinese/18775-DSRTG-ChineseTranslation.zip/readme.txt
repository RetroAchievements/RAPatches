Use with:

No Intro
Dai-2-ji Super Robot Taisen G (Japan) (SGB Enhanced).gb
24f96821369540f25dc3768053569029
DF8B2B20
