Use with:

(No Intro)
File:               Medarot - Kuwagata Version (Japan) (Rev 1) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              5E77E82E
MD5:                A9C9D6B6759C28F2B3986717F4DF2F98
SHA1:               2262F69A89ABE0F66DC1554C1EE470FD536130A3
SHA256:             19762A746F413714810C12ED41DDF0B09EE4A7EB538F6C820A6B9EFA0B7DBE1A