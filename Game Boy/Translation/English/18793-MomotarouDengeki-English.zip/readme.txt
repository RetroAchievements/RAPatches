Use with:

Momotarou Dengeki (Japan).gb
f31c556186b91cf161ecf60644fbecba
F09B34AB