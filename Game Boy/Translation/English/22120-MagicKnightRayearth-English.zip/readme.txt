﻿Use with:

(No Intro)
File:               Magic Knight Rayearth (Japan) (SGB Enhanced).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              94838A81
MD5:                06B75E657DEBD1568F18D369CC2422DD
SHA1:               4F77031946E62772A241A9B5B046D7FCF6A28EA8
SHA256:             3BE897438E69A22C64BE12AB1D5ED41F9F35A54E40A1CE909F9FE080734D7FA4