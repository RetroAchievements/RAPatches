Use with:
No Intro
Ultraman Chou Toushi Gekiden (Japan) (SGB Enhanced).gb
9be2b2635bd25b97a7599ab1df84a49a
b904230d