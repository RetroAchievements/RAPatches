Use with:

(Lost Level) (Itch.io)
File:               Senshijidaino kyoryu - DINOPREHIS! (World) (1997 Beta) (En) (v1.0) (AgamemnonGaming).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              DEB7337F
MD5:                7936B12937A175ABB39E199C9FEED508
SHA1:               25A10F54915C9CBA0D9E0E496FC27E7700734D7B
SHA256:             0AF1DE9F08B8B065D95E4AD7EDB95F52F82851AB4F26CDD9BA327ADE9BD70D5C

https://saltcake-official.itch.io/beta-de-1997-de-senshijidaino-kyry-dinoprehs