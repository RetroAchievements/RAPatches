Use with:

File:               Animal Breeder (Japan) (SGB Enhanced).gb (No Intro)
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              C2EEC22F
MD5:                54CEAD768696A61B7CD31F91C0C58021