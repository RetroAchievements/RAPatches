Use with:

(No Intro)
File:               Ultraman Ball (Japan) (SGB Enhanced).gb
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              468D1A2E
MD5:                90A0BC783FBE56748989D8FAD9AE48ED