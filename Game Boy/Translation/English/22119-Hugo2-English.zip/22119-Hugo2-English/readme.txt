Use with:
Hugo 2 (Germany).gb (No-Intro)
bf9334b9c902510cd9fe39af82b4b465
