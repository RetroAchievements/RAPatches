Use with:

(No Intro)
File:               Medarot - Kabuto Version (Japan) (Rev 1) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              12A3982D
MD5:                78C568CBFFF6314B1416880D9EFAECA6
SHA1:               1CBC7AB5941DC27BC50699A00EF2B1BEB930449D
SHA256:             3EE50992A8CDE0C1E7BB2BF1D812BF3D9577CD1F0C3DA0C072D52806B5A774EC