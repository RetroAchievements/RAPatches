Use with:

(No Intro)
File:               Downtown Special - Kunio-kun no Jidaigeki Da yo Zenin Shuugou! (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              229E9113
MD5:                4ED480F8974E938C01BE3B410EBEC3DF
SHA1:               97FF2392F126B195AC8A1700A9A91AA364549DFD
SHA256:             8FA401D71FA6D6B02773A72DD1EEA55B866ABB3E94F6644B57616C3E30CF05D4