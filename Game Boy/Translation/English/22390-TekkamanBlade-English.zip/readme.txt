use with:
Uchuu no Kishi Tekkaman Blade (Japan)
801548B89F31101653539988D7635DBA
22D8889E