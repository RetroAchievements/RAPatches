Use with:

(No Intro)
File:               Little Master - Raikuban no Densetsu (Japan).gb
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              31CD9670
MD5:                DE95D425F6A2836960F4EE2A9AA2F6F7
SHA1:               7C83B3C6CD9571C422E66E64E522A0416FA477B2
SHA256:             FD6EDEEC30256152846FB0BF00AF65D74E3E523B621AE8D575A391202DA61CDB