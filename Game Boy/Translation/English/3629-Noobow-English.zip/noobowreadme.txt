Use with:

(No Intro)
File:               Noobow (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              8BBCC8BB
MD5:                CCD0CF7CC240714A9694E1FE296AFB7C