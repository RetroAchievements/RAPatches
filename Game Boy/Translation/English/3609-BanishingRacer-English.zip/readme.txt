Use with:

(No-Intro)
Banishing Racer (Japan).gb
8fdffb08770609255ec3cd314f79f976
3D13EC6A