Use with:

(No Intro)
File:               Dragon Ball Z - Gokuu Hishouden (Japan) (SGB Enhanced).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              38DA46D7
MD5:                3D4537F6A0542F781E408BD5440D23DD
SHA1:               6BF8F3400BF323EDECC2152C4A86F6B0CAE628FE
SHA256:             F63B95B5B03C399B8546E5F72004A2EBAF2E2826FA83A76705B2629BD4DA817F