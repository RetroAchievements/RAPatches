Use with:

(No Intro)
File:               Undercover Cops Gaiden - Hakaishin Garumaa (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              B7AF37F5
MD5:                5294A5FED7E88A6F76707979C83017D6
SHA1:               E391EA099CE371EEF858D57E6C2DA63A25944472
SHA256:             7B9C17C0DFB67EEDDF7A4895689BBAD17DB802A7A735C58BCD740668F941B7EB