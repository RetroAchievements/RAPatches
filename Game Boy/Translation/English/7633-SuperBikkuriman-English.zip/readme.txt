Use with:

(No Intro)
File:               Super Bikkuriman - Densetsu no Sekiban (Japan).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              C1E1A041
MD5:                42F06D0E5FA65BF245F52249385B94A6
SHA1:               B7DAC857947FCE1069145A1F5D560C26AA3C8F42
SHA256:             18BA846B172E5C63F3E79DFBAB84F11F204E403DD436137CFAC3B13B47051A60