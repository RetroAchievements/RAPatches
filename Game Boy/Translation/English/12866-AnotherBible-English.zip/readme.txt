Use with:

(No Intro)
File:               Another Bible (Japan) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              4A486435
MD5:                FF9196CAA266AE36D409CE7E53DDC77A
SHA1:               6A5D0DA889247169135665DC91F153305E1C71B6
SHA256:             6BED3341D31078B04FAF22554804214992127E93B32C342359F44DD8F558B87E