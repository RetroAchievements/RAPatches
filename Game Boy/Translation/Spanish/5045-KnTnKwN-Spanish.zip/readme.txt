Use with:
Kaeru no Tame ni Kane wa Naru (Japan).gb (No-Intro)
4ebe14c4c51555908c0e4cabb66dc813
C18CD57A