Use with:

(No Intro)
Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
3d45c1ee9abd5738df46d2bdda8b57dc
9F7FDD53

Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
50927E843568814F7ED45EC4F944BD8B
D6DA8A1A
