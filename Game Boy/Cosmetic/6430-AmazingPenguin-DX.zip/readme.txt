Use with:

File:               Amazing Penguin (USA, Europe).gb (No-Intro)
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              3011D5CA
MD5:                D8326BFEE457CCB2C0AFB8DD6AC11DB2