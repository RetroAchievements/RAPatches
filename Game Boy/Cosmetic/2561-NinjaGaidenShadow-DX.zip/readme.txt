Use with:

File:               Ninja Gaiden Shadow (USA).gb (No-Intro)
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              D3741A3A
MD5:                E12C5C2897ED095F8D26C7578AFDDFDA