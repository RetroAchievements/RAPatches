Use with:

(No Intro)
File:               Snoopy - Magic Show (Japan) (En).gb
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              4892984D
MD5:                3D8F6ECCC13F3344C8D971B7E141F064
SHA1:               07BF2DD8C1BEBD40A63FB571C587F0E77286C6A0
SHA256:             11D1C9001E3A6DAACB5DD12F39B8E0B23335673C4B8A99769F85F9DC3BF7A2E3