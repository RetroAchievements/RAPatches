Snoopy -  Magic Show DX
=======================

No one asked for it, for here it goes!
Snoopy's Magic Show is a total classic for the DMG, a very simple yet addictive single-screen arcade now in full color!



Patching information
--------------------
You must provide the original japanese Snoopy Magic Show ROM:
Snoopy - Magic Show (Japan)
CRC32: 4892984d
MD5:   3d8f6eccc13f3344c8d971b7e141f064
SHA-1: 07bf2dd8c1bebd40a63fb571c587f0e77286c6a0

Apply the patch here: https://www.romhacking.net/patch/


Patch history
-------------
v1.0 (2022-03-10) - first version






Credits
-------
Jorge2D - palette choices
marc_max - reverse engineering & hacking
