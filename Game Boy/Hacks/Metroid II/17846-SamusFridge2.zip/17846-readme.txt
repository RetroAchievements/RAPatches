Use with:

Metroid II - Return of Samus (World).gb (No-Intro)
9639948ad274fa15281f549e5f9c4d87
DEE05370
