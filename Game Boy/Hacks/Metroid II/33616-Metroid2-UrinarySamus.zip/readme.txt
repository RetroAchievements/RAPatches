Use with:

(No Intro)
File:               Metroid II - Return of Samus (World).gb
BitSize:            2 Mbit
Size (Bytes):       262144
CRC32:              DEE05370
MD5:                9639948AD274FA15281F549E5F9C4D87
SHA1:               74A2FAD86B9A4C013149B1E214BC4600EFB1066D
SHA256:             3080BCC2EB9965DE463F5F4E02F0DABBB13B060E1654A18DA8B50948C10AF4A6