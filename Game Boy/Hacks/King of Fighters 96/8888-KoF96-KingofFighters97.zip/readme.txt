Use with:

(No Intro)
File:               King of Fighters, The - Heat of Battle (Europe) (SGB Enhanced).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              4D2D8BC3
MD5:                CF6EC3C13CD20240EF0C0C63EC06558F
SHA1:               1B5AC034B1333B3340FBDC5C128BC12ABD310043
SHA256:             4CCECAA47B975DEDD502E9BFBFF6E2F4F8884148A4456D89016A2950F6B2EAE7