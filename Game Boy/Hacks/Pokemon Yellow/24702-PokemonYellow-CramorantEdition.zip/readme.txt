Use with:

(No Intro)
File:               Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              7D527D62
MD5:                D9290DB87B1F0A23B89F99EE4469E34B
SHA1:               CC7D03262EBFAF2F06772C1A480C7D9D5F4A38E1
SHA256:             8CBAA499397E4F1A679C992EA9382A2DD7942AB398B48C19829C2D9529DE47BF