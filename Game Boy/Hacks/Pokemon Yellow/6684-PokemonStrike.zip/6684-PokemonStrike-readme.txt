Use with:

Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (GBC,SGB Enhanced).gb (No-Intro)
d9290db87b1f0a23b89f99ee4469e34b
7D527D62
