Use with:

(No-Intro)
File:               Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
Size (Bytes):       1048576
CRC32:              7d527d62
MD5:                d9290db87b1f0a23b89f99ee4469e34b
SHA1:               cc7d03262ebfaf2f06772c1a480c7d9d5f4a38e1