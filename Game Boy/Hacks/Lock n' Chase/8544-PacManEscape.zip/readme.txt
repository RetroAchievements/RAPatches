Use with:

(No Intro)
File:               Lock n' Chase ~ Lock 'n' Chase (World).gb
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              DAB91C7A
MD5:                8BB31F539E8999D5C4E9449FE1BEFAD6
SHA1:               643CBD566D35CE8DBE0F24627E4862C09805A04C
SHA256:             0D6C56DA2FDB6B27D388912604AD97C2F71729604A075D76C1FCD923F29E6915