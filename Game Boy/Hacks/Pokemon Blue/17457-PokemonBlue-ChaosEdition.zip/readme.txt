Use with:

(No Intro)
File:               Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D6DA8A1A
MD5:                50927E843568814F7ED45EC4F944BD8B