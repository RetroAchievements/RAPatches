Use with:

(No-Intro)
File:               Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
Size (Bytes):       1048576
CRC32:              d6da8a1a
MD5:                50927e843568814f7ed45ec4f944bd8b
SHA1:               d7037c83e1ae5b39bde3c30787637ba1d4c48ce2