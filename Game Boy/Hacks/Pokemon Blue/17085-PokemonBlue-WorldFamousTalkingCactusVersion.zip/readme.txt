Use with:

(No Intro)
File:               Pokemon - Blue Version (USA, Europe) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D6DA8A1A
MD5:                50927E843568814F7ED45EC4F944BD8B
SHA1:               D7037C83E1AE5B39BDE3C30787637BA1D4C48CE2
SHA256:             2A951313C2640E8C2CB21F25D1DB019AE6245D9C7121F754FA61AFD7BEE6452D