Use with:

(No-Intro)
File:               Donkey Kong (Japan, USA) (En) (SGB Enhanced).gb
Size (Bytes):       524288
CRC32:              edab3378
MD5:                60e55697da19bb160316ec290a7a7437
SHA1:               6ed661bd1d6d8cdd48e1c10f8ca4e8dcba49128e