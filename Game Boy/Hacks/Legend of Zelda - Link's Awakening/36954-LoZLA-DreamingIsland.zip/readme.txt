Use with:

(No-Intro)
File:               Legend of Zelda, The - Link's Awakening (USA, Europe).gb
BitSize:            4 Mbit
Size (Bytes):       524288
CRC32:              8CF27C90
MD5:                C4360F89E2B09A21307FE864258ECAB7
SHA1:               602167F897B4F56FE8CEE837933DA3BED5882BBD
SHA256:             21F712E213F43F9EFB93CA039A5190FC09325D5D932AF1FB2F8E90B4F9FD169F