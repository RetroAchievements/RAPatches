Use with:

(No Intro)
File:               Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              9F7FDD53
MD5:                3D45C1EE9ABD5738DF46D2BDDA8B57DC
SHA1:               EA9BCAE617FDF159B045185467AE58B2E4A48B9A
SHA256:             5CA7BA01642A3B27B0CC0B5349B52792795B62D3ED977E98A09390659AF96B7B