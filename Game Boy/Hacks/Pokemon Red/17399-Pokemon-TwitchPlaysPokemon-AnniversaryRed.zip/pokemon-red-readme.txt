Use with:

(No Intro)
File:               Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              9F7FDD53
MD5:                3D45C1EE9ABD5738DF46D2BDDA8B57DC