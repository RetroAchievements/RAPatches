Use with:

(No-Intro)
File:               Pokemon - Red Version (USA, Europe) (SGB Enhanced).gb
Size (Bytes):       1048576
CRC32:              9f7fdd53
MD5:                3d45c1ee9abd5738df46d2bdda8b57dc
SHA1:               ea9bcae617fdf159b045185467ae58b2e4a48b9a