Use with:

(No Intro)
File:               Super Mario Land (World) (Rev 1).gb
BitSize:            512 Kbit
Size (Bytes):       65536
CRC32:              2C27EC70
MD5:                B259FEB41811C7E4E1DC200167985C84