Use with:

(No Intro)
Pokemon - Yellow Version - Special Pikachu Edition (USA, Europe) (CGB+SGB Enhanced).gb
RA Checksum: d9290db87b1f0a23b89f99ee4469e34b
CRC32 Checksum: 7D527D62