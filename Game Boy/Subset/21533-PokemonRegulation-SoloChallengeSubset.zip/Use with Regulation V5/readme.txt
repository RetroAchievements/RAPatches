Use with:

(No Intro + RAPatches)
Pokemon - Blue Version (USA, Europe) (SGB Enhanced) (Regulation) (v5.0) (Rubicate).gb
6648b03c50228b9c343ad06183b6b9cc

Pokemon - Red Version (USA, Europe) (SGB Enhanced) (Regulation) (v5.0) (Rubicate).gb  
b84debc3304a4fec5eb72f7e4d1ae8a6