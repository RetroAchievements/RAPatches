Use with:

[No Intro]
[Dark Tower (1983) (Prototype).vec]
[db9929b0ad53c97afda065596806bf86]
[9DCFD5B7]